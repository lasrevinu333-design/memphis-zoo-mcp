// External disposable fixture construction only. No import by product code.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer,createConnection,isIP} from 'node:net';
import {createHash,createHmac,randomBytes} from 'node:crypto';
const IMAGE='public.ecr.aws/supabase/storage-api@sha256:528ec49c3c32561908b07ee91bced7f8456f3b688164e341eaa422441767a0bd';
const hash=x=>createHash('sha256').update(x).digest('hex');
const stable=x=>JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function sourceDenialRefuse(){throw new Error('Pinned official Storage denial tuple refused');}
// Pinned official1.70.3 legacy error wire: HTTP400 can encode a precise
// NoSuchKey404 or malformed-JWT AccessDenied403. Never accept generic400.
function validateFreshLocalStorageDeniedResponse(status, raw, kind) {
  if(status!==400 || !Buffer.isBuffer(raw) || raw.length>4096 || !['private-object','invalid-signature'].includes(kind))sourceDenialRefuse();
  if(!Buffer.from(raw.toString('utf8')).equals(raw))sourceDenialRefuse();
  let body;try{body=JSON.parse(raw.toString('utf8'));}catch{sourceDenialRefuse();}
  if(!body || typeof body!=='object' || Array.isArray(body) || Object.keys(body).sort().join(',')!=='code,error,message,statusCode')sourceDenialRefuse();
  const expected=kind==='private-object'
    ? {statusCode:'404',code:'NoSuchKey',error:'not_found',message:'Object not found'}
    : {statusCode:'403',code:'AccessDenied',error:'Unauthorized',message:'Invalid Compact JWS'};
  if(Object.keys(expected).some(k=>body[k]!==expected[k]))sourceDenialRefuse();
  return Object.freeze({http_status:400,semantic_status:Number(body.statusCode),code:body.code,body_sha256:hash(raw),probe_kind:kind});
}

export async function initializePrivate286OfficialStorageSource({db,container,network,networkId,bootstrap,ownerUser,out,projectRef='abcdefghijklmnopqrst'}){
  assert.match(container,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);assert.match(network,/^mz_schema_rebuild_storage_source_[a-f0-9]{20}$/);assert.match(networkId,/^[a-f0-9]{64}$/);
  assert.match(ownerUser,/^[a-f0-9-]{36}$/);assert.equal(projectRef,'abcdefghijklmnopqrst');assert.equal((await db.query('select count(*)::text n from auth.users where id=$1::uuid',[ownerUser])).rows[0].n,'1');
  // The authentic cached platform already has the empty Storage namespace.
  // Admit ONLY that exact source-derived placeholder, never existing vendor
  // objects or user DATA. The original successful signed286 pg_dump records
  // this owner/ACL even though its Storage table catalog was empty.
  const platform=(await db.query(`select n.nspname name,pg_get_userbyid(n.nspowner) owner,
    (select count(*)::int from pg_class c where c.relnamespace=n.oid) relations,
    (select count(*)::int from pg_proc p where p.pronamespace=n.oid) routines,
    (select count(*)::int from pg_type t where t.typnamespace=n.oid) types,
    (select count(*)::int from pg_operator o where o.oprnamespace=n.oid) operators,
    (select coalesce(jsonb_agg(jsonb_build_object('grantee',case when x.grantee=0 then 'PUBLIC' else pg_get_userbyid(x.grantee) end,
      'grantor',pg_get_userbyid(x.grantor),'privilege',x.privilege_type,'grantable',x.is_grantable)
      order by (case when x.grantee=0 then 'PUBLIC' else pg_get_userbyid(x.grantee) end) collate "C",x.privilege_type),'[]'::jsonb)
      from aclexplode(coalesce(n.nspacl,acldefault('n',n.nspowner))) x) acl
    from pg_namespace n where n.nspname='storage'`)).rows;
  fs.writeFileSync(path.join(out,'SOURCE_EMPTY_STORAGE_PLATFORM_PREIMAGE.json'),JSON.stringify(platform,null,2)+'\n',{mode:0o600,flag:'wx'});
  assert.equal(platform.length,1,'Exact authentic empty Storage platform namespace required');
  const expectedACL=[['anon','USAGE',false],['authenticated','USAGE',false],['dashboard_user','CREATE',false],['dashboard_user','USAGE',false],
    ['postgres','USAGE',true],['service_role','USAGE',false],['supabase_admin','CREATE',false],['supabase_admin','USAGE',false],
    ['supabase_storage_admin','CREATE',true],['supabase_storage_admin','USAGE',true]]
    .map(([grantee,privilege,grantable])=>({grantee,grantor:'supabase_admin',privilege,grantable}));
  assert.deepEqual(platform,[{name:'storage',owner:'supabase_admin',relations:0,routines:0,types:0,operators:0,acl:expectedACL}],
    'No retrofit: source platform must retain its exact original empty namespace/owner/ACL');
  // Disposable source credential setup only: original role DATA deliberately
  // excludes passwords. No attribute, membership, grant, owner or HBA change.
  assert.match(bootstrap,/^[a-f0-9]{64}$/);
  const credentialSnapshot=async()=>((await db.query(`select jsonb_build_object(
    'role',(select jsonb_build_object('oid',oid,'name',rolname,'super',rolsuper,'inherit',rolinherit,'createrole',rolcreaterole,'createdb',rolcreatedb,'login',rolcanlogin,'replication',rolreplication,'connection_limit',rolconnlimit,'valid_until',rolvaliduntil,'bypassrls',rolbypassrls,'config',rolconfig) from pg_roles where rolname='supabase_storage_admin'),
    'memberships',(select coalesce(jsonb_agg(to_jsonb(m) order by roleid,member,grantor),'[]'::jsonb) from pg_auth_members m),
    'schemas',(select coalesce(jsonb_agg(jsonb_build_array(oid,nspname,nspowner,nspacl) order by oid),'[]'::jsonb) from pg_namespace),
    'relations',(select coalesce(jsonb_agg(jsonb_build_array(oid,relowner,relacl) order by oid),'[]'::jsonb) from pg_class),
    'columns',(select coalesce(jsonb_agg(jsonb_build_array(attrelid,attnum,attacl) order by attrelid,attnum),'[]'::jsonb) from pg_attribute where attacl is not null),
    'routines',(select coalesce(jsonb_agg(jsonb_build_array(oid,proowner,proacl) order by oid),'[]'::jsonb) from pg_proc),
    'defaults',(select coalesce(jsonb_agg(to_jsonb(d) order by oid),'[]'::jsonb) from pg_default_acl d),
    'databases',(select coalesce(jsonb_agg(jsonb_build_array(oid,datdba,datacl) order by oid),'[]'::jsonb) from pg_database),
    'role_settings',(select coalesce(jsonb_agg(to_jsonb(d) order by setdatabase,setrole),'[]'::jsonb) from pg_db_role_setting d)
    ) snapshot`)).rows[0].snapshot);
  const beforeCredential=await credentialSnapshot();assert.ok(beforeCredential.role);assert.equal(beforeCredential.role.login,true);
  assert.equal((await db.query("select current_setting('log_statement') value")).rows[0].value,'none','No plaintext credential statement logging');
  // Fixed role and strict hex input; SQL literal quoting remains explicit.
  await db.query("alter role supabase_storage_admin password '"+bootstrap.replaceAll("'","''")+"'");
  const afterCredential=await credentialSnapshot();assert.deepEqual(afterCredential,beforeCredential,'Password-only source credential setup must preserve all nonsecret role/ACL/owner DATA');
  fs.writeFileSync(path.join(out,'SOURCE_STORAGE_ROLE_CREDENTIAL_NONSECRET_INVARIANCE.json'),JSON.stringify({role:'supabase_storage_admin',before:beforeCredential,after:afterCredential,only_ephemeral_password_initialized:true,plaintext_or_verifier_exported:false},null,2)+'\n',{mode:0o600,flag:'wx'});
  const started=Date.now(),deadline=started+180000,dir=fs.mkdtempSync(path.join(out,'official-source-'));fs.chmodSync(dir,0o700);
  const write=(name,value)=>fs.writeFileSync(path.join(dir,name),typeof value==='string'||Buffer.isBuffer(value)?value:JSON.stringify(value,null,2)+'\n',{mode:0o600,flag:'wx'});
  let seq=0,cid=null,first,closed=false,cleanupDeadline=null,relay=null;const relaySockets=new Set();
  const run=async(argv,seconds=20,allow=false,cleanup=false)=>{
    if(cleanup){cleanupDeadline??=Date.now()+45000;
      assert.ok(argv[0]==='inspect' && argv.at(-1)===(cid||name) || argv[0]==='rm' && argv[1]==='-f' && argv[2]===cid && /^[a-f0-9]{64}$/.test(cid||'')
        || argv[0]==='logs' && argv.slice(1).join(' ')==='--tail 80 '+cid && /^[a-f0-9]{64}$/.test(cid||'')
        || argv[0]==='ps' && argv.slice(1).join(' ')==='-aq --no-trunc --filter '+(cid?'id='+cid:'name=^/'+name+'$'),'Cleanup permits exact owned inspect/bounded failure logs/removal/absence only');}
    const remaining=(cleanup?cleanupDeadline:deadline)-Date.now();assert.ok(remaining>2000);seconds=Math.min(seconds,(remaining-2000)/1000);const prefix=String(++seq).padStart(3,'0');write(prefix+'.intent.json',{argv,work_seconds:seconds,source_initializer:true,cleanup});
    const child=spawn('/usr/bin/docker',['--host','unix:///var/run/docker.sock',...argv],{stdio:['ignore','pipe','pipe'],detached:true});
    const proc=fs.readFileSync('/proc/'+child.pid+'/stat','utf8'),fields=proc.slice(proc.lastIndexOf(')')+2).trim().split(/\s+/);write(prefix+'.owner.json',{pid:child.pid,ppid:fields[1],pgid:fields[2],start_ticks:fields[19]});
    const chunks=[[],[]];let bytes=0,reason=null;const timer=setTimeout(()=>{reason='TIMEOUT';child.kill('SIGTERM');},seconds*1000);
    const kill=setTimeout(()=>child.kill('SIGKILL'),seconds*1000+2000);
    for(const [i,stream]of[child.stdout,child.stderr].entries())stream.on('data',b=>{bytes+=b.length;if(bytes>1048576){reason='STREAM_CAP';child.kill('SIGTERM');}else chunks[i].push(b);});
    const terminal=await new Promise((yes,no)=>{child.once('error',no);child.once('close',(code,signal)=>yes({code,signal}));});clearTimeout(timer);clearTimeout(kill);
    write(prefix+'.wait.json',{...terminal,reason,actual_original_close:true});for(const [i,suffix]of['stdout','stderr'].entries())write(prefix+'.'+suffix,Buffer.concat(chunks[i]));
    assert.equal(reason,null);if(!allow)assert.equal(terminal.code,0);return {terminal,stdout:Buffer.concat(chunks[0]).toString('utf8'),stderr:Buffer.concat(chunks[1]).toString('utf8')};
  };
  const inspect=async(target,cleanup=false)=>JSON.parse((await run(['inspect','--format','{"Id":{{json .Id}},"Name":{{json .Name}},"Image":{{json .Config.Image}},"Labels":{{json .Config.Labels}},"Networks":{{json .NetworkSettings.Networks}},"State":{{json .State}},"Ports":{{json .NetworkSettings.Ports}}}',target],20,false,cleanup)).stdout);
  const pg=await inspect(container);const net=JSON.parse((await run(['network','inspect',network])).stdout)[0];
  assert.equal(net.Id,networkId);assert.equal(net.Internal,true);assert.equal(net.Labels['custodial.storage-source'],network);assert.equal(Object.keys(net.Containers).length,1);assert.ok(net.Containers[pg.Id]);
  const alias=Object.keys(pg.Networks).find(n=>n===network);assert.equal(alias,network);
  const secret=randomBytes(32).toString('hex'),jwt=(role,sub)=>{const h=Buffer.from('{"alg":"HS256","typ":"JWT"}').toString('base64url');const p=Buffer.from(JSON.stringify({role,...(sub?{sub}:{}),iss:'supabase',iat:Math.floor(Date.now()/1000),exp:Math.floor(deadline/1000)+60})).toString('base64url');return h+'.'+p+'.'+createHmac('sha256',secret).update(h+'.'+p).digest('base64url');};
  const serviceKey=jwt('service_role'),name=network+'_api';
  const config={DATABASE_URL:`postgresql://supabase_storage_admin:${bootstrap}@${container}:5432/postgres`,AUTH_JWT_SECRET:secret,SERVICE_KEY:serviceKey,ANON_KEY:jwt('anon'),TENANT_ID:projectRef,PROJECT_REF:projectRef,GLOBAL_S3_BUCKET:'stub',STORAGE_BACKEND:'file',STORAGE_FILE_BACKEND_PATH:'/owned-files',STORAGE_FILE_ETAG_ALGORITHM:'md5',DB_INSTALL_ROLES:'false',DB_ALLOW_MIGRATION_REFRESH:'false',DATABASE_MAX_CONNECTIONS:'8',PG_QUEUE_ENABLE:'false',IMAGE_TRANSFORMATION_ENABLED:'false',PORT:'5000'};
  const envfile=path.join(dir,'source.env');write('source.env',Object.entries(config).map(([k,v])=>k+'='+v).join('\n')+'\n');
  write('CONFIG_REDACTED.json',{image:IMAGE,config_sha256:hash(stable(config)),source_only:true,no_freeze_before_genuine_source_migration:true,secret_values_exported:false});
  const request=async(origin,url,token=serviceKey,body,deny=false)=>{
    assert.ok(Date.now()<deadline);const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);
    try{const r=await fetch(origin+url,{method:body===undefined?'GET':'POST',headers:{authorization:'Bearer '+token,apikey:serviceKey,...(body===undefined?{}:{'content-type':url==='/bucket'?'application/json':'application/octet-stream','cache-control':'max-age=3600'})},body,redirect:'error',signal:controller.signal});
      if(deny){
        if([401,403,404].includes(r.status)){await r.body?.cancel();return r.status;}
        assert.equal(r.status,400);assert.ok(r.body);const reader=r.body.getReader(),chunks=[];let size=0;
        try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>4096){controller.abort();await reader.cancel().catch(()=>{});sourceDenialRefuse();}chunks.push(Buffer.from(value));}}finally{reader.releaseLock();}
        const denied=validateFreshLocalStorageDeniedResponse(r.status,Buffer.concat(chunks),'private-object');write('ACTUAL_DENIAL_'+String(seq)+'_'+randomBytes(4).toString('hex')+'.json',denied);return denied;
      }
      assert.ok(r.ok,'Official source HTTP '+r.status+' '+url);const bytes=Buffer.from(await r.arrayBuffer());assert.ok(bytes.length<=1048576);return bytes;
    }finally{clearTimeout(timer);}
  };
  try{
    cid=(await run(['create','--pull','never','--name',name,'--label','custodial.storage-source='+network,'--network',network,'--cpus','1','--memory','512m','--pids-limit','128','--read-only','--tmpfs','/tmp:rw,size=32m','--tmpfs','/owned-files:rw,size=16m','--env-file',envfile,IMAGE])).stdout.trim();assert.match(cid,/^[a-f0-9]{64}$/);write('DURABLE_SOURCE_PROVIDER_CID.json',{cid,name,image:IMAGE});
    await run(['start',cid]);const service=await inspect(cid);assert.equal(service.Id,cid);assert.equal(service.Image,IMAGE);assert.equal(service.Labels['custodial.storage-source'],network);
    // Docker does not publish ports on this sole --internal bridge. Keep
    // isolation and use an owned, fixed-destination loopback TCP relay.
    const endpoint=service.Networks[network];assert.equal(Object.keys(service.Networks).length,1);assert.equal(endpoint.NetworkID,networkId);assert.equal(isIP(endpoint.IPAddress),4);
    assert.equal(service.Name,'/'+name);assert.equal(service.State.Running,true);assert.equal(service.Ports['5000/tcp'],null);
    const address=endpoint.IPAddress;
    const assertService=async()=>{const x=await inspect(cid);assert.equal(x.Id,cid);assert.equal(x.Name,'/'+name);assert.equal(x.Image,IMAGE);assert.equal(x.Labels['custodial.storage-source'],network);assert.equal(x.State.Running,true);assert.equal(Object.keys(x.Networks).length,1);assert.equal(x.Networks[network].NetworkID,networkId);assert.equal(x.Networks[network].IPAddress,address);};
    relay=createServer(client=>{
      if(Date.now()>=deadline||relaySockets.size>=64){client.destroy();return;}
      const upstream=createConnection({host:address,port:5000});
      for(const socket of [client,upstream]){relaySockets.add(socket);socket.setTimeout(10000);socket.on('timeout',()=>socket.destroy());socket.on('error',()=>{client.destroy();upstream.destroy();});socket.on('close',()=>{relaySockets.delete(socket);if(socket===client)upstream.destroy();else client.destroy();});}
      client.pipe(upstream);upstream.pipe(client);
    });
    await new Promise((resolve,reject)=>{relay.once('error',reject);relay.listen({host:'127.0.0.1',port:0,exclusive:true},resolve);});
    relay.on('error',()=>{for(const socket of relaySockets)socket.destroy();});
    const listener=relay.address();assert.equal(listener.address,'127.0.0.1');assert.ok(listener.port>0&&listener.port<=65535);const origin='http://127.0.0.1:'+listener.port;
    write('OWNED_LOOPBACK_RELAY_BOUND.json',{origin,container_id:cid,container_name:name,image:IMAGE,network_id:networkId,network_name:network,destination_address:address,destination_port:5000,external_network_attached:false,payloads_logged:false});
    await assertService();
    for(;;){try{await request(origin,'/status');break;}catch(e){const state=JSON.parse((await run(['inspect','--format','{{json .State}}',cid])).stdout);assert.equal(state.Running,true);if(Date.now()>=deadline)throw e;await delay(250);}}
    // Actual official vendor initialization precedes the source snapshot. Its
    // real count and full tuples are captured; no manufactured 74-row ledger.
    const migrations=(await db.query('select row_to_json(m) row from storage.migrations m order by id')).rows.map(r=>r.row);assert.ok(migrations.length>0&&migrations.length<=256);assert.equal(new Set(migrations.map(r=>r.id)).size,migrations.length);
    await db.query(`create policy custodial_fixture_original_owner_select on storage.objects for select to authenticated using (bucket_id in ('custodial-private-original','custodial-public-original') and coalesce(owner_id,owner::text)=auth.uid()::text);
      create policy custodial_fixture_original_owner_insert on storage.objects for insert to authenticated with check (bucket_id in ('custodial-private-original','custodial-public-original') and coalesce(owner_id,owner::text)=auth.uid()::text)`);
    const specs=[{id:'custodial-private-original',public:false,bytes:Buffer.from('Private original bytes: exact archived-version fixture.\n')},{id:'custodial-public-original',public:true,bytes:Buffer.from('Public original bytes: exact archived-version fixture.\n')}];
    const probes=[];
    for(const x of specs){await request(origin,'/bucket',serviceKey,JSON.stringify({id:x.id,name:x.id,public:x.public}));await request(origin,'/object/'+x.id+'/original.bin',jwt('authenticated',ownerUser),x.bytes);const privatePath='/object/authenticated/'+x.id+'/original.bin';assert.deepEqual(await request(origin,privatePath,jwt('authenticated',ownerUser)),x.bytes);
      const foreign='00000000-0000-4000-8000-000000000001';if(!x.public){probes.push({bucket:x.id,foreign:await request(origin,privatePath,jwt('authenticated',foreign),undefined,true),anon:await request(origin,privatePath,jwt('anon'),undefined,true)});}else assert.deepEqual(await request(origin,'/object/public/'+x.id+'/original.bin',jwt('anon')),x.bytes);}
    await assertService();
    // Quiesce the official service before pg_dump/native row capture.
    await run(['stop','--time','5',cid],10);const stopped=JSON.parse((await run(['inspect','--format','{{json .State}}',cid])).stdout);assert.equal(stopped.Running,false);
    const buckets=(await db.query('select row_to_json(b) row from storage.buckets b order by id')).rows.map(r=>r.row),rows=(await db.query('select row_to_json(o) row from storage.objects o order by bucket_id,name,id')).rows.map(r=>r.row);assert.equal(buckets.length,2);assert.equal(rows.length,2);
    const objects=rows.map(r=>{const spec=specs.find(s=>s.id===r.bucket_id);assert.ok(spec);assert.equal(r.name,'original.bin');assert.ok(r.version);assert.equal(r.owner_id||r.owner,ownerUser);const file='storage/objects/'+hash(r.bucket_id+'\0'+r.name)+'.bin';return {id:r.id,bucket_id:r.bucket_id,name:r.name,file,size_bytes:spec.bytes.length,sha256:hash(spec.bytes),metadata:r.metadata,user_metadata:r.user_metadata,version:r.version,created_at:r.created_at,updated_at:r.updated_at,database_row:r};});
    const result={source_fixture_only:true,original_noStorage_archive_modified:false,buckets,objects,blobs:specs.map(x=>({file:'storage/objects/'+hash(x.id+'\0original.bin')+'.bin',bytes:x.bytes})),migration_count:migrations.length,migrations,migrations_sha256:hash(stable(migrations)),actual_official_image:IMAGE,actual_role_probes:probes};
    write('ACTUAL_SOURCE_STORAGE_METADATA.json',{...result,blobs:result.blobs.map(x=>({file:x.file,sha256:hash(x.bytes),bytes:x.bytes.length}))});return result;
  }catch(e){first=e;
    if(cid)try{const x=await inspect(cid,true);assert.equal(x.Id,cid);assert.equal(x.Name,'/'+name);assert.equal(x.Image,IMAGE);assert.equal(x.Labels['custodial.storage-source'],network);await run(['logs','--tail','80',cid],10,true,true);}catch(logError){write('SOURCE_PROVIDER_FAILURE_LOG_CAPTURE_REFUSED.json',{message:'Exact owned bounded failure logs unavailable',error_name:logError.name});}
    throw e;
  }finally{
    try{if(relay){
      // Server close does not order our individual Socket close handlers.
      // Register every owned socket close waiter BEFORE destroying it.
      const socketClosures=[...relaySockets].map(socket=>new Promise(resolve=>{socket.once('close',resolve);socket.destroy();}));
      let timer;try{await Promise.race([Promise.all([...socketClosures,new Promise((resolve,reject)=>relay.close(error=>error?reject(error):resolve()))]),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Owned relay closure timed out')),1000);})]);}finally{clearTimeout(timer);}
      assert.equal(relay.listening,false);assert.equal(relaySockets.size,0);write('OWNED_LOOPBACK_RELAY_CLOSED.json',{listener_closed:true,owned_sockets_remaining:0,every_owned_socket_close_observed:true,before_container_removal:true});}}
    catch(e){write('SOURCE_RELAY_CLEANUP_FAILURE.json',{message:'Owned relay closure refused',error_name:e.name,error_code:e.code??null,error_message:e.message,owned_sockets_remaining:relaySockets.size});if(!first){first=e;write('SOURCE_RELAY_FATAL_AFTER_CONTAINER_CLEANUP.json',{must_refuse:true});}}
    try{if(!cid){const found=(await run(['ps','-aq','--no-trunc','--filter','name=^/'+name+'$'],20,false,true)).stdout.trim().split('\n').filter(Boolean);assert.ok(found.length<=1);cid=found[0]??null;}if(cid){const x=await inspect(cid,true);assert.equal(x.Id,cid);assert.equal(x.Name,'/'+name);assert.equal(x.Image,IMAGE);assert.equal(x.Labels['custodial.storage-source'],network);await run(['rm','-f',cid],20,false,true);const absent=await run(['ps','-aq','--no-trunc','--filter','id='+cid],20,false,true);assert.equal(absent.stdout.trim(),'');}closed=true;}
    catch(e){write('SOURCE_PROVIDER_CLEANUP_FAILURE.json',{message:'Exact owned source provider cleanup refused'});if(!first)throw e;}
    finally{write('SOURCE_PROVIDER_CLOSED.json',{exact_CID_absent_or_never_born:closed,official_service_stopped_before_signed_capture:true,source_metadata_preserved:true});if(closed)fs.unlinkSync(envfile);if(fs.existsSync(path.join(dir,'SOURCE_RELAY_FATAL_AFTER_CONTAINER_CLEANUP.json')))throw first;}
  }
}
