// One newly affected product flow. Reuses pinned cached PG reconstruction;
// SDK facade is local fixed SQL, NOT hosted PostgREST or human/browser proof.
import fs from 'node:fs';
import http from 'node:http';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash,createHmac,randomUUID,randomBytes,webcrypto} from 'node:crypto';
import {execFileSync,spawn} from 'node:child_process';
const [socket,B,out,bootstrap,stage,purpose='held',ownedContainerName,timeoutDiagnostic]=process.argv.slice(2),D="/home/eric/Documents/Codex/2026-09-13/i-x20/work/autonomous-repair-20260923/overnight-readiness-20261006/lean-held-correction-integration-20261011/";
assert.ok(timeoutDiagnostic===undefined||(timeoutDiagnostic==='read-only-timeout-sample'&&purpose==='immutable-private-populated-authority-normal-cli'));
const sha=x=>createHash('sha256').update(x).digest('hex'),put=(n,x)=>fs.writeFileSync(out+'/'+n,JSON.stringify(x,null,2)+'\n',{flag:'wx',mode:0o600});
// pg_get_functiondef (ruleutils.c) emits miscellaneous attributes on ONE
// option line and guarantees that the body begins at AS / BEGIN / RETURN.
// This is a check of that generated representation, not a SQL interpreter.
function privateCatalogFunctionHeader(definition){
 assert.equal(typeof definition,'string');
 assert.match(definition,/^CREATE OR REPLACE (?:FUNCTION|PROCEDURE) /);
 const body=/^(?:AS |BEGIN |RETURN )/m.exec(definition);assert.ok(body,'generated function body boundary');
 const header=definition.slice(0,body.index);
 // Mask quoted identifiers/literals/defaults and comments while retaining
 // line boundaries. An atom stays an atom: masking must not join keywords.
 let masked='';
 const hide=text=>'@'+text.slice(1).replace(/[^\n]/g,' ');
 for(let i=0;i<header.length;){
  const start=i,ch=header[i];
  if(ch==="'"||ch==='"'){
   const escape=ch==="'"&&/[eE]/.test(header[i-1]??'')&&!/[a-zA-Z0-9_$]/.test(header[i-2]??'');
   i++;let closed=false;
   while(i<header.length){
    if(escape&&header[i]==='\\'){i+=2;continue;}
    if(header[i]===ch){if(header[i+1]===ch){i+=2;continue;}i++;closed=true;break;}i++;
   }
   assert.ok(closed,'closed generated header quoted atom');masked+=hide(header.slice(start,i));continue;
  }
  const dollar=ch==='$'?/^(?:\$\$|\$[a-zA-Z_][a-zA-Z0-9_]*\$)/.exec(header.slice(i)):null;
  if(dollar){const end=header.indexOf(dollar[0],i+dollar[0].length);assert.ok(end>=0,'closed generated default');
   i=end+dollar[0].length;masked+=hide(header.slice(start,i));continue;}
  if(header.startsWith('--',i)){const end=header.indexOf('\n',i);i=end<0?header.length:end;
   masked+=header.slice(start,i).replace(/[^\n]/g,' ');continue;}
  if(header.startsWith('/*',i)){i+=2;let depth=1;
   while(i<header.length&&depth){if(header.startsWith('/*',i)){depth++;i+=2;}
    else if(header.startsWith('*/',i)){depth--;i+=2;}else i++;}
   assert.equal(depth,0,'closed generated header comment');masked+=header.slice(start,i).replace(/[^\n]/g,' ');continue;}
  masked+=ch;i++;
 }
 const lines=masked.split('\n'),languages=lines.flatMap((line,i)=>/^ LANGUAGE (?:[a-zA-Z_][a-zA-Z0-9_]*|@) *$/.test(line)?[i]:[]);
 assert.equal(languages.length,1,'one generated LANGUAGE clause');
 let securityDefiner=false,searchPath=false,optionLines=0;
 for(const line of lines.slice(languages[0]+1)){
  if(!line.trim())continue;
  if(/^ SET [a-zA-Z_@]/.test(line)){
   if(/^ SET search_path TO /.test(line)){assert.equal(searchPath,false);searchPath=true;}continue;
  }
  assert.match(line,/^ (?:WINDOW|IMMUTABLE|STABLE|PARALLEL|STRICT|SECURITY|LEAKPROOF|COST|ROWS|SUPPORT)\b/,'generated options, not function name/body/config value');
  assert.equal(++optionLines,1,'one generated miscellaneous-options line');
  securityDefiner=/(?:^|\s)SECURITY\s+DEFINER(?:\s|$)/.test(line);
 }
 return {header,securityDefiner,searchPath};
}
if(socket==='--private-function-catalog-header-format-only'){
 const ddl=(options,config='',body="AS $function$\nBEGIN RETURN 'SECURITY DEFINER'; END\n$function$\n",name='custodial_recovery.example',args='')=>
  'CREATE OR REPLACE FUNCTION '+name+'('+args+')\n RETURNS text\n LANGUAGE plpgsql\n'+options+config+body;
 const combined=ddl(' STABLE STRICT SECURITY DEFINER\n'," SET search_path TO 'pg_catalog', 'custodial_recovery'\n");
 // Retain the original failed expectation as a component counterexample,
 // not as a substitute for the preserved actual SQL assertion failure.
 assert.equal(/\n SECURITY DEFINER\n/.test(combined.slice(0,combined.indexOf('\nAS '))+'\n'),false);
 for(const [name,definition,expected] of [
  ['combined-options',combined,[true,true]],
  ['single-option',ddl(' SECURITY DEFINER\n'),[true,false]],
  ['invoker-name-body-and-comment',ddl(''," SET application_name TO 'SECURITY DEFINER\n SET search_path TO spoof'\n",undefined,'custodial_recovery."SECURITY DEFINER"'),[false,false]],
  ['quoted-default-and-support',ddl(' IMMUTABLE PARALLEL SAFE STRICT SUPPORT custodial_recovery."SECURITY DEFINER"\n'," SET search_path TO 'pg_catalog'\n",undefined,'custodial_recovery.example',"value text DEFAULT 'x\n LANGUAGE sql\n SECURITY DEFINER\n SET search_path TO spoof'::text"),[false,true]],
  ['sql-return-body',ddl(' STABLE\n','',"RETURN 'SECURITY DEFINER\n SET search_path TO spoof'\n").replace('LANGUAGE plpgsql','LANGUAGE sql'),[false,false]],
  ['sql-begin-body',ddl(' STRICT SECURITY DEFINER LEAKPROOF COST 5\n','',"BEGIN ATOMIC\n SELECT 'SET search_path TO spoof';\nEND\n").replace('LANGUAGE plpgsql','LANGUAGE sql'),[true,false]],
 ]){const actual=privateCatalogFunctionHeader(definition);assert.deepEqual([actual.securityDefiner,actual.searchPath],expected,name);console.log('HEADER_FORMAT_COMPONENT_ONLY '+name);}
 assert.throws(()=>privateCatalogFunctionHeader(ddl(' SECURITY DEFINER\n').replace('AS $function$','UNRECOGNIZED $function$')));
 console.log('NO_SQL_EXECUTED_ACTUAL_CATALOG_RECHECK_REQUIRED');process.exit(0);
}
if(socket==='--same-original-native-writer-hold-input-preflight'){
  await preflightSameOriginalNativeAcceptedCompletionInputs(process.argv[3],true,true);
  // The owning page performs strict source pins on import. Catch an invalid
  // prerequisite before acquiring the disposable SQL fixture; no old tests
  // register and no manager workflow executes merely by importing this member.
  await import(pathToFileURL(path.dirname(process.argv[3])+'/frontend/scripts/same-original-recovery-page-tests.mjs'));
  console.log('READY_NEW_DURABLE_NATIVE_WRITER_HOLD_INPUTS_NO_FIXTURE');process.exit(0);
}
if(socket==='--same-original-native-saved-browser-input-preflight'){
  await preflightSameOriginalNativeAcceptedCompletionInputs(process.argv[3],true);
  console.log('READY_SAVED_ORIGINAL_BROWSER_MANAGER_NATIVE_SQL_INPUTS_NO_FIXTURE');process.exit(0);
}
if(socket==='--same-original-native-accepted-completion-input-preflight'){
  await preflightSameOriginalNativeAcceptedCompletionInputs(process.argv[3]);
  console.log('READY_STAGED_ACCEPTED_NATIVE_COMPLETION_INPUTS_NO_FIXTURE');process.exit(0);
}
if(socket==='--same-original-native-completion-input-preflight'){
  await preflightSameOriginalNativeCompletionInputs(process.argv[3]);
  console.log('READY_SAME_ORIGINAL_NATIVE_COMPLETION_INPUTS_NO_FIXTURE');process.exit(0);
}
if(socket==='--same-original-native-manager-preparation-input-preflight'){
  await preflightSameOriginalNativeManagerPreparationInputs(process.argv[3]);
  console.log('READY_SAME_ORIGINAL_NATIVE_MANAGER_PREPARATION_INPUTS_NO_FIXTURE');process.exit(0);
}
if(socket==='--same-original-native-status-input-preflight'){
  await preflightSameOriginalNativeStatusInputs(process.argv[3]);
  console.log('READY_SAME_ORIGINAL_NATIVE_STATUS_INPUTS_NO_FIXTURE');process.exit(0);
}
if(socket==='--same-original-native-input-preflight'){
  await preflightSameOriginalNativeInputs(process.argv[3]);
  console.log('READY_SAME_ORIGINAL_NATIVE_INPUTS_NO_FIXTURE');process.exit(0);
}
const require=createRequire(B+'/package.json'),{Client}=require('pg'),{createClient}=require('@supabase/supabase-js'),express=require('express');
const storageCheckpointCaller=purpose==='storage-original-checkpoint-caller';
const storageSupportedSampler=purpose==='storage-supported-sampler';
const storageOriginalSql=storageSupportedSampler||storageCheckpointCaller||['storage-original-table-match','storage-original-table-temp-shadow','storage-original-table-negative','storage-original-table-no-members'].includes(purpose);
const legacyFidelityNative=purpose==='immutable-private-legacy-fidelity-native-refusal';
if(purpose==='vendor-auth-populated-authority-original-capture'||purpose==='immutable-authority-dependent-source-compile'||purpose==='approved-pending-staffing-private-compile'||purpose==='vendor-auth-enum-io-diagnostic'||purpose==='vendor-auth-complete-archive-capture'||purpose==='vendor-auth-new-original-capture'||purpose==='vendor-auth-current-source-repaired'||purpose==='vendor-auth-current-source-diagnostic'||purpose==='vendor-auth-current-source'||purpose==='vendor-auth-fixture-migrate-config'||purpose==='vendor-auth-fixture-migrate'||purpose==='vendor-auth-fixture-prerequisite'||purpose==='pre-restore-original-snapshot-roundtrip'||purpose==='restore-authority-target-preflight'||purpose==='original-data-numeric-output-profile'||purpose==='original-data-json-null-profile'||purpose==='original-data-native-text-roundtrip'||storageOriginalSql||legacyFidelityNative){
 const populatedAuthorityOriginal=purpose==='vendor-auth-populated-authority-original-capture';
 const populatedOriginalSource=Object.freeze({commit:'b20499c6a98b90db1779fe5d0060b619bceae261',tree:'ee9f1191672ff65f26592dfd0ca19a6200101cb1',
  producer:'31dee45261a57eb609e07b7e99fc03c1e575d7f4e9445795bd1383cbcd8fcbd3',
  fixture:'7ea86d9823b71c31776443cc2a2e7b1412f55297ec2e28dc7a4eaf5a6612d799',
  constructor:'dbf2638cd11ec874031eb4e48202176cfc7d95f499e4e6eeadf28f83cb1c957b'});
 const completeVendorArchive=purpose==='vendor-auth-complete-archive-capture'||populatedAuthorityOriginal;
 const captureVendorOriginal=completeVendorArchive||purpose==='vendor-auth-new-original-capture';
 const pendingStaffingCompile=purpose==='approved-pending-staffing-private-compile';
 const authorityChangedCompile=purpose==='immutable-authority-dependent-source-compile';
 const vendorSourceRepaired=captureVendorOriginal||purpose==='vendor-auth-current-source-repaired'||pendingStaffingCompile||authorityChangedCompile;
 const vendorCurrentSource=vendorSourceRepaired||purpose==='vendor-auth-current-source'||purpose==='vendor-auth-current-source-diagnostic';
 const connection={host:socket,user:'supabase_admin',database:storageOriginalSql||legacyFidelityNative?ownedContainerName:'postgres',password:bootstrap,connectionTimeoutMillis:500,query_timeout:vendorCurrentSource?60000:10000};
 const {capturePreRestoreState,compareRestoredState,preserveCurrentReleaseIdentity}=await import(B+'/scripts/disaster-recovery-state.mjs');
 let db,transaction=false,firstFailure;
 try{
  for(let attempt=0;attempt<40;attempt++){
   const candidate=new Client(connection);candidate.on('error',()=>{});
   try{
    await candidate.connect();
    const ready=(await candidate.query("select current_user actor,split_part(pg_catalog.pg_read_file('postmaster.pid',0,32),chr(10),1) postmaster_pid")).rows[0];
    if(ready.actor==='supabase_admin'&&ready.postmaster_pid==='1'){db=candidate;break;}
   }catch(error){if(attempt===39)throw error;}
   await candidate.end();await new Promise(resolve=>setTimeout(resolve,500));
  }
  assert.ok(db,'Original isolated image postmaster not ready');
  if(stage==='start'){
   put('SNAPSHOT_INPUT_READY.json',{actual_postmaster:true,actual_role:'supabase_admin',app_schema_replays:0,
    scope:'Disposable SQL snapshot component, not original restore effect/role/RLS/ACL admission'});
  }else if(vendorCurrentSource||purpose==='vendor-auth-enum-io-diagnostic'||purpose==='vendor-auth-fixture-prerequisite'||purpose==='vendor-auth-fixture-migrate'||purpose==='vendor-auth-fixture-migrate-config'){
   if(vendorCurrentSource){
    const {readMigrationReplayPlan}=await import(B+'/scripts/migration-replay-order.mjs');
    const {DEFAULT_EXCEPTIONS}=await import(B+'/scripts/current-release-recovery-replay.mjs');
    const plan=readMigrationReplayPlan(B);
    const currentDatedInstallation=purpose==='vendor-auth-current-source-repaired'||pendingStaffingCompile||authorityChangedCompile||populatedAuthorityOriginal;
    assert.equal(plan.files.length,currentDatedInstallation?286:285);
    assert.equal(plan.manifestSha256,currentDatedInstallation?'f8634d695f77c02ba2c27c6b2d7f8cc8f388e435ff639fd5aef9eb95267c3657':vendorSourceRepaired?'4e59080b688720bb0f469ba10e433bf7e1fba19a335ddd3f0b7afbf59913ee2e':'051fa5f7118c142c1aa4745a5decafb6508aaff6e87bf6807361c0bb30eb5284');
    if(currentDatedInstallation){
     assert.equal(plan.files.at(-1),'20261017225101_approved_static_dated_original_materialization.sql');
     assert.equal(sha(fs.readFileSync(B+'/supabase/migrations/'+plan.files.at(-1))),'2526dde3e55268da83ba43c8ce30c61c5f1a8c83df50aae85d557c517c383418');
    }
    const defaults="select count(*)::int n from pg_default_acl d cross join lateral aclexplode(d.defaclacl) a where d.defaclnamespace in (0,'public'::regnamespace) and d.defaclrole in ('postgres'::regrole,'supabase_admin'::regrole) and d.defaclobjtype in ('r','S') and a.grantee in (0,'anon'::regrole,'authenticated'::regrole,'service_role'::regrole)";
    const revoke=['postgres','supabase_admin'].flatMap(owner=>['',' in schema public'].map(scope=>
     `alter default privileges for role ${owner}${scope} revoke all on tables from public,anon,authenticated,service_role;alter default privileges for role ${owner}${scope} revoke all on sequences from public,anon,authenticated,service_role;`)).join('\n');
    await db.query(revoke);assert.equal((await db.query(defaults)).rows[0].n,0);
    const baseline=fs.readFileSync(B+'/supabase/migrations/00000000000000_production_baseline.sql','utf8');
    const extensions=baseline.split('\n').filter(row=>/^create extension if not exists "[a-z_-]+" with schema "[a-z_]+";$/.test(row));
    assert.equal(extensions.length,6);
    await db.query('create schema if not exists extensions authorization postgres;create schema if not exists vault authorization postgres');
    for(const sql of extensions)await db.query(sql);
    // Normal local UNIT platform metadata, matching the retained owning
    // restore fixture's schema. These are not production deployment records.
    if(completeVendorArchive||authorityChangedCompile)await db.query(`create schema supabase_migrations authorization supabase_admin;
     create table supabase_migrations.schema_migrations(version text primary key,name text not null,statements text[] not null default '{}')`);
    const applied=[];let currentFile;
    try{
     for(const file of plan.files){
      currentFile=file;const bytes=fs.readFileSync(B+'/supabase/migrations/'+file);
      if(purpose==='vendor-auth-current-source-diagnostic'&&file==='20261017200958_approved_static_original_confirmation_receipts.sql'){
       const {splitSchemaStatements}=await import(B+'/scripts/isolated-event-owner-schema.mjs');
       const {statements}=splitSchemaStatements(bytes.toString());
       for(const statement of statements){
        const exactGuard=statement.text.includes('DO $private_acl$');
        if(exactGuard)await db.query('savepoint owning_new_ledger_guard');
        try{await db.query(statement.text);}
        catch(error){
         if(exactGuard){
          await db.query('rollback to savepoint owning_new_ledger_guard');
          const relation=(await db.query(`select r.rolname owner,c.relrowsecurity,c.relforcerowsecurity,
           (select jsonb_agg(jsonb_build_object('grantee',case when x.grantee=0 then 'PUBLIC' else pg_get_userbyid(x.grantee) end,
            'privilege',x.privilege_type,'grantable',x.is_grantable) order by x.grantee,x.privilege_type)
            from aclexplode(coalesce(c.relacl,acldefault('r',c.relowner))) x) acl
           from pg_class c join pg_roles r on r.oid=c.relowner where c.oid='public.static_weekly_approved_template_confirmations'::regclass`)).rows;
          const triggers=(await db.query(`select tgname,tgenabled,tgtype,tgnargs,tgqual::text,
           tgfoid::regprocedure::text function from pg_trigger where tgrelid='public.static_weekly_approved_template_confirmations'::regclass
           and not tgisinternal order by tgname`)).rows;
          const routines=(await db.query(`select p.oid::regprocedure::text identity,r.rolname owner,
           (select jsonb_agg(jsonb_build_object('grantee',case when x.grantee=0 then 'PUBLIC' else pg_get_userbyid(x.grantee) end,
            'privilege',x.privilege_type,'grantable',x.is_grantable) order by x.grantee,x.privilege_type)
            from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) x) acl
           from pg_proc p join pg_roles r on r.oid=p.proowner where p.oid in(
            'public.static_weekly_guard_approved_template_confirmation()'::regprocedure,
            'public.static_weekly_read_approved_template_confirmation(uuid,text)'::regprocedure)`)).rows;
          const direct=(await db.query(`select role_name,has_table_privilege(role_name,'public.static_weekly_approved_template_confirmations','SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER') table_access,
           has_any_column_privilege(role_name,'public.static_weekly_approved_template_confirmations','SELECT,INSERT,UPDATE,REFERENCES') column_access
           from unnest(ARRAY['anon','authenticated','service_role','custodial_application_reader','static_weekly_control_plane',
            'static_weekly_release_operator','static_weekly_runtime_20260823']) roles(role_name)`)).rows;
          put('NEW_LEDGER_GUARD_ACTUAL_METADATA.json',{file,source_sha256:sha(bytes),statement:'UNCHANGED_PRIVATE_ACL_GUARD_FAILED',
           original_error:{code:error.code,message:error.message},relation,triggers,routines,direct,
           observation:'Only failed statement rolled back to own savepoint for native metadata; outer migration MUST rollback, no guard skipped or success authority',production:false});
         }
         throw error;
        }
       }
      }else await db.query(bytes.toString());
      if((await db.query(defaults)).rows[0].n!==0){
       assert.equal(sha(bytes),DEFAULT_EXCEPTIONS[file]);assert.ok(!/\bcreate\s+(?:unlogged\s+)?(?:table|sequence)\b/i.test(bytes.toString()));
       await db.query(revoke);
      }
      assert.equal((await db.query(defaults)).rows[0].n,0);applied.push(file);
      if(completeVendorArchive||authorityChangedCompile)await db.query('insert into supabase_migrations.schema_migrations(version,name,statements) values($1,$2,$3)',
       [file.slice(0,14),file.slice(15,-4),[bytes.toString()]]);
     }
     if(authorityChangedCompile){
      const {splitSchemaStatements}=await import(B+'/scripts/isolated-event-owner-schema.mjs');
      await db.query('begin');transaction=true;await db.query('set local check_function_bodies=on');
      // The owning authority installer requires the same transaction-held
      // global mutation fence as the normal restore path. Do not bypass it
      // merely because this fixture rolls the installation back.
      await db.query("select pg_advisory_xact_lock(pg_catalog.hashtextextended('memphis-zoo-application-mutation-fence',0))");
      const installed=[];
      for(const [file,digest] of [['proposals/immutable-private-owner-context.sql','b2a628db97d31854d9bce28f6f9bc266fda5d02f19f2a39888e4daf19a48afcf'],
       ['proposals/immutable-original-authority-reconciliation.sql','b1a4542d43722c2b6e4f833d64bcf7904f781022e5f78a98137a5358fd88065f']]){
       currentFile=file;const bytes=fs.readFileSync(B+'/'+file);assert.equal(sha(bytes),digest);
       const parsed=splitSchemaStatements(bytes.toString());assert.equal(parsed.psqlGuards,0);
       let begin=0,end=0;
       for(const statement of parsed.statements){
        const words=statement.tokens.map(token=>token.value);
        if(words.length===2&&words[0]==='begin'&&words[1]===';'){begin++;continue;}
        if(words.length===2&&words[0]==='commit'&&words[1]===';'){end++;continue;}
        await db.query(statement.text);
       }
       assert.equal(begin,1);assert.equal(end,1);installed.push({file,sha256:digest});
      }
      const routines=(await db.query(`select p.proname,p.proowner::regrole::text owner,p.prosecdef,
       (select count(*)::int from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee<>p.proowner) nonowner_grants
       from pg_proc p where p.pronamespace='custodial_dr'::regnamespace and p.proname in(
        'immutable_original_authority_scope_guard','immutable_original_authority_scope_shape','immutable_original_authority_snapshot',
        'immutable_original_authority_guard_matches','reconcile_committed_immutable_original_authority','read_committed_immutable_original_authority') order by p.proname`)).rows;
      assert.equal(routines.length,6);assert.ok(routines.every(row=>row.owner==='supabase_admin'&&!row.prosecdef&&row.nonowner_grants===0));
      const stored=(await db.query(`select p.prosrc from pg_proc p where p.oid='custodial_dr.immutable_original_authority_snapshot(bigint)'::regprocedure`)).rows[0].prosrc;
      assert.ok(stored.includes("'effect_transaction_started_at',pg_catalog.transaction_timestamp()"));
      const relation=(await db.query(`select relrowsecurity,relforcerowsecurity from pg_class where oid='custodial_dr.immutable_original_authority_scopes'::regclass`)).rows[0];
      assert.deepEqual(relation,{relrowsecurity:true,relforcerowsecurity:true});
      assert.equal((await db.query('select count(*)::int n from custodial_dr.immutable_original_authority_scopes')).rows[0].n,0);
      await db.query('rollback');transaction=false;
      assert.equal((await db.query("select to_regclass('custodial_dr.immutable_original_authority_scopes') relation")).rows[0].relation,null);
      put('AUTHORITY_CHANGED_SOURCE_COMPILE_RESULT.json',{scope:'NEW_DEPENDENT_ORDER_AND_DURABLE_TRANSACTION_TIME_SOURCE_NATIVE_COMPILE_ONLY',
       installed,routines,relation,rolled_back:true,original_contexts_or_effects_created:0,populated_effects:'NOT_RUN',
       post_restore_images:'NOT_RUN',complete_restore:false,production:false,old_groups_replayed:0});
     }else if(pendingStaffingCompile){
      currentFile='proposals/approved-static-pending-staffing.sql';
      const bytes=fs.readFileSync(B+'/'+currentFile);
      assert.equal(sha(bytes),'4ea18401e4ad65411933e7e17b84275dcf8b46732dde4f8ac953b38d004e3066');
      const snapshot=`select p.oid::regprocedure::text identity,pg_get_functiondef(p.oid) definition,p.proowner::regrole::text owner,
       p.prosecdef,p.proconfig,p.proacl::text acl from pg_proc p where p.pronamespace='public'::regnamespace
       and p.proname in('static_weekly_v10_stage_staffing_command','static_weekly_v11_accept_staffing_command',
        'static_weekly_v11_staged_projection_digest_matches','static_weekly_compiler_exception_set',
        'static_weekly_assert_approved_dated_projection','static_weekly_approved_dated_effective_work',
        'static_weekly_assert_approved_dated_lunch','static_weekly_v8_assert_lunch_document',
        'static_weekly_v2_materialize_projection') order by identity`;
      const original=(await db.query(snapshot)).rows;assert.equal(original.length,9);
      assert.equal((await db.query("select count(*)::int n from pg_proc where pronamespace='public'::regnamespace and proname like 'static_weekly_pending_%'")).rows[0].n,0);
      await db.query('begin');transaction=true;
      await db.query('set local check_function_bodies=on');
      await db.query(bytes.toString());
      const routines=(await db.query(`select p.oid::regprocedure::text identity,p.proowner::regrole::text owner,p.prosecdef,
       (select count(*)::int from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee<>p.proowner) nonowner_grants
       from pg_proc p where p.pronamespace='public'::regnamespace and p.proname like 'static_weekly_pending_%' order by identity`)).rows;
      assert.equal(routines.length,14);assert.ok(routines.every(r=>r.owner==='supabase_admin'&&r.prosecdef===false&&r.nonowner_grants===0));
      const denied=[];
      for(const role of ['anon','authenticated','service_role','custodial_application_reader',
       'static_weekly_control_plane','static_weekly_release_operator','static_weekly_runtime_20260823','postgres']){
       await db.query('savepoint pending_denied_role');await db.query('set local role '+role);
       await assert.rejects(db.query('select public.static_weekly_pending_context(null::uuid,null::uuid)'),e=>e.code==='42501');
       await db.query('rollback to savepoint pending_denied_role');denied.push(role);
      }
      await db.query('rollback');transaction=false;
      assert.deepEqual((await db.query(snapshot)).rows,original);
      assert.equal((await db.query("select count(*)::int n from pg_proc where pronamespace='public'::regnamespace and proname like 'static_weekly_pending_%'")).rows[0].n,0);
      put('PENDING_STAFFING_COMPILE_RESULT.json',{scope:'NEW_PRIVATE_PROPOSAL_NATIVE_COMPILE_AND_DENIED_DIRECT_CALLS_ONLY',
       proposal_sha256:sha(bytes),routines,denied,rolled_back:true,original_nine_definitions_and_ACLs_restored:true,
       stage_accept_publication:'NOT_RUN',production:false,old_groups_replayed:0});
     }else{
     const privacy=(await db.query(`select exists(select 1 from pg_class c cross join lateral aclexplode(coalesce(c.relacl,acldefault('r',c.relowner))) a
      where c.oid='public.static_weekly_approved_template_confirmations'::regclass and a.grantee='postgres'::regrole and a.grantee<>c.relowner) postgres_direct_nonowner_table_grant,
      has_function_privilege('postgres','public.static_weekly_guard_approved_template_confirmation()','EXECUTE') postgres_guard_access,
      has_function_privilege('postgres','public.static_weekly_read_approved_template_confirmation(uuid,text)','EXECUTE') postgres_reader_access,
      has_function_privilege('static_weekly_control_plane','public.static_weekly_read_approved_template_confirmation(uuid,text)','EXECUTE') control_reader_access,
      has_table_privilege('static_weekly_control_plane','public.static_weekly_approved_template_confirmations','SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER') control_table_access,
      has_table_privilege('supabase_admin','public.static_weekly_approved_template_confirmations','SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER') original_creator_access`)).rows[0];
     assert.deepEqual(privacy,{postgres_direct_nonowner_table_grant:false,postgres_guard_access:false,postgres_reader_access:false,
      control_reader_access:true,control_table_access:false,original_creator_access:true});
     const basis=(await db.query(`select proowner::regrole::text owner,prosecdef,
      position('templateCatalogEntries' in prosrc)>0 catalog_entries,
      position('templateInputsDigest' in prosrc)>0 input_binding
      from pg_proc where oid='public.static_weekly_read_approved_template_basis(uuid,uuid,date,text,text,bigint)'::regprocedure`)).rows[0];
     assert.equal(basis.catalog_entries,true);assert.equal(basis.input_binding,true);
     put('APPROVED_LEDGER_CURRENT_NATIVE_PRIVACY.json',{scope:'NEW_FORWARD_SOURCE_ACTUAL_OWNER_ACL_AND_COMPILED_BASIS_ONLY',
      privacy,basis,accepted_receipts_created:0,materializer_workflow:'NOT_RUN',old_groups_replayed:0});
     }
     put('CURRENT_SOURCE_ON_AUTH_PLATFORM.json',{scope:'NORMAL_CURRENT_SCHEMA_SETUP_ON_NEW_DISPOSABLE_VENDOR_PLATFORM',
      applied,manifestSha256:plan.manifestSha256,automatic_public_defaults_absent:true,old_tests_replayed:0,
      original_private_DATA_import:false,authority_effect_admission:false,production:false});
     let sourceStorage;
     if(captureVendorOriginal){
      // A NEW local original, never a repair/re-sign of the retained incomplete
      // Auth archive. Seed through normal owners/RPCs, then copy one actual
      // exported read-only snapshot with the shipping lossless DATA producer.
      const user=randomUUID(),session=randomUUID(),people=Array.from({length:3},()=>({employee:randomUUID(),user:randomUUID()}));
      await db.query(populatedAuthorityOriginal?'begin isolation level repeatable read':'begin');transaction=true;
      if(populatedAuthorityOriginal){
       await db.query('set local search_path=pg_catalog,pg_temp;set local row_security=off');
       for(const name of ['memphis-zoo-application-mutation-admission','memphis-zoo-application-mutation-fence'])
        await db.query('select pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended($1,0))',[name]);
      }
      if(completeVendorArchive)await db.query(`insert into public.release_deployment_manifest
       (release_id,backend_commit,frontend_commit,migration_head,migration_manifest_sha256,environment_contract_version,status,details_json,created_at,deployed_at,recovery_staged)
       values($1,$2,$3,$4,$5,'UNIT-isolated-immutable-v1','deployed',$6::jsonb,clock_timestamp(),clock_timestamp(),false)`,
       ['UNIT-auth-complete-original-'+randomUUID(),populatedAuthorityOriginal?populatedOriginalSource.commit:'d46866979190ae38022606a5f2fd42a660f324eb',
        populatedAuthorityOriginal?'a20c9f4c4bd6a4e0a97bbd73f8960fd3f8d046f7':'534842b83fd9988ac6bb824a863df899a300986f',
        plan.files.map(file=>file.slice(0,14)).sort().at(-1),plan.manifestSha256,JSON.stringify({production:false,unit_fixture_only:true,actual_deployment:false})]);
      await db.query('set local role supabase_auth_admin');
      await db.query("insert into auth.users(id,aud,role,email,created_at,updated_at) values($1,'authenticated','authenticated',$2,now(),now())",[user,'custodial-unit-'+user+'@example.invalid']);
      await db.query('insert into auth.sessions(id,user_id,created_at,updated_at) values($1,$2,now(),now())',[session,user]);
      await db.query('reset role');
      for(let i=0;i<people.length;i++){
       await db.query("insert into public.employees(id,employee_code,display_name,active,role) values($1,$2,$3,true,'staff')",
        [people[i].employee,'EMP98919'+(i+1),'UNIT Original '+(i+1)]);
       await db.query("insert into public.msg_users(id,employee_id,display_name,role,is_active) values($1,$2,$3,'employee',true)",
        [people[i].user,people[i].employee,'UNIT Original '+(i+1)]);
       await db.query('insert into public.msg_device_assignments(device_identifier,msg_user_id,is_active) values($1,$2,true)',
        ['UNIT_ORIGINAL_'+people[i].user,people[i].user]);
      }
      await db.query('set local role service_role');
      const operation='thread:'+randomUUID();
      const group=(await db.query('select (public.msg_create_group_thread_v2($1,$2,$3::uuid[],$4)).id::text id',
       [people[0].user,'  UNIT Auth-complete original  ',people.slice(1).map(p=>p.user),operation])).rows[0];
      if(populatedAuthorityOriginal){
       await db.query('reset role');
       currentFile='scripts/restore-mutation-gate-tests.mjs::populateRestoredAuthoritySixTargetOriginal';
       const fixture=await import(B+'/scripts/restore-mutation-gate-tests.mjs');
       const fixtureSource=fs.readFileSync(B+'/scripts/restore-mutation-gate-tests.mjs','utf8');
       assert.equal(sha(fixtureSource),populatedOriginalSource.fixture);
       const a=fixtureSource.indexOf('async function sixTargetFixturePort('),b=fixtureSource.indexOf('\nfunction sixTargetExpectedImageSql(',a);
       assert.ok(a>0&&b>a);assert.equal(sha(fixtureSource.slice(a,b)),populatedOriginalSource.constructor);
       const device=randomUUID(),manager=randomUUID(),deviceCode='UNIT_AUTHORITY_FIXTURE_'+people[0].user.toUpperCase();
       assert.match(deviceCode,/^[A-Z0-9_-]{1,64}$/);
       await db.query("insert into public.devices(id,device_id,device_name,active,assigned_employee_id,assignment_epoch) values($1,$2,'UNIT authority fixture',true,$3,1)",
        [device,deviceCode,people[0].employee]);
       await db.query('insert into public.msg_device_assignments(device_identifier,msg_user_id,is_active) values($1,$2,true)',
        [deviceCode,people[0].user]);
       await db.query("insert into public.ops_manager_managers(manager_id,display_name,contact_label,roles,active,is_system_principal) values($1,'UNIT_AUTHORITY_FIXTURE_ manager','UNIT@local.invalid',array['OPS_MANAGER'],true,false)",[manager]);
       const original=await fixture.populateRestoredAuthoritySixTargetOriginal(db,{employeeDeviceId:device,managerId:manager,employeeUserId:people[0].user,groupThreadId:group.id});
       assert.deepEqual(original.expected_effect_counts,['1','2','1','1','1','1']);
       put('POPULATED_AUTHORITY_EXPECTATIONS.json',original);
      }
      await db.query('commit');transaction=false;
      assert.equal(populatedAuthorityOriginal,true,'The nonempty variant is only the full private286 original constructor');
      const sourceInitializer=await import(pathToFileURL(path.join(path.dirname(fileURLToPath(import.meta.url)),'initialize-private286-official-storage-source.mjs')));
      sourceStorage=await sourceInitializer.initializePrivate286OfficialStorageSource({db,container:ownedContainerName,
       network:process.env.G31_PRIVATE_SOURCE_NETWORK,networkId:process.env.G31_PRIVATE_SOURCE_NETWORK_ID,bootstrap,ownerUser:user,out});
      const {productionBackupDataSchemas,productionBackupRowCount,requireProductionBackupPage,
       encodeProductionBackupDataRow,productionBackupDataEncoding,
       encodeProductionBackupTextColumnsDataRow,productionBackupTextColumnsDataEncoding}=await import(B+'/scripts/production-backup-pg-dump-command.mjs');
      let nativeTextProducer;
      if(populatedAuthorityOriginal){
       // Execute the exact fixed private shipping SQL-rendering/profile
       // fragment, not an alternate producer recipe. This fixture still owns
       // its real native snapshot and is NOT the complete backup CLI/provider.
       const producerSource=fs.readFileSync(B+'/scripts/production-backup.mjs','utf8');
       assert.equal(sha(producerSource),populatedOriginalSource.producer);
       const a=producerSource.indexOf('function quoteIdentifier(value) {'),b=producerSource.indexOf('function walkFiles(directory) {',a);
       assert.ok(a>0&&b>a);const fragment=producerSource.slice(a,b);
       const {types}=await import('node:util');
       const fixed=new Function('types',fragment+'\nreturn {projection:backupTextColumnsProjection,settings:backupNativeTextOutputStatements};')(types);
       assert.equal(typeof fixed.projection,'function');
       assert.deepEqual(fixed.settings,['set local extra_float_digits = 3',"set local datestyle = 'ISO, YMD'","set local timezone = 'UTC'","set local intervalstyle = 'postgres'","set local bytea_output = 'hex'"]);
       nativeTextProducer=Object.freeze({...fixed,fragment_sha256:sha(fragment)});
      }
      const originalEncoding=populatedAuthorityOriginal?productionBackupTextColumnsDataEncoding:productionBackupDataEncoding;
      const encodeOriginal=populatedAuthorityOriginal?encodeProductionBackupTextColumnsDataRow:encodeProductionBackupDataRow;
      const {captureProductionBackupOriginalMetadata}=await import(B+'/scripts/production-backup-original-metadata.mjs');
      const {captureCatalogFromSnapshot}=await import(B+'/scripts/schema-catalog-readonly-client.mjs');
      await db.query('begin isolation level repeatable read read only');transaction=true;
      if(nativeTextProducer){
       await db.query('set local search_path=pg_catalog;set local row_security=off');
       for(const statement of nativeTextProducer.settings)await db.query(statement);
      }else await db.query('set local extra_float_digits=3;set local search_path=pg_catalog;set local row_security=off');
      const exported=(await db.query('select pg_export_snapshot() snapshot_id')).rows[0].snapshot_id;
      const snapshot=(await db.query(`select current_database() database_name,current_setting('server_version') server_version,
       current_setting('TimeZone') timezone,transaction_timestamp() captured_at,txid_current_snapshot()::text snapshot_id,$1::text schema_export_snapshot`,[exported])).rows[0];
      const directory=out+'/new-auth-complete-original';fs.mkdirSync(directory,{mode:0o700});
      fs.mkdirSync(directory+'/database',{mode:0o700});fs.mkdirSync(directory+'/inventory',{mode:0o700});
      const write=(name,value)=>fs.writeFileSync(directory+'/'+name,value,{flag:'wx',mode:0o600});
      const metadata=await captureProductionBackupOriginalMetadata(db),catalog=await captureCatalogFromSnapshot(db);
      write('inventory/original-metadata.json',JSON.stringify(metadata,null,2)+'\n');
      write('inventory/source-catalog.json',JSON.stringify(catalog,null,2)+'\n');
      const tables=(await db.query(`select n.nspname schema_name,c.relname table_name,
       coalesce((select jsonb_agg(a.attname order by k.ordinality) from pg_index i cross join lateral unnest(i.indkey) with ordinality k(attnum,ordinality)
        join pg_attribute a on a.attrelid=i.indrelid and a.attnum=k.attnum where i.indrelid=c.oid and i.indisprimary),'[]'::jsonb) primary_key,
       coalesce((select jsonb_agg(jsonb_build_object('name',a.attname,'generated',a.attgenerated,'identity',a.attidentity,'data_type',format_type(a.atttypid,a.atttypmod)) order by a.attnum)
        from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped),'[]'::jsonb) columns
       from pg_class c join pg_namespace n on n.oid=c.relnamespace
       where n.nspname=any($1::text[]) and c.relkind in('r','p') and not c.relispartition order by n.nspname,c.relname`,[productionBackupDataSchemas])).rows;
      const quote=value=>'"'+value.replaceAll('"','""')+'"',tableCatalog=[];let totalRows=0,capturedReleaseOriginal;
      for(const table of tables){
       const target=quote(table.schema_name)+'.'+quote(table.table_name),count=(await db.query('select count(*)::text row_count from only '+target));
       const rowCount=productionBackupRowCount(count),order=table.primary_key.length?table.primary_key.map(quote).join(','):'ctid';
       const rowProjection=nativeTextProducer?nativeTextProducer.projection(table.columns):'row_to_json(snapshot_row)::text';
       const dataFile='database/'+table.schema_name+'.'+table.table_name+'.jsonl',fd=fs.openSync(directory+'/'+dataFile,'wx',0o600);
       try{for(let offset=0;offset<rowCount;offset+=500){
        const reply=await db.query('select '+rowProjection+' row from (select * from only '+target+' order by '+order+' limit $1 offset $2) snapshot_row',[500,offset]);
        for(const row of requireProductionBackupPage(reply,{offset,rowCount,pageSize:500})){
         if(nativeTextProducer&&table.schema_name==='public'&&table.table_name==='release_deployment_manifest'){
          assert.equal(rowCount,1);assert.equal(capturedReleaseOriginal,undefined);capturedReleaseOriginal=row.row;
         }
         fs.writeSync(fd,encodeOriginal(row.row)+'\n');
        }
       }fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
       tableCatalog.push({...table,row_count:String(rowCount),data_file:dataFile,data_encoding:originalEncoding});totalRows+=rowCount;
      }
      for(const section of ['pre-data','post-data']){
       const bytes=execFileSync('/usr/bin/docker',['--host','unix:///var/run/docker.sock','exec',ownedContainerName,
        'pg_dump','-U','supabase_admin','-d','postgres','--schema-only','--section='+section,'--snapshot='+exported],
        {timeout:60000,maxBuffer:32*1024*1024,stdio:['ignore','pipe','pipe']});
       write('inventory/application-schema-'+section+'.sql',bytes);
      }
      write('inventory/table-catalog.json',JSON.stringify(tableCatalog,null,2)+'\n');
      write('inventory/database-snapshot.json',JSON.stringify(snapshot,null,2)+'\n');
      let sealedArchive;
      if(completeVendorArchive){
       const json=value=>JSON.stringify(value,null,2)+'\n',jsonWrite=(name,value)=>write(name,json(value));
       const dump=execFileSync('/usr/bin/docker',['--host','unix:///var/run/docker.sock','exec',ownedContainerName,
        'pg_dump','-U','supabase_admin','-d','postgres','--schema-only','--clean','--if-exists','--snapshot='+exported],
        {timeout:60000,maxBuffer:32*1024*1024,stdio:['ignore','pipe','pipe']});
       write('inventory/application-schema.sql',dump);
       const ledger=(await db.query('select version::text,name::text,statements from supabase_migrations.schema_migrations order by version')).rows;
       const cron=(await db.query(`select json_build_object('jobid',j.jobid::text,'schedule',j.schedule,'command',j.command,
        'nodename',j.nodename,'nodeport',j.nodeport,'database',j.database,'username',j.username,'active',j.active,'jobname',j.jobname) row from cron.job j order by j.jobid`)).rows.map(r=>r.row);
       const extensions=(await db.query('select e.extname,e.extversion,n.nspname schema_name from pg_extension e join pg_namespace n on n.oid=e.extnamespace order by e.extname')).rows;
       // Use the SAME complete raw-row producer as shipping backup. The old
       // hand-picked driver-decoded fields truncate timestamp microseconds
       // and omit recovery_staged. Never weaken the importer's exact check.
       let release;
       if(populatedAuthorityOriginal){
        const {readProductionBackupOriginalRelease}=await import(B+'/scripts/production-backup-original-metadata.mjs');
        release=readProductionBackupOriginalRelease(await db.query("select row_to_json(r)::text original_row from public.release_deployment_manifest r where status='deployed' order by deployed_at desc nulls last,created_at desc,release_id"));
       }else{
        const releases=(await db.query("select release_id,backend_commit,frontend_commit,migration_head,migration_manifest_sha256,environment_contract_version,status,details_json,created_at,deployed_at from public.release_deployment_manifest where status='deployed'")).rows;
        assert.equal(releases.length,1);release=releases[0];
       }
       assert.equal(release.details_json.unit_fixture_only,true);
       // Explicit new UNIT domain, not a production emptiness observation.
       // This image has no Storage API schema; never invent provider tables
       // or treat a failed native SELECT as proof of zero production objects.
       const storageTables=tableCatalog.filter(table=>table.schema_name==='storage');
       assert.ok(storageTables.length>0 && sourceStorage,'Actual official source Storage must precede signed capture');
       assert.equal(tableCatalog.filter(t=>t.schema_name!=='storage').length,302,'All original286 nonStorage tables remain');
       const buckets=sourceStorage.buckets,objects=sourceStorage.objects;
       assert.equal(buckets.length,2);assert.equal(objects.length,2);
        const {validateV4StorageArchiveObjects}=await import(B+'/scripts/disaster-recovery-storage.mjs');
        validateV4StorageArchiveObjects(objects);
       for(const blob of sourceStorage.blobs){fs.mkdirSync(path.dirname(directory+'/'+blob.file),{recursive:true,mode:0o700});write(blob.file,blob.bytes);}
       for(const [name,value]of Object.entries({'migration-ledger':ledger,'cron-jobs':cron,'extensions':extensions,
        'original-relations':metadata.relations,'original-guards':metadata.guards,'original-acls':metadata.acls,
        'storage-buckets':buckets,'storage-objects':objects}))jsonWrite('inventory/'+name+'.json',value);
       const runtimeRoot='/home/eric/Documents/Codex/2026-10-09/task-8/restore-fixture-runtime-inputs-20261017-v1/inventory/';
       const contractBytes=fs.readFileSync(runtimeRoot+'runtime-contract.json'),configurationBytes=fs.readFileSync(runtimeRoot+'runtime-configuration.json');
       assert.equal(sha(contractBytes),'f6506ebe41cdd7d2bf8a9f7e3484c07bb7df9f905c430590ab8e34a278759c6c');
       assert.equal(sha(configurationBytes),'8c375e70c404ea528c238e800439a9febe466178a52d2a56ea82f542597770b3');
       const {loadRecoveryRuntimeContract,validateRecoveryRuntimeConfiguration}=await import(B+'/scripts/disaster-recovery-runtime-contract.mjs');
       const configuration=JSON.parse(configurationBytes),oldBackend=configuration.backend_commit,oldFrontend=configuration.frontend_commit;
       const replace=value=>typeof value==='string'?(value===oldBackend?release.backend_commit:value===oldFrontend?release.frontend_commit:value):
        Array.isArray(value)?value.map(replace):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).map(([k,v])=>[k,replace(v)])):value;
       const currentConfiguration={...replace(configuration),release_id:release.release_id,migration_head:release.migration_head};
       write('inventory/runtime-contract.json',contractBytes);jsonWrite('inventory/runtime-configuration.json',currentConfiguration);
       validateRecoveryRuntimeConfiguration({contract:loadRecoveryRuntimeContract(directory+'/inventory/runtime-contract.json'),configuration:currentConfiguration,
        releaseIdentity:release,projectRef:'abcdefghijklmnopqrst'});
       const sections=['pre-data','post-data'].map(section=>({section,path:'inventory/application-schema-'+section+'.sql',sha256:sha(fs.readFileSync(directory+'/inventory/application-schema-'+section+'.sql'))}));
       const identity={backup_tool_commit:release.backend_commit,backup_tool_tree:populatedAuthorityOriginal?populatedOriginalSource.tree:'540aa5d1be363a23d9804e4ab29c5614fd269a86',migration_head:release.migration_head,
        database_catalog_sha256:sha(fs.readFileSync(directory+'/inventory/table-catalog.json')),application_schema_sha256:sha(dump),application_schema_sections:sections,
        migration_ledger_sha256:sha(fs.readFileSync(directory+'/inventory/migration-ledger.json')),migration_ledger_count:ledger.length,
        cron_jobs_sha256:sha(fs.readFileSync(directory+'/inventory/cron-jobs.json')),cron_job_count:cron.length,
        extensions_sha256:sha(fs.readFileSync(directory+'/inventory/extensions.json')),runtime_contract_sha256:sha(contractBytes),
        runtime_configuration_sha256:sha(fs.readFileSync(directory+'/inventory/runtime-configuration.json')),
        original_relations_sha256:sha(fs.readFileSync(directory+'/inventory/original-relations.json')),
        original_guards_sha256:sha(fs.readFileSync(directory+'/inventory/original-guards.json')),
        original_acls_sha256:sha(fs.readFileSync(directory+'/inventory/original-acls.json')),
        pg_dump_image:'supabase/postgres@sha256:fbf77524fc188126c1775fd2d2e54040bde295438a3e6f07936f3c39e6f688ed',release};
       jsonWrite('inventory/fixture-provenance.json',{fixture_only:true,actual_database_capture:true,original_data_modified:false,
        local_UNIT_release_and_applied_source_ledger_seed:true,actual_deployment:false,runtime_configuration:'SYNTHETIC_UNIT_INPUT',
        Storage:'ACTUAL_OFFICIAL_SOURCE_PRIVATE_PUBLIC_API_OBJECTS_ARCHIVED_VERSIONS',actual_original_source:release.backend_commit,production:false});
       const summary={ok:true,format:'memphis-zoo-disaster-recovery.v4',started_at:snapshot.captured_at,completed_at:new Date().toISOString(),
        project_ref:'abcdefghijklmnopqrst',database_snapshot:snapshot,consistent_database_snapshot:true,backed_up_schemas:productionBackupDataSchemas,
        table_count:tableCatalog.length,database_row_count:totalRows,storage_bucket_count:buckets.length,storage_object_count:objects.length,storage_bytes:objects.reduce((n,o)=>n+o.size_bytes,0),
        source_identity:identity,fixture_only:true,actual_deployment:false};
       jsonWrite('backup-summary.json',summary);
       const members=[];const walk=(base,prefix='')=>{for(const entry of fs.readdirSync(base,{withFileTypes:true})){assert.ok(entry.isDirectory()||entry.isFile());
        const name=prefix+entry.name;if(entry.isDirectory())walk(base+'/'+entry.name,name+'/');else members.push(name);}};walk(directory);
       const sums=members.sort().map(name=>sha(fs.readFileSync(directory+'/'+name))+'  '+name).join('\n')+'\n';write('SHA256SUMS',sums);
       const key=populatedAuthorityOriginal?'UNIT-only-native-text-original-HMAC-20261018':'UNIT-only-auth-complete-original-HMAC-20261017',
        keyId=populatedAuthorityOriginal?'unit-native-text-original-v2':'unit-auth-complete-original-v1',digest=sha(sums);
       const {archiveSignatureBinding,signBinding}=await import(B+'/scripts/disaster-recovery-crypto.mjs');
       jsonWrite('archive-signature.json',{format:'memphis-zoo-disaster-recovery-signature.v1',algorithm:'hmac-sha256',key_id:keyId,archive_digest:digest,
        signature:signBinding(archiveSignatureBinding({archiveDigest:digest,projectRef:summary.project_ref,sourceIdentity:identity,archiveFormat:summary.format}),key)});
       const {materializeVerifiedArchive,readVerifiedPrivateImportSource}=await import(B+'/scripts/disaster-recovery-archive.mjs');
       const verified=materializeVerifiedArchive({sourceDir:directory,archiveVerifyKey:key,archiveVerifyKeyId:keyId,
        supportedFormats:['memphis-zoo-disaster-recovery.v4'],requiredEntries:['backup-summary.json','inventory/table-catalog.json',
         'inventory/application-schema.sql','inventory/original-relations.json','inventory/original-guards.json','inventory/original-acls.json',
         'inventory/migration-ledger.json','inventory/cron-jobs.json','inventory/extensions.json','inventory/runtime-contract.json',
         'inventory/runtime-configuration.json','inventory/storage-buckets.json','inventory/storage-objects.json']});
       try{const source=readVerifiedPrivateImportSource(verified);assert.equal(source.selection.databaseTables.length,tableCatalog.length);assert.equal(source.selection.privateTables.length,2);
        if(populatedAuthorityOriginal){
         // Validate the NEW paired metadata/raw originals through the normal
         // branded Source preparer before the capture can be called usable.
         // No SQL, private DATA import or execution capability is created.
         const {prepareVerifiedImmutableBootstrapSource}=await import(B+'/scripts/immutable-private-source-bootstrap.mjs');
         const prepared=await prepareVerifiedImmutableBootstrapSource(verified);
         assert.equal(prepared.sourceBinding,source.sourceBinding);
         assert.equal(typeof capturedReleaseOriginal,'string');
         assert.equal(prepared.releaseRows[0],capturedReleaseOriginal,'The Source-only preparer retains the SAME actual native TEXT capture, not coerced JS metadata');
         assert.ok(source.selection.databaseTables.every(table=>table.data_encoding===productionBackupTextColumnsDataEncoding));
         assert.equal(release.recovery_staged,false);
        }
       sealedArchive={archive_digest:digest,key_id:keyId,private_tables:source.selection.privateTables.length,actual_source_snapshot:true,
         data_encoding:originalEncoding,producer_file_sha256:nativeTextProducer?populatedOriginalSource.producer:null,
         producer_fragment_sha256:nativeTextProducer?.fragment_sha256??null,complete_backup_CLI:false,provider_storage_observed:true,actual_source_migration_count:sourceStorage.migration_count,
         complete_restore:false,authority_effects:false,signature_kind:'EXPLICITLY_AUTHORIZED_DISPOSABLE_LOCAL_TEST_HMAC_NOT_APK_OR_REAL_KEY'};
       }finally{verified.cleanup();}
      }
      const originalSession=(await db.query('select row_to_json(s)::text original from auth.sessions s where id=$1',[session])).rows;
      assert.equal(originalSession.length,1);assert.ok(tableCatalog.some(t=>t.schema_name==='auth'&&t.table_name==='sessions'&&t.row_count==='1'));
      await db.query('rollback');transaction=false;
      put('NEW_AUTH_COMPLETE_ORIGINAL_CAPTURE.json',{scope:completeVendorArchive?'NEW_DISPOSABLE_PRIVATE286_OFFICIAL_STORAGE_SIGNED_NATIVE_SNAPSHOT_NOT_RESTORE':'ACTUAL_NEW_DISPOSABLE_LOCAL_ORIGINAL_SNAPSHOT_NOT_YET_SEALED_ARCHIVE',
       snapshot,table_count:tableCatalog.length,total_rows:totalRows,actual_auth_session:{id:session,user_id:user,original:originalSession[0].original},
       actual_group_original:{thread_id:group.id,operation},data_source:'ONE_EXPORTED_NATIVE_READ_ONLY_SNAPSHOT',lossless_data_encoding:originalEncoding,
       directory,sealed_archive:sealedArchive??null,source_commit:populatedAuthorityOriginal?populatedOriginalSource.commit:'d46866979190ae38022606a5f2fd42a660f324eb',authority_effects:false,restore_executed:false,
       public_production_recipient_or_real_keys:false,old_originals_modified:false,old_groups_replayed:0});
     }
    }catch(error){
     const rollback=await db.query('rollback').then(value=>value.command).catch(()=>null);
     put('CURRENT_SOURCE_FIRST_FAILURE.json',{file:currentFile,applied_count:applied.length,applied,
      code:error.code??null,message:error.message,where:error.where??null,rollback,
      scope:'Actual normal Source setup/new forward SQL failure, no permission/grant/guard fallback'});
     if(purpose==='vendor-auth-current-source-repaired'&&rollback==='ROLLBACK'
       &&currentFile==='20261017225101_approved_static_dated_original_materialization.sql'
       &&error.code==='P0001'&&error.message==='Approved dated exact Source owner canary inventory or ALWAYS predecessor differs'){
      // Only current catalog predicates after the FAILED migration rolled
      // back. Do not skip a guard, execute a partial installer or adopt it.
      let metadata,diagnosticOpened=false;
      try{
       await db.query('begin isolation level repeatable read read only');diagnosticOpened=true;
       await db.query("set local search_path=pg_catalog,public,extensions;set local statement_timeout='8s'");
       metadata=(await db.query(`with actor as(select oid from pg_roles where rolname=current_user),
        surface as(select p.oid,p.proowner,pg_get_functiondef(p.oid) definition from pg_proc p
          where p.oid='public.custodial_release_canary_authority_surface()'::regprocedure)
        select current_user actor,session_user session_actor,
         (select pg_get_userbyid(relowner) from pg_class where oid='public.custodial_release_authority_restore_inventory'::regclass) inventory_owner,
         (select pg_get_userbyid(proowner) from surface) surface_owner,
         (select count(*)::int from public.custodial_release_authority_restore_inventory where definition_sha256 is distinct from public.static_weekly_digest_text(definition_sql)) self_hash_mismatches,
         (select (length(definition)-length(replace(definition,'  values','')))/length('  values') from surface) exact_values_marker_count,
         (select count(*)::int from public.custodial_release_authority_restore_inventory i,surface s where i.object_kind='function'
          and i.object_identity like '%(%' and to_regprocedure(i.object_identity)=s.oid
          and i.definition_sql=s.definition and i.definition_sha256=public.static_weekly_digest_text(s.definition)) exact_function_inventory_count,
         (select count(*)::int from public.custodial_release_authority_restore_inventory i,surface s where i.object_kind='grant'
          and i.object_identity like '%(%' and to_regprocedure(i.object_identity)=s.oid
          and i.definition_sql=public.custodial_release_authority_current_grant_definition(i.object_identity)) exact_grant_inventory_count,
         (select jsonb_agg(jsonb_build_object('tgtype',t.tgtype,'tgenabled',t.tgenabled,'tgnargs',t.tgnargs,
          'argument_bytes',octet_length(t.tgargs),'null_qual',t.tgqual is null,'attribute_text',t.tgattr::text,
          'exact_function',t.tgfoid='public.custodial_reject_release_authority_inventory_mutation()'::regprocedure))
          from pg_trigger t where t.tgrelid='public.custodial_release_authority_restore_inventory'::regclass
           and t.tgname='trg_custodial_release_authority_restore_inventory_immutable' and not t.tgisinternal) triggers`)).rows;
      }catch(diagnostic){metadata={available:false,sql_state:/^[0-9A-Z]{5}$/.test(diagnostic?.code||'')?diagnostic.code:null};}
      finally{if(diagnosticOpened)await db.query('rollback');}
      put('DATED_INSTALL_PREDECESSOR_NATIVE_PREDICATES.json',{metadata,read_only:true,failed_migration_rolled_back:true,
       Source_only:true,operational_DATA:false,guard_skipped:false,product_pass:false,old_groups_replayed:0});
     }
     throw error;
    }
   }
   await db.query('begin isolation level repeatable read read only');transaction=true;
   await db.query("set local statement_timeout='8s';set local lock_timeout='2s'");
   const identity=(await db.query(`select current_user actor,session_user session_actor,current_database() database,
    d.oid::text database_oid,r.rolname database_owner,pg_backend_pid() backend_pid,
    current_setting('transaction_read_only') read_only from pg_database d join pg_roles r on r.oid=d.datdba
    where d.datname=current_database()`)).rows[0];
   const roles=(await db.query(`select oid::text oid,rolname,rolcanlogin,rolinherit,rolsuper,rolbypassrls
    from pg_roles where rolname in ('supabase_auth_admin','postgres','supabase_admin') order by rolname`)).rows;
   const authRole=roles.find(row=>row.rolname==='supabase_auth_admin');
   const namespace=(await db.query(`select n.oid::text oid,n.nspname,r.rolname owner
    from pg_namespace n join pg_roles r on r.oid=n.nspowner where n.nspname='auth'`)).rows;
   const privileges=authRole?(await db.query(`select has_database_privilege('supabase_auth_admin',current_database(),'CONNECT') db_connect,
    has_database_privilege('supabase_auth_admin',current_database(),'CREATE') db_create,
    case when to_regnamespace('auth') is not null then has_schema_privilege('supabase_auth_admin','auth','USAGE') else false end auth_usage,
    case when to_regnamespace('auth') is not null then has_schema_privilege('supabase_auth_admin','auth','CREATE') else false end auth_create`)).rows[0]:null;
   const relations=(await db.query(`select c.relname,c.relkind,r.rolname owner,c.relrowsecurity,c.relforcerowsecurity
    from pg_class c join pg_namespace n on n.oid=c.relnamespace join pg_roles r on r.oid=c.relowner
    where n.nspname='auth' and c.relkind in ('r','p','v','m','S') order by c.relname`)).rows;
   const migrations=(await db.query('select version from auth.schema_migrations order by version')).rows;
   if(purpose==='vendor-auth-enum-io-diagnostic'){
    const enums=(await db.query(`select n.nspname,pg_get_userbyid(n.nspowner) namespace_owner,
     t.typname,pg_get_userbyid(t.typowner) owner,t.typtype,t.typcategory,t.typisdefined,t.typbasetype::text,
     t.typrelid::text,t.typelem::text,t.typarray::text,t.typcollation::text,t.typlen,t.typbyval,t.typdefault,t.typdefaultbin::text,
     t.typinput::regprocedure::text input,t.typoutput::regprocedure::text output,
     (select jsonb_agg(e.enumlabel order by e.enumsortorder) from pg_enum e where e.enumtypid=t.oid) labels,
     (select count(*)::text from pg_cast c where c.castsource in(t.oid,t.typarray) or c.casttarget in(t.oid,t.typarray)) explicit_casts
     from pg_type t join pg_namespace n on n.oid=t.typnamespace where n.nspname='auth' and t.typtype='e' order by t.typname`)).rows;
    const io=(await db.query(`select p.oid::regprocedure::text identity,p.prosrc,p.probin,p.prorettype::regtype::text return_type,
     pg_get_userbyid(p.proowner) owner,n.nspname,l.lanname,p.prokind,p.prosecdef,p.proretset,p.proconfig
     from pg_proc p join pg_namespace n on n.oid=p.pronamespace join pg_language l on l.oid=p.prolang
     where n.nspname='pg_catalog' and p.proname in('enum_in','enum_out','array_in','array_out') order by p.proname`)).rows;
    put('AUTH_ENUM_IO_NATIVE_DIAGNOSTIC.json',{enums,io,actual_read_only:true,original_restore:false,
     expected_original_types_not_adopted:true,application_schema_replayed:0,DATA_imports:0,effects:0,production:false});
   }
   if(vendorCurrentSource||purpose==='vendor-auth-fixture-migrate'||purpose==='vendor-auth-fixture-migrate-config'){
    assert.equal(authRole?.rolcanlogin,true);assert.equal(privileges.auth_usage,true);assert.equal(privileges.auth_create,true);
    assert.ok(relations.some(row=>row.relname==='sessions'&&row.owner==='supabase_auth_admin'));
   }
   assert.equal(identity.read_only,'on');
   await db.query('rollback');transaction=false;
   put('VENDOR_AUTH_PREREQUISITES.json',{scope:'NEW_OWNED_CACHED_IMAGE_EXISTING_AUTH_PREREQUISITES_ONLY',
    identity,roles,namespace,privileges,relations,migrations,transaction:'ROLLED_BACK',actual_SQL:true,
    vendor_migration_executed_before_snapshot:vendorCurrentSource||purpose==='vendor-auth-fixture-migrate'||purpose==='vendor-auth-fixture-migrate-config',
    application_source_schema_setup:vendorCurrentSource,ad_hoc_role_or_grant_changes_by_fixture:0,credentials_inspected:false,auth_server_started:false,
    complete_restore:false,production:false,old_groups_replayed:0});
  }else if(purpose==='original-data-native-text-roundtrip'){
   await db.query('begin isolation level repeatable read read only');transaction=true;
   const preflight=(await db.query("select current_user actor,current_setting('transaction_read_only') read_only,current_setting('server_version') version")).rows[0];
   assert.equal(preflight.actor,'supabase_admin');assert.equal(preflight.read_only,'on');
   await db.query('rollback');transaction=false;
   await db.query('begin');transaction=true;
   await db.query("set local statement_timeout='8s';set local lock_timeout='2s'");
   const source=fs.readFileSync(B+'/proposals/immutable-private-owner-context.sql','utf8');
   assert.equal(sha(source),'984a3324024b152bfddc36a42d32da8c0d19e0962ff1e5885562d462a3f3300f');
   const codec=await import(B+'/scripts/production-backup-pg-dump-command.mjs');
   await db.query('create schema if not exists custodial_dr');
   const installed=[];
   for(const name of ['immutable_import_text_projection','immutable_import_text_record']){
    const start=source.indexOf('CREATE FUNCTION custodial_dr.'+name+'('),end=source.indexOf('END $fn$;',start);
    assert.ok(start>0&&end>start);
    const definition=source.slice(start,end+'END $fn$;'.length);installed.push({name,sha256:sha(definition)});
    await db.query(definition);
   }
   await db.query(`do $acl$ declare f record;a record;begin
    for f in select p.oid,p.proowner from pg_proc p join pg_namespace n on n.oid=p.pronamespace
     where n.nspname='custodial_dr' and p.proname in('immutable_import_text_record','immutable_import_text_projection') loop
     for a in select grantee from aclexplode(coalesce((select proacl from pg_proc where oid=f.oid),acldefault('f',f.proowner))) where grantee<>f.proowner loop
      execute format('revoke all on function %s from %s',f.oid::regprocedure,case when a.grantee=0 then 'PUBLIC' else quote_ident(pg_get_userbyid(a.grantee)) end);
     end loop;
    end loop;end $acl$`);
   await db.query('create domain public.custodial_text_codec_json as json');
   const columns='id bigint,j json,jb jsonb,ja json[],n numeric(60,20),f double precision,b bytea,ts timestamptz,iv interval,d public.custodial_text_codec_json';
   await db.query('create table public.custodial_text_codec_original('+columns+');create table public.custodial_text_codec_restored('+columns+')');
   const rows=[
    ['1',null,null,'[0:1]={NULL,"null"}','9007199254740993.12345678901234567890','1.0000000000000002','00ff','2026-10-18T04:00:00.123456Z','1 mon 2 days 03:04:05.123456',null],
    ['2','null','null','[0:1]={"null",NULL}','-9007199254740993.12345678901234567890','1.0000000000000004','ff00','2026-10-17T23:00:00.123456-05:00','-1 mon -2 days -03:04:05.123456','null'],
    ['3','{"a": 1,"a":2,"zero":"\\u0000"}','{"z":1,"a":2}','[2:3]={"null",NULL}','1.00000000000000000001','0.000000000000000001','0123','2026-10-18T04:00:00Z','3 days','{"a": 1,"a":2}'],
   ];
   for(const r of rows)await db.query('insert into public.custodial_text_codec_original values($1::bigint,$2::json,$3::jsonb,$4::json[],$5::numeric,$6::float8,decode($7,\'hex\'),$8::timestamptz,$9::interval,$10::public.custodial_text_codec_json)',r);
   const originals=(await db.query('select id::text,custodial_dr.immutable_import_text_projection(o) raw from public.custodial_text_codec_original o order by id')).rows;
   const hashes=[];
   for(const original of originals){
    const line=codec.encodeProductionBackupTextColumnsDataRow(original.raw),raw=codec.decodeProductionBackupTextColumnsDataRow(line);
    assert.equal(raw,original.raw);
    const inserted=await db.query('insert into public.custodial_text_codec_restored select r.* from custodial_dr.immutable_import_text_record(null::public.custodial_text_codec_restored,$1) r returning custodial_dr.immutable_import_text_projection(custodial_text_codec_restored) raw',[raw]);
    assert.equal(inserted.rowCount,1);assert.equal(inserted.rows[0].raw,raw);hashes.push(sha(raw));
   }
   const observed=(await db.query(`select id::text,j is null j_sql_null,json_typeof(j) j_kind,jb is null jb_sql_null,jsonb_typeof(jb) jb_kind,
    array_dims(ja) dimensions,ja[array_lower(ja,1)] is null first_sql_null,ja[array_lower(ja,1)+1] is null second_sql_null,
    d is null d_sql_null,json_typeof(d) d_kind from public.custodial_text_codec_restored order by id`)).rows;
   assert.deepEqual(observed[0],{id:'1',j_sql_null:true,j_kind:null,jb_sql_null:true,jb_kind:null,dimensions:'[0:1]',first_sql_null:true,second_sql_null:false,d_sql_null:true,d_kind:null});
   assert.deepEqual(observed[1],{id:'2',j_sql_null:false,j_kind:'null',jb_sql_null:false,jb_kind:'null',dimensions:'[0:1]',first_sql_null:false,second_sql_null:true,d_sql_null:false,d_kind:'null'});
   assert.equal(observed[2].dimensions,'[2:3]');
   const catalog=(await db.query(`select p.oid::regprocedure::text identity,p.prosecdef,
    exists(select 1 from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee<>p.proowner) nonowner_execute
    from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='custodial_dr'
     and p.proname in('immutable_import_text_record','immutable_import_text_projection') order by p.proname`)).rows;
   assert.equal(catalog.length,2);assert.ok(catalog.every(row=>row.prosecdef===false&&row.nonowner_execute===false));
   let rejected=0;
   const base=JSON.parse(originals[0].raw);
   const invalid=[JSON.stringify({...base,j:1}),JSON.stringify({...base,extra:null}),JSON.stringify(Object.fromEntries(Object.entries(base).filter(([key])=>key!=='j'))),
    '{"id":"1",'+originals[0].raw.slice(1),JSON.stringify({...base,n:'1234567890123456789012345678901234567890123456789012345678901234567890'}),JSON.stringify({...base,n:'1.000000000000000000001'})];
   for(const raw of invalid){
    await db.query('savepoint rejected_original');let refused=false;
    try{await db.query('select * from custodial_dr.immutable_import_text_record(null::public.custodial_text_codec_restored,$1)',[raw]);}catch{refused=true;}
    await db.query('rollback to savepoint rejected_original');await db.query('release savepoint rejected_original');assert.equal(refused,true);rejected++;
   }
   await db.query('savepoint denied_codec');await db.query('set local role anon');let denied;
   try{await db.query('select custodial_dr.immutable_import_text_projection(null::public.custodial_text_codec_original)');}catch(error){denied=error.code;}
   await db.query('rollback to savepoint denied_codec');await db.query('release savepoint denied_codec');assert.equal(denied,'42501');
   assert.deepEqual((await db.query('select custodial_dr.immutable_import_text_projection(r) raw from public.custodial_text_codec_restored r order by id')).rows.map(row=>sha(row.raw)),hashes);
   await db.query('rollback');transaction=false;
   assert.equal((await db.query("select to_regclass('public.custodial_text_codec_original') is null absent")).rows[0].absent,true);
   put('PRODUCT_RESULT.json',{scope:'NEW_ACTUAL_SOURCE_NATIVE_TEXT_RECORD_CODEC_ROUNDTRIP',actual_SQL:true,preflight,installed,
    rows:originals.length,row_sha256:hashes,SQL_NULL_JSON_null_and_domain_preserved:true,array_bounds_and_NULL_elements_preserved:true,
    original_json_lexical_text_and_native_values_preserved:true,malformed_or_lossy_cast_refusals:rejected,actual_anon_denial:denied,
    invoker_only_nonowner_execute_absent:true,transaction:'OWN_FIXTURE_ROLLED_BACK',target_objects_absent:true,
    authenticated_original_archive_restore:false,context_or_effect_admission:false,whole_G31:false,old_groups_replayed:0});
  }else if(purpose==='original-data-json-null-profile'){
   await db.query('begin isolation level repeatable read read only');transaction=true;
   await db.query("set local statement_timeout='8s';set local lock_timeout='2s'");
   const codec=await import(B+'/scripts/production-backup-pg-dump-command.mjs');
   const archiveApi=await import(B+'/scripts/disaster-recovery-archive.mjs');
   const backupSource=fs.readFileSync(B+'/scripts/production-backup.mjs','utf8');
   assert.ok(backupSource.includes('select row_to_json(snapshot_row)::text as row from'));
   const results=[];
   for(const type of ['json','jsonb']){
    const observed=(await db.query(`with originals(kind,payload) as
      (values ('SQL_NULL'::text,null::${type}),('JSON_NULL'::text,'null'::${type}))
     select o.kind,o.payload is null sql_null,pg_catalog.${type}_typeof(o.payload) json_kind,
      pg_catalog.row_to_json(x)::text original_row
     from originals o cross join lateral(select o.payload as payload) x order by o.kind`)).rows;
    assert.equal(observed.length,2);
    const a=observed.find(row=>row.kind==='SQL_NULL'),b=observed.find(row=>row.kind==='JSON_NULL');
    assert.equal(a.sql_null,true);assert.equal(a.json_kind,null);
    assert.equal(b.sql_null,false);assert.equal(b.json_kind,'null');
    assert.equal(a.original_row,b.original_row);
    const encoded=observed.map(row=>codec.encodeProductionBackupDataRow(row.original_row));
    assert.equal(encoded[0],encoded[1]);
    const table={data_encoding:codec.productionBackupDataEncoding,
     columns:[{name:'payload',data_type:type,generated:'',identity:''}]};
    const decoded=encoded.map(line=>archiveApi.decodeRestoreTableRowLine(line,table));
    assert.equal(decoded[0],decoded[1]);assert.equal(decoded[0],a.original_row);
    results.push({native_type:type,SQL_null_and_JSON_null_are_distinct:true,
     producer_raw_rows_identical:true,shipping_encoded_lines_identical:true,
     shipping_decoded_rows_identical:true,row_sha256:sha(a.original_row)});
   }
   await db.query('rollback');transaction=false;
   put('PRODUCT_RESULT.json',{scope:'NEW_NATIVE_SQL_NULL_JSON_NULL_SHIPPING_CODEC_COUNTEREXAMPLE',
    outcome:'DATA_FIDELITY_DEFECT_REPRODUCED_NOT_PRODUCT_PASS',actual_SQL:true,results,
    encoding:codec.productionBackupDataEncoding,target_objects_written:0,
    transaction:'OWN_READ_ONLY_ROLLED_BACK',normal_backup_capture_or_restore:false,
    whole_G31:false,old_numeric_groups_replayed:0,permissions_changed:false});
  }else if(purpose==='original-data-numeric-output-profile'){
   await db.query('begin isolation level repeatable read read only');transaction=true;
   const originalSetting=(await db.query("select current_setting('extra_float_digits') value")).rows[0].value;
   const sql=`with x(value) as (values (1::double precision),(1.0000000000000002::double precision))
    select count(distinct value)::text native_distinct,count(distinct row_to_json(x)::text)::text text_distinct,
      current_setting('extra_float_digits') profile from x`;
   await db.query('set local extra_float_digits=0');const lossy=(await db.query(sql)).rows[0];
   assert.equal(lossy.native_distinct,'2');assert.equal(lossy.text_distinct,'1');assert.equal(lossy.profile,'0');
   await db.query('set local extra_float_digits=3');const lossless=(await db.query(sql)).rows[0];
   assert.equal(lossless.native_distinct,'2');assert.equal(lossless.text_distinct,'2');assert.equal(lossless.profile,'3');
   await db.query('rollback');transaction=false;
   assert.equal((await db.query("select current_setting('extra_float_digits') value")).rows[0].value,originalSetting);
   put('PRODUCT_RESULT.json',{scope:'NEW_NATIVE_NUMERIC_OUTPUT_PREREQUISITE_ONLY',actual_SQL:true,
    observed_current_default:originalSetting,lossy,lossless,rollback:'OWN_READ_ONLY_TRANSACTION',settings_restored:true,
    target_objects_written:0,whole_G31:false,normal_restore_or_effect_authority:false,old_groups_replayed:0});
  }else if(legacyFidelityNative){
   // Actual shipping methods and REAL managed PG clients: no extracted
   // prefix, query/prototype replacement or reconstructed private ancestry.
   const archiveApi=await import(B+'/scripts/disaster-recovery-archive.mjs');
   const crypto=await import(B+'/scripts/disaster-recovery-crypto.mjs');
   const importer=await import(B+'/scripts/immutable-private-data-import.mjs');
   const source=path.resolve(D,'../restore-runtime-authorized-KM9tAR/populated-raw-release-original-v109-9WKkdl/new-auth-complete-original');
   const originalDigest='c2ca572a9b54f9e3f02f3136fbe42a590857778f310edd32e54315edd3554ef0';
   assert.equal(sha(fs.readFileSync(path.join(source,'SHA256SUMS'))),originalDigest);
   const snapshotSql=`select pg_backend_pid()::text backend_pid,current_database() database,
    txid_current_if_assigned()::text assigned_transaction_id,
    (select jsonb_agg(jsonb_build_array(n.oid::text,n.nspname,n.nspowner::text) order by n.oid)
      from pg_namespace n) namespaces,
    (select jsonb_agg(jsonb_build_array(c.oid::text,c.relnamespace::text,c.relname,c.relkind,c.relowner::text) order by c.oid)
      from pg_class c) relations`;
   const observations=[];
   for(const method of ['stageVerifiedImmutableFreshData','stageVerifiedImmutablePrivateData']){
    let archive;
    try{
     archive=archiveApi.materializeVerifiedArchive({sourceDir:source,
      archiveVerifyKey:'UNIT-only-auth-complete-original-HMAC-20261017',archiveVerifyKeyId:'unit-auth-complete-original-v1'});
     const binding=archiveApi.readVerifiedArchiveSourceBinding(archive);assert.equal(binding.archive_digest,originalDigest);
     const copy=fs.lstatSync(archive.directory);put('LEGACY_NATIVE_COPY_'+method+'.json',{
      directory:archive.directory,dev:copy.dev,ino:copy.ino,uid:copy.uid,mode:copy.mode&511});
     const now=Date.now(),release={};
     for(const key of ['release_id','backend_commit','frontend_commit','migration_head','migration_manifest_sha256'])release[key]=binding.source_identity.release[key];
     const intent={restore_id:randomUUID(),authority_generation:1,retry_of_restore_id:null,
      archive_digest:binding.archive_digest,source_project_ref:binding.project_ref,target_project_ref:binding.project_ref,
      source_identity_sha256:binding.source_identity_sha256,target_migration_head:binding.source_identity.migration_head,
      target_release_identity:release,actor:'UNIT legacy native preinitializer refusal',approved_at:new Date(now).toISOString(),
      expires_at:new Date(now+15*60*1000).toISOString(),resume_after_verification:false};
     const key='UNIT-only-legacy-native-intent-HMAC-20261018',keyId='unit-legacy-native-intent-v1';
     const envelope={format:'memphis-zoo-production-restore-intent.v1',algorithm:'hmac-sha256',key_id:keyId,intent,
      signature:crypto.signBinding(crypto.restoreIntentBinding(intent),key)};
     await db.query('begin');transaction=true;
     const before=(await db.query(snapshotSql)).rows[0];
     assert.equal(before.database,ownedContainerName);assert.equal(before.assigned_transaction_id,null);
     let failure;
     try{await importer[method]({db,verifiedArchive:archive,originalIntentEnvelope:envelope,intentVerifyKey:key,intentVerifyKeyId:keyId});}
     catch(error){failure=error;}
     assert.ok(failure);assert.equal(failure.code,'IMMUTABLE_LEGACY_DATA_FIDELITY_UNPROVEN');
     assert.equal(failure.outcome,'UNKNOWN');assert.equal(failure.retry_safe,false);
     assert.equal(Object.hasOwn(failure,'cause'),false);
     const after=(await db.query(snapshotSql)).rows[0];assert.deepEqual(after,before);
     assert.equal(after.assigned_transaction_id,null,'No DDL/DML transaction ID may have been assigned');
     await db.query('rollback');transaction=false;
     observations.push({method,code:failure.code,native_client:true,signed_original_intent:true,
      native_transaction_id_unassigned_before_and_after:true,all_catalog_relations_and_namespaces_unchanged:true,
      archive_digest:binding.archive_digest,rollback:'ACKNOWLEDGED',COMMIT_attempted:false,
      initializer_DDL_or_import_DML:false,unknown_is_error_DATA_not_a_COMMIT_outcome:true});
    }finally{if(archive){const directory=archive.directory;archive.cleanup();assert.equal(fs.existsSync(directory),false);}}
   }
   assert.equal(sha(fs.readFileSync(path.join(source,'SHA256SUMS'))),originalDigest);
   put('PRODUCT_RESULT.json',{scope:'NEW_ACTUAL_NATIVE_MANDATORY_LEGACY_FIDELITY_BEFORE_INITIALIZER_AND_DIRECT_MUTATION',
    actual_SQL:true,observations,original_unchanged:true,original_digest:originalDigest,
    target_objects_written:0,Source_initializer_runs:0,private_IMPORT_runs:0,COMMIT_attempts:0,
    native_positive_restore:false,whole_G31:false,A2:'OPEN',old_groups_replayed:0,
    limits:'Actual preflight refuses unsupported original type before effects through both shipping stage methods. Does not prove every later legacy ambiguity, safe legacy restoration, v2 positive workflow, owner/RLS/ACL or full restore.'});
  }else if(storageSupportedSampler){
   const {runStorageSupportedSamplerNativeCase}=await import(B+'/scripts/disaster-recovery-storage-tests.mjs');
   const profiles=[];
   for(const profile of ['SAFE_NATIVE','BIGINT_REFUSED','FRACTION_REFUSED'])profiles.push(await runStorageSupportedSamplerNativeCase(db,profile));
   assert.equal(db._txStatus,'I');assert.equal(db.queryQueue.length,0);
   put('PRODUCT_RESULT.json',{scope:'ONLY_CHANGED_STORAGE_SUPPORTED_SAMPLER_NATIVE_SQL_READ_PATH',
    profiles,actual_SQL:true,transaction:'EACH_FIXED_UNIT_SETUP_AND_READ_ROLLED_BACK',fixture_objects_absent:true,
    provider:false,archives_or_signatures_created:false,private_context_or_restore_effect:false,
    whole_G31:false,A2:'OPEN',old_groups_replayed:0});
  }else if(storageOriginalSql){
   // Same already-qualified provisioning control as the normal fresh CLI:
   // assign the required owner only to THIS new, empty image-created target,
   // before test/archive/Source rows. Never adopt an existing database.
   assert.match(ownedContainerName,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);
   const initial=(await db.query(`select current_database() database,pg_get_userbyid(datdba) owner,
    (select count(*)::int from pg_catalog.pg_class c join pg_catalog.pg_namespace n on n.oid=c.relnamespace where n.nspname='public') public_objects
    from pg_catalog.pg_database where datname=current_database()`)).rows[0];
   assert.equal(initial.database,ownedContainerName);assert.equal(initial.public_objects,0);
   assert.ok(['postgres','supabase_admin'].includes(initial.owner));
   if(initial.owner!=='postgres')await db.query('alter database "'+ownedContainerName+'" owner to postgres');
   assert.equal((await db.query('select pg_get_userbyid(datdba) owner from pg_catalog.pg_database where datname=current_database()')).rows[0].owner,'postgres');
   put('NEW_EMPTY_DATABASE_OWNER_PREREQUISITE.json',{initial,required_owner:'postgres',existing_target_adopted:false,
    stage:'before UNIT rows/archive/test',roles_grants_HBA_or_product_guards_changed:false});
   const {runStorageOriginalOwningSqlCase,runStorageExactCheckpointNativeCase,STORAGE_ORIGINAL_UNIT_INPUT}=await import(B+'/scripts/disaster-recovery-storage-tests.mjs');
   const {materializeVerifiedArchive}=await import(B+'/scripts/disaster-recovery-archive.mjs');
   if(purpose==='storage-original-table-match'||storageCheckpointCaller){
    const inputFile='/home/eric/Documents/Codex/2026-10-09/task-9/typed-text-storage-native-workflow-20261018-v1/inputs/UNIT_STORAGE_V2_INPUT.json';
    const inputBytes=fs.readFileSync(inputFile),input=JSON.parse(inputBytes),fixed=STORAGE_ORIGINAL_UNIT_INPUT.text_columns_v2;
    assert.equal(sha(inputBytes),'9eeac5819158873bafb075282062cde9e210e73b75d4e7242cda47c9da436194');
    assert.equal(input.data_encoding,'postgres-text-columns-line.v2');
    for(const key of ['fixture_id','project_ref','source_uri','create_sql','seed_sql','seed_rows','profiles','source_variant_profiles'])assert.deepEqual(input[key],fixed[key]);
    await db.query('begin isolation level repeatable read');transaction=true;
    await db.query("set local search_path=pg_catalog,pg_temp;set local row_security=off;set local extra_float_digits=3;set local datestyle='ISO, YMD';set local timezone='UTC';set local intervalstyle='postgres';set local bytea_output='hex'");
    const settings=(await db.query(`select current_user actor,session_user session_actor,
     current_setting('extra_float_digits') float_digits,current_setting('DateStyle') date_style,current_setting('TimeZone') timezone,
     current_setting('IntervalStyle') interval_style,current_setting('bytea_output') bytea_output,
     to_regnamespace('custodial_dr') prior_private_namespace`)).rows[0];
    assert.deepEqual(settings,{actor:'supabase_admin',session_actor:'supabase_admin',float_digits:'3',date_style:'ISO, YMD',
     timezone:'UTC',interval_style:'postgres',bytea_output:'hex',prior_private_namespace:null});
    // Existing pure DATA recipes only. Exact original complete table DDL is
    // retained for native owner provenance, never a one-column owner stub.
    // Both ancestry tables remain EMPTY; no begin/arm/effect function exists.
    const source=fs.readFileSync(B+'/proposals/immutable-private-owner-context.sql','utf8');
    assert.equal(sha(source),'f0c870ea6691552b47daa8eb962645512b74cdd8d26078cef05a42f52116fc55');
    const control=fs.readFileSync(B+'/supabase/migrations/20260820125325_custodial_disaster_restore_generation_authority.sql','utf8');
    assert.equal(sha(control),'315853219694bc7c05e26fd83b10f673acd561a4507bafb4229fa861cf004715');
    await db.query('create schema custodial_dr authorization postgres');
    const controlStart=control.indexOf('create table if not exists custodial_dr.restore_control ('),controlEnd=control.indexOf('\n);',controlStart);
    assert.ok(controlStart>=0&&controlEnd>controlStart);await db.query(control.slice(controlStart,controlEnd+3));
    const ctxStart=source.indexOf('CREATE TABLE custodial_dr.immutable_private_import_context('),ctxEnd=source.indexOf('\n);',ctxStart);
    assert.ok(ctxStart>0&&ctxEnd>ctxStart);await db.query(source.slice(ctxStart,ctxEnd+3));
    await db.query('ALTER TABLE custodial_dr.immutable_private_import_context ENABLE ROW LEVEL SECURITY');
    await db.query('ALTER TABLE custodial_dr.immutable_private_import_context FORCE ROW LEVEL SECURITY');
    const installed=[];
    for(const name of ['immutable_import_text_projection','immutable_import_text_record']){
     const start=source.indexOf('CREATE FUNCTION custodial_dr.'+name+'('),end=source.indexOf('END $fn$;',start);
     assert.ok(start>0&&end>start);const definition=source.slice(start,end+'END $fn$;'.length);
     await db.query(definition);installed.push({name,definition_sha256:sha(definition)});
    }
    // Same Source owner-only ACL cleanup pattern as the existing pure-codec
    // prerequisite. REVOKE only on THESE new objects; never GRANT/new roles,
    // change an existing role/owner/default, or expose an effect/context API.
    await db.query(`do $acl$ declare f record;a record;begin
     for f in select c.oid,c.relowner from pg_class c where c.oid in
      ('custodial_dr.restore_control'::regclass,'custodial_dr.immutable_private_import_context'::regclass) loop
      for a in select grantee from aclexplode(coalesce((select relacl from pg_class where oid=f.oid),acldefault('r',f.relowner))) where grantee<>f.relowner loop
       execute format('revoke all on table %s from %s',f.oid::regclass,case when a.grantee=0 then 'PUBLIC' else quote_ident(pg_get_userbyid(a.grantee)) end);
      end loop;
     end loop;
     for f in select p.oid,p.proowner from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='custodial_dr' and p.proname in('immutable_import_text_record','immutable_import_text_projection') loop
      for a in select grantee from aclexplode(coalesce((select proacl from pg_proc where oid=f.oid),acldefault('f',f.proowner))) where grantee<>f.proowner loop
       execute format('revoke all on function %s from %s',f.oid::regprocedure,case when a.grantee=0 then 'PUBLIC' else quote_ident(pg_get_userbyid(a.grantee)) end);
      end loop;
     end loop;end $acl$`);
    const codec=await import(B+'/scripts/production-backup-pg-dump-command.mjs');
    const {archiveSignatureBinding,signBinding,stableJson}=await import(B+'/scripts/disaster-recovery-crypto.mjs');
    assert.equal(codec.productionBackupTextColumnsDataEncoding,input.data_encoding);
    await db.query('savepoint storage_v2_original_capture');
    await db.query(input.create_sql);
    for(const row of input.seed_rows)assert.equal((await db.query(input.seed_sql,row)).rowCount,1);
    const captured=(await db.query('select custodial_dr.immutable_import_text_projection(t) image from storage.unit_storage_original_exact_v2 t order by ctid')).rows.map(row=>row.image);
    assert.equal(captured.length,5);assert.equal(captured[0],captured[1]);
    for(const raw of captured)assert.equal(codec.decodeProductionBackupTextColumnsDataRow(codec.encodeProductionBackupTextColumnsDataRow(raw)),raw);
    await db.query('rollback to savepoint storage_v2_original_capture');await db.query('release savepoint storage_v2_original_capture');
    assert.equal((await db.query("select to_regclass('storage.unit_storage_original_exact_v2') relation")).rows[0].relation,null);
    put('STORAGE_V2_NATIVE_CAPTURE.json',{input_sha256:sha(inputBytes),typed_seed_sha256:sha(stableJson(input.seed_rows)),
     rows:5,raw_row_sha256:captured.map(sha),native_capture:true,codec_sha256:sha(fs.readFileSync(B+'/scripts/production-backup-pg-dump-command.mjs')),
     installed_pure_recipes:installed,no_context_rows_or_effect_api:true,settings});
    const results=[],fixturePins=[];
    for(const variant of storageCheckpointCaller?['ORIGINAL']:['ORIGINAL',...Object.values(input.source_variant_profiles)]){
     let rows=captured.slice();
     if(variant==='CHANGED_LABEL'||variant==='MALFORMED_INT8'){
      // Explicit hostile UNIT variant, not a claimed native canonical row.
      const row=JSON.parse(rows[0]);row[variant==='CHANGED_LABEL'?'original_label':'exact_integer']=variant==='CHANGED_LABEL'?'UNIT-changed-original.invalid':'not-a-native-int8';rows[0]=JSON.stringify(row);
     }else if(variant==='MISSING_ROW')rows.pop();else if(variant==='EXCESS_ROW')rows.push(rows[0]);
     const fixture=path.join(out,'synthetic-storage-v2-'+variant);fs.mkdirSync(fixture,{mode:0o700});
     fs.mkdirSync(fixture+'/inventory',{mode:0o700});fs.mkdirSync(fixture+'/database',{mode:0o700});
     const schema='-- SYNTHETIC UNIT-only native TEXT Storage comparison fixture, NOT production provenance.\n'
      +'create table public.unit_storage_placeholder_v2 (id text);\ncreate table auth.unit_storage_placeholder_v2 (id text);\n'+input.create_sql+';\n';
     const empty=schema_name=>({schema_name,table_name:'unit_storage_placeholder_v2',row_count:'0',primary_key:[],columns:[{name:'id',generated:'',identity:'',data_type:'text'}],
      data_file:'database/'+schema_name+'.unit_storage_placeholder_v2.jsonl',data_encoding:input.data_encoding});
     const catalogBytes=Buffer.from(JSON.stringify([empty('public'),empty('auth'),fixed.table],null,2)+'\n');
     const rowBytes=Buffer.from(rows.map(raw=>codec.encodeProductionBackupTextColumnsDataRow(raw)+'\n').join(''));
     const summary={format:'memphis-zoo-disaster-recovery.v4',ok:true,consistent_database_snapshot:true,project_ref:input.project_ref,
      backed_up_schemas:['public','auth','storage'],table_count:3,database_row_count:5,fixture_only:true,storage_bucket_count:0,storage_object_count:0,storage_bytes:0,
      source_identity:{fixture_id:input.fixture_id,unit_fixture_only:true,source_uri:input.source_uri,storage_v2_variant:variant,
       unit_input_sha256:sha(inputBytes),typed_seed_sha256:sha(stableJson(input.seed_rows)),application_schema_sha256:sha(schema),database_catalog_sha256:sha(catalogBytes)}};
     const entries=[['backup-summary.json',Buffer.from(JSON.stringify(summary,null,2)+'\n')],['inventory/table-catalog.json',catalogBytes],
      ['inventory/application-schema.sql',Buffer.from(schema)],['inventory/fixture-input.json',inputBytes],
      ['inventory/storage-buckets.json',Buffer.from('[]\n')],['inventory/storage-objects.json',Buffer.from('[]\n')],
      ['database/public.unit_storage_placeholder_v2.jsonl',Buffer.alloc(0)],['database/auth.unit_storage_placeholder_v2.jsonl',Buffer.alloc(0)],
      [fixed.table.data_file,rowBytes]];
     for(const [member,bytes]of entries)fs.writeFileSync(path.join(fixture,member),bytes,{flag:'wx',mode:0o400});
     const sums=entries.map(([member,bytes])=>sha(bytes)+'  '+member).join('\n')+'\n',archiveDigest=sha(sums);
     fs.writeFileSync(fixture+'/SHA256SUMS',sums,{flag:'wx',mode:0o400});
     fs.writeFileSync(fixture+'/archive-signature.json',JSON.stringify({format:'memphis-zoo-disaster-recovery-signature.v1',algorithm:'hmac-sha256',key_id:fixed.key_id,
      archive_digest:archiveDigest,signature:signBinding(archiveSignatureBinding({archiveDigest,projectRef:input.project_ref,sourceIdentity:summary.source_identity,archiveFormat:summary.format}),fixed.public_unit_key)})+'\n',{flag:'wx',mode:0o400});
     for(const dir of [fixture+'/inventory',fixture+'/database',fixture])fs.chmodSync(dir,0o500);
     const archive=materializeVerifiedArchive({sourceDir:fixture,archiveVerifyKey:fixed.public_unit_key,archiveVerifyKeyId:fixed.key_id});
     const snapshot=archive.directory;let failed=false,first;const cleanup=[];
     try{
      if(storageCheckpointCaller){
       // ONLY this freshly named disposable target is committed, not an
       // application import. The shipping caller must start from native I
       // and own its readonly transactions. Both private ancestry tables
       // remain empty; no grant/effect/restore-context API is installed.
       await db.query(input.create_sql);
       for(const row of input.seed_rows)assert.equal((await db.query(input.seed_sql,row)).rowCount,1);
       await db.query('commit');transaction=false;
       for(const profile of ['MATCH','INTEGER_DIFFERENT'])results.push(await runStorageExactCheckpointNativeCase(db,archive,profile));
       assert.equal(db._txStatus,'I');
      }else{
       const profiles=fixed.profiles.filter(profile=>(fixed.source_variant_profiles[profile]||'ORIGINAL')===variant);
       for(const profile of profiles)results.push(await runStorageOriginalOwningSqlCase(db,archive,profile));
      }
     }catch(error){failed=true;first=error;}
     try{archive.cleanup();assert.equal(fs.existsSync(snapshot),false);}catch(error){cleanup.push(error);}
     try{assert.equal(sha(fs.readFileSync(fixture+'/SHA256SUMS')),archiveDigest);
      for(const [member,bytes]of entries)assert.equal(sha(fs.readFileSync(path.join(fixture,member))),sha(bytes));}catch(error){cleanup.push(error);}
     if(cleanup.length)throw new AggregateError(failed?[first,...cleanup]:cleanup,'Storage v2 original/cleanup failed',failed?{cause:first}:undefined);
     if(failed)throw first;
     fixturePins.push({variant,directory:fixture,archive_digest:archiveDigest,data_sha256:sha(rowBytes),verification_copy_absent:true,original_members_unchanged:true});
    }
    assert.deepEqual((await db.query(`select (select count(*)::text from custodial_dr.restore_control) controls,
     (select count(*)::text from custodial_dr.immutable_private_import_context) contexts`)).rows,[{controls:'0',contexts:'0'}]);
    if(!storageCheckpointCaller){
     await db.query('rollback');transaction=false;
     assert.deepEqual((await db.query("select to_regclass('storage.unit_storage_original_exact_v2') relation,to_regnamespace('custodial_dr') namespace")).rows,[{relation:null,namespace:null}]);
    }else assert.equal(db._txStatus,'I');
    put('STORAGE_V2_FIXTURE_PINS.json',{input_sha256:sha(inputBytes),fixtures:fixturePins});
    put('PRODUCT_RESULT.json',{scope:storageCheckpointCaller?'NEW_EXACT_STORAGE_CHECKPOINT_SHIPPING_NATIVE_CALLER_ONLY':'NEW_V2_STORAGE_ORIGINAL_NATIVE_TABLE_COMPARISON_ONLY',profiles:results,
     actual_SQL:true,data_encoding:input.data_encoding,native_original_capture:true,typed_seed_sha256:sha(stableJson(input.seed_rows)),
     transaction:storageCheckpointCaller?'READ_SNAPSHOTS_ROLLED_BACK;ONLY_FRESH_UNIT_SETUP_COMMITTED':'ROLLED_BACK',
     fixture_objects_absent:!storageCheckpointCaller,owned_container_cleanup_required:storageCheckpointCaller,
     verification_copies_absent:true,private_context_rows_created:0,
     public_UNIT_HMAC_only:true,production:false,normal_restore_or_effect_authority:false,whole_G31:false,old_groups_replayed:0});
   }else{
   const noMembers=purpose==='storage-original-table-no-members';
   const fixture=noMembers?'/home/eric/Documents/Codex/2026-10-09/task-7/complete-normal-restore-fixture-20261017-v1/synthetic-unit-original-v1'
    :'/home/eric/Documents/Codex/2026-10-09/task-9/storage-original-owning-sql-product-20261017-v1/synthetic-storage-unit-original-v1';
   const sourceBefore=sha(fs.readFileSync(fixture+'/SHA256SUMS'));
   assert.equal(sourceBefore,noMembers?'9e7f0cd9659232106ed993eb19c7e3a9796a787a5349128df7a1d2789bf7b40a':'33f32bea4e6dc2955183afa2323bd7107eb52d7dbfd7434a6f3ca1f867dcbc11');
   const archive=materializeVerifiedArchive({sourceDir:fixture,archiveVerifyKey:STORAGE_ORIGINAL_UNIT_INPUT.public_unit_key,
    archiveVerifyKeyId:STORAGE_ORIGINAL_UNIT_INPUT.key_id});
   const snapshot=archive.directory;
   try{
    await db.query('begin isolation level repeatable read');transaction=true;
    if(purpose!=='storage-original-table-match'){
     await db.query('create temporary table unit_source_bootstrap_temp_namespace(id integer) on commit drop');
     await db.query('drop table pg_temp.unit_source_bootstrap_temp_namespace');
     assert.ok((await db.query('select pg_my_temp_schema()::text oid')).rows[0].oid!=='0');
    }
    await db.query(purpose!=='storage-original-table-match'
     ?'set local search_path=pg_catalog,pg_temp;set local row_security=off'
     :'set local search_path=pg_catalog;set local row_security=off');
    const settings=(await db.query(`select pg_catalog.current_setting('extra_float_digits') float_digits,
     (pg_catalog.current_schemas(true))[1]::text first_schema,pg_catalog.current_setting('search_path') search_path,
     pg_catalog.current_setting('DateStyle') date_style,pg_catalog.current_setting('TimeZone') timezone`)).rows[0];
    put('STORAGE_CALLER_INTERPRETATION_SETTINGS.json',settings);
    const results=[];
    if(noMembers){
     await db.query('set local transaction_read_only=on');
     const {compareVerifiedStorageTableData}=await import(B+'/scripts/disaster-recovery-storage.mjs');
     const result=await compareVerifiedStorageTableData({db,verifiedArchive:archive});
     assert.equal(result.status,'NOT_APPLICABLE_ORIGINAL_NO_MEMBERS');assert.deepEqual(result.tables,[]);
     results.push({profile:'NO_MEMBERS',comparison:result,complete_restore:false});
    }else{
     const selected=purpose==='storage-original-table-negative'?STORAGE_ORIGINAL_UNIT_INPUT.profiles.filter(profile=>profile!=='MATCH'):['MATCH'];
     for(const profile of selected)results.push(await runStorageOriginalOwningSqlCase(db,archive,profile));
    }
    await db.query('rollback');transaction=false;
    put('PRODUCT_RESULT.json',{...(results.length===1?results[0]:{profiles:results}),actual_SQL:true,public_UNIT_HMAC_only:true,production:false,
     normal_restore_or_effect_authority:false,whole_G31:false,old_groups_replayed:0});
   }finally{
    archive.cleanup();assert.equal(fs.existsSync(snapshot),false);assert.equal(sha(fs.readFileSync(fixture+'/SHA256SUMS')),sourceBefore);
    put('STORAGE_ORIGINAL_INPUT_CLEANUP.json',{verification_copy_absent:true,retained_UNIT_original_unchanged:true});
   }
   }
  }else if(purpose==='restore-authority-target-preflight'){
   const {invalidateRestoredAuthority}=await import(B+'/scripts/disaster-recovery-state.mjs');
   await db.query('begin');transaction=true;
   await db.query("set local statement_timeout='8s';set local lock_timeout='2s'");
   // These are explicit disposable UNIT targets, not a reconstructed app,
   // owner/guard qualification, or authorization to invalidate real rows.
   const definitions=[
    ['public','device_auth_credentials','revoked_at timestamptz,revoked_reason text'],
    ['public','device_auth_enrollment_codes','revoked_at timestamptz'],
    ['public','ops_manager_trusted_devices','revoked_at timestamptz,revoked_reason text'],
    ['public','ops_manager_enrollment_codes',"status text default 'active',revoked_at timestamptz,revoked_reason text"],
    ['public','ops_manager_push_devices','enabled boolean,revoked_at timestamptz,revoked_reason text'],
    ['auth','sessions','id uuid'],
   ];
   for(const[schema,table,columns]of definitions){
    await db.query(`create table ${schema}.${table}(${columns})`);
    await db.query(`insert into ${schema}.${table} default values`);
   }
   // A target missing at the end of preflight must refuse before changing an
   // earlier present target, rather than silently reporting zero authority.
   await db.query('alter table auth.sessions rename to unit_unavailable_sessions');
   await assert.rejects(invalidateRestoredAuthority(db,{generation:'7'}),/RESTORE_AUTHORITY_TARGET_UNAVAILABLE/);
   assert.equal((await db.query('select revoked_at from public.device_auth_credentials')).rows[0].revoked_at,null);
   await db.query('alter table auth.unit_unavailable_sessions rename to sessions');
   await db.query('alter table public.ops_manager_push_devices rename column revoked_reason to unit_missing_reason');
   await assert.rejects(invalidateRestoredAuthority(db,{generation:'7'}),/RESTORE_AUTHORITY_TARGET_UNAVAILABLE/);
   assert.equal((await db.query('select revoked_at from public.device_auth_credentials')).rows[0].revoked_at,null);
   await db.query('alter table public.ops_manager_push_devices rename column unit_missing_reason to revoked_reason');
   await assert.rejects(invalidateRestoredAuthority(db,{generation:'9223372036854775808'}),/RESTORE_AUTHORITY_GENERATION_INVALID/);
   const result=await invalidateRestoredAuthority(db,{generation:'9223372036854775807'});
   assert.deepEqual(result,{employee_credentials:1,employee_enrollment:1,manager_credentials:1,
    manager_enrollment:1,manager_push:1,auth_sessions:1});
   for(const table of ['device_auth_credentials','ops_manager_trusted_devices','ops_manager_enrollment_codes','ops_manager_push_devices']){
    const row=(await db.query(`select revoked_at is not null revoked,revoked_reason from public.${table}`)).rows[0];
    assert.deepEqual(row,{revoked:true,revoked_reason:'disaster_restore_generation_9223372036854775807'});
   }
   assert.equal((await db.query('select count(*)::text count from auth.sessions')).rows[0].count,'0');
   await db.query('rollback');transaction=false;
   put('PRODUCT_RESULT.json',{scope:'NEW_REQUIRED_AUTHORITY_TARGET_PREFLIGHT_ACTUAL_SQL_UNIT_ONLY',actual_SQL:true,
    absent_last_target_refused_before_first_write:true,absent_last_column_refused_before_first_write:true,
    invalid_generation_refused:true,exact_int64_generation_reason_preserved:true,six_fixed_targets_observed:true,
    transaction:'ROLLED_BACK',protected_original_effect_admission:false,whole_restore:false,production:false,old_groups_replayed:0});
  }else{
   await db.query('begin');transaction=true;
   await db.query("set local statement_timeout='8s';set local lock_timeout='2s'");
   await db.query("set local extra_float_digits=3;set local datestyle='ISO, YMD';set local timezone='UTC';set local intervalstyle='postgres';set local bytea_output='hex'");
   const outputProfile=(await db.query(`select pg_catalog.current_setting('extra_float_digits') float_digits,
    pg_catalog.current_setting('DateStyle') date_style,pg_catalog.current_setting('TimeZone') timezone,
    pg_catalog.current_setting('IntervalStyle') interval_style,pg_catalog.current_setting('bytea_output') bytea_output`)).rows;
   assert.deepEqual(outputProfile,[{float_digits:'3',date_style:'ISO, YMD',timezone:'UTC',interval_style:'postgres',bytea_output:'hex'}]);
   const {stableJson}=await import(B+'/scripts/disaster-recovery-crypto.mjs');
   const {productionBackupTextColumnsDataEncoding:encoding}=await import(B+'/scripts/production-backup-pg-dump-command.mjs');
   const {decodeRestoreTableRowLine}=await import(B+'/scripts/disaster-recovery-archive.mjs');
   assert.equal(encoding,'postgres-text-columns-line.v2');
   await db.query('create schema custodial_dr authorization postgres');
   const definition=fs.readFileSync(B+'/supabase/migrations/20260820125325_custodial_disaster_restore_generation_authority.sql','utf8');
   for(const table of ['pre_restore_snapshots','restore_discrepancies']){
    const start=definition.indexOf('create table if not exists custodial_dr.'+table+' (');
    const finish=definition.indexOf('\n);',start);assert.ok(start>=0&&finish>start);
    await db.query(definition.slice(start,finish+3));
   }
   // Fixed canonical table/types/NOT NULL/defaults/constraints, not a selected
   // version, app owner/RLS/ACL reconstruction or release-selection authority.
   const baseline=fs.readFileSync(B+'/supabase/migrations/00000000000000_production_baseline.sql','utf8');
   assert.equal(sha(baseline),'decf8dcdceb1f722ec966d16addd8c47d7ceaca9a21f1464a26bf8cbfee7d7fb');
   const releaseStart=baseline.indexOf('create table "public"."release_deployment_manifest" (');
   const releaseEnd=baseline.indexOf('\n);',releaseStart);assert.ok(releaseStart>=0&&releaseEnd>releaseStart);
   assert.equal(baseline.split('create table "public"."release_deployment_manifest" (').length,2);
   await db.query(baseline.slice(releaseStart,releaseEnd+3));
   const releaseConstraints=baseline.split('\n').filter(line=>line.startsWith('alter table only "public"."release_deployment_manifest" add constraint '));
   assert.deepEqual(releaseConstraints.map(line=>line.match(/add constraint "([^"]+)"/)[1]),[
    'release_deployment_manifest_pkey','release_deployment_manifest_backend_sha','release_deployment_manifest_details_object',
    'release_deployment_manifest_frontend_sha','release_deployment_manifest_manifest_sha','release_deployment_manifest_status_check']);
   for(const statement of releaseConstraints)await db.query(statement);
   await db.query(`insert into public.release_deployment_manifest values(
    'UNIT exact raw original','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',
    '20261016143226',repeat('c',64),'UNIT-v1','deployed',
    '{"integer":9223372036854775807,"fraction":0.123456789012345678901}'::jsonb,
    '2026-10-17T00:00:00.123456+00','2026-10-17T00:00:00.654321+00')`);
   const releaseSql=`select pg_catalog.json_object(
    ARRAY['release_id','backend_commit','frontend_commit','migration_head','migration_manifest_sha256',
     'environment_contract_version','status','details_json','created_at','deployed_at']::text[],
    ARRAY[r.release_id::text,r.backend_commit::text,r.frontend_commit::text,r.migration_head::text,r.migration_manifest_sha256::text,
     r.environment_contract_version::text,r.status::text,r.details_json::text,r.created_at::text,r.deployed_at::text]::text[])::text original_row
    from public.release_deployment_manifest r`;
   const original=(await db.query(releaseSql)).rows[0].original_row;
   assert.ok(original.includes('9223372036854775807')&&original.includes('0.123456789012345678901')&&original.includes('.123456'));
   const typedReleaseSql=`select details_json->>'integer' integer_text,details_json->>'fraction' fraction_text,
    created_at::text created_text,deployed_at::text deployed_text from public.release_deployment_manifest`;
   const typedOriginal=(await db.query(typedReleaseSql)).rows;
   assert.deepEqual(typedOriginal,[{integer_text:'9223372036854775807',fraction_text:'0.123456789012345678901',
    created_text:'2026-10-17 00:00:00.123456+00',deployed_text:'2026-10-17 00:00:00.654321+00'}]);
   // Deliberate UNIT JSONB carrier under an approved snapshot field name.
   // The real app changed_fields is text[] NOT NULL (20260820153000); this
   // nullable component tests native JSONB/SQL NULL only, NOT that app schema,
   // its constraints/immutability/RLS/ACL, or original application row scope.
   await db.query('create table public.custodial_session_corrections(correction_id uuid,changed_fields jsonb,created_at timestamptz)');
   await db.query(`insert into public.custodial_session_corrections values
    ('00000000-0000-4000-8000-000000000009',null,'2026-10-18T00:00:00.123456+00'),
    ('00000000-0000-4000-8000-000000000009',null,'2026-10-18T00:00:00.123456+00'),
    ('00000000-0000-4000-8000-000000000009','null'::jsonb,'2026-10-18T00:00:00.123456+00')`);
   const nullSql=`select count(*)::text total,count(*) filter(where changed_fields is null)::text sql_nulls,
    count(*) filter(where changed_fields is not null and jsonb_typeof(changed_fields)='null')::text json_nulls
    from public.custodial_session_corrections`;
   assert.deepEqual((await db.query(nullSql)).rows,[{total:'3',sql_nulls:'2',json_nulls:'1'}]);
   const restoreId=randomUUID(),generation=1;
   const evidence=await capturePreRestoreState(db,{restoreId,generation});
   const read=async()=>(await db.query(`select restore_id::text,authority_generation::text generation,category,
    row_count::text count,snapshot_sha256,state_json,captured_at::text captured from custodial_dr.pre_restore_snapshots
    where restore_id=$1 order by category collate "C"`,[restoreId])).rows;
   const first=await read();assert.equal(first.length,10);assert.equal(Object.keys(evidence).length,10);
   for(const snapshot of first){
    assert.equal(snapshot.restore_id,restoreId);assert.equal(snapshot.generation,'1');assert.equal(snapshot.state_json.data_encoding,encoding);
    assert.equal(snapshot.count,String(snapshot.state_json.rows.length));assert.equal(snapshot.snapshot_sha256,sha(stableJson(snapshot.state_json.rows)));
    for(const raw of snapshot.state_json.rows)assert.equal(decodeRestoreTableRowLine(JSON.stringify(raw),{
     data_encoding:encoding,columns:snapshot.state_json.fields.map(name=>({name}))}),raw);
    assert.deepEqual(evidence[snapshot.category],{row_count:snapshot.state_json.rows.length,sha256:snapshot.snapshot_sha256,missing:snapshot.state_json.missing});
   }
   const release=first.find(row=>row.category==='release_identity'),corrections=first.find(row=>row.category==='cleaning_session_corrections');
   assert.deepEqual(release.state_json.rows,[original]);assert.equal(release.count,'1');assert.equal(release.state_json.missing,false);
   assert.deepEqual(corrections.state_json.fields,['correction_id','changed_fields','created_at']);assert.equal(corrections.count,'3');
   const nullRows=corrections.state_json.rows.map(raw=>JSON.parse(raw)); // Assertion-only, never restore parameters.
   assert.deepEqual(nullRows.map(row=>row.changed_fields),[null,null,'null']);
   assert.equal(corrections.state_json.rows[0],corrections.state_json.rows[1],'Duplicate original rows were lost');
   assert.notEqual(corrections.state_json.rows[1],corrections.state_json.rows[2],'SQL NULL and JSON null collapsed');
   const missingCategories=first.filter(row=>row.state_json.missing).map(row=>row.category);
   assert.equal(missingCategories.length,8);
   for(const snapshot of first.filter(row=>row.state_json.missing)){
    assert.deepEqual(snapshot.state_json.fields,[]);assert.deepEqual(snapshot.state_json.rows,[]);assert.equal(snapshot.count,'0');
   }
   assert.deepEqual(await compareRestoredState(db,{restoreId,generation}),[]);
   await capturePreRestoreState(db,{restoreId,generation});assert.deepEqual(await read(),first,'Idempotent read rewrote original data/time');
   await assert.rejects(capturePreRestoreState(db,{restoreId,generation:2}));assert.deepEqual(await read(),first);
   await assert.rejects(compareRestoredState(db,{restoreId,generation:2}));assert.deepEqual(await read(),first);
   await assert.rejects(preserveCurrentReleaseIdentity(db,{restoreId,generation:2}),{code:'RESTORE_ORIGINAL_RELEASE_SNAPSHOT_INVALID'});
   const absentId=randomUUID();await assert.rejects(preserveCurrentReleaseIdentity(db,{restoreId:absentId,generation}),{code:'RESTORE_ORIGINAL_RELEASE_SNAPSHOT_INVALID'});
   await assert.rejects(compareRestoredState(db,{restoreId:absentId,generation}));assert.deepEqual(await read(),first);
   // Fixture-owned tamper probes are undone only by SAVEPOINT rollback. No
   // recapture/upgrade/rewrite is allowed to repair the retained original.
   await db.query('savepoint unit_snapshot_tamper');
   await db.query("update custodial_dr.pre_restore_snapshots set snapshot_sha256=repeat('0',64) where restore_id=$1 and category='release_identity'",[restoreId]);
   const altered=await read();assert.notDeepEqual(altered,first);
   await assert.rejects(preserveCurrentReleaseIdentity(db,{restoreId,generation}),{code:'RESTORE_ORIGINAL_RELEASE_SNAPSHOT_INVALID'});
   await assert.rejects(compareRestoredState(db,{restoreId,generation}));
   await assert.rejects(capturePreRestoreState(db,{restoreId,generation}));assert.deepEqual(await read(),altered);
   await db.query('rollback to savepoint unit_snapshot_tamper');await db.query('release savepoint unit_snapshot_tamper');assert.deepEqual(await read(),first);
   await db.query('savepoint unit_snapshot_count');
   await db.query("update custodial_dr.pre_restore_snapshots set row_count=2 where restore_id=$1 and category='release_identity'",[restoreId]);
   const wrongCount=await read();
   await assert.rejects(preserveCurrentReleaseIdentity(db,{restoreId,generation}),{code:'RESTORE_ORIGINAL_RELEASE_SNAPSHOT_INVALID'});
   await assert.rejects(compareRestoredState(db,{restoreId,generation}));
   await assert.rejects(capturePreRestoreState(db,{restoreId,generation}));assert.deepEqual(await read(),wrongCount);
   await db.query('rollback to savepoint unit_snapshot_count');await db.query('release savepoint unit_snapshot_count');assert.deepEqual(await read(),first);
   await db.query('savepoint unit_snapshot_tag');
   await db.query("update custodial_dr.pre_restore_snapshots set state_json=jsonb_set(state_json,'{data_encoding}','\"UNIT-unknown-encoding\"'::jsonb) where restore_id=$1 and category='release_identity'",[restoreId]);
   const wrongTag=await read();
   await assert.rejects(preserveCurrentReleaseIdentity(db,{restoreId,generation}),{code:'RESTORE_ORIGINAL_RELEASE_SNAPSHOT_INVALID'});
   await assert.rejects(compareRestoredState(db,{restoreId,generation}));
   await assert.rejects(capturePreRestoreState(db,{restoreId,generation}));assert.deepEqual(await read(),wrongTag);
   await db.query('rollback to savepoint unit_snapshot_tag');await db.query('release savepoint unit_snapshot_tag');assert.deepEqual(await read(),first);
   await db.query('savepoint unit_snapshot_missing');
   await db.query("delete from custodial_dr.pre_restore_snapshots where restore_id=$1 and category='release_identity'",[restoreId]);
   const missing=await read();assert.equal(missing.length,9);
   await assert.rejects(preserveCurrentReleaseIdentity(db,{restoreId,generation}),{code:'RESTORE_ORIGINAL_RELEASE_SNAPSHOT_INVALID'});
   await assert.rejects(compareRestoredState(db,{restoreId,generation}));assert.deepEqual(await read(),missing);
   await db.query('rollback to savepoint unit_snapshot_missing');await db.query('release savepoint unit_snapshot_missing');assert.deepEqual(await read(),first);
   await db.query('savepoint unit_snapshot_changed_rows');
   await db.query("update public.release_deployment_manifest set created_at='2026-10-17T00:00:00.123457+00'");
   await db.query("update public.custodial_session_corrections set changed_fields='null'::jsonb where changed_fields is null");
   assert.deepEqual((await db.query(nullSql)).rows,[{total:'3',sql_nulls:'0',json_nulls:'3'}]);
   await assert.rejects(capturePreRestoreState(db,{restoreId,generation}));assert.deepEqual(await read(),first);
   const discrepancies=await compareRestoredState(db,{restoreId,generation});
   assert.ok(discrepancies.some(row=>row.category==='release_identity'),'One-microsecond change was lost');
   assert.ok(discrepancies.some(row=>row.category==='cleaning_session_corrections'),'SQL NULL to JSON null change was lost');
   assert.equal(await preserveCurrentReleaseIdentity(db,{restoreId,generation}),1,'Native ON CONFLICT update did not preserve original');
   assert.equal((await db.query(releaseSql)).rows[0].original_row,original);
   assert.deepEqual((await db.query(typedReleaseSql)).rows,typedOriginal);
   assert.deepEqual((await compareRestoredState(db,{restoreId,generation})).map(row=>row.category),['cleaning_session_corrections']);
   assert.deepEqual(await read(),first);
   await db.query('rollback to savepoint unit_snapshot_changed_rows');await db.query('release savepoint unit_snapshot_changed_rows');
   assert.deepEqual((await db.query(nullSql)).rows,[{total:'3',sql_nulls:'2',json_nulls:'1'}]);
   await db.query('delete from public.release_deployment_manifest');
   const preserved=await preserveCurrentReleaseIdentity(db,{restoreId,generation});assert.equal(preserved,1);
   const restored=(await db.query(releaseSql)).rows[0].original_row;
   assert.equal(restored,original,'Original native TEXT/JSON/time/numeric DATA changed during preservation');
   assert.deepEqual((await db.query(typedReleaseSql)).rows,typedOriginal);
   assert.deepEqual(await compareRestoredState(db,{restoreId,generation}),[]);
   assert.deepEqual(await read(),first);
   await db.query('rollback');transaction=false;
   assert.deepEqual((await db.query(`select to_regclass('public.release_deployment_manifest') release_table,
    to_regclass('public.custodial_session_corrections') corrections,to_regnamespace('custodial_dr') snapshot_schema`)).rows,
    [{release_table:null,corrections:null,snapshot_schema:null}]);
   put('PRODUCT_RESULT.json',{scope:'NEW_V2_PRE_RESTORE_ORIGINAL_CAPTURE_PRESERVE_COMPARE_ACTUAL_SQL',actual_SQL:true,
    data_encoding:encoding,native_output_profile:outputProfile[0],canonical_release_types_not_null_and_constraints:true,
    raw_original_rows_exact:true,timestamp_microseconds_exact:true,large_and_precise_JSON_numbers_exact:true,
    sql_null_vs_json_null_direct_native_predicates:true,duplicate_rows_preserved:true,
    changed_null_distinction_detected:true,native_release_update_and_insert_roundtrip_exact:true,
    stored_hash_count_tag_verified:true,altered_original_and_unknown_tag_refused_without_rewrite:true,
    first_snapshot_unchanged:true,idempotent_no_timestamp_rewrite:true,wrong_generation_refused:true,missing_snapshot_refused:true,
    changed_original_refused:true,one_microsecond_change_detected:true,transaction:'ROLLED_BACK',rolled_back_objects_absent:true,
    explicitly_missing_snapshot_categories:missingCategories,nullable_JSONB_component_not_application_schema:true,
    archive_or_immutable_DATA_import:false,original_restore_effect_admission:false,production:false,whole_G31:false,
    old_groups_replayed:0,limits:'Actual three v2 state helper/driver/SQL joins only. Minimal nullable JSONB correction carrier is NOT the application text[]/NOT NULL/guard/RLS/ACL schema. Eight missing categories are unavailable, not empty production proof. No v1 recapture or complete restore/owner/phase/effect authorization.'});
  }
 }catch(error){firstFailure=error;throw error;}
 finally{
  const cleanup=[];
  if(db){if(transaction)try{await db.query('rollback');}catch(error){cleanup.push(error);}
   try{await db.end();}catch(error){cleanup.push(error);}}
  if(cleanup.length)throw new AggregateError(firstFailure?[firstFailure,...cleanup]:cleanup,'Snapshot SQL fixture cleanup failed',{cause:firstFailure??cleanup[0]});
 }
 process.exit(0);
}
if(purpose==='reconciliation-commit-receipt'||purpose==='reconciliation-original-expiry-clock'){
 const expiryClock=purpose==='reconciliation-original-expiry-clock';
 const source=fs.readFileSync(B+'/scripts/apply-production-restore-reconciliation.mjs','utf8');
 assert.equal(sha(source),expiryClock?'502787e00e0ba6883d9c2b8db87db9b9a7a1652cb7e6dc72c62885b5955d3d1c':'4c4dad5138e160ead71a86af86faf230c6a31b0d2473c1d6f2eed664c9288786');
 const start=source.indexOf('function requireReconciliationCommitReceipt(result) {'),end=source.indexOf('\nasync function commitOriginalReconciliationOnce()',start);
 assert.ok(start>0&&end>start);
 const {types}=await import('node:util');
 // Exact pure receipt predicate ONLY. This does not execute or substitute any
 // signing/authentication/authorization prefix or the resume/COMMIT caller.
 const validate=new Function('types',source.slice(start,end)+';return requireReconciliationCommitReceipt;')(types);
 let db,transaction=false,firstFailure;const observations=[];
 try{
  for(let n=0,ready=0;n<40;n++){
   const candidate=new Client({host:socket,user:'supabase_admin',database:'postgres',password:bootstrap,connectionTimeoutMillis:500,query_timeout:10000});candidate.on('error',()=>{});
   try{
    await candidate.connect();
    const postmaster=(await candidate.query("select split_part(pg_catalog.pg_read_file('postmaster.pid',0,32),chr(10),1) postmaster_pid,pg_catalog.pg_postmaster_start_time()::text started_at")).rows[0];
    observations.push(postmaster);
    if(postmaster.postmaster_pid==='1'&&++ready===4){db=candidate;break;}
    if(postmaster.postmaster_pid!=='1')ready=0;
   }catch(error){ready=0;if(n===39)throw error;}
   await candidate.end();await new Promise(resolve=>setTimeout(resolve,500));
  }
  assert.ok(db,'Existing final cached postmaster prerequisite');
  put('FIXTURE_POSTMASTER_READINESS.json',{observations,final_postmaster_pid:'1',no_new_role_or_grant:true});
  const identity=(await db.query('select current_user actor,session_user session_actor,current_database() database')).rows[0];
  assert.deepEqual(identity,{actor:'supabase_admin',session_actor:'supabase_admin',database:'postgres'});
  if(expiryClock){
   const guardStart=source.indexOf('function requireOriginalReconciliationClient() {'),guardEnd=source.indexOf('\nfunction requireReconciliationCommitReceipt',guardStart);
   const clockStart=source.indexOf('function requireOriginalReconciliationNodeLifetime() {'),clockEnd=source.indexOf('\nasync function commitOriginalReconciliationOnce()',clockStart);
   assert.ok(guardStart>0&&guardEnd>guardStart&&clockStart>guardEnd&&clockEnd>clockStart);
   const code=source.slice(guardStart,guardEnd)+'\n'+source.slice(clockStart,clockEnd);
   const make=new Function('Client','nativeClientPrototype','nativeQuery','nativeConnect','nativeEnd','types','db',
    'originalReconciliationExpiresAt','originalReconciliationExpiresAtMs',code+';return requireOriginalReconciliationPublicationLifetime;');
   await db.query('begin isolation level repeatable read read only');transaction=true;
   const times=(await db.query("select pg_catalog.clock_timestamp()+interval '60 seconds' future,pg_catalog.clock_timestamp()-interval '1 second' past")).rows[0];
   assert.ok(times.future instanceof Date&&times.past instanceof Date);
   const guard=value=>make(Client,Client.prototype,Client.prototype.query,Client.prototype.connect,Client.prototype.end,types,db,value,Date.parse(value));
   await guard(times.future.toISOString())();
   await assert.rejects(()=>guard(times.past.toISOString())(),/Original signed reconciliation lifetime expired or is unavailable/);
   const readonly=(await db.query("select current_setting('transaction_read_only') readonly")).rows[0];assert.equal(readonly.readonly,'on');
   await db.query('rollback');transaction=false;
   put('PRODUCT_RESULT.json',{scope:'NEW_SHIPPING_PUBLICATION_LIFETIME_GUARD_ACTUAL_NATIVE_READONLY_SQL',actual_SQL:true,identity,
    source_module_sha256:sha(source),lifetime_guard_sha256:sha(code),unsigned_test_deadlines:{future:times.future.toISOString(),past:times.past.toISOString()},
    future_deadline_accepted:true,expired_deadline_refused:true,actual_readonly:true,transaction:'ROLLED_BACK',
    signatures_created:0,user_tables_changed:false,COMMIT:false,authenticated_app_or_reconciliation:false,restore_complete:false,production:false,
    limits:'Exact private native/clock predicates ONLY, original timestamp parameters are unsigned testcase DATA. No app signature/admission, resume, DATA restore or Android/G28/platform clock proof. Old COMMIT-tag cases not replayed.'});
  }else{
  await db.query('begin');transaction=true;
  const accepted=await db.query('commit');transaction=false;validate(accepted);
  await db.query('begin');transaction=true;
  let abort;try{await db.query('select 1/0');}catch(error){abort=error;}
  assert.equal(abort?.code,'22012');
  const rejected=await db.query('commit');transaction=false;
  assert.equal(rejected.command,'ROLLBACK');
  assert.throws(()=>validate(rejected),/Native reconciliation COMMIT receipt differs/);
  const alive=(await db.query('select 1::int live')).rows;assert.deepEqual(alive,[{live:1}]);
  put('PRODUCT_RESULT.json',{scope:'NEW_SHIPPING_RECEIPT_PREDICATE_ACTUAL_EMPTY_COMMIT_AND_ABORT_ROLLBACK',actual_SQL:true,identity,
   predicate_sha256:sha(source.slice(start,end)),source_module_sha256:sha(source),
   accepted:{command:accepted.command,rowCount:accepted.rowCount,rows:accepted.rows},
   refused:{command:rejected.command,rowCount:rejected.rowCount,rows:rejected.rows,expected_abort_sqlstate:abort.code},
   connection_alive_after_refusal:true,user_tables_changed:false,signed_inputs_created:0,
   authenticated_app_or_reconciliation:false,restore_complete:false,resume_authority:false,production:false,
   limits:'Actual driver/server command tags to exact pure shipping predicate ONLY. Empty transaction COMMIT is not DATA restore, application auth, lost-reply or resumed-control proof.'});
  }
 }catch(error){firstFailure=error;throw error;}finally{
  const cleanup=[];if(db){if(transaction)try{await db.query('rollback');}catch(error){cleanup.push(error);}
   try{await db.end();}catch(error){cleanup.push(error);}}
  if(cleanup.length)throw new AggregateError(firstFailure?[firstFailure,...cleanup]:cleanup,'Receipt fixture cleanup failed',{cause:firstFailure??cleanup[0]});
 }
 process.exit(0);
}
if(purpose==='immutable-ordinary-set-compile'){
 const file=B+'/proposals/immutable-private-owner-context.sql',source=fs.readFileSync(file,'utf8');
 assert.equal(sha(source),'515da4decae3d0d6fce5a06463e56c3d00030a9f9bff5f06bbf1e462cda61819');
 const connection={host:socket,user:'postgres',database:'postgres',password:bootstrap,connectionTimeoutMillis:500,query_timeout:10000};
 assert.match(ownedContainerName,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);
 let bootstrapClient,db;let firstFailure;
 try{
  for(let n=0;n<30;n++){const c=new Client(connection);c.on('error',()=>{});
   try{await c.connect();assert.equal((await c.query('select current_user actor')).rows[0].actor,'postgres');bootstrapClient=c;break;}
   catch(error){await c.end().catch(()=>{});if(n===29)throw error;await new Promise(resolve=>setTimeout(resolve,200));}}
  await bootstrapClient.query('create database "'+ownedContainerName+'" template template0');
  db=new Client({...connection,database:ownedContainerName});db.on('error',()=>{});await db.connect();
  assert.deepEqual((await db.query('select current_user actor,current_database() database')).rows[0],{actor:'postgres',database:ownedContainerName});
  await db.query("set statement_timeout='8s';set lock_timeout='2s';create schema custodial_dr authorization postgres;create table public.records(id bigint primary key,parent_id bigint references public.records(id),value json not null)");
  const end=source.indexOf('CREATE FUNCTION custodial_dr.immutable_import_owner_fence()');assert.ok(end>0);
  await db.query(source.slice(0,end)); // Exact source owner check, tables/RLS/ALWAYS guards. No context DATA.
  const names=['stage_immutable_ordinary_row','insert_staged_immutable_ordinary_table'];
  for(const name of names){const start=source.indexOf('CREATE FUNCTION custodial_dr.'+name+'('),finish=source.indexOf('END $fn$;',start);
   assert.ok(start>end&&finish>start);await db.query(source.slice(start,finish+'END $fn$;'.length));}
  const acl=source.indexOf('DO $acl$'),aclEnd=source.indexOf('END $acl$;',acl);assert.ok(acl>0&&aclEnd>acl);
  await db.query(source.slice(acl,aclEnd+'END $acl$;'.length));
  const functions=(await db.query("select p.proname,p.prosecdef,p.proconfig,pg_get_userbyid(p.proowner) owner,has_function_privilege('service_role',p.oid,'execute') runtime_execute from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='custodial_dr' and p.proname=any($1::text[]) order by p.proname",[names])).rows;
  assert.equal(functions.length,2);for(const row of functions){assert.equal(row.prosecdef,false);assert.equal(row.owner,'postgres');assert.equal(row.runtime_execute,false);assert.ok(row.proconfig.includes('search_path=pg_catalog'));}
  const table=(await db.query("select c.relrowsecurity,c.relforcerowsecurity from pg_class c where c.oid='custodial_dr.immutable_ordinary_import_rows'::regclass")).rows[0];assert.deepEqual(table,{relrowsecurity:true,relforcerowsecurity:true});
  const triggers=(await db.query("select tgname,tgenabled from pg_trigger where tgrelid='custodial_dr.immutable_ordinary_import_rows'::regclass and not tgisinternal order by tgname")).rows;
  assert.equal(triggers.length,2);for(const t of triggers)assert.equal(t.tgenabled,'A');
  // Prepare (DO NOT EXECUTE) the exact dynamic set statement against a real
  // ordinary self-FK row type. No signed/context row, lease or authority is
  // manufactured to reach an INSERT. This proves grammar/types only.
  const match=source.match(/EXECUTE format\('(WITH inserted AS \(INSERT INTO[^\n]+)',\n  target_oid::regclass/);
  assert.ok(match);const dynamic=(await db.query('select format($1::text,$2::text,$3::text,$4::text,$5::text) sql',
   [match[1],'public.records','id,parent_id,value','r.id,r.parent_id,r.value','public.records'])).rows[0].sql;
  await db.query('prepare immutable_ordinary_set(oid,integer,bigint,oid) as '+dynamic);
  await db.query('deallocate immutable_ordinary_set');
  const contexts=(await db.query('select count(*)::int n from custodial_dr.immutable_private_import_context')).rows[0].n;assert.equal(contexts,0);
  await db.query('rollback');
  assert.equal((await db.query("select to_regclass('custodial_dr.immutable_ordinary_import_rows') relation")).rows[0].relation,null);
  assert.equal((await db.query('select count(*)::int n from public.records')).rows[0].n,0);
  assert.equal(sha(fs.readFileSync(file)),'515da4decae3d0d6fce5a06463e56c3d00030a9f9bff5f06bbf1e462cda61819');
  put('CASE_RESULT.json',{scope:'NEW_SOURCE_ORDINARY_SELF_TABLE_DDL_AND_EXACT_SET_STATEMENT_PREPARE_ONLY',functions,table,triggers,
   source_sha256:sha(source),signed_restore_contexts_created:0,actual_target_inserts:0,definitions_rolled_back:true,
   full_owner_context:'NOT_RUN',actual_staging_and_set_runtime:'NOT_RUN',complete_restore:false,
   limits:'Fresh disposable postgres-owned unit database, exact source prefix/two new invoker functions/ACL and dynamic statement PREPARE. No application migrations/cron retry, no guard stub, no auth context/key, no restore activation/grants or production.'});
 }catch(error){firstFailure=error;put('FAILURE_compile.json',{code:error.code??null,message:String(error.message).slice(0,1200),product_PASS:false});throw error;}
 finally{if(db){await db.query('rollback').catch(()=>{});await db.end().catch(error=>{if(!firstFailure)throw error;});}if(bootstrapClient)await bootstrapClient.end();}
 process.exit(0);
}
if(purpose==='data-source-consumer'){
 const archiveApi=await import(pathToFileURL(B+'/scripts/disaster-recovery-archive.mjs'));
 const {archiveSignatureBinding,signBinding}=await import(pathToFileURL(B+'/scripts/disaster-recovery-crypto.mjs'));
 const {suspendUnvalidatedRestoreChecks,reinstateUnvalidatedRestoreChecks,restoreCheckEvidence}=await import(pathToFileURL(B+'/scripts/restore-unvalidated-checks.mjs'));
 const {pipeline}=await import('node:stream/promises'),{createInterface}=await import('node:readline');
 const text=fs.readFileSync(B+'/scripts/production-restore.mjs','utf8'),start=text.indexOf('  await db.query("begin");\n  let unvalidatedCheckEvidence'),end=text.indexOf('\n  await setControl("DATABASE_RESTORED")',start);
 assert.ok(start>0&&end>start);
 const consume=new(Object.getPrototypeOf(async function(){}).constructor)('db','databaseTables','verifiedArchive','openVerifiedRestoreTableData','createRestoreRowUtf8Guard','pipeline','createInterface','decodeRestoreTableRowLine','requireOriginalArchiveSource','suspendUnvalidatedRestoreChecks','reinstateUnvalidatedRestoreChecks','restoreCheckEvidence',
  'let restorePhase,restoreTable;const quoteIdentifier=x=>`"${String(x).replaceAll(\'"\',\'""\')}"`;const qualified=(s,t)=>quoteIdentifier(s)+"."+quoteIdentifier(t);\n'+text.slice(start,end));
 assert.match(ownedContainerName,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);
 const connection={host:socket,user:'supabase_admin',database:'postgres',password:bootstrap,connectionTimeoutMillis:500,query_timeout:15000};
 let client,db;const results=[];
 try{
  for(let n=0;n<30;n++){const candidate=new Client(connection);candidate.on('error',()=>{});
   try{await candidate.connect();assert.deepEqual((await candidate.query('select current_user actor,current_database() database')).rows[0],{actor:'supabase_admin',database:'postgres'});client=candidate;break;}
   catch{await candidate.end().catch(()=>{});await new Promise(resolve=>setTimeout(resolve,200));}}
  assert.ok(client);await client.query(`create database "${ownedContainerName}" template template0`);
  db=new Client({...connection,database:ownedContainerName});db.on('error',()=>{});await db.connect();
  assert.deepEqual((await db.query('select current_user actor,current_database() database')).rows[0],{actor:'supabase_admin',database:ownedContainerName});
  await db.query("set statement_timeout='8s';set lock_timeout='2s';create table public.records(id bigint primary key,value json not null,check(id>0))");
  const payload='{"unsafe":9007199254740993,"duplicate":1,"duplicate":2,"unicode":"café🐾"}',raw='{"id":9223372036854775807,"value":'+payload+'}';
  for(const failureCase of [false,true]){
   await db.query('truncate public.records');await db.query('insert into public.records values(7,$1::json)',['{"original":"seed retained on rollback"}']);
   const source=out+'/unit-source-'+(failureCase?'duplicate':'success');fs.mkdirSync(source,{mode:0o700});fs.mkdirSync(source+'/inventory',{mode:0o700});fs.mkdirSync(source+'/database',{mode:0o700});
   const rowCount=failureCase?2:1,data=Buffer.from((JSON.stringify(raw)+'\n').repeat(rowCount));
   const catalog=['public','auth','storage'].map(schema_name=>({schema_name,table_name:'records',primary_key:['id'],columns:[{name:'id',generated:'',identity:'',data_type:'bigint'},{name:'value',generated:'',identity:'',data_type:'json'}],row_count:String(schema_name==='public'?rowCount:0),data_file:`database/${schema_name}.records.jsonl`,data_encoding:archiveApi.postgresJsonTextLineEncoding}));
   const catalogBytes=Buffer.from(JSON.stringify(catalog)+'\n'),summary={ok:true,format:'memphis-zoo-disaster-recovery.v4',consistent_database_snapshot:true,project_ref:'abcdefghijklmnopqrst',source_identity:{database_catalog_sha256:sha(catalogBytes)},backed_up_schemas:['public','auth','storage'],table_count:3,database_row_count:rowCount};
   const entries=[['backup-summary.json',Buffer.from(JSON.stringify(summary)+'\n')],['inventory/table-catalog.json',catalogBytes],['database/public.records.jsonl',data],['database/auth.records.jsonl',Buffer.alloc(0)],['database/storage.records.jsonl',Buffer.alloc(0)]];
   for(const[path,bytes]of entries)fs.writeFileSync(source+'/'+path,bytes,{flag:'wx',mode:0o600});
   const sums=entries.map(([path,bytes])=>sha(bytes)+'  '+path).join('\n')+'\n',archiveDigest=sha(sums),key='disaster-recovery-archive-materialization-test-key-0001',keyId='archive-materialization-test-v1';
   fs.writeFileSync(source+'/SHA256SUMS',sums,{flag:'wx',mode:0o600});fs.writeFileSync(source+'/archive-signature.json',JSON.stringify({format:'memphis-zoo-disaster-recovery-signature.v1',algorithm:'hmac-sha256',key_id:keyId,archive_digest:archiveDigest,signature:signBinding(archiveSignatureBinding({archiveDigest,projectRef:summary.project_ref,sourceIdentity:summary.source_identity,archiveFormat:summary.format}),key)}),{flag:'wx',mode:0o600});
   const archive=archiveApi.materializeVerifiedArchive({sourceDir:source,archiveVerifyKey:key,archiveVerifyKeyId:keyId}),binding=archiveApi.readVerifiedArchiveSourceBinding(archive),readers=[];
   const open=(...args)=>{const result=archiveApi.openVerifiedRestoreTableData(...args);readers.push(result);return result;};
   let failure=null;
   try{
    try{await consume(db,[catalog[0]],archive,open,archiveApi.createRestoreRowUtf8Guard,pipeline,createInterface,archiveApi.decodeRestoreTableRowLine,()=>assert.equal(archiveApi.readVerifiedArchiveSourceBinding(archive),binding),suspendUnvalidatedRestoreChecks,reinstateUnvalidatedRestoreChecks,restoreCheckEvidence);}
    catch(error){failure=error;}
    const rows=(await db.query('select id::text id,value::text value from public.records order by id')).rows;
    if(failureCase){assert.equal(failure?.code,'23505');assert.deepEqual(rows,[{id:'7',value:'{"original":"seed retained on rollback"}'}]);}
    else{assert.equal(failure,null);assert.deepEqual(rows,[{id:'9223372036854775807',value:payload}]);}
    for(const reader of readers){await reader.close();assert.ok(reader.stream.closed);}
    results.push({case:failureCase?'REAL_SQL_DUPLICATE_INSERT_ROLLBACK_PRESERVES_SEED':'REAL_SQL_EXACT_ORIGINAL_BIGINT_NESTED_JSON_COMMIT',status:'PASS',actual_sql_error:failure?.code||null,readers_closed:true});
   }finally{for(const reader of readers)await reader.close();archive.cleanup();assert.equal(fs.existsSync(archive.directory),false);}
  }
  put('CASE_RESULT.json',{scope:'ACTUAL_ISOLATED_SQL_THROUGH_SIGNED_SOURCE_READER_AND_EXACT_SHIPPING_TABLE_LOOP',results,application_migrations_replayed:0,limits:'Synthetic unit archive HMAC and ordinary disposable table; actual PostgreSQL constraints/commit/rollback and original reader/decoder/cleanup. Not full production restore, target intent, private-ledger import, genuine manager/native or unknown COMMIT/ROLLBACK settlement.'});
 }finally{if(db)await db.end().catch(()=>{});if(client)await client.end().catch(()=>{});}
 process.exit(0);
}
if(purpose==='section-emitter'){
 assert.match(ownedContainerName,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);
 const connection={host:socket,user:'supabase_admin',database:'postgres',password:bootstrap,connectionTimeoutMillis:500,query_timeout:15000};
 let client,fixtureClient;
 try {
  for(let n=0;n<30;n++){
   const candidate=new Client(connection);candidate.on('error',()=>{});
   try{await candidate.connect();assert.deepEqual((await candidate.query('select current_user actor,current_database() database')).rows[0],{actor:'supabase_admin',database:'postgres'});client=candidate;break;}
   catch{await candidate.end().catch(()=>{});await new Promise(resolve=>setTimeout(resolve,200));}
  }
  assert.ok(client,'Owned cached PostgreSQL did not become available');
  const database=ownedContainerName;
  await client.query(`create database "${database}" template template0`);
  fixtureClient=new Client({...connection,database});fixtureClient.on('error',()=>{});await fixtureClient.connect();
  assert.deepEqual((await fixtureClient.query('select current_user actor,current_database() database')).rows[0],{actor:'supabase_admin',database});
  await fixtureClient.query("set statement_timeout='8s';set lock_timeout='2s'");
  await fixtureClient.query(`create table public.section_parent(id bigint generated always as identity primary key,label text default 'original' not null, constraint positive_id check(id>0));
   create table public.section_child(id bigint primary key,parent_id bigint not null references public.section_parent(id));
   alter table public.section_parent enable row level security;
   alter table public.section_parent force row level security;
   create policy section_no_public_rows on public.section_parent for select to anon using(false);
   revoke all on public.section_parent from public;grant select on public.section_parent to anon;
   comment on table public.section_parent is 'Isolated actual section emitter fixture';
   create function public.section_guard() returns event_trigger language plpgsql as $$begin return;end$$;
   revoke all on function public.section_guard() from public;
   create event trigger section_guard_trigger on ddl_command_end execute function public.section_guard();
   alter event trigger section_guard_trigger enable always;`);
  await fixtureClient.query('begin isolation level repeatable read read only');
  const exported=(await fixtureClient.query('select pg_export_snapshot() snapshot')).rows[0].snapshot;
  assert.match(exported,/^[0-9A-F]+-[0-9A-F]+-[0-9]+$/i);
  const docker=['--host','unix:///var/run/docker.sock','exec',ownedContainerName];
  const version=execFileSync('/usr/bin/docker',[...docker,'pg_dump','--version'],{encoding:'utf8',timeout:5000,maxBuffer:4096}).trim();
  const sections=[];
  for(const section of ['pre-data','post-data']){
   const argv=[...docker,'pg_dump','-U','supabase_admin','-d',database,'--schema-only','--section='+section,'--snapshot='+exported];
   const bytes=execFileSync('/usr/bin/docker',argv,{timeout:8000,maxBuffer:2097152});assert.ok(bytes.length>0);
   const path=section+'.sql';fs.writeFileSync(out+'/'+path,bytes,{flag:'wx',mode:0o600});sections.push({section,path,sha256:sha(bytes),argv:['/usr/bin/docker',...argv]});
  }
  const commit=execFileSync('/usr/bin/git',['rev-parse','HEAD'],{cwd:B,encoding:'utf8'}).trim();
  const tree=execFileSync('/usr/bin/git',['rev-parse','HEAD^{tree}'],{cwd:B,encoding:'utf8'}).trim();
  put('receipt.json',{schema:'custodial.pg-dump-section-fixture-receipt.v1',source_commit:commit,source_tree:tree,pg_dump_version:version,exported_snapshot:exported,sections});
  await fixtureClient.query('rollback');
  put('CASE_RESULT.json',{status:'ACTUAL_SECTION_EMISSION_ONLY_NOT_PARSER_OR_RESTORE_PASS',sections,pg_dump_version:version,one_exported_snapshot:exported,application_migrations_replayed:0});
 } finally {if(fixtureClient)await fixtureClient.end().catch(()=>{});if(client)await client.end().catch(()=>{});}
 process.exit(0);
}
if(purpose==='backup-wire'){
 const {requireProductionBackupPage,productionBackupRowCount,encodeProductionBackupDataRow,productionBackupDataEncoding}=await import(pathToFileURL(B+'/scripts/production-backup-pg-dump-command.mjs'));
 const {decodeRestoreTableRowLine,postgresJsonTextLineEncoding}=await import(pathToFileURL(B+'/scripts/disaster-recovery-archive.mjs'));
 assert.equal(productionBackupDataEncoding,postgresJsonTextLineEncoding);
 const connection={host:socket,user:'supabase_admin',database:'postgres',password:bootstrap,connectionTimeoutMillis:500,query_timeout:15000};
 let client,connected=false;
 try{
  for(let n=0;n<30;n++){
   const candidate=new Client(connection);candidate.on('error',()=>{});
   try{await candidate.connect();const identity=(await candidate.query('select current_user actor,current_database() database')).rows[0];
    assert.deepEqual(identity,{actor:'supabase_admin',database:'postgres'});client=candidate;connected=true;break;
   }catch{await candidate.end().catch(()=>{});await new Promise(resolve=>setTimeout(resolve,200));}
  }
  assert.equal(connected,true);await client.query('begin');
  await client.query("set local statement_timeout='12s';set local lock_timeout='2s'");
  await client.query('create temporary table original_backup_wire(id bigint,epoch bigint,minimum bigint,amount numeric,payload json,note text,bytes_value bytea,occurred_at timestamptz(6))');
  await client.query('create temporary table restored_backup_wire(like original_backup_wire)');
  const payload='{\n "unsafe":9007199254740993,"duplicate":1,"duplicate":2,"precise":0.12345678901234567890123456789\n}';
  for(const [id,epoch] of [['9223372036854775807','9007199254740993'],['-9223372036854775808','9007199254740995']]){
   await client.query('insert into original_backup_wire values($1::bigint,$2::bigint,$3::bigint,$4::numeric,$5::json,$6::text,decode($7,\'hex\'),$8::timestamptz)',
    [id,epoch,'-9223372036854775808','12345678901234567890.1234567890123456789',payload,'  Original café 🐾\\n literal and\nactual line  ','00ff001122deadbeef','2026-10-13T18:42:27.123456Z']);
  }
  const count=productionBackupRowCount(await client.query('select count(*)::bigint row_count from original_backup_wire'));
  const columns=(await client.query("select attname name,attgenerated generated,attidentity identity,format_type(atttypid,atttypmod) data_type from pg_attribute where attrelid='original_backup_wire'::regclass and attnum>0 and not attisdropped order by attnum")).rows;
  const metadata={columns,data_encoding:productionBackupDataEncoding};const frames=[];
  for(let offset=0;offset<count;offset++){
   const rows=requireProductionBackupPage(await client.query('select row_to_json(snapshot_row)::text as row from (select * from only original_backup_wire order by id limit $1 offset $2) snapshot_row',[1,offset]),{offset,rowCount:count,pageSize:1});
   const raw=rows[0].row;assert.equal(typeof raw,'string');const encoded=encodeProductionBackupDataRow(raw);
   const decoded=decodeRestoreTableRowLine(encoded,metadata);assert.equal(decoded,raw);assert.deepEqual(Buffer.from(decoded),Buffer.from(raw));
   await client.query('insert into restored_backup_wire select * from json_populate_record(null::restored_backup_wire,$1::json)',[decoded]);
   frames.push({raw_sha256:sha(raw),wire_sha256:sha(encoded),bytes:Buffer.byteLength(raw)});
  }
  const original=(await client.query('select row_to_json(t)::text row from original_backup_wire t order by id')).rows.map(x=>x.row);
  const restored=(await client.query('select row_to_json(t)::text row from restored_backup_wire t order by id')).rows.map(x=>x.row);
  assert.deepEqual(restored,original);assert.ok(original.some(x=>x.includes('9007199254740993')));assert.ok(original.some(x=>x.includes('9223372036854775807')));
  const typed=(await client.query('select id::text,epoch::text,minimum::text,amount::text,payload::text,note,encode(bytes_value,\'hex\') bytes_value,occurred_at::text from restored_backup_wire order by id')).rows;
  assert.equal(typed[1].epoch,'9007199254740993');assert.equal(typed[1].payload,payload);
  await client.query('rollback');
  put('BACKUP_WIRE_SQL_RESULT.json',{status:'PASS_NEW_ACTUAL_POSTGRES_TEMP_WIRE',rows:count,frames,exact_original_and_restored_rows_equal:true,exact_json_column_text_preserved:true,actual_SQL:true,
   limits:'TEMP synthetic DATA and actual shipping wire helpers only; no actual signed archive, immutable private import, production, real manager or device.'});
  console.log('NEW actual PostgreSQL original unsafe integers/JSON/text/bytea/microseconds shipping producer-consumer wire PASS');
 }catch(error){if(connected)await client.query('rollback').catch(()=>{});throw error;}
 finally{if(client)await client.end().catch(()=>{});}
 process.exit(0);
}
const {readMigrationReplayPlan}=await import(pathToFileURL(B+'/scripts/migration-replay-order.mjs'));
// Only the original286 no-Storage fixture's default-grant exception table uses retained fixture helpers.
const defaultExceptionFixtureRoot=purpose==='immutable-private-no-storage-normal-cli'?"/mnt/ai_models/codex-preserved-custodial/current-source-staging-20261024/inventory-ack/G31-original286-fixture-only-default-exceptions-source-gap-PROPOSAL-source01/authentic-original286-fixture-helper-context":B;
if(purpose==='immutable-private-no-storage-normal-cli'){
 for(const [relative,digest]of Object.entries({"scripts/current-release-recovery-probe.mjs":"89bf3cbea970ae1c59be00acc2be9bfa71d1abcd82741748fa566b05cdb19b54","scripts/current-release-recovery-replay.mjs":"b787c9c5759649ed4d482382b5a039b2e802152e7e8ba11b78e461efea9b064d","scripts/schema-fingerprint-catalog.mjs":"2d9a6c581d434630257fdb9c915bf196380af96d15af7185fb3f6d19a6cfafad"}))assert.equal(sha(fs.readFileSync(defaultExceptionFixtureRoot+'/'+relative)),digest,'Authentic original286 fixture helper changed');
}
const {DEFAULT_EXCEPTIONS}=await import(pathToFileURL(defaultExceptionFixtureRoot+'/scripts/current-release-recovery-replay.mjs'));
// Existing254 is a schema prerequisite only. New migration is applied separately.
const oldRoot=D+'../private-custody-exchange-draft-20261010-v1/http-bounded-piece-composition-draft-20261011-v1/backend';
const staffingCurrentHttp=purpose==='staffing-current-http';
const consoleOriginal=purpose==='console-original';
const consoleOriginalHttp=purpose==='console-original-http';
const groupOriginal=purpose==='group-original';
const groupRecovery=purpose==='group-recovery';
const recoveryNativePositive=purpose==='same-original-native-positive';
const recoveryNativeStatus=purpose==='same-original-native-status';
const recoveryNativeManagerPreparation=purpose==='same-original-native-manager-preparation';
const recoveryLeasePair=purpose==='same-original-native-manager-lease-pair';
const recoveryWriterHold=purpose==='same-original-native-durable-writer-hold'||recoveryLeasePair;
const recoverySavedBrowser=purpose==='same-original-native-saved-browser-read'||recoveryWriterHold;
const recoveryNativeAcceptedCompletion=purpose==='same-original-native-accepted-completion-read'||recoverySavedBrowser;
const recoveryNativeCompletion=purpose==='same-original-native-completion-read'||recoveryNativeAcceptedCompletion;
const recoveryManagerReadFloor=purpose==='same-original-current-manager-read-floor';
const inventoryRequestFloor=purpose==='native-original-inventory-registration';
const inventoryStatusFloor=purpose==='native-original-inventory-status';
const inventoryConfirmation=purpose==='native-original-inventory-confirmation-guard';
const inventoryManifestStatus=purpose==='native-original-inventory-manifest-http-status';
const inventoryManifestManagerSource=purpose==='native-original-inventory-manager-manifest-source';
const inventoryManagerDecision=purpose==='native-original-inventory-manager-decision';
const inventoryManagerDecisionHttp=purpose==='native-original-inventory-manager-decision-http';
const inventoryManifestSemanticReview=purpose==='native-original-inventory-semantic-review'||inventoryManagerDecision||inventoryManagerDecisionHttp;
const inventoryManifestChunks=purpose==='native-original-inventory-manifest-chunks'||inventoryManifestStatus||inventoryManifestManagerSource||inventoryManifestSemanticReview;
const inventoryPositive=purpose==='native-original-inventory-registration-status-join'||inventoryConfirmation||inventoryManifestChunks;
const immutableOwnerCapabilities=purpose==='immutable-private-owner-capabilities';
const immutableBoundOwnerContext=purpose==='immutable-private-bound-owner-context';
const immutableContextPlan=purpose==='immutable-private-context-query-plan';
const freshStatusCli=purpose==='immutable-private-fresh-status-cli';
const originalRestoreStatus=purpose==='immutable-private-original-status'||freshStatusCli;
const backupOriginalMetadata=purpose==='immutable-private-backup-original-metadata';
const shippingSourceProfile=purpose==='immutable-private-shipping-source-profile';
const freshRecordDenial=purpose==='immutable-private-fresh-record-denial';
const freshStageCommit=purpose==='immutable-private-fresh-stage-commit';
const freshSnapshotCli=purpose==='immutable-private-fresh-snapshot-normal-cli';
const noStorageContinuationCli=purpose==='immutable-private-no-storage-normal-cli';
// Only target-schema reconstruction uses the exact retained original286 root.
// All currentCLI/initializer/archive/auth imports remain rooted in B.
const original286SchemaRoot="/mnt/ai_models/codex-preserved-custodial/current-source-staging-20261024/inventory-ack/G31-original286-schema-currentCLI-qualifier-adapter-source01/authentic-original286-schema-root";
const fixtureSchemaRoot=noStorageContinuationCli?original286SchemaRoot:B;
const postAuthorityContinuationCli=noStorageContinuationCli||purpose==='immutable-private-post-authority-normal-cli';
const populatedAuthorityReadbackCli=postAuthorityContinuationCli||purpose==='immutable-private-populated-authority-normal-cli';
const sourceOwnedReadbackCli=purpose==='immutable-private-source-owned-readback-normal-cli'||populatedAuthorityReadbackCli;
const freshAuthCompleteCli=purpose==='immutable-private-auth-complete-scope-normal-cli'||sourceOwnedReadbackCli;
const freshCompleteReadbackCli=purpose==='immutable-private-ordinary-original-readback-normal-cli'||freshAuthCompleteCli;
const freshOriginalReadbackCli=purpose==='immutable-private-fresh-original-readback-normal-cli'||purpose==='immutable-private-post-database-first-refusal'||freshCompleteReadbackCli;
const freshNormalCli=purpose==='immutable-private-fresh-normal-cli'||freshSnapshotCli||freshOriginalReadbackCli;
const shippingSourceInitializer=purpose==='immutable-private-shipping-source-initializer'||shippingSourceProfile||freshRecordDenial||freshStageCommit||freshNormalCli;
const cronInt64Owned=purpose==='cron-int64-owned-database';
const immutableFreshSchema=purpose==='immutable-private-fresh-schema'||immutableContextPlan;
const immutableOwnerContext=purpose==='immutable-private-owner-context'||immutableOwnerCapabilities||immutableBoundOwnerContext||immutableFreshSchema||originalRestoreStatus||backupOriginalMetadata||shippingSourceInitializer||cronInt64Owned;
const privateFunctionCatalog=purpose==='immutable-private-function-catalog';
const privateSchemaOwnerCatalog=purpose==='immutable-private-schema-owner-catalog';
const schemaOwnerInputPins=privateSchemaOwnerCatalog?Object.freeze({
 "scripts/schema-fingerprint-catalog.mjs": "2d9a6c581d434630257fdb9c915bf196380af96d15af7185fb3f6d19a6cfafad",
 "scripts/backup-release-schema-binding-tests.mjs": "d01bdba1bd8ca2792bf2573bb3dcfce53dd903c046e279588c0ececb32a2ea74",
 "scripts/release-migration-workflow-preflight.mjs": "4cda1106041741c8aa3ea3f9f303f06a1672b2a3ef894cec3af15b2df1b42d2f",
 "scripts/release-migration-workflow-tests.mjs": "cf8080f5d276bb2fd59a8f5f65ef44f33bdb152a675dfc979bd28e7658945b7b",
 "scripts/schema-catalog-readonly-client.mjs": "c0aa6989d893e399a2f50841c2fa17dec8c5a435a9290071f782b1dc3db9288b"
}):null;
const recoveryRegistrationStatus=purpose==='same-original-registration-status';
const recoveryRegistration=purpose==='same-original-registration'||recoveryRegistrationStatus;
const recoveryPreparation=purpose==='same-original-preparation'||recoveryRegistration;
const currentSchema=privateSchemaOwnerCatalog||privateFunctionCatalog||inventoryPositive||inventoryStatusFloor||inventoryRequestFloor||recoveryNativeCompletion||recoveryNativeManagerPreparation||recoveryManagerReadFloor||recoveryNativeStatus||recoveryNativePositive||recoveryPreparation||groupRecovery||groupOriginal||consoleOriginalHttp||consoleOriginal||staffingCurrentHttp||['feedback','staffing-positive','staffing-date','staffing-schema','staffing-cancel','staffing-replaced','vacancy-source','vacancy-workflow','vacancy-retained','event-source','event-date-source','dashboard-original-source','completion-readback-permission','completion-positive','completion-protected-positive','completion-protected-http','a1-delegate-multiweek','feedback-current-original','messenger-original','messenger-original-http'].includes(purpose);
const current261=['staffing-schema','staffing-cancel'].includes(purpose);
const plan=readMigrationReplayPlan(noStorageContinuationCli?fixtureSchemaRoot:(consoleOriginal?B:((currentSchema||immutableOwnerContext)?B:oldRoot)));
if(privateFunctionCatalog){
 assert.equal(plan.files.length,283);assert.equal(plan.manifestSha256,'ad0ab3d406e1d39818605b2676b5ebde9b29dc2c7a0b0175f59fdfea89a3229f');
 assert.equal(plan.files.at(-1),'20261016143226_native_original_inventory_manager_decision.sql');
 assert.equal(sha(fs.readFileSync(B+'/scripts/schema-fingerprint-catalog.mjs')),'de073aac8ee59679c95b632a2131d4341392d875060b98aad843698f1fe0218d');
 assert.equal(sha(fs.readFileSync(B+'/scripts/schema-catalog-readonly-client.mjs')),'c0aa6989d893e399a2f50841c2fa17dec8c5a435a9290071f782b1dc3db9288b');
}else if(privateSchemaOwnerCatalog){
 assert.equal(plan.files.length,283);assert.equal(plan.manifestSha256,'ad0ab3d406e1d39818605b2676b5ebde9b29dc2c7a0b0175f59fdfea89a3229f');
 assert.equal(plan.files.at(-1),'20261016143226_native_original_inventory_manager_decision.sql');
 for(const [file,digest]of Object.entries(schemaOwnerInputPins))assert.equal(sha(fs.readFileSync(path.join(B,file))),digest);
}else if(inventoryManagerDecisionHttp){
 assert.equal(plan.files.length,283);assert.equal(plan.manifestSha256,'ad0ab3d406e1d39818605b2676b5ebde9b29dc2c7a0b0175f59fdfea89a3229f');
 assert.equal(plan.files.at(-1),'20261016143226_native_original_inventory_manager_decision.sql');
 for(const [file,digest]of Object.entries({
  'scripts/native-original-inventory-manifest-chunk-tests.mjs':'be0e3fb1c0b53739933e83f552cdbac837e6b8b35476c524ea045c8448526411',
  'scripts/native-original-inventory-request-sql-tests.mjs':'40ca456c3a19e85637597e28cf3bc7e59403a3852bdb4d7d4cf04bd16f87180a',
  'src/native-original-inventory-status.js':'67a252973f73877a7fd427a971bc828ac4111490bcaa870c25fec6877b7b39d3',
  'src/native-original-inventory-request-route.js':'9ea31e8164b76d4c18bc68dd3a138fd87ac0f813c9481e9b4e3850831149799b',
  'src/same-original-recovery-native-challenge-composition.js':'39ebb1dec559c27e00a8ffb4b03275d3daf96d5edbf95c699a9199ca6f0a441f',
 }))assert.equal(sha(fs.readFileSync(path.join(B,file))),digest);
}else if(inventoryManagerDecision){
 assert.equal(plan.files.length,283);assert.equal(plan.manifestSha256,'ad0ab3d406e1d39818605b2676b5ebde9b29dc2c7a0b0175f59fdfea89a3229f');
 assert.equal(plan.files.at(-1),'20261016143226_native_original_inventory_manager_decision.sql');
 for(const [file,digest]of Object.entries({
  'supabase/migrations/20261016143226_native_original_inventory_manager_decision.sql':'ec4d2920dc99830d217a7e179a3696e487d6ebe6170801f9f53112b9ccc00d79',
  'scripts/native-original-inventory-manifest-chunk-tests.mjs':'4b5ffdb3b214aef1d0177f62ce9090882fb2291fd3fa09ed59970fce4d32bb92',
  'scripts/native-original-inventory-request-sql-tests.mjs':'dfb796c9ef0797dfe62ae82ec260bc19ed330eaa91f18da312796f45a2a5a0e4',
  'src/native-original-inventory-manifest.js':'5e3beb973833ed799922c810dea8bcd7fb60421abbe4329f3f5c9a2b7f9550d2',
  'src/original-inventory-separation-store.js':'8b17cd564b20eb88a8161ffb846e2c3049872e5cc456e3f7ad895232316f11c5',
 }))assert.equal(sha(fs.readFileSync(B+'/'+file)),digest,file);
}else if(inventoryManifestSemanticReview){
 assert.equal(plan.files.length,282);assert.equal(plan.manifestSha256,'1537386085fb63cc1e96fc0fd148b25c6ef99854f3a38ed994d0bf1e6534ead4');
 assert.equal(plan.files.at(-1),'20261016140703_native_original_inventory_semantic_review.sql');
 for(const [file,digest]of Object.entries({
  'supabase/migrations/20261016140703_native_original_inventory_semantic_review.sql':'e61de073f2374bea3305ad23fa06fa22c9d2f1ef9f5c25115e8b98bb0ccbf0e8',
  'scripts/native-original-inventory-manifest-chunk-tests.mjs':'ffc83127d154d18776d112bc0d7774a7a53a29731ded78645a186714ef00f1ac',
  'scripts/native-original-inventory-request-sql-tests.mjs':'f65986085ebd704bbbddb765dc72f2866b2c4fe50bde9f99fb442fd34a08ffc2',
  'src/native-original-inventory-manifest.js':'5e3beb973833ed799922c810dea8bcd7fb60421abbe4329f3f5c9a2b7f9550d2',
  'src/original-inventory-separation-store.js':'8b17cd564b20eb88a8161ffb846e2c3049872e5cc456e3f7ad895232316f11c5',
 }))assert.equal(sha(fs.readFileSync(B+'/'+file)),digest,file);
}else if(inventoryManifestManagerSource){
 assert.equal(plan.files.length,281);assert.equal(plan.manifestSha256,'4bcaee111d1ec78cfcb3acf9bc82458f785f955d391a24ba9e6fdbc356b8de27');
 assert.equal(plan.files.at(-1),'20261016133120_native_original_inventory_manager_manifest_read.sql');
 assert.equal(sha(fs.readFileSync(B+'/supabase/migrations/'+plan.files.at(-1))),'7acafd2bd12cedc790aafb4fb696ba6326eb20f530f98fc6f7e6ab1b89d89827');
 assert.equal(sha(fs.readFileSync(B+'/scripts/native-original-inventory-manifest-chunk-tests.mjs')),'affcfd161b4fc4bce4a02960dfffde52b78cac2a681dcc6d401c96b1e602fe46');
 assert.equal(sha(fs.readFileSync(B+'/scripts/native-original-inventory-request-sql-tests.mjs')),'9b2685ece6a83726b3934df5631f964b8046d103afa8217f83045361267e536c');
 assert.equal(sha(fs.readFileSync(B+'/src/native-original-inventory-manifest.js')),'2b43e1ce9626d2f3826a9bc53d81730fb967ac49f757127f30698035973b6bb3');
}else if(inventoryManifestChunks){
 assert.equal(plan.files.length,280);assert.equal(plan.manifestSha256,'e1c111698f12b2900942fa758c705e85d4f513dae3b82bfc2fc87a1cd327f9b7');
 assert.equal(plan.files.at(-1),'20261016121857_native_original_inventory_manifest_chunks.sql');
 assert.equal(sha(fs.readFileSync(B+'/supabase/migrations/'+plan.files.at(-1))),'4f3687fe9a35376b5859c90b3c33f417bd6d87ec41658fb53f6d79d2d51d84ce');
 assert.equal(sha(fs.readFileSync(B+'/scripts/native-original-inventory-manifest-chunk-tests.mjs')),inventoryManifestStatus?'f72168d2a20e25c066542bdad15871590789028909ff152e30208b93acc9925f':'81fd5a943542d48d740757ed859c9c936b8221cb96bd24b9cf4076cd3f811832');
}else if(inventoryConfirmation){
 assert.equal(plan.files.length,279);assert.equal(plan.manifestSha256,'272fc50a0a1bad7a9cf7ae3b6d49c8618bce15c176a33468baf0289f590de709');
 assert.equal(sha(fs.readFileSync(B+'/scripts/native-original-inventory-request-sql-tests.mjs')),'60b1d8dc1cce6aa1542a15632f03d257a0f430d14f23774cd488e6f374a31022');
 assert.equal(sha(fs.readFileSync(B+'/supabase/migrations/20261016111320_native_inventory_current_confirmation_guard.sql')),'760877770d9739ec041d8cefa7d20f48ef771dc4f9437c3c09264d2b0be0c4c3');
}else if(inventoryPositive){
 assert.equal(plan.files.length,278);assert.equal(plan.manifestSha256,'903bdd47be244f728904c656274da22cf0fba3ff89ab835446dd2edf9b99d39c');
 assert.equal(sha(fs.readFileSync(B+'/scripts/native-original-inventory-request-sql-tests.mjs')),'0f181f93c9818380a196b36cfc92c4f9b530633c68115a367ac9d5dd2adafa06');
 assert.equal(sha(fs.readFileSync(B+'/scripts/same-original-recovery-local-database-tests.mjs')),'8f1d392f7c0930cc7785434d98b4f42e232256a1b39617acdeeb8598ed508a43');
}else if(inventoryStatusFloor){
 assert.equal(plan.files.length,278);assert.equal(plan.manifestSha256,'903bdd47be244f728904c656274da22cf0fba3ff89ab835446dd2edf9b99d39c');
 assert.equal(plan.files.at(-1),'20261016103024_native_original_inventory_request_status_read.sql');
 assert.equal(sha(fs.readFileSync(B+'/supabase/migrations/'+plan.files.at(-1))),'e181509806947b79d00bc43a3472fadf46512b5983876f9a093cafc7a7a37aa6');
 assert.equal(sha(fs.readFileSync(B+'/scripts/native-original-inventory-request-sql-tests.mjs')),'4355a61e3a38d979696feb1c038c8b5c44fe17facf908712ea6b37fba7ad471b');
}else if(inventoryRequestFloor){
 assert.equal(plan.files.length,277);assert.equal(plan.manifestSha256,'f80fbe8c37242de47d1321f06009fe090fe45b07fad041d519e785350c9304f1');
 assert.equal(plan.files.at(-1),'20261016095134_native_original_inventory_request_registration.sql');
 assert.equal(sha(fs.readFileSync(B+'/supabase/migrations/'+plan.files.at(-1))),'c0d0f2b0aa9bd7a98adeb4b7a460256c2cc57b5edd748fdf3778504bf9fd7041');
 assert.equal(sha(fs.readFileSync(B+'/scripts/native-original-inventory-request-sql-tests.mjs')),'1c4ca3bddfb0c3fc78ad4e55a9f231fb63f394b3eb4581a82df85310a62fb3da');
}else if(recoveryNativeCompletion){
 assert.equal(plan.files.length,276);assert.equal(plan.manifestSha256,'b49cb0c76aa27d784dbf3b3d508a6e02f787661502667b89f03b59c2e0bd2d45');
 assert.equal(plan.files.at(-1),'20261015040830_same_original_retained_completion_read.sql');
 assert.equal(sha(fs.readFileSync(B+'/supabase/migrations/'+plan.files.at(-1))),'ecb708c726535401ddf085d122c54bfad1e58b6322c17c0c89af7c234b046c3d');
}else if(freshAuthCompleteCli){
 assert.equal(plan.files.length,286);assert.equal(plan.manifestSha256,'f8634d695f77c02ba2c27c6b2d7f8cc8f388e435ff639fd5aef9eb95267c3657');
 assert.equal(plan.files.at(-1),'20261017225101_approved_static_dated_original_materialization.sql');
 assert.equal(sha(fs.readFileSync(fixtureSchemaRoot+'/supabase/migrations/'+plan.files.at(-1))),'2526dde3e55268da83ba43c8ce30c61c5f1a8c83df50aae85d557c517c383418');
}else if(immutableOwnerContext){
 assert.equal(plan.files.length,283);assert.equal(plan.manifestSha256,'ad0ab3d406e1d39818605b2676b5ebde9b29dc2c7a0b0175f59fdfea89a3229f');
 assert.equal(plan.files.at(-1),'20261016143226_native_original_inventory_manager_decision.sql');
}else if(recoveryManagerReadFloor||recoveryNativeManagerPreparation){
 assert.equal(plan.files.length,275);assert.equal(plan.manifestSha256,'dee928018a92ebd13a6e86c49b88b14dd356d3d3f7f5e34b3666b991021e48ef');
 assert.equal(plan.files.at(-1),'20261014143050_same_original_current_manager_preparation_read.sql');
}else if(recoveryNativeStatus||recoveryNativePositive||recoveryRegistrationStatus){
 assert.equal(plan.files.length,274);assert.equal(plan.manifestSha256,'751f229857fec246f5e7b067fd18ac34806bec1962b55b3b178b55d3c4c10b20');
 assert.equal(plan.files.at(-1),'20261014031928_same_original_native_registration_status.sql');
}else if(recoveryRegistration){
 assert.equal(plan.files.length,273);assert.equal(plan.manifestSha256,'853d4a66f72c87cdabcf2f3b6300dfaedda2cc29bc304424d43e310560f0efd3');
 assert.deepEqual(plan.files.slice(-2),['20261014010337_same_original_recovery_target_read.sql','20261014024357_same_original_native_challenge_registration.sql']);
}else if(recoveryPreparation){
 assert.equal(plan.files.length,271);
 assert.equal(plan.files[270],'20261014000624_same_original_recovery_preparation.sql');
 assert.equal(sha(fs.readFileSync(B+'/supabase/migrations/'+plan.files[270])),'3c6506413076bc39a0bae52a281ffd7da0d7683f30c3df1a1a21367e3c7361cb');
}else if(purpose==='a1-delegate-multiweek'){
 assert.equal(plan.files.length,270);assert.equal(plan.manifestSha256,'bab874d187141c14c17ce51d050ec3ca67fde7df495e378bfb4e93367399aef7');
 assert.deepEqual(execFileSync('/usr/bin/git',['-C',B,'rev-parse','HEAD','HEAD^{tree}'],{encoding:'utf8'}).trim().split('\n'),['0f168f72826673abe6194f4d1735617970404bc2','7f5b886b1af3ba805c557cc2da18f0ae422c78d6']);
 for(const [file,digest] of Object.entries({
  'scripts/fixtures/oc24-coverall-database-fixture.mjs':'af0343dccb2155fa5ca9399e152992ff2d906df1251050d8f0221cd63634d232',
  'src/static-weekly-control-plane.js':'9abd4da9f6f1eeeb99fae4ab4abacb78de842112a962e160609c0e6f41f980c5',
  'src/static-weekly-control-plane-runtime.js':'8597371d1ce0e14c7039038ce116f344c2e3a54d54f7c159f013ace68a94a92e',
 }))assert.equal(sha(fs.readFileSync(B+'/'+file)),digest,file);
}else if(groupOriginal||groupRecovery){assert.equal(plan.files.length,270);assert.equal(plan.manifestSha256,groupRecovery?'bab874d187141c14c17ce51d050ec3ca67fde7df495e378bfb4e93367399aef7':'f9d96b4f3d32b95f376ef21e09642b74958db51cb3bbd0101fa2ca57bd6fe3dd');}else if(consoleOriginal||consoleOriginalHttp){assert.equal(plan.files.length,269);assert.equal(plan.manifestSha256,'0a07478826d83fa4f6f8cf243f108c43b7841dc51b558ec3df5dba2b6d463267');}else{
if(staffingCurrentHttp){assert.equal(plan.files.length,268);assert.equal(plan.manifestSha256,'ba4d47368893462d690cafdfc5ea34fb87e29aa32bdb07127c7a29c6c559879c');}else assert.equal(plan.files.length,['completion-protected-positive','completion-protected-http','a1-delegate-multiweek','feedback-current-original','messenger-original','messenger-original-http'].includes(purpose)?(['messenger-original','messenger-original-http'].includes(purpose)?268:267):['event-date-source','dashboard-original-source','completion-readback-permission','completion-positive','completion-protected-positive','completion-protected-http'].includes(purpose)?266:purpose==='vacancy-retained'?265:purpose==='event-source'?264:['vacancy-source','vacancy-workflow'].includes(purpose)?263:purpose==='staffing-replaced'?262:current261?261:['staffing-positive','staffing-date'].includes(purpose)?260:currentSchema?258:254);
if(!staffingCurrentHttp&&purpose!=='messenger-original-http') assert.equal(plan.manifestSha256,['completion-protected-positive','completion-protected-http','a1-delegate-multiweek','feedback-current-original','messenger-original','messenger-original-http'].includes(purpose)?(['messenger-original','messenger-original-http'].includes(purpose)?'8c6eff7a39ff18c91534a86a62f8fb2e5795bd07c0304489a9986b2c2e958298':'f2268119ae170b11d77c3b2da1a02a0728690cfa49e5fb4e94732c799d1d020e'):['event-date-source','dashboard-original-source','completion-readback-permission','completion-positive','completion-protected-positive','completion-protected-http'].includes(purpose)?'4696df5f8284ac99c0dc368a1577dd647ccf08a3f1930a9e5efb875fc30f7416':purpose==='vacancy-retained'?'5eb2e65dfa68e75f461edffe0d94784b7bcaa69b2a54c5af9a18f945edb6fa86':purpose==='event-source'?'b7578b7459cec11eada78481c7100b16070e284785218dedde5a3f9fffa1449d':['vacancy-source','vacancy-workflow'].includes(purpose)?'e98bf16ee1da41ca50374e43c822ca05b2ca86a075149191850d416c5f646cb6':purpose==='staffing-replaced'?'eadf18d1183ea3dd1e2c83f14a76736a0415eadfd9abd7b2c6e7e6d2a6d272e4':current261?'efbfb6947721fada077068bc98e001606dfa8a82818df88e0168c21db1093469':['staffing-positive','staffing-date'].includes(purpose)?'3d8a7bef4b6a1a0e77319d4ce3c29f29f472a1a77fc52c16e10518512954cd95':currentSchema?'e6b59bdf7150dc6ce63fcb130f184d05549dba3127106028d0682a2ef92244f7':'8e63c31b5f8bf9be8dbe45cc663874ff4e32b0d8c31da082d9cb21ee6afdb1eb');
else if(!staffingCurrentHttp) assert.equal(plan.manifestSha256,'ba4d47368893462d690cafdfc5ea34fb87e29aa32bdb07127c7a29c6c559879c');
}
// Both schema stages use the same explicitly admitted source, never mutable
// Main drafts. Rebind only these new-mode pins after the owning source changes.
const consoleHttpBinding=consoleOriginalHttp?{
 backend:['b4f5c19841f730b7757d95e9b1cb65fdede37ebe','63c6865e09d304636f75aed3a2905ecd7b4f295f'],
 files:{
  'src/gemini-console-api.js':'8dad750811e5d1aa700ca20a1c4b85dd9964d5b23f586aa703eaee95f8a9bd5d',
  'src/gemini-original-outcome.js':'028c5b588fb164dcaff1cb2d2294278ab43866267f2479aefe44ed55fa97cb48',
  'src/auth/shared-access-auth.js':'17bd837f46d5692a042ec280331c0f15c9ee3fd9b7a43ed0458dc1c1f7741c8b',
  'supabase/migrations/20261013113033_gemini_original_turn_preservation.sql':'33249306963b02d90e84e56f06bfe2d852c2009e869f7b50b8c8d87b91f712f4',
 },
}:null;
if(consoleHttpBinding){
 assert.deepEqual(execFileSync('/usr/bin/git',['-C',B,'rev-parse','HEAD','HEAD^{tree}'],{encoding:'utf8'}).trim().split('\n'),consoleHttpBinding.backend);
 assert.equal(execFileSync('/usr/bin/git',['-C',B,'status','--porcelain'],{encoding:'utf8'}).trim(),'');
 for(const [file,digest] of Object.entries(consoleHttpBinding.files))assert.equal(sha(fs.readFileSync(B+'/'+file)),digest,file);
}
// Complete immutable DATA finish is one guarded SQL statement, not a source
// smoke query. Production restore does not impose this fixture's former30s
// client read cutoff. Keep a finite client allowance inside the independently
// bounded whole run; no SQL/server timeout, role or guard setting is changed.
const fixtureDatabase=freshNormalCli?ownedContainerName:'postgres';
const options={host:socket,user:immutableOwnerContext?'postgres':'supabase_admin',database:fixtureDatabase,password:bootstrap,connectionTimeoutMillis:500,
 query_timeout:immutableFreshSchema&&!immutableContextPlan?180000:30000};
const revokeFor=owners=>owners.flatMap(owner=>['',' in schema public'].map(scope=>`alter default privileges for role ${owner}${scope} revoke all on tables from public,anon,authenticated,service_role;alter default privileges for role ${owner}${scope} revoke all on sequences from public,anon,authenticated,service_role;`)).join('\n');
const revoke=revokeFor(immutableOwnerContext?['postgres']:['postgres','supabase_admin']);
const defaults="select count(*)::int n from pg_default_acl d cross join lateral aclexplode(d.defaclacl) a where d.defaclnamespace in (0,'public'::regnamespace) and d.defaclrole in ('postgres'::regrole,'supabase_admin'::regrole) and d.defaclobjtype in ('r','S') and a.grantee in (0,'anon'::regrole,'authenticated'::regrole,'service_role'::regrole)";
let admin,gateway,api,staffingFixture,staffingHttpPool,phase='startup';const clients=new Set(),checks=[],witness=[],replayed=[];
const id=n=>`98000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
async function tx(sql,args=[],role='service_role',write=false) {
 assert.ok(['service_role','custodial_application_reader','anon','authenticated','static_weekly_control_plane','static_weekly_release_operator'].includes(role));
 const c=new Client(options);clients.add(c);c.on('error',()=>{});
 try {await c.connect();await c.query(write?'begin':'begin read only');await c.query('set local role '+role);
  await c.query("set local statement_timeout='8s';set local lock_timeout='2s'");
  const ctx=(await c.query("select current_user actor,current_setting('transaction_read_only') readonly")).rows[0];
  assert.equal(ctx.actor,role);assert.equal(ctx.readonly,write?'off':'on');witness.push({...ctx,SQL_sha256:sha(sql)});
  const r=await c.query(sql,args);await c.query('commit');return r;
 }catch(e){await c.query('rollback').catch(()=>{});throw e;}
 finally{await c.end().catch(()=>{});clients.delete(c);}
}
async function start(server){await new Promise((ok,no)=>{server.once('error',no);server.listen(0,'127.0.0.1',ok);});return server;}
try {
 if(immutableOwnerContext&&stage==='start'){
  // Existing disposable-fixture bootstrap administration ONLY. This is not
  // an import/guard call, permission fallback, role grant or owner replacement.
  // The subsequent schema/import connection is still the declared postgres
  // owner and must independently pass its unchanged permissions and guards.
  let bootstrapAdmin;const postmasterObservations=[];
  try{
   for(let n=0,ready=0;n<40;n++){
    const candidate=new Client({...options,user:'supabase_admin'});clients.add(candidate);candidate.on('error',()=>{});
    try{
     await candidate.connect();
     const roles=(await candidate.query("select count(*)::int n from pg_roles where rolname in ('anon','authenticated','service_role','supabase_admin')")).rows[0].n;
     // The cached image briefly exposes a temporary bootstrap postmaster with
     // all four roles before restarting. Wait for its final exec'd PID1
     // postmaster BEFORE any extension/default-ACL fixture administration.
     // Fixed PID metadata only: no arbitrary server file or credential read.
     const postmaster=(await candidate.query("select split_part(pg_catalog.pg_read_file('postmaster.pid',0,32),chr(10),1) postmaster_pid,pg_catalog.pg_postmaster_start_time()::text started_at")).rows[0];
     postmasterObservations.push({roles,...postmaster});
     if(roles===4&&postmaster.postmaster_pid==='1'&&++ready===4){bootstrapAdmin=candidate;break;}
     if(roles!==4||postmaster.postmaster_pid!=='1')ready=0;
    }catch(error){ready=0;if(n===39)throw error;}
    await candidate.end().catch(()=>{});clients.delete(candidate);await new Promise(resolve=>setTimeout(resolve,500));
   }
   assert.ok(bootstrapAdmin,'Original cached-image fixture roles not ready');
   put('FIXTURE_POSTMASTER_READINESS.json',{observations:postmasterObservations,final_postmaster_pid:'1',
    scope:'Read-only final cached-image postmaster prerequisite before fixture DDL; no PID1 inference from role visibility or elapsed sleep'});
   const identity=(await bootstrapAdmin.query('select current_user actor,session_user session_actor,current_database() database')).rows[0];
   assert.deepEqual(identity,{actor:'supabase_admin',session_actor:'supabase_admin',database:fixtureDatabase});
   if(freshNormalCli){
    // Provision the REQUIRED owner of this brand-new EMPTY image-created
    // database before application Source, signed intent or import admission.
    // No existing/populated target is adopted and the product guard stays exact.
    assert.match(fixtureDatabase,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);
    const before=(await bootstrapAdmin.query("select pg_get_userbyid(datdba) owner,(select count(*)::int from pg_catalog.pg_class c join pg_catalog.pg_namespace n on n.oid=c.relnamespace where n.nspname='public') public_objects from pg_catalog.pg_database where datname=current_database()")).rows[0];
    assert.equal(before.public_objects,0);assert.ok(['postgres','supabase_admin'].includes(before.owner));
    if(before.owner!=='postgres')await bootstrapAdmin.query('alter database "'+fixtureDatabase+'" owner to postgres');
    const after=(await bootstrapAdmin.query("select pg_get_userbyid(datdba) owner from pg_catalog.pg_database where datname=current_database()")).rows[0];
    assert.equal(after.owner,'postgres');
    put('NEW_EMPTY_DATABASE_OWNER_PREREQUISITE.json',{database:fixtureDatabase,before,after,
     stage:'before application Source and original intent creation',existing_target_adopted:false,
     roles_grants_HBA_or_product_guards_changed:false});
   }
   await bootstrapAdmin.query(revokeFor(['postgres','supabase_admin']));
   assert.equal((await bootstrapAdmin.query(defaults)).rows[0].n,0);
   // Match the source-declared managed platform prerequisites, using only the
   // exact cached-image extensions. Source/ledger/import ownership remains
   // postgres; no denied application query is run through this connection.
   const baseline=fs.readFileSync(fixtureSchemaRoot+'/supabase/migrations/00000000000000_production_baseline.sql','utf8');
   const extensionStatements=baseline.split('\n').filter(line=>/^create extension if not exists "[a-z_-]+" with schema "[a-z_]+";$/.test(line));
   assert.equal(extensionStatements.length,6);
   await bootstrapAdmin.query('create schema if not exists extensions authorization postgres;create schema if not exists vault authorization postgres');
   for(const statement of extensionStatements)await bootstrapAdmin.query(statement);
   put('FIXTURE_ADMINISTRATION.json',{identity,extension_statements:extensionStatements,baseline_sha256:sha(baseline),
    scope:'Existing isolated platform/default-ACL prerequisites ONLY; no application/import/source guard calls, permissions added, role grants or owner replacement'});
   put('FIXTURE_OWNER_CONNECT_PREREQUISITES.json',{
    configuration:(await bootstrapAdmin.query("select current_setting('config_file') config_file,current_setting('hba_file') hba_file,current_setting('session_preload_libraries') session_preload_libraries")).rows,
    original_owner_role:(await bootstrapAdmin.query("select rolname,rolcanlogin,rolsuper from pg_roles where rolname='postgres'")).rows,
    local_authentication_rules:(await bootstrapAdmin.query("select type,database,user_name,auth_method,error from pg_hba_file_rules where type='local'")).rows,
    scope:'Read-only fixture connection configuration; no passwords, password hashes or credentials read; no application query fallback'});
  }finally{if(bootstrapAdmin){await bootstrapAdmin.end().catch(()=>{});clients.delete(bootstrapAdmin);}}
 }
 if(immutableOwnerContext){
  // The image's ORIGINAL HBA requires OS peer identity for postgres. Use the
  // existing fixture's psql route as that exact OS owner, not a password
  // change, HBA exception, SET ROLE, superuser, or alternate application role.
  assert.match(ownedContainerName,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);
  assert.equal(clients.size,0,'bootstrap connections closed before owner peer work');
  const peerSQL=sql=>{
   try{return execFileSync('/usr/bin/docker',['--host','unix:///var/run/docker.sock','exec','--user','postgres','-i',ownedContainerName,
    'psql','-X','-qAt','-v','ON_ERROR_STOP=1','-v','VERBOSITY=verbose','-U','postgres','-d',fixtureDatabase],
    {input:sql,encoding:'utf8',timeout:35000,maxBuffer:2097152});}
   catch(error){put('ORIGINAL_OWNER_PEER_FAILURE_'+stage+'.json',{status:error.status??null,code:error.code??null,
    stdout:String(error.stdout??'').slice(-12000),stderr:String(error.stderr??'').slice(-12000),
    role:'postgres',OS_user:'postgres',HBA_changed:false,alternate_role:false});throw error;}
  };
  const peerIdentity=`do $identity$ begin
   if current_user<>'postgres' or session_user<>current_user
    or (select rolsuper from pg_roles where rolname=current_user)
    or current_setting('session_preload_libraries') not like '%supautils%'
   then raise exception 'Original managed owner identity/configuration mismatch';end if;end $identity$;
   set statement_timeout='12s';set lock_timeout='2s';
   select json_build_object('actor',current_user,'session_actor',session_user,'database',current_database(),'peer_OS_owner','postgres');\n`;
  // Preserve the NORMAL cached-image/source schema-reconstruction owner.
  // Retained IMPORT_OWNER_BINDING.json already observes dr_owner=postgres
  // while group_owner=supabase_admin. Rebuilding every object as postgres
  // changes the immutable canonical predecessor bytes; it is not the target
  // contract. This connection executes exact SCHEMA sources only, never the
  // private import, its guards or any denied application query.
  phase='current immutable fixture normal schema owner prerequisite';
  const files=stage==='start'?plan.files.slice(0,200):plan.files.slice(200);
  const schemaOwner=new Client({...options,user:'supabase_admin'});clients.add(schemaOwner);schemaOwner.on('error',()=>{});
  const schemaReplayed=[];
  let originalFixtureArchive,originalFixtureInventory,originalFixtureRows;
  try{
   await schemaOwner.connect();
   assert.deepEqual((await schemaOwner.query('select current_user actor,session_user session_actor,current_database() database')).rows[0],
    {actor:'supabase_admin',session_actor:'supabase_admin',database:fixtureDatabase});
   assert.equal((await schemaOwner.query(defaults)).rows[0].n,0);
   if(freshAuthCompleteCli&&stage==='finish'){
    // The fresh restore fixture must match its authenticated ORIGINAL, not
    // preinstall newer unarchived app routines and ask ACL reconciliation to
    // overlook them. This is UNIT target setup, never a product fallback,
    // downgrade, DROP, relaxed exact-object check or chosen release version.
    const archiveApi=await import(B+'/scripts/disaster-recovery-archive.mjs');
    originalFixtureArchive=archiveApi.materializeVerifiedArchive({
     sourceDir:path.resolve(D,populatedAuthorityReadbackCli?'../restore-runtime-authorized-KM9tAR/native-text-original-v127-wEMJlz/new-auth-complete-original':'../restore-runtime-authorized-KM9tAR/auth-complete-original-release-row-v76'),
     archiveVerifyKey:populatedAuthorityReadbackCli?'UNIT-only-native-text-original-HMAC-20261018':'UNIT-only-auth-complete-original-HMAC-20261017',
     archiveVerifyKeyId:populatedAuthorityReadbackCli?'unit-native-text-original-v2':'unit-auth-complete-original-v1',
     supportedFormats:['memphis-zoo-disaster-recovery.v4']});
    const binding=archiveApi.readVerifiedArchiveSourceBinding(originalFixtureArchive);
    assert.equal(binding.archive_digest,populatedAuthorityReadbackCli?'732bc0b6c639db92b62e0203f40c1e7a025ecfc3389a5245a92cef86d2ab2cb2':'a86d0b7805eac5dba5f5dac5907d5fd0e974b0259e707079ed1927ad116d27de');
    originalFixtureInventory=archiveApi.readVerifiedImmutableBootstrapInventory(originalFixtureArchive);
    const ledger=JSON.parse(originalFixtureInventory.inventory['inventory/migration-ledger.json']);
    const originalCount=populatedAuthorityReadbackCli?286:285;
    assert.ok(Array.isArray(ledger));assert.equal(ledger.length,originalCount);
    originalFixtureRows=new Map();
    for(const row of ledger){
     assert.deepEqual(Object.keys(row).sort(),['name','statements','version']);
     assert.match(row.version,/^[0-9]{14}$/);assert.match(row.name,/^[a-z0-9_]+$/);
     assert.ok(Array.isArray(row.statements));assert.equal(row.statements.length,1);assert.equal(typeof row.statements[0],'string');
     const file=row.version+'_'+row.name+'.sql';assert.equal(originalFixtureRows.has(file),false);
     originalFixtureRows.set(file,row.statements[0]);
    }
    assert.equal(originalFixtureRows.size,originalCount);
    assert.equal(plan.files.length,286);
    assert.deepEqual(plan.files.filter(file=>!originalFixtureRows.has(file)),
      populatedAuthorityReadbackCli?[]:['20261017225101_approved_static_dated_original_materialization.sql']);
    // The signed DB ledger is ordered by version; the normal replay recipe
    // has an explicitly reviewed paired-source phase order. Require the same
    // closed members; execution BELOW still follows that exact pinned recipe.
    assert.deepEqual([...originalFixtureRows.keys()].sort(),plan.files.slice(0,originalCount).sort());
    const changes=[];
    for(const file of plan.files.slice(0,originalCount)){
     assert.ok(originalFixtureRows.has(file));
     if(sha(fs.readFileSync(fixtureSchemaRoot+'/supabase/migrations/'+file))!==sha(Buffer.from(originalFixtureRows.get(file))))changes.push(file);
    }
    assert.deepEqual(changes,populatedAuthorityReadbackCli?[]:['20261017200958_approved_static_original_confirmation_receipts.sql']);
    if(populatedAuthorityReadbackCli){
     put('ORIGINAL_RESTORE_FIXTURE_SCHEMA_SETUP.json',{archive_digest:binding.archive_digest,
      source_commit:binding.source_identity.release.backend_commit,exact_signed_members:originalCount,
      original_current_bytes_match:true,newer_unarchived_members:0,exact_object_guard_unchanged:true,
      scope:'NEW_POPULATED_SIGNED_UNIT_ORIGINAL286_EXACT_SCHEMA_PREREQUISITE_NOT_RESTORE_OR_DEPLOYMENT'});
    }else{
    assert.equal(sha(Buffer.from(originalFixtureRows.get(changes[0]))),'b8e8e207e3332f5758fb6de00ffaf0fcca4d2f44c6e61140ac1c8f813c938e5f');
    put('ORIGINAL_RESTORE_FIXTURE_SCHEMA_SETUP.json',{archive_digest:binding.archive_digest,
     source_commit:binding.source_identity.release.backend_commit,changed_current_members_not_adopted:changes,
     original_schema_member_sha256:'b8e8e207e3332f5758fb6de00ffaf0fcca4d2f44c6e61140ac1c8f813c938e5f',
     unchanged_current_prefix_members:284,exact_object_guard_unchanged:true,
     current_unarchived_tail_not_installed:[{file:plan.files[285],sha256:sha(fs.readFileSync(B+'/supabase/migrations/'+plan.files[285]))}],
     current_286_native_compile:'NOT_RUN; this target is the independently signed original285 schema only',
     newer_source_native_compile_retained:'auth-original-authority-status-cli-v86-L5SDjS/SCHEMA_finish.json',
     scope:'SIGNED_ORIGINAL_SCHEMA_ON_EXCLUSIVELY_OWNED_NEW_UNIT_TARGET_NOT_CURRENT_DEPLOYMENT_OR_SOURCE_ADMISSION'});
    }
   }
   for(const file of files){
    // The exact named new tail is NOT in this signed original. Do not create
    // newer objects, DROP them later, or weaken the original object-set guard.
    if(originalFixtureRows&&!originalFixtureRows.has(file)){
     assert.equal(file,'20261017225101_approved_static_dated_original_materialization.sql');continue;
    }
    phase='normal source schema prerequisite '+file;
    const bytes=originalFixtureRows?Buffer.from(originalFixtureRows.get(file)):fs.readFileSync(fixtureSchemaRoot+'/supabase/migrations/'+file);
    if(originalFixtureArchive){
     const archiveApi=await import(B+'/scripts/disaster-recovery-archive.mjs');
     assert.equal(archiveApi.readVerifiedImmutableBootstrapInventory(originalFixtureArchive).sourceBinding,originalFixtureInventory.sourceBinding);
    }
    await schemaOwner.query(bytes.toString());
    if(originalFixtureArchive){
     const archiveApi=await import(B+'/scripts/disaster-recovery-archive.mjs');
     assert.equal(archiveApi.readVerifiedImmutableBootstrapInventory(originalFixtureArchive).sourceBinding,originalFixtureInventory.sourceBinding);
    }
    if((await schemaOwner.query(defaults)).rows[0].n!==0){
     assert.equal(sha(bytes),DEFAULT_EXCEPTIONS[file]);assert.ok(!/\bcreate\s+(?:unlogged\s+)?(?:table|sequence)\b/i.test(bytes.toString()));
     await schemaOwner.query(revokeFor(['postgres','supabase_admin']));
    }
    assert.equal((await schemaOwner.query(defaults)).rows[0].n,0);schemaReplayed.push(file);
   }
  }finally{
   try{await schemaOwner.end();}finally{
    clients.delete(schemaOwner);
    if(originalFixtureArchive){const directory=originalFixtureArchive.directory;originalFixtureArchive.cleanup();
     assert.equal(fs.existsSync(directory),false);put('ORIGINAL_FIXTURE_SCHEMA_COPY_CLEANUP.json',{verification_copy_absent:true,original_retained:true});}
   }
  }
  put('SCHEMA_'+stage+'.json',{replayed:schemaReplayed,old_tests_NOT_repeated:true,normal_schema_owner:'supabase_admin',
   private_import_owner:immutableBoundOwnerContext?'supabase_admin (predeclared actual original object owner)':'postgres',
   normal_managed_configuration:true,application_import_queries_as_schema_owner:0,
   phase_limit:'SCHEMA prerequisites only; application operations, if any, separately recorded in PRODUCT_RESULT'});
  if(stage==='finish'&&immutableOwnerCapabilities){
   phase='new original postgres owner capabilities READ ONLY';
   const observed=peerSQL(peerIdentity+`begin isolation level repeatable read read only;
    select json_build_object(
     'server_version',current_setting('server_version'),
     'actor',current_user,'session_actor',session_user,
     'read_only',current_setting('transaction_read_only'),
     'isolation',current_setting('transaction_isolation'),
     'role',(select row_to_json(r) from(select rolname,rolsuper,rolinherit,rolcreaterole,rolcreatedb,rolbypassrls from pg_roles where rolname=current_user)r),
     'database_owner',(select pg_get_userbyid(datdba) from pg_database where datname=current_database()),
     'schema_owners',(select json_agg(row_to_json(s)) from(select nspname,pg_get_userbyid(nspowner) owner,
       has_schema_privilege(current_user,oid,'USAGE') usage,has_schema_privilege(current_user,oid,'CREATE') create_allowed
       from pg_namespace where nspname in('custodial_dr','custodial_release_identity') order by nspname)s),
     'private_relations',(select json_agg(row_to_json(t)) from(select n.nspname,c.relname,pg_get_userbyid(c.relowner) owner,
       c.relrowsecurity,c.relforcerowsecurity,pg_has_role(current_user,c.relowner,'USAGE') inherits_owner,
       has_table_privilege(current_user,c.oid,'SELECT') select_allowed,has_table_privilege(current_user,c.oid,'INSERT') insert_allowed
       from pg_class c join pg_namespace n on n.oid=c.relnamespace
       where (n.nspname='custodial_release_identity' and c.relname in('employee_message_original_outcomes','group_original_creations'))
         or (n.nspname='custodial_dr' and c.relname in('restore_control','application_mutation_leases'))
       order by n.nspname,c.relname)t),
     'original_functions',(select json_agg(row_to_json(f)) from(select n.nspname,p.proname,
       pg_get_function_identity_arguments(p.oid) arguments,pg_get_userbyid(p.proowner) owner,p.prosecdef,
       pg_has_role(current_user,p.proowner,'USAGE') inherits_owner,has_function_privilege(current_user,p.oid,'EXECUTE') execute_allowed
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
       where (n.nspname='custodial_release_identity' and p.proname='guard_group_original_creation')
         or (n.nspname='custodial_dr' and p.proname='guard_application_mutation')
         or (n.nspname='public' and p.proname like 'custodial%restore%authority%')
       order by n.nspname,p.proname,arguments)f));
    rollback;`);
   const lines=observed.trim().split('\n');assert.equal(lines.length,2);
   const identity=JSON.parse(lines[0]),capabilities=JSON.parse(lines[1]);
   assert.equal(identity.actor,'postgres');assert.equal(identity.session_actor,'postgres');
   assert.equal(capabilities.actor,'postgres');assert.equal(capabilities.session_actor,'postgres');
   assert.equal(capabilities.read_only,'on');assert.equal(capabilities.isolation,'repeatable read');
   put('ORIGINAL_OWNER_CAPABILITIES.json',{identity,capabilities,scope:'Actual READ ONLY original-owner metadata only; no private protocol/guard/ALTER OWNER/grant/HBA/SET ROLE/DATA call'});
   console.log('ORIGINAL_OWNER_CAPABILITIES_READ_ONLY_COMPLETE_NOT_IMPORT_OR_DDL');process.exit(0);
  }
  if(stage==='finish'&&cronInt64Owned){
   phase='NEW exact-int64 cron owning database and sequence rollback case';
   const {runCronTransactionalRollbackOwnedDatabaseCase}=await import(B+'/scripts/disaster-recovery-cron-tests.mjs?cron-transactional-rollback-owned-database-case');
   const original=new Client({...options,user:'supabase_admin'});clients.add(original);original.on('error',()=>{});
   let transaction=false,firstFailure;
   try{
    await original.connect();await original.query('begin');transaction=true;
    await original.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-admission',0))");
    await original.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-fence',0))");
    const cronSource=fs.readFileSync(B+'/scripts/disaster-recovery-cron.mjs','utf8');
    const catalogMarker='const CRON_JOB_DEFAULT_SEQUENCE_SQL = '+String.fromCharCode(96);
    const catalogStart=cronSource.indexOf(catalogMarker)+catalogMarker.length,catalogEnd=cronSource.indexOf(String.fromCharCode(96)+';',catalogStart);
    assert.ok(catalogStart>=catalogMarker.length&&catalogEnd>catalogStart);
    const catalogQuery=cronSource.slice(catalogStart,catalogEnd);assert.equal(catalogQuery.includes('$'+'{'),false);
    const catalog=await original.query(catalogQuery);
    put('CRON_DEFAULT_SEQUENCE_CATALOG.json',{rows:catalog.rows,actual_SQL:true,metadata_only:true,production:false});
    const result=await runCronTransactionalRollbackOwnedDatabaseCase(original);
    put('CRON_INT64_RETURNED.json',{result,actual_SQL:true,production:false});
    await original.query('rollback');transaction=false;
    put('PRODUCT_RESULT.json',{scope:'NEW_EXACT_INT64_CRON_OWNING_SQL_AND_SEQUENCE_ROLLBACK',
     result,transaction:'ROLLED_BACK',old_groups_replayed:false,production:false,restore_complete:false});
   }catch(error){firstFailure=error;throw error;}finally{
    const cleanup=[];
    if(transaction)try{await original.query('rollback');}catch(error){cleanup.push(error);}
    try{await original.end();}catch(error){cleanup.push(error);}clients.delete(original);
    if(cleanup.length)throw new AggregateError(firstFailure?[firstFailure,...cleanup]:cleanup,'Cron owning fixture cleanup failed',{cause:firstFailure??cleanup[0]});
   }
  }else if(stage==='finish'&&shippingSourceInitializer){
   phase='NEW shipping fresh-source initializer actual owned SQL join';
   const archiveApi=await import(B+'/scripts/disaster-recovery-archive.mjs');
   const {initializeVerifiedImmutableFreshSource:initialize}=await import(B+'/scripts/immutable-private-source-initializer.mjs');
   const {quoteIdentifier,planEventOwnerRestore,executeEventOwnerPlan}=await import(B+'/scripts/isolated-event-owner-schema.mjs');
   const original=new Client({...options,user:'supabase_admin',query_timeout:180000});clients.add(original);original.on('error',()=>{});
   let archive,transaction=false,firstFailure,profileTimer,profileCapture,profiler,profileObserver;
   try{
    assert.ok(process.env.G31_PRIVATE_PROVIDER_ORIGINAL_ARCHIVE && path.isAbsolute(process.env.G31_PRIVATE_PROVIDER_ORIGINAL_ARCHIVE));
    const originalSource=populatedAuthorityReadbackCli?process.env.G31_PRIVATE_PROVIDER_ORIGINAL_ARCHIVE:
     freshAuthCompleteCli?path.resolve(D,'../restore-runtime-authorized-KM9tAR/auth-complete-original-release-row-v76'):
     freshNormalCli?'/home/eric/Documents/Codex/2026-10-09/task-7/complete-normal-restore-fixture-20261017-v1/synthetic-unit-original-v1':path.resolve(D,'../restore-runtime-authorized-KM9tAR/authenticated-setwise-original-restore-v16/authenticated-original-source');
    const originalKey=populatedAuthorityReadbackCli?'UNIT-only-native-text-original-HMAC-20261018':freshAuthCompleteCli?'UNIT-only-auth-complete-original-HMAC-20261017':'UNIT-only-immutable-archive-verification-key-20261016';
    const originalKeyId=populatedAuthorityReadbackCli?'unit-native-text-original-v2':freshAuthCompleteCli?'unit-auth-complete-original-v1':'unit-immutable-archive-v1';
    archive=archiveApi.materializeVerifiedArchive({sourceDir:originalSource,
     archiveVerifyKey:originalKey,archiveVerifyKeyId:originalKeyId,
     supportedFormats:['memphis-zoo-disaster-recovery.v4']});
    const bound=archiveApi.readVerifiedArchiveSourceBinding(archive);
    const snapshotIdentity=fs.lstatSync(archive.directory);
    put('OWNED_ARCHIVE_SNAPSHOT.json',{directory:archive.directory,dev:snapshotIdentity.dev,
     ino:snapshotIdentity.ino,uid:snapshotIdentity.uid,mode:snapshotIdentity.mode&511,
     scope:'Exact new owned verification copy, not the retained original archive'});
    if(populatedAuthorityReadbackCli && process.env.G31_PRIVATE_PROVIDER_SOURCE_CAPTURE_REF){
     // Root's already-closed source constructor supplies the exact capture
     // receipt. The archive itself remains authenticated by the shipping
     // signature/digest verifier above; an unsigned caller hash is insufficient.
     const captureRef=JSON.parse(process.env.G31_PRIVATE_PROVIDER_SOURCE_CAPTURE_REF);
     assert.deepEqual(Object.keys(captureRef).sort(),['bytes','path','sha256']);assert.match(captureRef.sha256,/^[a-f0-9]{64}$/);
     assert.ok(path.isAbsolute(captureRef.path));assert.equal(fs.realpathSync(captureRef.path),captureRef.path);
     const stat=fs.lstatSync(captureRef.path);assert.ok(stat.isFile()&&!stat.isSymbolicLink()&&stat.nlink===1&&stat.uid===process.getuid()&&stat.size===captureRef.bytes&&stat.size<=1048576);
     const raw=fs.readFileSync(captureRef.path);assert.equal(raw.length,captureRef.bytes);assert.equal(sha(raw),captureRef.sha256);
     const capture=JSON.parse(raw);assert.equal(capture.scope,'NEW_DISPOSABLE_PRIVATE286_OFFICIAL_STORAGE_SIGNED_NATIVE_SNAPSHOT_NOT_RESTORE');
     assert.equal(capture.directory,originalSource);assert.equal(capture.source_commit,'b20499c6a98b90db1779fe5d0060b619bceae261');
     assert.equal(capture.old_originals_modified,false);assert.equal(capture.restore_executed,false);assert.equal(capture.sealed_archive.actual_source_snapshot,true);
     assert.equal(capture.sealed_archive.provider_storage_observed,true);assert.equal(capture.sealed_archive.private_tables,2);
     assert.equal(capture.sealed_archive.key_id,originalKeyId);assert.equal(capture.sealed_archive.data_encoding,'postgres-text-columns-line.v2');
     assert.equal(capture.sealed_archive.producer_file_sha256,'31dee45261a57eb609e07b7e99fc03c1e575d7f4e9445795bd1383cbcd8fcbd3');
     assert.equal(capture.sealed_archive.producer_fragment_sha256,'28561b0f0b0acd1055ff81d17ea7b624e443ea9942f08aa92b5bc79010a19bae');
     assert.equal(bound.archive_digest,capture.sealed_archive.archive_digest);
     assert.equal(Number(archive.summary.table_count),capture.table_count);assert.equal(String(archive.summary.database_row_count),String(capture.total_rows));
     const storage=archiveApi.readVerifiedStorageUploadInventory(archive);assert.equal(storage.bucketRecords.length,2);assert.equal(storage.objectRecords.length,2);
     put('NEW_SIGNED_ORIGINAL_CAPTURE_BINDING.json',{capture_ref:captureRef,archive_digest:bound.archive_digest,source_commit:capture.source_commit,
      shipping_archive_signature_and_digest_verified:true,table_count:capture.table_count,total_rows:capture.total_rows,Storage_buckets:2,Storage_objects:2,
      actual_source_migration_count:capture.sealed_archive.actual_source_migration_count,old_noStorage_archive_modified:false});
    }else{
    assert.equal(bound.archive_digest,populatedAuthorityReadbackCli?'732bc0b6c639db92b62e0203f40c1e7a025ecfc3389a5245a92cef86d2ab2cb2':freshAuthCompleteCli?'a86d0b7805eac5dba5f5dac5907d5fd0e974b0259e707079ed1927ad116d27de':freshNormalCli?'9e7f0cd9659232106ed993eb19c7e3a9796a787a5349128df7a1d2789bf7b40a':'969fde44613e2153f5eebce6df7308efcdfc00c7cd7c80dd69ce316b62941132');
    }
    const inventory=archiveApi.readVerifiedImmutableBootstrapInventory(archive).inventory;
    const plan=planEventOwnerRestore(inventory['inventory/application-schema.sql']);
    await original.connect();await original.query("set statement_timeout='12s';set lock_timeout='2s'");
    // One bounded actual prerequisite read uses the already-supported original
    // managed fixture identity. Never retry the failed postgres peer identity,
    // change HBA/roles/owners, or treat superuser status as a cron-owner match.
    const cronOwnership=(await original.query("select current_user actor,session_user session_actor,pg_get_userbyid(c.relowner) job_owner,(select pg_get_userbyid(s.relowner) from pg_catalog.pg_class s where s.oid=pg_get_serial_sequence('cron.job','jobid')::regclass) sequence_owner from pg_catalog.pg_class c where c.oid='cron.job'::regclass")).rows;
    put('CRON_ORIGINAL_OWNER_PREREQUISITE.json',{rows:cronOwnership,read_only_metadata:true,cron_runtime_executed:false,postgres_peer_retry:false});
    await original.query('begin');transaction=true;
    await original.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-admission',0))");
    await original.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-fence',0))");
    const invocation=(await original.query('select pg_backend_pid() pid,txid_current()::text xid')).rows[0];
    phase='fresh exact Source schema prerequisite for shipping initializer';
    const schema=await executeEventOwnerPlan(original,plan);
    await original.query('set local search_path=pg_catalog');await original.query('set local row_security=off');
    phase='actual shipping immutable Source initializer and revocation-only ACL adapter';
    if(shippingSourceProfile){
     const {Session}=await import('node:inspector');profiler=new Session();profiler.connect();
     const post=method=>new Promise((resolve,reject)=>profiler.post(method,(error,value)=>error?reject(error):resolve(value)));
     profileObserver=new Client({...options,user:'supabase_admin'});clients.add(profileObserver);profileObserver.on('error',()=>{});
     await profileObserver.connect();await profileObserver.query('begin read only');
     await post('Profiler.enable');await post('Profiler.start');
     profileTimer=setTimeout(()=>{
      profileCapture=(async()=>{
       try{
        const {profile}=await post('Profiler.stop');put('OWNING_CPU_PROFILE.json',profile);
        const observed=await profileObserver.query(`select current_user observer_actor,session_user observer_session,
         a.pid,a.state,a.wait_event_type,a.wait_event,
         extract(epoch from clock_timestamp()-a.query_start)::float8 statement_age_seconds,
         case when a.query like '%namespace_owners_ok%' then 'ACL_CONTEXT'
          when a.query ilike 'REVOKE %' then 'ACL_REVOKE'
          when a.query like '%count(*)::text row_count%' then 'ORIGINAL_EMPTY_COUNTS'
          when a.query like '%pg_get_functiondef%' then 'ROUTINE_CATALOG'
          when a.query like '%schema_migrations%' then 'MIGRATION_METADATA'
          when a.query like '%custodial_release_authority_restore_inventory%' then 'REGISTRY_METADATA'
          else 'OTHER_FIXED_STATEMENT' end statement_kind
         from pg_catalog.pg_stat_activity a where a.pid=$1 and a.datname=current_database() and a.usename=session_user`,[invocation.pid]);
        put('OWNING_SINGLE_SQL_WAIT.json',{diagnostic_only:true,original_invocation:invocation,rows:observed.rows,
         observation_window_seconds:45,initializer_acceptance:false});
       }finally{
        await post('Profiler.disable').catch(()=>{});profiler.disconnect();profiler=null;
        // End ONLY our disposable caller connection. The server rolls back
        // its uncommitted Source transaction; no product timeout/guard changes.
        await original.end();
       }
      })();profileCapture.catch(()=>{});
     },45000);profileTimer.unref();
    }
    if(freshNormalCli){
     // Qualified Source-schema construction is setup, not an initializer/DATA
     // proof replay. The NORMAL child CLI owns the only DATA import/COMMIT.
     await original.query('commit');transaction=false;
     assert.match(ownedContainerName,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);
     phase='verify exclusively owned image-initialized normal-CLI target';
     assert.equal((await original.query('select current_database() database')).rows[0].database,ownedContainerName);
     put('NORMAL_CLI_FIXTURE_DATABASE.json',{database:ownedContainerName,created_by_normal_image_entrypoint:true,
      clone_attempts:0,sessions_terminated:0,source_schema_only:true,DATA_imports_before_normal_child:0});
     if(postAuthorityContinuationCli&&!noStorageContinuationCli){
      // NEW affected cron boundary only: current product restore before pause,
      // readonly verification after pause, then exact rollback. No signed
      // import/manager/ACK authority is synthesized by these inactive rows.
      const {restoreCronJobs,verifyRestoredCronJobs,readCronJobs,resolveCronJobDefaultSequence,normalizedCronJobs}
       =await import(B+'/scripts/disaster-recovery-cron.mjs');
      const quote=value=>'"'+value.replaceAll('"','""')+'"';
      const counter=async()=>{const identity=await resolveCronJobDefaultSequence(original);
       const value=(await original.query('select last_value::text last_value,is_called from '
        +quote(identity.schema_name)+'.'+quote(identity.sequence_name))).rows;
       assert.equal(value.length,1);assert.equal(typeof value[0].last_value,'string');
       assert.equal(typeof value[0].is_called,'boolean');return {identity,value:value[0]};};
      const cases=[];
      for(const profile of ['empty','populated-int64']){
       const savedJobs=await readCronJobs(original),savedCounter=await counter();
       assert.deepEqual(savedJobs,[]);
       assert.equal((await original.query('select count(*)::text n from custodial_dr.restore_control')).rows[0].n,'0');
       await original.query('begin');transaction=true;
       try{
        await original.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-admission',0))");
        await original.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-fence',0))");
        await original.query('insert into custodial_dr.restore_control(singleton) values(true)');
        const jobs=profile==='empty'?[]:['7','9007199254740992','9007199254740993','9223372036854775807'].map((jobid,index)=>({
         jobid,schedule:'0 0 1 1 *',command:'SELECT 1',nodename:'localhost',nodeport:5432,
         database:index===1?'unit-unrelated-cron':'unit-original-cron',username:'supabase_admin',active:false,jobname:'new-paused-cron-'+index}));
        const exactInput=JSON.stringify(jobs);
        const restored=await restoreCronJobs(original,jobs,{sourceDatabase:'unit-original-cron'});
        assert.deepEqual(restored.differences,[]);
        const expected=normalizedCronJobs(jobs,{sourceDatabase:'unit-original-cron',targetDatabase:ownedContainerName});
        assert.deepEqual(restored.actual,expected);assert.equal(JSON.stringify(jobs),exactInput);
        const restoredCounter=await counter();
        await original.query('update custodial_dr.restore_control set mutations_paused=true');
        await original.query('savepoint new_paused_cron_guard');
        let refused=false;
        try{await original.query('alter sequence '+quote(restoredCounter.identity.schema_name)+'.'+quote(restoredCounter.identity.sequence_name)+' restart');}
        catch(error){assert.equal(error.code,'55000');assert.match(error.message,/application mutations are paused/);refused=true;}
        assert.equal(refused,true,'The existing application DDL pause guard must still refuse');
        await original.query('rollback to savepoint new_paused_cron_guard');
        await original.query('release savepoint new_paused_cron_guard');
        // This new helper is strictly SELECT-only in the program. The
        // production fresh caller additionally supplies an actual RO snapshot.
        const verified=await verifyRestoredCronJobs(original,jobs,{sourceDatabase:'unit-original-cron'});
        assert.deepEqual(verified.expected,expected);assert.deepEqual(verified.actual,expected);
        assert.deepEqual(verified.differences,[]);assert.equal(JSON.stringify(jobs),exactInput);
        if(jobs.length){
         const foreign=jobs.map((job,index)=>index===0?{...job,command:'SELECT 2'}:{...job});
         const mismatch=await verifyRestoredCronJobs(original,foreign,{sourceDatabase:'unit-original-cron'});
         assert.ok(mismatch.differences.length>0);
         assert.deepEqual(await readCronJobs(original),expected);
        }
        const afterCounter=await counter();assert.deepEqual(afterCounter.value,restoredCounter.value);
        assert.equal((await original.query('select mutations_paused from custodial_dr.restore_control where singleton')).rows[0].mutations_paused,true);
        cases.push({profile,rows:jobs.length,actual_default_sequence_oid:restoredCounter.identity.sequence_oid,
         counter:restoredCounter.value,DDL_pause_refusal:'55000',readonly_verifier_differences:0,
         populated_foreign_command:jobs.length?'RETAINED_MISMATCH':'NOT_APPLICABLE',effects_or_resume_permission:false});
       }finally{await original.query('rollback');transaction=false;}
       assert.deepEqual(await readCronJobs(original),savedJobs);
       const afterRollback=await counter();assert.deepEqual(afterRollback.value,savedCounter.value);
       assert.equal(afterRollback.identity.sequence_oid,savedCounter.identity.sequence_oid);
       assert.equal((await original.query('select count(*)::text n from custodial_dr.restore_control')).rows[0].n,'0');
      }
      put('CRON_PREPAUSE_NATIVE_JOIN.json',{scope:'NEW_CURRENT_CRON_PREPAUSE_AND_PAUSED_READ_VERIFIER_ONLY',
       actual_SQL:true,normal_original_actor:'supabase_admin',cases,all_fixture_changes_rolled_back:true,
       original_counter_restored_without_compensation:true,production:false,whole_G31:false,old_groups_replayed:0});
     }
     const {createServer,createConnection}=await import('node:net');
     const streams=new Set();let forwardError;
     const forward=createServer(inbound=>{
      const target=createConnection({path:path.join(socket,'.s.PGSQL.5432')});
      streams.add(inbound);streams.add(target);
      inbound.once('close',()=>streams.delete(inbound));target.once('close',()=>streams.delete(target));
      const fail=error=>{forwardError??=error;inbound.destroy();target.destroy();};
      inbound.once('error',fail);target.once('error',fail);inbound.pipe(target);target.pipe(inbound);
     });
     let child,timeoutSampleTimer,timeoutSample,progressObserver,progressSetup;
     const progressTimers=[];let progressChain=Promise.resolve();
     try{
      await new Promise((yes,no)=>{forward.once('error',no);forward.listen(0,'127.0.0.1',yes);});
      const endpoint=forward.address();assert.equal(endpoint.address,'127.0.0.1');
      put('OWNED_LOCAL_CLI_ENDPOINT.json',{host:endpoint.address,port:endpoint.port,database:ownedContainerName,
       same_owned_unix_backend:true,SQL_or_authentication_mock:false,Docker_network:'none',production:false});
      const crypto=await import(B+'/scripts/disaster-recovery-crypto.mjs');
      const intentKey='UNIT-only-independent-normal-cli-intent-key-20261017',intentKeyId='unit-normal-cli-intent-v1';
      const release={};for(const key of ['release_id','backend_commit','frontend_commit','migration_head','migration_manifest_sha256'])
       release[key]=bound.source_identity.release[key];
      const now=Date.now(),intent={restore_id:randomUUID(),authority_generation:1,retry_of_restore_id:null,
       archive_digest:bound.archive_digest,source_project_ref:bound.project_ref,target_project_ref:bound.project_ref,
       source_identity_sha256:bound.source_identity_sha256,target_migration_head:bound.source_identity.migration_head,
       target_release_identity:release,actor:'UNIT NORMAL CLI local DATABASE phase',approved_at:new Date(now).toISOString(),
       expires_at:new Date(now+35*60*1000).toISOString(),resume_after_verification:false};
      const envelope={format:'memphis-zoo-production-restore-intent.v1',algorithm:'hmac-sha256',key_id:intentKeyId,
       intent,signature:crypto.signBinding(crypto.restoreIntentBinding(intent),intentKey)};
      put('NORMAL_CLI_ORIGINAL_INPUT.json',{intent,synthetic_original_fixture:true,Storage:'NEW_ACTUAL_OFFICIAL_SOURCE_PRIVATE_PUBLIC_NONEMPTY_SIGNED_ORIGINAL',
       real_keys:false,full_production_apply:false});
      const tmp=path.join(out,'normal-cli-tmp');fs.mkdirSync(tmp,{mode:0o700});
      const childEnv={PATH:'/usr/bin:/bin',LANG:'C.UTF-8',TMPDIR:tmp,RESTORE_SOURCE_DIR:originalSource,
       RESTORE_ARCHIVE_VERIFY_KEY:originalKey,RESTORE_ARCHIVE_VERIFY_KEY_ID:originalKeyId,
       RESTORE_APPLY:'true',RESTORE_DATABASE_ONLY:'true',SUPABASE_PROJECT_REF:bound.project_ref,RESTORE_CONFIRM_PROJECT_REF:bound.project_ref,
       SUPABASE_DB_URL:'postgresql://supabase_admin:'+bootstrap+'@127.0.0.1:'+endpoint.port+'/'+ownedContainerName,
       RESTORE_INTENT_VERIFY_KEY:intentKey,RESTORE_INTENT_VERIFY_KEY_ID:intentKeyId,RESTORE_INTENT_JSON:JSON.stringify(envelope),
       REHEARSAL_SCOPE:'backup_only',OFFICIAL_LOCAL_STORAGE_PROVIDER:'true',RUNNER_TEMP:tmp,
       GITHUB_RUN_ID:ownedContainerName.slice('mz_schema_rebuild_'.length)};
      phase='actual NORMAL CLI current signed local original -> DATABASE phase';
      child=spawn(process.execPath,['--max-old-space-size=384',B+'/scripts/run-official-local-storage-rehearsal.mjs'],
       {cwd:B,env:childEnv,stdio:['ignore','pipe','pipe']});
      // Diagnostic only: no source/row reads, locks, permission or completion inference.
      // The existing outer utility still owns the original timeout and custody.
      const observerFailure=(stage,error)=>put('NORMAL_CLI_PROGRESS_FAILURE_'+stage+'.json',{
       diagnostic_only:true,stage,code:/^[0-9A-Z_]{1,80}$/.test(error?.code||'')?error.code:null,
       raw_query_or_DATA:false,owning_qualification:false});
      const childProc=()=>{const raw=fs.readFileSync('/proc/'+child.pid+'/stat','utf8');
       const f=raw.slice(raw.lastIndexOf(') ')+2).trim().split(/\s+/);
       return {pid:child.pid,ppid:Number(f[1]),pgid:Number(f[2]),start_ticks:f[19],user_ticks:f[11],system_ticks:f[12]};};
      const originalChild=childProc(),progressStarted=performance.now();
      put('NORMAL_CLI_ORIGINAL_CHILD_OWNER_BEFORE_PROGRESS.json',{child:originalChild,
       same_original_child:true,live_parent_owns_child:true,new_authority:false});
      progressSetup=(async()=>{try{
       progressObserver=new Client({...options,user:'supabase_admin',database:ownedContainerName,
        application_name:'custodial-g31-progress-observer',connectionTimeoutMillis:3000,query_timeout:3000,
        statement_timeout:3000,lock_timeout:1000});clients.add(progressObserver);progressObserver.on('error',()=>{});
       await progressObserver.connect();
       const query=`select a.pid,a.state,a.wait_event_type,a.wait_event,
        pg_catalog.encode(pg_catalog.sha256(pg_catalog.convert_to(a.query,'UTF8')),'hex') query_sha256,
        extract(epoch from clock_timestamp()-a.query_start)::float8 statement_age_seconds,
        extract(epoch from clock_timestamp()-a.xact_start)::float8 transaction_age_seconds,
        pg_catalog.pg_blocking_pids(a.pid) blocking_pids
        from pg_catalog.pg_stat_activity a
        where a.datname=current_database() and a.usename=session_user
         and a.application_name='memphis-zoo-disaster-restore' order by a.pid`;
       const sample=async label=>{
        try{const cpu=childProc();assert.equal(cpu.start_ticks,originalChild.start_ticks);
         const activity=await progressObserver.query(query);
         put('NORMAL_CLI_SAFE_PROGRESS_'+label+'.json',{diagnostic_only:true,owning_qualification:false,
          elapsed_ms:performance.now()-progressStarted,original_child_start_identity:originalChild,observed_child:cpu,
          same_owned_database:ownedContainerName,query_text_or_parameters_or_rows:false,activity:activity.rows});
        }catch(error){observerFailure(label,error);}
       };
       for(const ms of [120000,300000,600000,840000]){
        const t=setTimeout(()=>{progressChain=progressChain.then(()=>sample(String(ms))).catch(error=>observerFailure('chain_'+ms,error));},ms);
        t.unref();progressTimers.push(t);
       }
      }catch(error){observerFailure('connect',error);}})();
      let stdout='',stderr='',truncated=false;
      const collect=(kind,bytes)=>{if(Buffer.byteLength(stdout)+Buffer.byteLength(stderr)+bytes.length>1024*1024){
        truncated=true;child.kill('SIGTERM');return;}if(kind==='out')stdout+=bytes.toString('utf8');else stderr+=bytes.toString('utf8');};
      child.stdout.on('data',bytes=>collect('out',bytes));child.stderr.on('data',bytes=>collect('err',bytes));
      const terminal=await new Promise((yes,no)=>{child.once('error',no);child.once('close',(code,signal)=>yes({code,signal}));});
      if(progressSetup)await progressSetup;
      for(const timer of progressTimers)clearTimeout(timer);await progressChain;
      if(progressObserver){await progressObserver.end();clients.delete(progressObserver);progressObserver=null;}
      if(timeoutSampleTimer)clearTimeout(timeoutSampleTimer);
      if(timeoutSample)await timeoutSample;
      fs.writeFileSync(out+'/NORMAL_CLI.stdout',stdout,{flag:'wx',mode:0o600});
      fs.writeFileSync(out+'/NORMAL_CLI.stderr',stderr,{flag:'wx',mode:0o600});
      put('NORMAL_CLI_TERMINAL.json',{...terminal,truncated,tmp_empty:fs.readdirSync(tmp).length===0,
       normal_entrypoint:true,SQL_and_authentication_not_stubbed:true});
      if(freshOriginalReadbackCli&&terminal.code!==0){
       // One diagnostic of THIS failed UNIT target before normal cleanup.
       // This is a different parent backend, never the child's private ACK,
       // live original context, effect permission, or a passing reader case.
       let diagnostic,diagnosticTransaction=false;
       try{
        await original.query('begin isolation level repeatable read read only');diagnosticTransaction=true;
        await original.query('set local search_path=pg_catalog;set local row_security=off');
        await original.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-admission',0))");
        await original.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-fence',0))");
        await original.query('lock table public.custodial_release_authority_restore_inventory in share mode');
        diagnostic=(await original.query(`with current_shape as materialized(select custodial_dr.immutable_import_target_shape() value)
         select c.phase,c.database_oid::text original_database_oid,c.backend_pid original_backend_pid,
          c.transaction_id::text original_transaction_id,c.restore_id::text restore_id,c.authority_generation::text generation,
          c.target_shape->'recovery_inventory' original_inventory,current_shape.value->'recovery_inventory' current_inventory,
          (c.target_shape-'recovery_inventory') is not distinct from (current_shape.value-'recovery_inventory') same_non_epoch_source,
          array(select key from jsonb_object_keys(c.target_shape||current_shape.value) key
            where key<>'recovery_inventory' and c.target_shape->key is distinct from current_shape.value->key order by key) changed_non_epoch_keys,
          jsonb_typeof(c.target_shape->'recovery_inventory'->'relation_oid') original_relation_oid_JSON_type,
          (select count(*)::text from custodial_dr.immutable_private_import_rows r where r.database_oid=c.database_oid
            and r.backend_pid=c.backend_pid and r.transaction_id=c.transaction_id) private_rows
         from custodial_dr.immutable_private_import_context c cross join current_shape`)).rows;
       }catch(error){diagnostic={available:false,sql_state:/^[0-9A-Z]{5}$/.test(error?.code||'')?error.code:null};}
       finally{if(diagnosticTransaction)await original.query('rollback');}
       put('POST_DATABASE_FAILURE_METADATA.json',{diagnostic,scope:'Failed disposable UNIT target parent-backend metadata only',
        original_child_context_or_ACK:false,whole_restore:false,old_groups_replayed:0});
      }
      if(freshCompleteReadbackCli&&!freshAuthCompleteCli){
       // NEW actual affected authority helper: the normal paused original must
       // still DENY unadmitted effects. Existing whole schema is setup only.
       const authority=new Client({...options,user:'supabase_admin',database:ownedContainerName});
       clients.add(authority);authority.on('error',()=>{});let begun=false;
       try{
        await authority.connect();await authority.query('begin isolation level repeatable read read write');begun=true;
        await authority.query('set local search_path=pg_catalog, pg_temp;set local row_security=off');
        await authority.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-admission',0))");
        await authority.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-fence',0))");
        const {runRestoredAuthorityUnadmittedSqlCase}=await import(B+'/scripts/restore-mutation-gate-tests.mjs');
        const denial=await runRestoredAuthorityUnadmittedSqlCase(authority,{generation:String(intent.authority_generation)});
        assert.equal(denial.outcome,'MISSING_REQUIRED_TARGET_REFUSED');
        assert.deepEqual(denial.missing_identifiers,['auth.sessions']);
        assert.equal(denial.available_target_sets,5);assert.equal(denial.full_platform_or_effect_proof,false);
        assert.equal(denial.first_update_guard_test,'NOT_RUN');assert.equal(denial.sqlstate,null);
        assert.equal(denial.before_rollback,'RAW_AVAILABLE_ROWS_CONTROL_AND_ABSENCE_IDENTICAL');
        assert.equal(denial.after_own_rollback,'RAW_AVAILABLE_ROWS_CONTROL_AND_ABSENCE_IDENTICAL');
        put('RESTORED_AUTHORITY_UNADMITTED_SQL.json',{...denial,synthetic_fixture_only:true,
         original_child_ACK_or_effect_permission:false,whole_restore:false});
       }finally{
        try{if(begun)await authority.query('rollback');}
        finally{try{await authority.end();}finally{clients.delete(authority);}}
       }
      }
      assert.equal(terminal.code,0);assert.equal(terminal.signal,null);assert.equal(truncated,false);
      assert.equal(stderr,'');assert.ok(fs.readdirSync(tmp).every(name=>name.startsWith('official-storage-')||name==='official-local-storage-provider-evidence'));assert.equal(forwardError,undefined);
      if(postAuthorityContinuationCli){
       const result=JSON.parse(stdout);
       if(noStorageContinuationCli){
        assert.equal(result.storage.scope,'OFFICIAL_LOCAL_FILE_BACKEND_SAME_ORIGINAL');
        assert.equal(result.storage.source_profile,'immutable-private-fresh-supabase-admin');
        for(const key of ['metadata_and_ownership_verified','object_bytes_verified','provider_verified'])assert.equal(result.storage[key],true);
        assert.equal(result.storage.production_provider_verified,false);assert.equal(result.storage.metadata_only,false);
        assert.equal(result.storage.owner_access_probes.length,2);
        const denied=(value,kind)=>[401,403,404].includes(value)||(value?.http_status===400&&value.probe_kind===kind&&value.semantic_status===(kind==='private-object'?404:403)&&value.code===(kind==='private-object'?'NoSuchKey':'AccessDenied')&&/^[a-f0-9]{64}$/.test(value.body_sha256));
        assert.ok(result.storage.owner_access_probes.some(p=>!p.public && p.intended==='OWNER_EXACT_BYTES' && denied(p.foreign,'private-object') && denied(p.anon,'private-object')));
        assert.ok(result.storage.owner_access_probes.some(p=>p.public && p.anon==='PUBLIC_EXACT_BYTES'));
        assert.ok(result.storage.owner_access_probes.every(p=>denied(p.invalid_signature,'invalid-signature')));
        assert.equal(result.storage.final_provider_resample.provider_verified,true);
       }
       assert.equal(result.database_only,true);assert.equal(result.state,'PAUSED_RECONCILIATION');
       assert.equal(result.mutations_paused,true);assert.equal(result.complete_restore,false);
       assert.equal(result.resume_allowed,false);
       assert.equal(result.restore_id,intent.restore_id);assert.equal(String(result.authority_generation),'1');
       assert.match(result.final_manifest_sha256,/^[0-9a-f]{64}$/);
       await original.query('begin isolation level repeatable read read only');transaction=true;
       try{
        const controls=(await original.query(`select restore_id::text,authority_generation::text generation,archive_digest,
          target_project_ref,state,mutations_paused,completed_at is not null completed
          from custodial_dr.restore_control where singleton`)).rows;
        assert.deepEqual(controls,[{restore_id:intent.restore_id,generation:'1',archive_digest:bound.archive_digest,
         target_project_ref:bound.project_ref,state:'PAUSED_RECONCILIATION',mutations_paused:true,completed:true}]);
        const manifests=(await original.query(`select restore_id::text,authority_generation::text generation,archive_digest,
          database_verified,authority_invalidated,storage_verified,post_restore_verified,final_manifest_sha256
          from custodial_dr.restore_manifests where restore_id=$1`,[intent.restore_id])).rows;
        assert.deepEqual(manifests,[{restore_id:intent.restore_id,generation:'1',archive_digest:bound.archive_digest,
         database_verified:true,authority_invalidated:true,storage_verified:true,post_restore_verified:true,
         final_manifest_sha256:result.final_manifest_sha256}]);
        const scopes=(await original.query(`select phase,completed_step,active_table_oid,counts
          from custodial_dr.immutable_original_authority_scopes where restore_id=$1`,[intent.restore_id])).rows;
        assert.deepEqual(scopes,[{phase:'CONSUMED',completed_step:6,active_table_oid:null,
         counts:{employee_credentials:'1',employee_enrollment:'2',manager_credentials:'1',manager_enrollment:'1',manager_push:'1',auth_sessions:'1'}}]);
        const events=(await original.query(`select phase,outcome,count(*)::text occurrences from custodial_dr.restore_events
          where restore_id=$1 group by phase,outcome order by phase,outcome`,[intent.restore_id])).rows;
        for(const [phase,outcome]of [['CRON','PASSED'],['STORAGE','PASSED'],['FINAL','HELD']]){
         assert.deepEqual(events.filter(row=>row.phase===phase&&row.outcome===outcome),[{phase,outcome,occurrences:'1'}]);
        }
        const unresolved=(await original.query("select count(*)::text n from custodial_dr.restore_discrepancies where restore_id=$1 and status='OPEN'",[intent.restore_id])).rows[0].n;
        assert.equal(String(result.unresolved_discrepancies),unresolved);
        assert.equal(result.resume_eligible,unresolved==='0');
        const leases=(await original.query(`select count(*)::text n from pg_catalog.pg_locks l
          where l.locktype='advisory' and l.granted and l.pid<>pg_catalog.pg_backend_pid()
          and l.database=(select oid from pg_catalog.pg_database where datname=current_database())
          and l.classid=((pg_catalog.hashtextextended('memphis-zoo-application-mutation-fence',0)>>32)&4294967295)::oid
          and l.objid=(pg_catalog.hashtextextended('memphis-zoo-application-mutation-fence',0)&4294967295)::oid and l.objsubid=1`)).rows[0].n;
        assert.equal(leases,'0','Original child must have released its carried session writer fence');
        put(noStorageContinuationCli?'HELD_POSTVERIFY_RESULT.json':'PRODUCT_RESULT.json',{scope:noStorageContinuationCli?'NEW_PRIVATE286_OFFICIAL_NONEMPTY_STORAGE_TO_HELD_POSTVERIFY_NORMAL_CLI':'NEW_SAME_ORIGINAL_PRIVATE_POST_AUTHORITY_TO_HELD_POSTVERIFICATION_NORMAL_CLI',
         actual_SQL:true,normal_entrypoint:true,original_archive_digest:bound.archive_digest,original_source_unchanged:true,
         observed_control:controls[0],observed_manifest:manifests[0],single_consumed_six_effect_scope:scopes[0],
         phase_events:events,unresolved_discrepancies:unresolved,original_child_writer_locks_remaining:leases,
         mutations_paused:true,complete_restore:false,resume_allowed:false,provider_storage:'ACTUAL_OFFICIAL_LOCAL_NONEMPTY_CURRENT_ROLE_VERIFIED',
         signed_reconciliation:'NOT_RUN',whole_G31:false,A2:'OPEN',production:false,old_groups_replayed:0});
       }finally{await original.query('rollback');transaction=false;}
        if(noStorageContinuationCli){
         // New freshly captured original effect-3 positive and ordinary-mutation refusal checks.
         // These are actual current native PostgreSQL calls, never fabricated scopes.
         const targets=['public.ops_manager_push_devices','public.ops_manager_trusted_devices',
          'custodial_dr.immutable_original_authority_scopes','custodial_dr.restore_control',
          'custodial_dr.restore_manifests','custodial_dr.restore_events'];
         const snapshot=async()=>{const value=[];for(const relation of targets){
          const v=await original.query('select pg_catalog.row_to_json(t)::text raw from '+relation+' t order by pg_catalog.row_to_json(t)::text collate "C"');
          value.push({relation,rows:v.rows.map(x=>x.raw)});}return value;};
         const aged=(await original.query(`select p.credential_id::text,p.manager_id::text,p.enabled,p.revoked_at is not null push_retired,
          d.expires_at<clock_timestamp() archived_credential_expired,d.revoked_at is not null credential_retired
          from public.ops_manager_push_devices p join public.ops_manager_trusted_devices d using(credential_id,manager_id)`)).rows;
         assert.equal(aged.length,1);assert.deepEqual(Object.fromEntries(Object.entries(aged[0]).filter(([k])=>!['credential_id','manager_id'].includes(k))),
          {enabled:false,push_retired:true,archived_credential_expired:false,credential_retired:true});
         const cases=[];
         for(const [name,sql] of [
          ['ordinary_push_reenable','update public.ops_manager_push_devices set enabled=true'],
          ['ordinary_push_clear_revocation','update public.ops_manager_push_devices set revoked_at=null'],
          ['ordinary_push_change_manager','update public.ops_manager_push_devices set manager_id=gen_random_uuid()'],
          ['ordinary_push_change_credential','update public.ops_manager_push_devices set credential_id=gen_random_uuid()']]){
          await original.query('begin isolation level repeatable read read write');transaction=true;
          try{await original.query('set local search_path=pg_catalog,pg_temp;set local row_security=off');
           const before=await snapshot();await original.query('savepoint aged_negative');let caught;
           try{await original.query(sql);}catch(e){caught=e;}
           assert.ok(caught,'Unadmitted aged-original UPDATE must refuse');
           assert.equal(caught.code,'55000');assert.equal(caught.message,'disaster recovery is in progress; application mutations are paused');
           await original.query('rollback to savepoint aged_negative');assert.deepEqual(await snapshot(),before);
           cases.push({name,sqlstate:caught.code,message:caught.message,full_six_relation_raw_rollback_equal:true,
            scope:'Actual ordinary paused application fence refusal; NOT a forged active effect-3 row-branch exercise'});
          }finally{await original.query('rollback');transaction=false;}
         }
         await original.query('begin isolation level repeatable read read only');transaction=true;
         try{const outside=(await original.query("select custodial_dr.immutable_original_authority_guard_matches('public.ops_manager_push_devices'::regclass,'UPDATE') admitted")).rows;
          assert.deepEqual(outside,[{admitted:false}]);cases.push({name:'outside_trigger_consumed_scope_not_authority',admitted:false});
         }finally{await original.query('rollback');transaction=false;}
         put('AGED_ORIGINAL_EFFECT3_AND_REAL_UNADMITTED_NEGATIVES.json',{state:'ACTUAL_ONLY_IF_REACHED',actual_SQL:true,
          aged_original:aged,ordinary_refusals:cases,original_archive_bytes_and_expiry_unchanged:true,
          actual_normal_CLI_six_effect_and_fixed_status_assertions:'Executed unchanged earlier in this same original invocation',
          no_active_scope_fabricated:true,no_row_branch_mutant_adoption:true,whole_G31:false,current294_replay:false});
        }
       if(noStorageContinuationCli){
        // One new owning downstream stage, ONLY on this disposable local
        // target and ONLY with no unresolved discrepancy to approve. This
        // UNIT operator/HMAC is not Eric, a production key or a real grant.
        const open=(await original.query("select category from custodial_dr.restore_discrepancies where restore_id=$1 and status='OPEN' order by category",[intent.restore_id])).rows;
        let reconciliation={status:'NOT_RUN_OPEN_DISCREPANCIES',open_categories:open.map(row=>row.category),production:false};
        if(open.length===0){
         const fixedTables=['custodial_release_identity.group_original_creations','custodial_release_identity.employee_message_original_outcomes'];
         const privateSnapshot=async()=>{
          await original.query('begin isolation level repeatable read read only');transaction=true;
          try{
           await original.query("set local row_security=off;set local extra_float_digits=3;set local DateStyle='ISO, YMD';set local TimeZone='UTC';set local IntervalStyle='postgres';set local bytea_output='hex'");
           const rows=[];
           for(const table of fixedTables){
            const actual=await original.query('select pg_catalog.row_to_json(t)::text raw from '+table+' t order by pg_catalog.row_to_json(t)::text collate "C"');
            rows.push({table,rows:actual.rows.map(row=>row.raw)});
           }
           const guards=(await original.query(`select n.nspname schema_name,c.relname table_name,
            pg_catalog.pg_get_userbyid(c.relowner) owner_name,c.relrowsecurity,c.relforcerowsecurity,c.relacl::text acl,
            (select pg_catalog.jsonb_agg(pg_catalog.jsonb_build_array(a.attname,a.attacl::text) order by a.attnum)
              from pg_catalog.pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped) column_acl,
            (select pg_catalog.jsonb_agg(pg_catalog.jsonb_build_array(t.tgname,t.tgenabled,
              pg_catalog.pg_get_triggerdef(t.oid,false),pg_catalog.pg_get_functiondef(t.tgfoid)) order by t.tgname)
              from pg_catalog.pg_trigger t where t.tgrelid=c.oid and not t.tgisinternal) guards
            from pg_catalog.pg_class c join pg_catalog.pg_namespace n on n.oid=c.relnamespace
            where c.oid=any($1::regclass[]) order by n.nspname,c.relname`,[fixedTables])).rows;
           assert.equal(guards.length,2);
           return {rows,guards};
          }finally{await original.query('rollback');transaction=false;}
         };
         const before=await privateSnapshot();
         const unitKey='UNIT-only-normal-local-reconciliation-HMAC-20261018',unitKeyId='unit-local-reconciliation-v1';
         const runCommand=async(script,extra,record)=>{
          assert.ok(['create-production-restore-reconciliation.mjs','apply-production-restore-reconciliation.mjs'].includes(script));
          phase='NEW normal local signed reconciliation '+script;
          child=spawn(process.execPath,[B+'/scripts/'+script],{cwd:B,env:{...childEnv,...extra},stdio:['ignore','pipe','pipe']});
          let output='',errors='',overflow=false;
          const collect=(chunk,isError)=>{const value=chunk.toString('utf8');
           if(output.length+errors.length+value.length>1048576){overflow=true;return;}
           if(isError)errors+=value;else output+=value;};
          child.stdout.on('data',chunk=>collect(chunk,false));child.stderr.on('data',chunk=>collect(chunk,true));
          const terminal=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});
          fs.writeFileSync(path.join(out,record+'.stdout'),output.replaceAll(bootstrap,'[REDACTED_EPHEMERAL_TEST_VALUE]'),{flag:'wx',mode:0o600});
          fs.writeFileSync(path.join(out,record+'.stderr'),errors.replaceAll(bootstrap,'[REDACTED_EPHEMERAL_TEST_VALUE]'),{flag:'wx',mode:0o600});
          put(record+'_TERMINAL.json',{...terminal,overflow,normal_script:script,production:false});
          assert.equal(overflow,false);assert.equal(terminal.code,0);assert.equal(terminal.signal,null);assert.equal(errors,'');
          return JSON.parse(output);
         };
         const approved=await runCommand('create-production-restore-reconciliation.mjs',{
          RESTORE_RECONCILIATION_NAMED_ACTOR:'UNIT_LOCAL_PROTOTYPE_OPERATOR_NOT_A_HUMAN',
          RESTORE_RECONCILIATION_SIGNING_KEY:unitKey,RESTORE_RECONCILIATION_SIGNING_KEY_ID:unitKeyId,
          RESTORE_RECONCILIATION_TTL_MINUTES:'5',RESTORE_RECONCILIATION_RESOLUTIONS_JSON:'[]'},'NORMAL_LOCAL_RECONCILIATION_CREATE');
         assert.equal(approved.format,'memphis-zoo-production-restore-reconciliation.v1');
         assert.equal(approved.intent.restore_id,intent.restore_id);assert.equal(approved.intent.archive_digest,bound.archive_digest);
         assert.equal(approved.intent.final_manifest_sha256,result.final_manifest_sha256);assert.deepEqual(approved.intent.resolutions,[]);
         assert.equal(approved.intent.target_project_ref,bound.project_ref);
         assert.equal(crypto.verifyBinding(crypto.restoreReconciliationBinding(approved.intent),approved.signature,unitKey),true);
         const applied=await runCommand('apply-production-restore-reconciliation.mjs',{
          RESTORE_RECONCILIATION_APPLY:'true',RESTORE_RECONCILIATION_CONFIRM_PROJECT_REF:bound.project_ref,
          RESTORE_RECONCILIATION_VERIFY_KEY:unitKey,RESTORE_RECONCILIATION_VERIFY_KEY_ID:unitKeyId,
          RESTORE_RECONCILIATION_JSON:JSON.stringify(approved)},'NORMAL_LOCAL_RECONCILIATION_APPLY');
         assert.equal(applied.ok,true);assert.equal(applied.resumed,true);assert.equal(applied.idempotent_replay,false);
         assert.equal(applied.restore_id,intent.restore_id);assert.equal(applied.reconciliation_id,approved.intent.reconciliation_id);
         const after=await privateSnapshot();assert.deepEqual(after,before,'Signed metadata finalization must preserve private DATA/owners/RLS/ACL/ALWAYS guards');
         const controls=(await original.query('select restore_id::text,authority_generation::text generation,archive_digest,state,mutations_paused from custodial_dr.restore_control where singleton')).rows;
         assert.deepEqual(controls,[{restore_id:intent.restore_id,generation:'1',archive_digest:bound.archive_digest,state:'COMPLETE',mutations_paused:false}]);
         const events=(await original.query("select count(*)::text n from custodial_dr.restore_events where restore_id=$1 and phase='PRODUCTION_RECONCILIATION' and outcome='RESOLVED'",[intent.restore_id])).rows;
         assert.deepEqual(events,[{n:'1'}]);assert.equal(forwardError,undefined);
         reconciliation={status:'LOCAL_SIGNED_RECONCILIATION_OBSERVED',normal_scripts:true,synthetic_UNIT_operator:true,
          test_HMAC_only:true,real_keys:false,actual_SQL:true,control:controls[0],private_rows_guards_before_sha256:sha(JSON.stringify(before)),
          private_rows_guards_after_sha256:sha(JSON.stringify(after)),private_rows_owners_RLS_ACL_ALWAYS_unchanged:true,
          reconciliation_id:approved.intent.reconciliation_id,one_resolution_event:true,repeat_or_retry:false,production:false};
        }
        put('SIGNED_LOCAL_RECONCILIATION_RESULT.json',reconciliation);
        put('PRODUCT_RESULT.json',{scope:'NEW_PRIVATE286_OFFICIAL_NONEMPTY_STORAGE_AND_LOCAL_SIGNED_RECONCILIATION',
         actual_SQL:true,normal_entrypoint:true,original_archive_digest:bound.archive_digest,held_postverify:'HELD_POSTVERIFY_RESULT.json',
         official_local_provider_evidence:result.storage,reconciliation,provider_verified:true,real_operator:false,whole_G31:false,A2:'OPEN',
         production:false,old_passed_cron_cases_replayed:0,old_groups_replayed:0});
       }
      }else{
      const result=JSON.parse(stdout);assert.equal(result.database_only,true);assert.equal(result.state,'DATABASE_RESTORED');
      assert.equal(result.mutations_paused,true);assert.equal(result.database_phase.commit_status,'ACKNOWLEDGED');
      if(freshOriginalReadbackCli){
       const readback=result.original_data_readback;assert.equal(readback.commit_status,'ACKNOWLEDGED');
       assert.equal(readback.comparison_only,true);assert.deepEqual(readback.requested_original,result.database_phase.requested_original);
       for(const key of ['complete_restore','resume_allowed','retry_allowed','rerun_import_allowed'])assert.equal(readback[key],false);
       assert.notEqual(readback.current_context.transaction_id,readback.current_context.original_transaction_id);
       assert.equal(readback.current_context.restore_id,intent.restore_id);assert.equal(readback.current_context.authority_generation,'1');
       assert.equal(readback.current_context.transaction_authority,false);assert.equal(readback.current_context.admission_resumed,false);
       assert.equal(readback.private_data.state,'MATCH');assert.equal(readback.private_data.tables.length,2);
       for(const table of readback.private_data.tables){assert.equal(table.state,'MATCH');
        assert.equal(table.schema_name,'custodial_release_identity');assert.equal(table.missing_rows,'0');assert.equal(table.extra_rows,'0');
        assert.equal(table.original_rows,table.current_rows);}
       if(freshCompleteReadbackCli){
        const ordinary=readback.ordinary_data;assert.equal(ordinary.state,sourceOwnedReadbackCli?'SOURCE_TRANSFORMATION_VERIFIED':'CURRENT_TARGET_SOURCE_REQUIRES_OWNER_CHECK');
        const originals=archiveApi.readVerifiedRestoreTableSelection(archive,{databaseOnly:true}).databaseTables
         .filter(table=>['public','auth'].includes(table.schema_name));
        assert.deepEqual(ordinary.tables.map(table=>table.schema_name+'.'+table.table_name).sort(),
         originals.map(table=>table.schema_name+'.'+table.table_name).sort());
        const sourceOwned=['public.release_deployment_manifest','public.custodial_release_authority_restore_inventory'];
        for(const table of ordinary.tables){
         if(sourceOwned.includes(table.schema_name+'.'+table.table_name)){
          if(sourceOwnedReadbackCli){
           assert.equal(table.state,table.table_name==='release_deployment_manifest'?'MATCH':'SOURCE_TRANSFORMATION_VERIFIED');
           assert.equal(table.metadata_only,true);assert.equal(table.current_rows,table.original_rows);
           assert.equal(table.missing_rows,'0');assert.equal(table.extra_rows,'0');
           assert.equal(table.source_transformed_rows,table.table_name==='release_deployment_manifest'?'0':populatedAuthorityReadbackCli?'24':'22');
          }else{
          assert.equal(table.state,'CURRENT_TARGET_SOURCE_REQUIRES_OWNER_CHECK');
          assert.equal(table.current_rows,null);assert.equal(table.missing_rows,null);assert.equal(table.extra_rows,null);
          }
         }else{assert.equal(table.state,'MATCH');assert.equal(table.current_rows,table.original_rows);
          assert.equal(table.missing_rows,'0');assert.equal(table.extra_rows,'0');}
        }
       }
       assert.equal(readback.storage_data.status,'NOT_APPLICABLE_ORIGINAL_NO_MEMBERS');assert.deepEqual(readback.storage_data.tables,[]);
       if(freshCompleteReadbackCli&&!freshAuthCompleteCli){
        const preparation=result.authority_preparation;assert.equal(preparation.preparation_only,true);
        assert.deepEqual(preparation.requested_original,result.database_phase.requested_original);
        for(const key of ['effect_allowed','transaction_authority','admission_resumed','complete_restore','resume_allowed','retry_allowed','rerun_import_allowed'])
         assert.equal(preparation[key],false);
        assert.notEqual(preparation.current_context.transaction_id,readback.current_context.transaction_id);
        assert.equal(preparation.current_context.original_transaction_id,readback.current_context.original_transaction_id);
        assert.equal(preparation.current_context.database_oid,readback.current_context.database_oid);
        assert.equal(preparation.current_context.backend_pid,readback.current_context.backend_pid);
       }
       put('POST_DATABASE_ORIGINAL_DATA_READBACK.json',{...readback,actual_SQL:true,
        Storage_members:'EMPTY_BY_CONSTRUCTION_UNIT_ONLY',Storage_object_bytes:'NOT_QUALIFIED',
        authority_invalidation:freshAuthCompleteCli?'SEE_SEPARATE_NEW_NATIVE_RESULT':'NOT_RUN',
        final_reconciliation:'NOT_RUN',old_groups_replayed:0});
      }
      for(const key of ['complete_restore','resume_allowed','retry_allowed','rerun_import_allowed'])assert.equal(result[key],false);
      const reader=new Client({...options,user:'supabase_admin',database:ownedContainerName});clients.add(reader);reader.on('error',()=>{});
      try{
       await reader.connect();await reader.query('begin isolation level repeatable read read only');
       const {readVerifiedImmutableFreshDatabaseCommitOutcome:readOutcome}=await import(B+'/scripts/immutable-private-fresh-restore-recovery.mjs');
       const observed=await readOutcome({db:reader,request:result.database_phase.requested_original});
       assert.equal(observed.outcome,'DATABASE_MARKERS_OBSERVED');await reader.query('rollback');
       if(freshAuthCompleteCli){
        await reader.query('begin isolation level repeatable read read only');
        await reader.query('set local search_path=pg_catalog, pg_temp;set local row_security=off');
        const scope=(await reader.query(`select c.target_shape ? 'authority_reconciliation' sealed_scope,
         jsonb_array_length(c.target_shape->'authority_reconciliation'->'functions') function_count,
         (select count(*)::text from auth.sessions) original_auth_sessions,
         (select count(*)::text from custodial_dr.immutable_original_authority_scopes) effect_records
         from custodial_dr.immutable_private_import_context c where c.restore_id=$1`,[intent.restore_id])).rows;
        assert.equal(scope.length,1);assert.deepEqual(scope[0],{sealed_scope:true,function_count:6,original_auth_sessions:'0',effect_records:'1'});
        assert.equal(result.authority_staged.commit_status,'NOT_YET_COMMITTED');
        assert.equal(result.authority_staged.completion.state,'CONSUMED_PAUSED');
        assert.equal(result.authority_commit.commit_status,'ACKNOWLEDGED');
        assert.equal(result.authority_observation.outcome,'AUTHORITY_COMPLETION_OBSERVED');
        assert.equal(result.authority_observation.authority_status.revocations.auth_sessions,'1');
        assert.deepEqual(result.authority_observation.authority_status.revocations,result.authority_staged.completion.revocations);
        for(const object of [result.authority_staged,result.authority_commit,result.authority_observation])
         for(const key of ['complete_restore','resume_allowed','retry_allowed','rerun_import_allowed'])assert.equal(object[key],false);
        const saved=(await reader.query(`select s.phase,s.completed_step,s.active_table_oid,s.counts,
          (select count(*)::text from auth.users) original_auth_users,
          (select count(*)::text from custodial_release_identity.group_original_creations) original_group_records,
          (select mutations_paused from custodial_dr.restore_control where singleton) mutations_paused,
          (select state from custodial_dr.restore_control where singleton) control_state
          from custodial_dr.immutable_original_authority_scopes s where s.restore_id=$1`,[intent.restore_id])).rows;
        assert.equal(saved.length,1);assert.equal(saved[0].phase,'CONSUMED');assert.equal(saved[0].completed_step,6);
        assert.equal(saved[0].active_table_oid,null);assert.equal(saved[0].original_auth_users,'1');assert.equal(saved[0].original_group_records,'1');
        assert.equal(saved[0].mutations_paused,true);assert.equal(saved[0].control_state,'DATABASE_RESTORED');
        assert.deepEqual(saved[0].counts,result.authority_staged.completion.revocations);
        if(populatedAuthorityReadbackCli){
         assert.deepEqual(saved[0].counts,{employee_credentials:'1',employee_enrollment:'2',manager_credentials:'1',manager_enrollment:'1',manager_push:'1',auth_sessions:'1'});
         const data=result.authority_data_readback;
         assert.equal(data.schema,'custodial.immutable-private-post-authority-data-readback.v1');
         assert.equal(data.state,'SOURCE_TRANSFORMATION_VERIFIED');assert.equal(data.private_data.state,'MATCH');
         assert.equal(data.ordinary_data.state,'SOURCE_TRANSFORMATION_VERIFIED');
         assert.equal(data.storage_data.status,'NOT_APPLICABLE_ORIGINAL_NO_MEMBERS');
         const originals=archiveApi.readVerifiedRestoreTableSelection(archive,{databaseOnly:true}).databaseTables;
         assert.equal(data.private_data.tables.length,2);
         for(const table of data.private_data.tables){assert.equal(table.state,'MATCH');assert.equal(table.original_rows,'1');
          assert.equal(table.current_rows,'1');assert.equal(table.missing_rows,'0');assert.equal(table.extra_rows,'0');}
         assert.deepEqual(data.ordinary_data.tables.map(t=>t.schema_name+'.'+t.table_name).sort(),
          originals.filter(t=>['public','auth'].includes(t.schema_name)).map(t=>t.schema_name+'.'+t.table_name).sort());
         const effects={'public.device_auth_credentials':'1','public.device_auth_enrollment_codes':'2',
          'public.ops_manager_trusted_devices':'1','public.ops_manager_enrollment_codes':'1','public.ops_manager_push_devices':'1','auth.sessions':'1'};
         for(const [name,count]of Object.entries(effects)){
          const tables=data.ordinary_data.tables.filter(t=>t.schema_name+'.'+t.table_name===name);assert.equal(tables.length,1);
          const table=tables[0];assert.equal(table.state,'SOURCE_TRANSFORMATION_VERIFIED');
          assert.equal(table.source_transformed_rows,count);assert.equal(table.clock_fields_valid,true);
          assert.equal(table.current_rows,name==='auth.sessions'?'0':count);assert.equal(table.missing_rows,'0');assert.equal(table.extra_rows,'0');
         }
         for(const flag of ['complete_restore','resume_allowed','retry_allowed','rerun_import_allowed','inventory_acknowledged','effects'])assert.equal(data[flag],false);
         put('POPULATED_AUTHORITY_POST_DATA_READBACK.json',{...data,actual_SQL:true,actual_six_populated_effects:true,
          genuine_manager_or_Android:false,Storage_members:'EMPTY_BY_CONSTRUCTION_UNIT_ONLY',complete_restore:false,
          previous_foreign_receipt_and_status_CLI_groups_replayed:0});
        }
        await reader.query('rollback');
        if(!populatedAuthorityReadbackCli){
        await reader.query('begin isolation level repeatable read read only');
        await reader.query('set local search_path=pg_catalog, pg_temp;set local row_security=off');
        const context=result.authority_commit.requested_original;let refusal;
        try{await reader.query('select custodial_dr.read_committed_immutable_original_authority($1::oid,$2::integer,$3::bigint,$4::uuid,$5::bigint,$6::text,$7::bigint)',
         [context.databaseOid,context.effectBackendPid,(BigInt(context.effectTransactionId)+1n).toString(),intent.restore_id,'1',bound.archive_digest,context.originalTransactionId]);}
        catch(error){refusal={code:error.code,message:error.message,detail:error.detail};}
        assert.deepEqual(refusal,{code:'55000',message:'IMMUTABLE_ORIGINAL_AUTHORITY_STATUS_UNKNOWN',detail:'outcome=UNKNOWN;retry_safe=false'});
        await reader.query('rollback');
        // Newly integrated actual status CLI, not another DATA import or
        // a synthetic reader port. One independent process reads this SAME
        // committed original scope and cannot enter signing/effect paths.
        const prefix='RESTORE_RECONCILIATION_STATUS_';
        const statusEnv={PATH:'/usr/bin:/bin',LANG:'C.UTF-8',SUPABASE_DB_URL:childEnv.SUPABASE_DB_URL,
         SUPABASE_PROJECT_REF:bound.project_ref,[prefix+'AUTHORITY_OUTCOME']:'true',
         [prefix+'ID']:context.restoreId,[prefix+'GENERATION']:context.generation,
         [prefix+'ARCHIVE_DIGEST']:context.archiveDigest,[prefix+'DATABASE_OID']:context.databaseOid,
         [prefix+'EFFECT_BACKEND_PID']:String(context.effectBackendPid),
         [prefix+'EFFECT_TRANSACTION_ID']:context.effectTransactionId,
         [prefix+'ORIGINAL_TRANSACTION_ID']:context.originalTransactionId};
        const statusChild=spawn(process.execPath,[B+'/scripts/create-production-restore-reconciliation.mjs'],
         {cwd:B,env:statusEnv,stdio:['ignore','pipe','pipe']});
        let statusOut='',statusErr='',statusTruncated=false;
        const collectStatus=(kind,bytes)=>{
         if(Buffer.byteLength(statusOut)+Buffer.byteLength(statusErr)+bytes.length>1024*1024){
          statusTruncated=true;statusChild.kill('SIGTERM');return;}
         if(kind==='out')statusOut+=bytes.toString('utf8');else statusErr+=bytes.toString('utf8');};
        statusChild.stdout.on('data',bytes=>collectStatus('out',bytes));statusChild.stderr.on('data',bytes=>collectStatus('err',bytes));
        const statusTerminal=await new Promise((yes,no)=>{statusChild.once('error',no);statusChild.once('close',(code,signal)=>yes({code,signal}));});
        fs.writeFileSync(out+'/AUTHORITY_STATUS_CLI.stdout',statusOut,{flag:'wx',mode:0o600});
        fs.writeFileSync(out+'/AUTHORITY_STATUS_CLI.stderr',statusErr,{flag:'wx',mode:0o600});
        put('AUTHORITY_STATUS_CLI_TERMINAL.json',{...statusTerminal,truncated:statusTruncated,
         actual_native_loopback:true,SQL_not_stubbed:true,TLS:'NOT_QUALIFIED_LOCAL_FIXTURE',signing:false,effect_attempts:0});
        assert.equal(statusTerminal.code,0);assert.equal(statusTerminal.signal,null);assert.equal(statusTruncated,false);assert.equal(statusErr,'');
        const statusObserved=JSON.parse(statusOut);
        assert.equal(statusObserved.outcome,'AUTHORITY_COMPLETION_OBSERVED');
        assert.deepEqual(statusObserved.requested_original,context);
        for(const key of ['complete_restore','resume_allowed','retry_allowed','rerun_import_allowed'])assert.equal(statusObserved[key],false);
        put('AUTHORITY_STATUS_CLI_READBACK.json',{...statusObserved,actual_child_process:true,
         actual_SQL:true,fixture_only:true,production:false,real_credential_or_TLS_or_resume:false});
        put('NEW_AUTH_COMPLETE_SCOPE_NATIVE_RESULT.json',{scope,committed_scope:saved,foreign_effect_receipt:refusal,
         schema_and_original_import_actual_SQL:true,scope_installed_before_original_shape:true,actual_private_original_factory:true,
         actual_six_effects_and_COMMIT:true,actual_fixed_historical_readback:true,full_restore:false,resume:false,
         Source_preparation_not_adopted_as_authority:true,old_auth_missing_case_replayed:false,old_groups_replayed:0});
        }
       }
       if(freshSnapshotCli){
        await reader.query('begin isolation level repeatable read read only');
        const snapshots=(await reader.query(`select category,authority_generation::text generation,row_count::text row_count,
          state_json->>'missing' missing,state_json->>'data_encoding' data_encoding,
          jsonb_array_length(state_json->'rows') raw_rows,snapshot_sha256
          from custodial_dr.pre_restore_snapshots where restore_id=$1 order by category`,[intent.restore_id])).rows;
        assert.equal(snapshots.length,10);
        for(const saved of snapshots){assert.equal(saved.generation,'1');assert.equal(saved.data_encoding,'postgres-json-text-line.v1');
         assert.equal(String(saved.raw_rows),saved.row_count);assert.match(saved.snapshot_sha256,/^[0-9a-f]{64}$/);}
        const employee=snapshots.find(row=>row.category==='employee_status');assert.ok(employee);
        assert.equal(employee.missing,'false');assert.equal(employee.row_count,'0');
        const currentEmployees=(await reader.query('select count(*)::text n from public.employees')).rows[0].n;
        assert.equal(currentEmployees,'7','Retained UNIT archive employee DATA differs');
        await reader.query('rollback');
        put('ORIGINAL_PRE_DATA_SNAPSHOT_JOIN.json',{snapshots,current_employee_rows:currentEmployees,
         captured_employee_rows:employee.row_count,actual_SQL:true,original_generation:'1',
         pre_DATA_capture_observed:true,returned_metadata_is_not_effect_authority:true,whole_restore:false,
         old_snapshot_recording_or_SQL_groups_replayed:0});
       }
       put('PRODUCT_RESULT.json',{scope:'NORMAL_CLI_TO_REAL_FRESH_LOCAL_DATABASE_ONE_COMMIT_AND_FIXED_READ',result,observed,
        original_source_unchanged:true,actual_SQL:true,production:false,complete_restore:false,
        Storage_and_final_reconciliation:'NOT_RUN',Android_and_genuine_manager:'NOT_RUN',old_groups_replayed:0});
      }finally{await reader.end();clients.delete(reader);}
      }
     }finally{
      if(progressSetup)await progressSetup;
      for(const timer of progressTimers)clearTimeout(timer);await progressChain;
      if(progressObserver){try{await progressObserver.end();}finally{clients.delete(progressObserver);progressObserver=null;}}
      // The child terminal precedes closure; never kill an unknown commit as
      // resolution. Only exact owned transport handles are drained here.
      for(const stream of streams)stream.destroy();
      if(forward.listening)await new Promise((yes,no)=>forward.close(error=>error?no(error):yes()));
      put('NORMAL_CLI_ENDPOINT_CLEANUP.json',{closed:!forward.listening,owned_streams:streams.size,production:false});
     }
    }else if(freshStageCommit){
     // FIRST full shipping private stage/record/commit join, not the old
     // initializer/refusal probes. Source inputs and native guards unchanged.
     const crypto=await import(B+'/scripts/disaster-recovery-crypto.mjs');
     const {stageVerifiedImmutableFreshData:stageFresh,commitVerifiedImmutableFreshData:commitFresh}=
      await import(B+'/scripts/immutable-private-data-import.mjs');
     const {readVerifiedImmutableFreshDatabaseCommitOutcome:readOutcome}=
      await import(B+'/scripts/immutable-private-fresh-restore-recovery.mjs');
     const release={};for(const key of ['release_id','backend_commit','frontend_commit','migration_head','migration_manifest_sha256'])
      release[key]=bound.source_identity.release[key];
     const now=Date.now(),intentKey='UNIT-only-independent-restore-intent-key-20261016',intentKeyId='unit-immutable-intent-v1';
     const intent={restore_id:randomUUID(),authority_generation:1,retry_of_restore_id:null,archive_digest:bound.archive_digest,
      source_project_ref:bound.project_ref,target_project_ref:bound.project_ref,source_identity_sha256:bound.source_identity_sha256,
      target_migration_head:bound.source_identity.migration_head,target_release_identity:release,
      actor:'UNIT fresh original stage and COMMIT',approved_at:new Date(now).toISOString(),
      expires_at:new Date(now+15*60*1000).toISOString(),resume_after_verification:false};
     const envelope={format:'memphis-zoo-production-restore-intent.v1',algorithm:'hmac-sha256',key_id:intentKeyId,intent,
      signature:crypto.signBinding(crypto.restoreIntentBinding(intent),intentKey)};
     put('FRESH_ORIGINAL_INPUT.json',{intent,invocation,archive_digest:bound.archive_digest,
      test_signature_only:true,real_key:false,source_role:'existing isolated managed fixture supabase_admin',
      source_capture_replayed:false,normal_APPLY_activated:false});
     phase='FIRST shipping fresh initializer/control/original DATA stage';
     const staged=await stageFresh({db:original,verifiedArchive:archive,originalIntentEnvelope:envelope,
      intentVerifyKey:intentKey,intentVerifyKeyId:intentKeyId});
     put('FRESH_ORIGINAL_STAGED.json',{staged,actual_SQL:true,phase_only:true});
     phase='FIRST shipping atomic DATABASE evidence and one native COMMIT';
     let committed;
     try{committed=await commitFresh({db:original,verifiedArchive:archive});transaction=false;}
     catch(error){if(error.commit_attempted===true)transaction=false;throw error;}
     assert.equal(committed.commit_status,'ACKNOWLEDGED');assert.equal(committed.database_phase_recorded,true);
     for(const key of ['complete_restore','retry_allowed','rerun_import_allowed','resume_allowed'])assert.equal(committed[key],false);
     put('FRESH_ORIGINAL_COMMIT.json',{committed,actual_SQL:true,full_restore:false});
     // A distinct native connection sees only fixed current metadata after the
     // commit. It cannot reimport, retry, reconcile or resume the application.
     const reader=new Client({...options,user:'supabase_admin'});clients.add(reader);reader.on('error',()=>{});
     let readerTx=false;
     try{
      await reader.connect();await reader.query('begin isolation level repeatable read read only');readerTx=true;
      await reader.query('set local search_path=pg_catalog');
      const observed=await readOutcome({db:reader,request:committed.requested_original});
      assert.equal(observed.observation,'CURRENT_FIXED_READ');assert.equal(observed.outcome,'DATABASE_MARKERS_OBSERVED');
      assert.equal(observed.complete_restore,false);assert.equal(observed.resume_allowed,false);
      await reader.query('rollback');readerTx=false;
      put('PRODUCT_RESULT.json',{scope:'FIRST_SHIPPING_FRESH_ORIGINAL_DATA_ONE_COMMIT_DISTINCT_CURRENT_READ',
       staged,committed,observed,actual_SQL:true,disposable_UNIT_intent_only:true,production:false,
       complete_restore:false,normal_APPLY_activated:false,Storage_and_final_reconciliation_NOT_RUN:true,
       Android_or_real_manager:false,old_initializer_or_refusal_groups_replayed:false});
     }finally{if(readerTx)await reader.query('rollback');await reader.end();clients.delete(reader);}
    }else{
    const initialized=await initialize({db:original,verifiedArchive:archive});
    put('SHIPPING_INITIALIZER_RETURNED.json',{initialized,invocation,actual_SQL:true,production:false});
    if(freshRecordDenial){
     phase='new actual DATABASE record SQL planned-ID denial without FINISHED import';
     // Use the exact shipping fixed SQL, not a second policy/query builder or
     // an injected success token. No signature or FINISHED context is created.
     const recordSource=fs.readFileSync(B+'/scripts/immutable-private-fresh-restore-record.mjs','utf8');
     const marker='const recordSql=`';assert.equal(recordSource.split(marker).length,2);
     const from=recordSource.indexOf(marker)+marker.length,to=recordSource.indexOf('`;',from);assert.ok(to>from);
     const sql=recordSource.slice(from,to);assert.equal(sql.includes('${'),false);
     const stateSql=`select (select to_jsonb(c) from custodial_dr.restore_control c where singleton) control,
      (select count(*)::int from custodial_dr.restore_manifests) manifests,
      (select count(*)::int from custodial_dr.restore_events) events,
      (select count(*)::int from custodial_dr.immutable_private_import_context) contexts`;
     const before=(await original.query(stateSql)).rows;
     assert.equal(before.length,1);assert.equal(before[0].control.state,'READY');
     assert.equal(before[0].control.authority_generation,0);assert.equal(before[0].control.mutations_paused,false);
     assert.deepEqual({manifests:before[0].manifests,events:before[0].events,contexts:before[0].contexts},{manifests:0,events:0,contexts:0});
     const planned='11111111-1111-1111-1111-111111111111';
     const attempt=await original.query(sql,[planned,'1',bound.archive_digest,bound.project_ref,bound.project_ref,
      'UNIT planned ID denial only','{}','{}',initialized.database_oid,invocation.pid,invocation.xid,'{}']);
     assert.equal(attempt.rowCount,1);
     assert.deepEqual(attempt.rows,[{control_count:0,manifest_count:0,event_count:0,database_oid:initialized.database_oid,
      backend_pid:invocation.pid,transaction_id:invocation.xid,restore_id:null,authority_generation:null,archive_digest:null}]);
     assert.deepEqual((await original.query(stateSql)).rows,before);
     await original.query('rollback');transaction=false;
     put('PRODUCT_RESULT.json',{scope:'NEW_SHIPPING_DATABASE_RECORD_SQL_PLANNED_ID_WITHOUT_FINISHED_IMPORT_DENIED',
      actual_SQL:true,shipping_sql_sha256:sha(sql),record_module_sha256:sha(recordSource),
      original_transaction:invocation,denial_receipt:attempt.rows[0],control_unchanged:true,manifests:0,events:0,contexts:0,
      initializer:'QUALIFIED_SETUP_ONLY_OLD_SOURCE_TEST_CASES_NOT_REPLAYED',transaction:'ROLLED_BACK',
      signed_intents_created:0,valid_tokens_created:0,DATA_import:false,COMMIT:false,
      limits:'READY0 target, no manifest or FINISHED context; collective planned-ID denial and SQL compilation only, not isolated phase-guard/positive writer/token/restore proof. Existing managed fixture owner, not production least-privilege.',
      positive_metadata_record:false,restore_complete:false,resume:false,production:false});
    }else{
    assert.equal(initialized.guard_recipes,23);assert.equal(initialized.source_statements,9);
    assert.equal(initialized.backend_pid,invocation.pid);assert.equal(initialized.transaction_id,invocation.xid);
    for(const key of ['transaction_authority','restore_complete','admission_resumed'])assert.equal(initialized[key],false);
    for(const name of ['group_original_creations','employee_message_original_outcomes'])
     assert.equal((await original.query('select count(*)::text n from ONLY custodial_release_identity.'+quoteIdentifier(name))).rows[0].n,'0');
    phase='same-client second initialization and injected native port refuse';
    await assert.rejects(()=>initialize({db:original,verifiedArchive:archive}),/Original fresh Source initializer is unavailable/);
    let fakeQueries=0;await assert.rejects(()=>initialize({db:{query(){fakeQueries++;}},verifiedArchive:archive}),/Original fresh Source initializer is unavailable/);
    assert.equal(fakeQueries,0);assert.equal(archiveApi.readVerifiedArchiveSourceBinding(archive),bound);
    await original.query('rollback');transaction=false;
    put('PRODUCT_RESULT.json',{scope:'NEW_SHIPPING_FRESH_SOURCE_INITIALIZER_ACTUAL_SQL_SOURCE_ONLY',initialized,schema,
     original_transaction:invocation,original_archive:bound.archive_digest,source_only:true,
     complete_Source_guard_and_registry_readback:true,private_originals_still_empty:true,
     duplicate_same_client_refused:true,fake_port_queries:fakeQueries,transaction:'ROLLED_BACK',
     DATA_replayed:false,DATA_import:false,COMMIT:false,restore_complete:false,resume:false,production:false,
     role_scope:'Existing original managed fixture owner supabase_admin; intrinsic superuser/bypass attributes are unchanged. Not a production least-privilege or genuine-manager result.'});
    }
    }
   }catch(error){firstFailure=error;throw error;}finally{
    const cleanup=[];
    if(profileTimer)clearTimeout(profileTimer);
    if(profileCapture)try{await profileCapture;}catch(error){cleanup.push(error);}
    if(profiler){try{profiler.disconnect();}catch(error){cleanup.push(error);}profiler=null;}
    if(profileObserver){try{await profileObserver.query('rollback');}catch(error){cleanup.push(error);}
     try{await profileObserver.end();}catch(error){cleanup.push(error);}clients.delete(profileObserver);}
    if(transaction)try{await original.query('rollback');}catch(error){cleanup.push(error);}
    try{await original.end();}catch(error){cleanup.push(error);}clients.delete(original);
    if(archive)try{archive.cleanup();assert.equal(fs.existsSync(archive.directory),false);}catch(error){cleanup.push(error);}
    if(cleanup.length)throw new AggregateError(firstFailure?[firstFailure,...cleanup]:cleanup,'Shipping initializer fixture cleanup failed',{cause:firstFailure??cleanup[0]});
   }
  }else if(stage==='finish'&&backupOriginalMetadata){
   phase='NEW shipping original backup metadata in one actual READ ONLY snapshot';
   const {captureProductionBackupOriginalMetadata:capture}=await import(B+'/scripts/production-backup-original-metadata.mjs');
   const archiveApi=await import(B+'/scripts/disaster-recovery-archive.mjs');
   const original=new Client({...options,user:'supabase_admin'});clients.add(original);original.on('error',()=>{});
   const input=path.resolve(D,'../restore-runtime-authorized-KM9tAR/authenticated-setwise-original-restore-v16/authenticated-original-source');
   let transaction=false,archive,firstFailure;
   try{
    archive=archiveApi.materializeVerifiedArchive({sourceDir:input,
     archiveVerifyKey:'UNIT-only-immutable-archive-verification-key-20261016',archiveVerifyKeyId:'unit-immutable-archive-v1',
     supportedFormats:['memphis-zoo-disaster-recovery.v4']});
    const bound=archiveApi.readVerifiedArchiveSourceBinding(archive);
    assert.equal(bound.archive_digest,'969fde44613e2153f5eebce6df7308efcdfc00c7cd7c80dd69ce316b62941132');
    const inventory=archiveApi.readVerifiedImmutableBootstrapInventory(archive).inventory;
    await original.connect();await original.query('begin isolation level repeatable read read only');transaction=true;
    await original.query('set local search_path=pg_catalog');await original.query('set local row_security=off');
    const snapshot=(await original.query('select pg_export_snapshot() snapshot')).rows[0].snapshot;assert.ok(typeof snapshot==='string'&&snapshot.length>0);
    const actual=await capture(original);
    assert.deepEqual(actual.relations,JSON.parse(inventory['inventory/original-relations.json']));
    assert.deepEqual(actual.guards,JSON.parse(inventory['inventory/original-guards.json']));
    assert.deepEqual(actual.acls,JSON.parse(inventory['inventory/original-acls.json']));
    const context=(await original.query(`select current_user actor,session_user session_actor,
     current_setting('transaction_read_only') readonly,current_setting('transaction_isolation') isolation,
     current_setting('search_path') search_path,current_setting('row_security') row_security`)).rows[0];
    assert.deepEqual(context,{actor:'supabase_admin',session_actor:'supabase_admin',readonly:'on',isolation:'repeatable read',search_path:'pg_catalog',row_security:'off'});
    assert.equal(archiveApi.readVerifiedArchiveSourceBinding(archive),bound);
    await original.query('rollback');transaction=false;
    put('PRODUCT_RESULT.json',{scope:'NEW_NORMAL_BACKUP_ORIGINAL_METADATA_ACTUAL_SQL_CAPTURE_ONLY',context,
     actual_metadata:actual,exact_retained_original_equality:true,retained_archive:bound.archive_digest,
     source_sha256:sha(fs.readFileSync(B+'/scripts/production-backup-original-metadata.mjs')),
     relation_count:actual.relations.length,guard_count:actual.guards.length,
     acl_counts:Object.fromEntries(Object.entries(actual.acls).map(([key,value])=>[key,value.length])),
     snapshot_rolled_back:true,DATA_read_or_import:false,full_backup_or_signature:false,restore:false,COMMIT:false,production:false});
   }catch(error){firstFailure=error;throw error;}finally{
    const cleanup=[];
    if(transaction)try{await original.query('rollback');}catch(error){cleanup.push(error);}
    try{await original.end();}catch(error){cleanup.push(error);}clients.delete(original);
    if(archive)try{archive.cleanup();assert.equal(fs.existsSync(archive.directory),false);}catch(error){cleanup.push(error);}
    if(cleanup.length)throw new AggregateError(firstFailure?[firstFailure,...cleanup]:cleanup,'Backup metadata fixture cleanup failed',{cause:firstFailure??cleanup[0]});
   }
  }else if(stage==='finish'&&freshStatusCli){
   phase='NEW joined shipping status CLI -> fixed readonly SQL -> original UNKNOWN handoff';
   const owner=new Client({...options,user:'supabase_admin'});clients.add(owner);owner.on('error',()=>{});
   const original={restoreId:id(762),generation:'1',archiveDigest:sha('UNIT_NEW_STATUS_CLI_UNKNOWN_ONLY'),targetProjectRef:'abcdefghijklmnopqrst'};
   let setupTransaction=false,firstFailure;
   const stateSql=`select (select to_jsonb(c) from custodial_dr.restore_control c where singleton) control,
    (select coalesce(jsonb_agg(to_jsonb(m) order by m.restore_id),'[]'::jsonb) from custodial_dr.restore_manifests m) manifests,
    (select coalesce(jsonb_agg(to_jsonb(e) order by e.event_id),'[]'::jsonb) from custodial_dr.restore_events e) events`;
   try{
    await owner.connect();await owner.query('begin');setupTransaction=true;
    // Synthetic metadata ONLY, not imported DATA or an observed lost COMMIT.
    const updated=await owner.query(`update custodial_dr.restore_control set restore_id=$1,authority_generation=$2,
     archive_digest=$3,target_project_ref=$4,state='PAUSED_FAILURE',mutations_paused=true where singleton`,
     [original.restoreId,original.generation,original.archiveDigest,original.targetProjectRef]);assert.equal(updated.rowCount,1);
    await owner.query(`insert into custodial_dr.restore_manifests(restore_id,authority_generation,archive_digest)
     values($1,$2,$3)`,[original.restoreId,original.generation,original.archiveDigest]);
    await owner.query(`insert into custodial_dr.restore_events(restore_id,authority_generation,phase,outcome,actor,evidence_json)
     values($1,$2,'DATABASE','FAILED','UNIT metadata profile',$3::jsonb)`,
     [original.restoreId,original.generation,JSON.stringify({outcome:'UNKNOWN',retry_safe:false})]);
    await owner.query('commit');setupTransaction=false;
    const before=(await owner.query(stateSql)).rows;
    const databaseUrl='postgresql://supabase_admin@localhost/postgres?host='+encodeURIComponent(socket);
    const bytes=execFileSync(process.execPath,[B+'/scripts/create-production-restore-reconciliation.mjs'],{
     env:{PATH:'/usr/bin:/bin',LANG:'C.UTF-8',PGPASSWORD:bootstrap,SUPABASE_DB_URL:databaseUrl,
      SUPABASE_PROJECT_REF:original.targetProjectRef,RESTORE_RECONCILIATION_STATUS_ID:original.restoreId,
      RESTORE_RECONCILIATION_STATUS_GENERATION:original.generation,RESTORE_RECONCILIATION_STATUS_ARCHIVE_DIGEST:original.archiveDigest,
      RESTORE_RECONCILIATION_STATUS_COMMIT_OUTCOME:'true'},encoding:'utf8',timeout:20000,maxBuffer:65536});
    assert.equal(bytes.trim().split('\n').length,1);const observed=JSON.parse(bytes);
    assert.equal(observed.schema,'custodial.immutable-private-fresh-commit-outcome.v1');
    assert.deepEqual(observed.requested_original,original);assert.equal(observed.observation,'CURRENT_FIXED_READ');
    assert.equal(observed.outcome,'UNKNOWN');assert.equal(observed.status.database_marker_status,'UNRESOLVED');
    assert.equal(observed.status.prior_unknown_recorded,true);assert.equal(observed.metadata_only,true);
    for(const key of ['retry_allowed','resume_allowed','rerun_import_allowed','complete_restore'])assert.equal(observed[key],false);
    assert.deepEqual((await owner.query(stateSql)).rows,before,'Status CLI must not change original metadata');
    const remaining=(await owner.query(`select count(*)::int n from pg_stat_activity where datname=current_database()
     and application_name='memphis-zoo-create-restore-reconciliation'`)).rows[0].n;assert.equal(remaining,0);
    put('PRODUCT_RESULT.json',{scope:'NEW_JOINED_SHIPPING_STATUS_CLI_ACTUAL_READONLY_SQL_UNKNOWN_OUTCOME',actual_SQL:true,
     observed,original_metadata_unchanged:true,status_client_absent:true,synthetic_metadata_only:true,
     signatures_created:0,private_DATA_replayed:false,actual_DATA_commit:false,restore_complete:false,production:false});
   }catch(error){firstFailure=error;throw error;}finally{
    const cleanup=[];if(setupTransaction)try{await owner.query('rollback');}catch(error){cleanup.push(error);}
    try{await owner.end();}catch(error){cleanup.push(error);}clients.delete(owner);
    if(cleanup.length)throw new AggregateError(firstFailure?[firstFailure,...cleanup]:cleanup,'Status CLI fixture cleanup failed',{cause:firstFailure??cleanup[0]});
   }
  }else if(stage==='finish'&&originalRestoreStatus){
   phase='NEW original-status fixed reader on actual canonical SQL metadata';
   const {readOriginalRestoreDatabaseStatus:readStatus}=await import(B+'/scripts/disaster-recovery-state.mjs');
   const owner=new Client({...options,user:'supabase_admin'});clients.add(owner);owner.on('error',()=>{});
   const reader=new Client({...options,user:'supabase_admin'});clients.add(reader);reader.on('error',()=>{});
   const original={restoreId:id(761),generation:'1',archiveDigest:sha('UNIT_ORIGINAL_STATUS_METADATA_ONLY'),targetProjectRef:'abcdefghijklmnopqrst'};
   const results=[];let setupTransaction=false,readTransaction=false,statusFailure;
   const deny=error=>error?.code==='RESTORE_ORIGINAL_STATUS_UNAVAILABLE';
   try{
    await owner.connect();await reader.connect();
    const context=(await owner.query(`select current_user actor,session_user session_actor,
     (select pg_get_userbyid(relowner) from pg_class where oid='custodial_dr.restore_control'::regclass) control_owner`)).rows[0];
    assert.deepEqual(context,{actor:'supabase_admin',session_actor:'supabase_admin',control_owner:'supabase_admin'});
    for(const profile of ['empty','matching_marker','unknown_without_marker','duplicate_marker','foreign_generation_marker','contradictory_marker','foreign_current_control']){
     phase='NEW original-status metadata profile '+profile;
     await owner.query('begin');setupTransaction=true;
     const updated=await owner.query(`update custodial_dr.restore_control set restore_id=$1,authority_generation=$2,
      archive_digest=$3,target_project_ref=$4,state='PAUSED_FAILURE',mutations_paused=true where singleton`,
      [original.restoreId,original.generation,original.archiveDigest,original.targetProjectRef]);assert.equal(updated.rowCount,1);
     await owner.query('delete from custodial_dr.restore_events where restore_id=$1',[original.restoreId]);
     await owner.query('delete from custodial_dr.restore_manifests where restore_id=$1',[original.restoreId]);
     const marked=!['empty','unknown_without_marker'].includes(profile);
     // Contrived canonical metadata, not an import/COMMIT observation. Never
     // reused as DATA evidence or authority outside this disposable fixture.
     const receipt={database_oid:(await owner.query('select oid::text value from pg_database where datname=current_database()')).rows[0].value,
      backend_pid:(await owner.query('select pg_backend_pid() value')).rows[0].value,
      transaction_id:(await owner.query('select txid_current()::text value')).rows[0].value,
      restore_id:original.restoreId,authority_generation:original.generation,archive_digest:original.archiveDigest,
      private_rows:'2',transaction_authority:false,admission_resumed:false};
     await owner.query(`insert into custodial_dr.restore_manifests(restore_id,authority_generation,archive_digest,database_verified,database_evidence)
      values($1,$2,$3,$4,$5::jsonb)`,[original.restoreId,original.generation,original.archiveDigest,marked,
      JSON.stringify(marked?{original_data_import:receipt}:{})]);
     if(marked){
      const eventReceipt=profile==='contradictory_marker'?{...receipt,private_rows:'3'}:receipt;
      const eventGeneration=profile==='foreign_generation_marker'?'2':original.generation;
      for(let n=0;n<(profile==='duplicate_marker'?2:1);n++)await owner.query(`insert into custodial_dr.restore_events
       (restore_id,authority_generation,phase,outcome,actor,evidence_json) values($1,$2,'DATABASE','PASSED','UNIT metadata profile',$3::jsonb)`,
       [original.restoreId,eventGeneration,JSON.stringify({original_data_import:eventReceipt})]);
     }
     if(profile==='unknown_without_marker')await owner.query(`insert into custodial_dr.restore_events
      (restore_id,authority_generation,phase,outcome,actor,evidence_json) values($1,$2,'DATABASE','FAILED','UNIT metadata profile',$3::jsonb)`,
      [original.restoreId,original.generation,JSON.stringify({outcome:'UNKNOWN',retry_safe:false})]);
     if(profile==='foreign_current_control')await owner.query('update custodial_dr.restore_control set authority_generation=2 where singleton');
     await owner.query('commit');setupTransaction=false;
     await reader.query('begin isolation level repeatable read read only');readTransaction=true;
     let observed,refusal;try{observed=await readStatus(reader,original);}catch(error){refusal=error;}
     if(profile==='foreign_current_control'){assert.ok(deny(refusal));assert.equal(observed,undefined);}
     else{
      if(refusal)throw refusal;
      assert.equal(observed.database_marker_status,profile==='empty'?'NOT_OBSERVED':profile==='matching_marker'?'OBSERVED_DATABASE_MARKERS':'UNRESOLVED');
      assert.equal(observed.prior_unknown_recorded,profile==='unknown_without_marker');
      assert.equal(observed.metadata_only,true);assert.ok(Object.isFrozen(observed));
      for(const key of ['retry_allowed','resume_allowed','rerun_import_allowed','complete_restore'])assert.equal(observed[key],false);
     }
     await reader.query('rollback');readTransaction=false;
     results.push({profile,observed:observed??null,refusal:refusal?.code??null,synthetic_metadata_only:true});
    }
    const restoredControl=await owner.query('update custodial_dr.restore_control set authority_generation=1 where singleton and restore_id=$1 and authority_generation=2',[original.restoreId]);
    assert.equal(restoredControl.rowCount,1);
    await reader.query('begin isolation level repeatable read read only');readTransaction=true;
    assert.equal((await readStatus(reader,original)).database_marker_status,'OBSERVED_DATABASE_MARKERS');
    await reader.query('rollback');readTransaction=false;
    // Context refusals keep a proven matching tuple and do not borrow a role.
    await reader.query('begin isolation level repeatable read');readTransaction=true;
    await assert.rejects(()=>readStatus(reader,original),deny);await reader.query('rollback');readTransaction=false;
    await reader.query('begin read only');readTransaction=true;
    await assert.rejects(()=>readStatus(reader,original),deny);await reader.query('rollback');readTransaction=false;
    results.push({profile:'writable_and_wrong_isolation_refused',synthetic_metadata_only:true});
    put('PRODUCT_RESULT.json',{scope:'NEW_SHIPPING_ORIGINAL_STATUS_ACTUAL_CANONICAL_SQL_METADATA_ONLY',context,cases:results,
     private_DATA_replayed:false,actual_DATA_commit:false,retry_allowed:false,resume_allowed:false,restore_complete:false,production:false});
   }catch(error){statusFailure=error;throw error;}finally{
    const failures=[];
    if(readTransaction)try{await reader.query('rollback');}catch(error){failures.push(error);}
    if(setupTransaction)try{await owner.query('rollback');}catch(error){failures.push(error);}
    for(const client of [reader,owner]){try{await client.end();}catch(error){failures.push(error);}clients.delete(client);}
    if(failures.length)throw new AggregateError(statusFailure?[statusFailure,...failures]:failures,'Original status fixture cleanup failed',{cause:statusFailure??failures[0]});
   }
  }else if(stage==='finish'&&immutableFreshSchema){
   // This branch runs ONLY in Main's existing network-none/no-published-port
   // owned fixture. Its name/UNIT signatures are not target admission. Keep
   // that controller and its budget unchanged; never use the production CLI.
   phase='verify retained authenticated original full DATA inputs';
   const archiveApi=await import(pathToFileURL(B+'/scripts/disaster-recovery-archive.mjs'));
   const cryptoApi=await import(pathToFileURL(B+'/scripts/disaster-recovery-crypto.mjs'));
   const backup=await import(pathToFileURL(B+'/scripts/production-backup-pg-dump-command.mjs'));
   const {stageVerifiedImmutablePrivateData}=await import(pathToFileURL(B+'/scripts/immutable-private-data-import.mjs'));
   const {quoteIdentifier,planEventOwnerRestore,executeEventOwnerPlan}=await import(pathToFileURL(B+'/scripts/isolated-event-owner-schema.mjs'));
   const {createInterface}=await import('node:readline');
   const {pipeline}=await import('node:stream/promises');
   // Catalog DATA only. The caller owns snapshot/owner/fences and signatures.
   // SCHEMA identity: "schema"; COLUMN identity: "schema"."table"("column").
   async function captureOriginalNamespaceColumnAcls(client){

    const data=(value,keys)=>{
     assert.ok(value!==null&&typeof value==='object'&&(Object.getPrototypeOf(value)===Object.prototype||Object.getPrototypeOf(value)===null),'Closed ACL record required');
     const ds=Object.getOwnPropertyDescriptors(value),names=Reflect.ownKeys(ds);
     assert.ok(names.every(k=>typeof k==='string'),'ACL symbol keys refused');
     assert.deepEqual(names.sort(),[...keys].sort(),'Exact ACL record keys');
     const copy={};
     for(const key of keys){assert.ok(Object.hasOwn(ds[key],'value')&&ds[key].enumerable,'ACL accessors refused');copy[key]=ds[key].value;}
     return copy;
    };
    const list=value=>{
     assert.ok(Array.isArray(value)&&Object.getPrototypeOf(value)===Array.prototype,'Plain ACL array required');
     const ds=Object.getOwnPropertyDescriptors(value),length=ds.length?.value;
     assert.ok(Number.isSafeInteger(length)&&length>=0);assert.equal(Reflect.ownKeys(ds).length,length+1,'ACL sparse/extra array properties refused');
     const copy=[];
     for(let i=0;i<length;i++){const d=ds[String(i)];assert.ok(d&&Object.hasOwn(d,'value')&&d.enumerable,'ACL array accessors/holes refused');copy.push(d.value);}
     return copy;
    };
    const name=value=>{
     assert.ok(typeof value==='string'&&value.length>0&&!value.includes('\0')&&Buffer.byteLength(value,'utf8')<=63&&Buffer.from(value,'utf8').toString('utf8')===value,'Exact PostgreSQL ACL name required');
     return value;
    };
    const compare=(a,b)=>{for(let i=0;i<a.length;i++){const n=Buffer.compare(Buffer.from(a[i]??'','utf8'),Buffer.from(b[i]??'','utf8'));if(n)return n;}return 0;};
    const objectKey=r=>[r.kind,r.schema_name,r.object_name,r.column_name];
    const grantKey=g=>[g.grantee,g.grantor,g.privilege_type];
    const scopes=['public','auth','storage','custodial_release_identity'];
    const privileges={SCHEMA:['USAGE','CREATE'],COLUMN:['SELECT','INSERT','UPDATE','REFERENCES']};
    const rows=(await client.query(`
     with namespaces as (
      select oid,nspname,nspowner,nspacl from pg_catalog.pg_namespace
      where nspname in ('public','auth','storage','custodial_release_identity')
     ), objects as (
      select 'SCHEMA'::text kind,n.nspname schema_name,n.nspname object_name,
       n.nspowner owner_oid,null::text column_name,n.nspacl acl
      from namespaces n
      union all
      select case when a.attnum>0 and not a.attisdropped and c.relkind in ('r','p','v','m','f') then 'COLUMN'
        else 'UNSUPPORTED_COLUMN_RELATION_'||c.relkind::text end,
       n.nspname,c.relname,c.relowner,a.attname::text,a.attacl
      from namespaces n join pg_catalog.pg_class c on c.relnamespace=n.oid
      join pg_catalog.pg_attribute a on a.attrelid=c.oid
      -- Do not silently omit explicit ACLs on an unsupported/dropped/system
      -- column. Return an unsupported descriptor and refuse capture instead.
      where (a.attnum>0 and not a.attisdropped and c.relkind in ('r','p','v','m','f'))
       or pg_catalog.cardinality(a.attacl)>0
     )
     select o.kind,o.schema_name,o.object_name,owner.rolname owner_name,o.column_name,
      coalesce((select pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
       'grantee',case when a.grantee=0 then 'PUBLIC' when grantee.rolname<>'PUBLIC' then grantee.rolname end,
       'grantor',case when grantor.rolname<>'PUBLIC' then grantor.rolname end,
       'privilege_type',a.privilege_type,'is_grantable',a.is_grantable))
       from pg_catalog.aclexplode(case when o.kind='SCHEMA'
        then coalesce(o.acl,pg_catalog.acldefault('n',o.owner_oid)) else o.acl end) a
       left join pg_catalog.pg_roles grantee on grantee.oid=a.grantee
       left join pg_catalog.pg_roles grantor on grantor.oid=a.grantor
       where a.grantee<>o.owner_oid),'[]'::jsonb) grants
     from objects o left join pg_catalog.pg_roles owner on owner.oid=o.owner_oid
    `)).rows;
    const objects=[],seen=new Set();
    for(const value of list(rows)){
     const r=data(value,['kind','schema_name','object_name','owner_name','column_name','grants']);
     assert.ok(r.kind==='SCHEMA'||r.kind==='COLUMN','Unsupported explicit column ACL object');
     name(r.schema_name);name(r.object_name);name(r.owner_name);assert.ok(scopes.includes(r.schema_name),'ACL namespace outside fixed scope');
     if(r.kind==='SCHEMA'){assert.equal(r.object_name,r.schema_name);assert.equal(r.column_name,null);}
     else name(r.column_name);
     const identity=r.kind==='SCHEMA'?quoteIdentifier(r.schema_name):
      quoteIdentifier(r.schema_name)+'.'+quoteIdentifier(r.object_name)+'('+quoteIdentifier(r.column_name)+')';
     const grants=[],seenGrants=new Set();
     for(const value of list(r.grants)){
      const g=data(value,['grantee','grantor','privilege_type','is_grantable']);
      name(g.grantee);name(g.grantor);assert.notEqual(g.grantor,'PUBLIC');assert.notEqual(g.grantee,r.owner_name,'Owner ACL entries must be excluded');
      assert.ok(privileges[r.kind].includes(g.privilege_type),'Unsupported ACL privilege');assert.equal(typeof g.is_grantable,'boolean');
      assert.ok(!(g.grantee==='PUBLIC'&&g.is_grantable),'PUBLIC grant option refused');
      const key=JSON.stringify(grantKey(g));assert.ok(!seenGrants.has(key),'Duplicate ACL permission/grantor');seenGrants.add(key);
      grants.push(Object.freeze(g));
     }
     grants.sort((a,b)=>compare(grantKey(a),grantKey(b)));
     const row=Object.freeze({kind:r.kind,schema_name:r.schema_name,object_name:r.object_name,identity,owner_name:r.owner_name,column_name:r.column_name,grants:Object.freeze(grants)});
     const key=JSON.stringify(objectKey(row));assert.ok(!seen.has(key),'Duplicate ACL object');seen.add(key);objects.push(row);
    }
    objects.sort((a,b)=>compare(objectKey(a),objectKey(b)));
    return Object.freeze(objects);
   }
   async function reconcileOriginalNamespaceColumnAcls(target,original){

    const data=(value,keys)=>{
     assert.ok(value!==null&&typeof value==='object'&&(Object.getPrototypeOf(value)===Object.prototype||Object.getPrototypeOf(value)===null),'Closed ACL record required');
     const ds=Object.getOwnPropertyDescriptors(value),names=Reflect.ownKeys(ds);
     assert.ok(names.every(k=>typeof k==='string'),'ACL symbol keys refused');
     assert.deepEqual(names.sort(),[...keys].sort(),'Exact ACL record keys');
     const copy={};
     for(const key of keys){assert.ok(Object.hasOwn(ds[key],'value')&&ds[key].enumerable,'ACL accessors refused');copy[key]=ds[key].value;}
     return copy;
    };
    const list=value=>{
     assert.ok(Array.isArray(value)&&Object.getPrototypeOf(value)===Array.prototype,'Plain ACL array required');
     const ds=Object.getOwnPropertyDescriptors(value),length=ds.length?.value;
     assert.ok(Number.isSafeInteger(length)&&length>=0);assert.equal(Reflect.ownKeys(ds).length,length+1,'ACL sparse/extra array properties refused');
     const copy=[];
     for(let i=0;i<length;i++){const d=ds[String(i)];assert.ok(d&&Object.hasOwn(d,'value')&&d.enumerable,'ACL array accessors/holes refused');copy.push(d.value);}
     return copy;
    };
    const name=value=>{
     assert.ok(typeof value==='string'&&value.length>0&&!value.includes('\0')&&Buffer.byteLength(value,'utf8')<=63&&Buffer.from(value,'utf8').toString('utf8')===value,'Exact PostgreSQL ACL name required');
     return value;
    };
    const compare=(a,b)=>{for(let i=0;i<a.length;i++){const n=Buffer.compare(Buffer.from(a[i]??'','utf8'),Buffer.from(b[i]??'','utf8'));if(n)return n;}return 0;};
    const objectKey=r=>[r.kind,r.schema_name,r.object_name,r.column_name];
    const grantKey=g=>[g.grantee,g.grantor,g.privilege_type];
    const scopes=['public','auth','storage','custodial_release_identity'];
    const privileges={SCHEMA:['USAGE','CREATE'],COLUMN:['SELECT','INSERT','UPDATE','REFERENCES']};
    // Clone closed DATA before the first await. In particular, never sort or
    // mutate the independently verified/deep-frozen signed original snapshot.
    const copySnapshot=snapshot=>{
     const objects=[],seen=new Set();
     for(const value of list(snapshot)){
      const r=data(value,['kind','schema_name','object_name','identity','owner_name','column_name','grants']);
      assert.ok(r.kind==='SCHEMA'||r.kind==='COLUMN','Unsupported ACL descriptor kind');
      name(r.schema_name);name(r.object_name);name(r.owner_name);assert.ok(scopes.includes(r.schema_name),'ACL namespace outside fixed scope');
      if(r.kind==='SCHEMA'){assert.equal(r.object_name,r.schema_name);assert.equal(r.column_name,null);}
      else name(r.column_name);
      const identity=r.kind==='SCHEMA'?quoteIdentifier(r.schema_name):
       quoteIdentifier(r.schema_name)+'.'+quoteIdentifier(r.object_name)+'('+quoteIdentifier(r.column_name)+')';
      assert.equal(r.identity,identity,'Exact ACL object identity required');
      const grants=[],seenGrants=new Set();
      for(const value of list(r.grants)){
       const g=data(value,['grantee','grantor','privilege_type','is_grantable']);
       name(g.grantee);name(g.grantor);assert.notEqual(g.grantor,'PUBLIC');assert.notEqual(g.grantee,r.owner_name,'Owner ACL entries must be excluded');
       assert.ok(privileges[r.kind].includes(g.privilege_type),'Unsupported ACL privilege');assert.equal(typeof g.is_grantable,'boolean');
       assert.ok(!(g.grantee==='PUBLIC'&&g.is_grantable),'PUBLIC grant option refused');
       const key=JSON.stringify(grantKey(g));assert.ok(!seenGrants.has(key),'Duplicate ACL permission/grantor');seenGrants.add(key);
       grants.push(Object.freeze(g));
      }
      grants.sort((a,b)=>compare(grantKey(a),grantKey(b)));
      const row=Object.freeze({kind:r.kind,schema_name:r.schema_name,object_name:r.object_name,identity,owner_name:r.owner_name,column_name:r.column_name,grants:Object.freeze(grants)});
      const key=JSON.stringify(objectKey(row));assert.ok(!seen.has(key),'Duplicate ACL object');seen.add(key);objects.push(row);
     }
     objects.sort((a,b)=>compare(objectKey(a),objectKey(b)));
     return Object.freeze(objects);
    };
    const expected=copySnapshot(original);
    const actual=copySnapshot(await captureOriginalNamespaceColumnAcls(target));
    assert.equal(actual.length,expected.length,'Complete original ACL object set required');
    const revocations=[];
    // Preflight EVERY expected object/owner/grant/grantor/option before ANY
    // REVOKE. An absent original permission is never repaired with a GRANT.
    for(let i=0;i<expected.length;i++){
     const before=actual[i],wanted=expected[i];
     assert.deepEqual(objectKey(before),objectKey(wanted),'Original namespace/column set differs');
     assert.equal(before.identity,wanted.identity);assert.equal(before.owner_name,wanted.owner_name,'Original ACL object owner differs');
     const old=new Map(before.grants.map(g=>[JSON.stringify(grantKey(g)),g]));
     const keep=new Map(wanted.grants.map(g=>[JSON.stringify(grantKey(g)),g]));
     for(const [key,g]of keep){
      const present=old.get(key);assert.ok(present,'Expected original permission/grantor missing');
      assert.ok(!g.is_grantable||present.is_grantable,'Expected original grant option missing');
     }
     for(const [key,g]of old){
      const originalGrant=keep.get(key);
      if(!originalGrant)revocations.push({object:before,grant:g,optionOnly:false});
      else if(g.is_grantable&&!originalGrant.is_grantable)revocations.push({object:before,grant:g,optionOnly:true});
     }
    }
    let revokedPrivileges=0,revokedGrantOptions=0;
    // The caller owns rollback on ANY refusal; never commit/retry here.
    for(const {object:r,grant:g,optionOnly}of revocations){
     // Identifiers come from the actual catalog object matched above, never
     // from caller SQL/identity text. Native REVOKE checks actual rights; any
     // denial/RESTRICT dependency failure is terminal, with no role fallback.
     const privilege=g.privilege_type+(r.kind==='COLUMN'?' ('+quoteIdentifier(r.column_name)+')':'');
     const object=r.kind==='SCHEMA'?'SCHEMA '+quoteIdentifier(r.schema_name):
      'TABLE '+quoteIdentifier(r.schema_name)+'.'+quoteIdentifier(r.object_name);
     const grantee=g.grantee==='PUBLIC'?'PUBLIC':quoteIdentifier(g.grantee);
     await target.query('REVOKE '+(optionOnly?'GRANT OPTION FOR ':'')+privilege+' ON '+object+
      ' FROM '+grantee+' GRANTED BY '+quoteIdentifier(g.grantor)+' RESTRICT');
     if(optionOnly)revokedGrantOptions++;else revokedPrivileges++;
    }
    const final=copySnapshot(await captureOriginalNamespaceColumnAcls(target));
    assert.deepEqual(final,expected,'Exact original namespace/column ACL readback required');
    return Object.freeze({revoked_privileges:revokedPrivileges,revoked_grant_options:revokedGrantOptions});
   }
   const qualified=t=>quoteIdentifier(t.schema_name)+'.'+quoteIdentifier(t.table_name);
   // Local fixture DATA only. Main authenticates the original snapshot and
   // owns the real client, fresh target, transaction and exclusive fences.
   async function captureOriginalRoutineAcls(client){
    const reply=await client.query(`select pg_catalog.current_setting('search_path') search_path,
     coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
      'kind',case p.prokind when 'f' then 'FUNCTION' when 'p' then 'PROCEDURE' else null end,
      'schema_name',n.nspname,'object_name',p.proname,
      'identity',pg_catalog.format('%I.%I(%s)',n.nspname,p.proname,pg_catalog.oidvectortypes(p.proargtypes)),
      'owner_name',owner_role.rolname,'column_name',null,
      'grants',coalesce((select pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
       'grantee',case when a.grantee=0 then 'PUBLIC' when grantee_role.rolname='PUBLIC' then null else grantee_role.rolname end,
       'grantor',grantor_role.rolname,'privilege_type',a.privilege_type,'is_grantable',a.is_grantable))
       from pg_catalog.aclexplode(coalesce(p.proacl,pg_catalog.acldefault('f',p.proowner))) a
       left join pg_catalog.pg_roles grantee_role on grantee_role.oid=a.grantee
       left join pg_catalog.pg_roles grantor_role on grantor_role.oid=a.grantor
       where a.grantee<>p.proowner),'[]'::jsonb))),'[]'::jsonb) routines
     from pg_catalog.pg_proc p join pg_catalog.pg_namespace n on n.oid=p.pronamespace
     left join pg_catalog.pg_roles owner_role on owner_role.oid=p.proowner
     where n.nspname in ('public','auth','storage','custodial_release_identity')`);
    assert.equal(reply.rows.length,1);assert.equal(reply.rows[0].search_path,'pg_catalog','Routine type identity requires Main pg_catalog search_path');
    const closed=(value,names)=>{
     assert.ok(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)));
     const d=Object.getOwnPropertyDescriptors(value);assert.deepEqual(Reflect.ownKeys(d).sort(),[...names].sort());
     return Object.fromEntries(names.map(k=>{assert.ok(Object.hasOwn(d[k],'value')&&d[k].enumerable);return [k,d[k].value];}));
    };
    const list=(value)=>{
     assert.ok(Array.isArray(value));const d=Object.getOwnPropertyDescriptors(value),length=d.length.value;
     assert.ok(Number.isSafeInteger(length)&&length>=0&&length<=100000);assert.equal(Reflect.ownKeys(d).length,length+1);
     return Array.from({length},(_,i)=>{assert.ok(d[i]&&Object.hasOwn(d[i],'value')&&d[i].enumerable);return d[i].value;});
    };
    const text=(s,max=63)=>{assert.equal(typeof s,'string');assert.ok(s.length>0&&!s.includes('\0'));
     const bytes=Buffer.from(s,'utf8');assert.ok(bytes.length<=max&&bytes.toString('utf8')===s);return s;};
    const compare=(a,b)=>Buffer.compare(Buffer.from(a,'utf8'),Buffer.from(b,'utf8'));
    const routineKey=r=>JSON.stringify([r.schema_name,r.object_name,r.identity,r.kind]);
    const grantKey=g=>JSON.stringify([g.grantee,g.grantor,g.privilege_type]);
    const result=list(reply.rows[0].routines).map(value=>{
     const r=closed(value,['kind','schema_name','object_name','identity','owner_name','column_name','grants']);
     assert.ok(['FUNCTION','PROCEDURE'].includes(r.kind),'Unsupported selected pg_proc routine kind');
     assert.ok(['public','auth','storage','custodial_release_identity'].includes(r.schema_name));
     text(r.object_name);text(r.identity,65536);text(r.owner_name);assert.equal(r.column_name,null);
     const seen=new Set();const grants=list(r.grants).map(value=>{
      const g=closed(value,['grantee','grantor','privilege_type','is_grantable']);
      text(g.grantee);text(g.grantor);assert.notEqual(g.grantee,r.owner_name,'Owner ACL entries are excluded');
      assert.equal(g.privilege_type,'EXECUTE');assert.equal(typeof g.is_grantable,'boolean');
      const key=grantKey(g);assert.ok(!seen.has(key),'Duplicate effective routine ACL tuple');seen.add(key);return g;
     }).sort((a,b)=>compare(grantKey(a),grantKey(b)));
     return {kind:r.kind,schema_name:r.schema_name,object_name:r.object_name,identity:r.identity,owner_name:r.owner_name,column_name:null,grants};
    }).sort((a,b)=>compare(routineKey(a),routineKey(b)));
    assert.ok(result.length>0,'Empty selected original routine catalog');
    const identities=new Set();for(const r of result){assert.ok(!identities.has(r.identity),'Duplicate selected routine identity');identities.add(r.identity);}
    return result;
   }
   async function reconcileOriginalRoutineAcls(target,original){
    // Detach/validate ALL original DATA synchronously before the first await.
    // Frozen signed arrays are never sorted or mutated in place.
    const closed=(value,names)=>{
     assert.ok(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)));
     const d=Object.getOwnPropertyDescriptors(value);assert.deepEqual(Reflect.ownKeys(d).sort(),[...names].sort());
     return Object.fromEntries(names.map(k=>{assert.ok(Object.hasOwn(d[k],'value')&&d[k].enumerable);return [k,d[k].value];}));
    };
    const list=(value)=>{
     assert.ok(Array.isArray(value));const d=Object.getOwnPropertyDescriptors(value),length=d.length.value;
     assert.ok(Number.isSafeInteger(length)&&length>=0&&length<=100000);assert.equal(Reflect.ownKeys(d).length,length+1);
     return Array.from({length},(_,i)=>{assert.ok(d[i]&&Object.hasOwn(d[i],'value')&&d[i].enumerable);return d[i].value;});
    };
    const text=(s,max=63)=>{assert.equal(typeof s,'string');assert.ok(s.length>0&&!s.includes('\0'));
     const bytes=Buffer.from(s,'utf8');assert.ok(bytes.length<=max&&bytes.toString('utf8')===s);return s;};
    const compare=(a,b)=>Buffer.compare(Buffer.from(a,'utf8'),Buffer.from(b,'utf8'));
    const routineKey=r=>JSON.stringify([r.schema_name,r.object_name,r.identity,r.kind]);
    const grantKey=g=>JSON.stringify([g.grantee,g.grantor,g.privilege_type]);
    const identities=new Set();let previousRoutine=null;
    const expected=list(original).map(value=>{
     const r=closed(value,['kind','schema_name','object_name','identity','owner_name','column_name','grants']);
     assert.ok(['FUNCTION','PROCEDURE'].includes(r.kind));assert.ok(['public','auth','storage','custodial_release_identity'].includes(r.schema_name));
     text(r.object_name);text(r.identity,65536);text(r.owner_name);assert.equal(r.column_name,null);
     assert.ok(!identities.has(r.identity),'Duplicate original routine identity');identities.add(r.identity);
     const key=routineKey(r);if(previousRoutine!==null)assert.ok(compare(previousRoutine,key)<0,'Original routine array is not canonical');previousRoutine=key;
     let previousGrant=null;const grants=list(r.grants).map(value=>{
      const g=closed(value,['grantee','grantor','privilege_type','is_grantable']);text(g.grantee);text(g.grantor);
      assert.notEqual(g.grantee,r.owner_name);assert.equal(g.privilege_type,'EXECUTE');assert.equal(typeof g.is_grantable,'boolean');
      const key=grantKey(g);if(previousGrant!==null)assert.ok(compare(previousGrant,key)<0,'Original ACL array is not canonical/unique');previousGrant=key;return g;
     });
     return {kind:r.kind,schema_name:r.schema_name,object_name:r.object_name,identity:r.identity,owner_name:r.owner_name,column_name:null,grants};
    });
    assert.ok(expected.length>0,'Empty original routine snapshot is unsupported');
    const actual=await captureOriginalRoutineAcls(target);
    assert.equal(actual.length,expected.length,'Target selected routine object set differs');
    const header=r=>({kind:r.kind,schema_name:r.schema_name,object_name:r.object_name,identity:r.identity,owner_name:r.owner_name,column_name:r.column_name});
    const plan=[];
    for(let i=0;i<expected.length;i++){
     const before=expected[i],now=actual[i];assert.deepEqual(header(now),header(before),'Target routine identity/owner differs');
     const originalGrants=new Map(before.grants.map(g=>[grantKey(g),g])),currentGrants=new Map(now.grants.map(g=>[grantKey(g),g]));
     for(const [key,g]of originalGrants){const current=currentGrants.get(key);
      assert.ok(current&&(!g.is_grantable||current.is_grantable),'An original routine privilege/grantor/option is missing; no automatic GRANT');}
     for(const [key,g]of currentGrants){const old=originalGrants.get(key);
      if(!old)plan.push({routine:now,grant:g,optionOnly:false});
      else if(g.is_grantable&&!old.is_grantable)plan.push({routine:now,grant:g,optionOnly:true});}
    }
    const ownerResult=await target.query("select current_user actor,session_user session_actor,pg_catalog.current_setting('search_path') search_path");
    assert.equal(ownerResult.rows.length,1);const owner=ownerResult.rows[0];
    text(owner.actor);assert.equal(owner.actor,owner.session_actor,'Original target owner context changed');assert.equal(owner.search_path,'pg_catalog');
    // REVOKE issued by the actual routine owner targets its OWN grant tuple.
    // A different grantor/owner would need unsupported role context; refuse
    // the ENTIRE plan first, never SET ROLE or accidentally revoke originals.
    for(const step of plan){assert.equal(step.routine.owner_name,owner.actor,'Extra ACL requires unsupported routine-owner context');
     assert.equal(step.grant.grantor,owner.actor,'Extra ACL requires unsupported grantor context');}
    const quote=s=>'"'+s.replaceAll('"','""')+'"';
    for(const step of plan){
     const role=step.grant.grantee==='PUBLIC'?'PUBLIC':quote(step.grant.grantee);
     // identity comes ONLY from the fresh fixed-scope target catalog query,
     // never original/caller SQL; its names/types were formatted by Postgres.
     const command='REVOKE '+(step.optionOnly?'GRANT OPTION FOR ':'')+'EXECUTE ON '+step.routine.kind+' '+step.routine.identity+' FROM '+role+' RESTRICT';
     const revoked=await target.query(command);assert.equal(revoked.command,'REVOKE','Ambiguous routine REVOKE result');
    }
    const after=await captureOriginalRoutineAcls(target);
    assert.deepEqual(after,expected,'Routine ACL reconciliation is not exact (including grantor/options)');
    const finalOwner=(await target.query("select current_user actor,session_user session_actor,pg_catalog.current_setting('search_path') search_path")).rows;
    assert.deepEqual(finalOwner,[owner],'Routine ACL owner/search_path changed');
    return {revoked_count:plan.length,privilege_revokes:plan.filter(s=>!s.optionOnly).length,grant_option_revokes:plan.filter(s=>s.optionOnly).length};
   }
   const schemas=backup.productionBackupDataSchemas;
   assert.deepEqual(schemas,['public','auth','storage','custodial_release_identity']);
   assert.equal(backup.productionBackupDataEncoding,archiveApi.postgresJsonTextLineEncoding);
   const proposal=fs.readFileSync(B+'/proposals/immutable-private-owner-context.sql','utf8');
   assert.equal(sha(proposal),'b2a628db97d31854d9bce28f6f9bc266fda5d02f19f2a39888e4daf19a48afcf');
   // Exact pre-refactor SQL body from sealed Bfe4ef6dd, independently pinned.
   // Compare its read DATA with the setwise implementation in the SAME real
   // target transaction. Never install a second function or adopt target output
   // as Source authority. No extra grant, role, cache or target effect.
   const originalTargetShapeQuery="\n SELECT jsonb_build_object('database',current_database(),'database_oid',(SELECT oid FROM pg_catalog.pg_database WHERE datname=current_database()),\n 'owner_contract',jsonb_build_object(\n   'operator',(SELECT jsonb_build_object('oid',r.oid,'name',r.rolname,'session_user',session_user,\n     'superuser',r.rolsuper,'inherit',r.rolinherit,'create_role',r.rolcreaterole,'create_database',r.rolcreatedb,\n     'login',r.rolcanlogin,'replication',r.rolreplication,'bypass_rls',r.rolbypassrls,\n     'connection_limit',r.rolconnlimit,'valid_until',r.rolvaliduntil)\n     FROM pg_catalog.pg_roles r WHERE r.rolname=current_user),\n   'database_owner',(SELECT datdba FROM pg_catalog.pg_database WHERE datname=current_database()),\n   'namespaces',(SELECT jsonb_agg(jsonb_build_object('oid',n.oid,'name',n.nspname,'owner',n.nspowner,'acl',n.nspacl)\n     ORDER BY n.nspname) FROM pg_catalog.pg_namespace n WHERE n.nspname IN('custodial_dr','custodial_release_identity')),\n   'original_relations',(SELECT jsonb_agg(jsonb_build_object('oid',c.oid,'schema',n.nspname,'name',c.relname,\n     'owner',c.relowner,'acl',c.relacl,'rls',c.relrowsecurity,'force',c.relforcerowsecurity) ORDER BY n.nspname,c.relname)\n     FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace WHERE c.oid IN(\n       to_regclass('custodial_dr.restore_control'),to_regclass('custodial_dr.restore_manifests'),\n       to_regclass('custodial_dr.application_mutation_leases'),\n       to_regclass('custodial_release_identity.group_original_creations'),\n       to_regclass('custodial_release_identity.employee_message_original_outcomes'))),\n   'original_guards',(SELECT jsonb_agg(jsonb_build_object('oid',p.oid,'identity',p.oid::regprocedure::text,\n     'owner',p.proowner,'acl',p.proacl,'definer',p.prosecdef,'config',p.proconfig,\n     'definition',pg_get_functiondef(p.oid)) ORDER BY p.oid::regprocedure::text)\n     FROM pg_catalog.pg_proc p WHERE p.oid IN(to_regprocedure('custodial_dr.guard_application_mutation()'),\n       to_regprocedure('custodial_release_identity.guard_group_original_creation()'),\n       to_regprocedure('public.custodial_feedback_triage_immutable()')))),\n 'migration_head',(SELECT max(version)::text FROM supabase_migrations.schema_migrations),\n 'release',(SELECT jsonb_agg(jsonb_build_object('release_id',release_id,'backend_commit',backend_commit,'frontend_commit',frontend_commit,\n   'migration_head',migration_head,'migration_manifest_sha256',migration_manifest_sha256) ORDER BY release_id)\n   FROM public.release_deployment_manifest WHERE status='deployed'),\n -- Current target SOURCE metadata, initialized under the real unexposed\n -- bootstrap fence before begin(). This is NOT its archive-file digest or\n -- proof of initializer provenance. Bind EVERY typed row/field, including\n -- inventory identity/order/captured_at, for each later assert_context().\n 'recovery_inventory',custodial_dr.immutable_import_source_inventory_state(),\n 'relations',(SELECT jsonb_agg(jsonb_build_object('oid',c.oid,'schema',n.nspname,'name',c.relname,'owner',c.relowner,\n   'kind',c.relkind,'partition',c.relispartition,'persistence',c.relpersistence,'acl',c.relacl,'rls',c.relrowsecurity,'force',c.relforcerowsecurity,\n   'columns',(SELECT jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),\n     'notnull',a.attnotnull,'generated',a.attgenerated,'identity',a.attidentity,'acl',a.attacl,'default',pg_get_expr(d.adbin,d.adrelid)) ORDER BY a.attnum)\n     FROM pg_catalog.pg_attribute a LEFT JOIN pg_catalog.pg_attrdef d ON d.adrelid=a.attrelid AND d.adnum=a.attnum\n     WHERE a.attrelid=c.oid AND a.attnum>0 AND NOT a.attisdropped),\n   'constraints',(SELECT jsonb_agg(jsonb_build_object('name',k.conname,'valid',k.convalidated,'type',k.contype,'definition',pg_get_constraintdef(k.oid,true)) ORDER BY k.conname)\n     FROM pg_catalog.pg_constraint k WHERE k.conrelid=c.oid),\n   'indexes',(SELECT jsonb_agg(pg_get_indexdef(i.indexrelid) ORDER BY i.indexrelid) FROM pg_catalog.pg_index i WHERE i.indrelid=c.oid),\n   'policies',(SELECT jsonb_agg(to_jsonb(p) ORDER BY p.polname) FROM pg_catalog.pg_policy p WHERE p.polrelid=c.oid),\n   'triggers',(SELECT jsonb_agg(jsonb_build_object('definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled,'type',t.tgtype,\n     'function',pg_get_functiondef(t.tgfoid),'owner',f.proowner,'acl',f.proacl,'definer',f.prosecdef,'config',f.proconfig) ORDER BY t.tgname)\n     FROM pg_catalog.pg_trigger t JOIN pg_catalog.pg_proc f ON f.oid=t.tgfoid WHERE t.tgrelid=c.oid AND NOT t.tgisinternal))\n   ORDER BY n.nspname,c.relname) FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace\n   WHERE n.nspname IN('public','auth','storage','custodial_release_identity') AND c.relkind IN('r','p','f')))\n";
   assert.equal(sha(originalTargetShapeQuery),'6760fbce1fd6138a8791ae2c5afe2ec23f145d3b988cf6410058953a05fd1713');
   // Explicit UNIT keys, distinct purposes. Never real/retrieved signers.
   const archiveKey='UNIT-only-immutable-archive-verification-key-20261016';
   const intentKey='UNIT-only-independent-restore-intent-key-20261016';
   const archiveKeyId='unit-immutable-archive-v1',intentKeyId='unit-immutable-intent-v1';
   // Historical signed originals are inputs, not a new producer/capture proof.
   const source=path.resolve(D,'../restore-runtime-authorized-KM9tAR/authenticated-setwise-original-restore-v16/authenticated-original-source');
   const pinPaths=['scripts/disaster-recovery-archive.mjs','scripts/disaster-recovery-crypto.mjs',
    'scripts/production-backup-pg-dump-command.mjs','scripts/immutable-private-data-import.mjs',
    'scripts/isolated-event-owner-schema.mjs','scripts/empty-database-rebuild-check.mjs','proposals/immutable-private-owner-context.sql',
    'proposals/immutable-original-event-restore.sql','proposals/immutable-original-employee-restore.sql','proposals/immutable-original-messenger-restore.sql',
    'proposals/immutable-original-message-effects-restore.sql','proposals/immutable-original-message-guards-restore.sql',
    'proposals/immutable-original-device-boundary-restore.sql',
    'proposals/immutable-original-message-audit-restore.sql','proposals/immutable-original-message-receipts-restore.sql'];
   // The retained signed capture predates the new retry reader. Keep its
   // exact historical pin set, and independently pin this current-only
   // consumer dependency; never rewrite/adopt historical signed metadata.
   const currentOnlyPinPaths=['scripts/disaster-recovery-state.mjs'];
   const sourcePins=Object.fromEntries([...pinPaths,...currentOnlyPinPaths].map(p=>[p,sha(fs.readFileSync(B+'/'+p))]));
   const requirePins=()=>{for(const [p,digest]of Object.entries(sourcePins))assert.equal(sha(fs.readFileSync(B+'/'+p)),digest,p);
    const currentPlan=readMigrationReplayPlan(B);assert.equal(currentPlan.manifestSha256,plan.manifestSha256);assert.deepEqual(currentPlan.files,plan.files);};
   // Metadata only. Main owns snapshot authentication, the actual fresh-target
   // owner/admission fences and this original client's transaction lifetime.
   async function captureOriginalRelationAcls(client){
    const {types}=createRequire(import.meta.url)('node:util');
    const fixedSchemas=new Set(['public','auth','storage','custodial_release_identity']);
    const kinds=new Set(['TABLE','PARTITIONED TABLE','VIEW','MATERIALIZED VIEW','FOREIGN TABLE','SEQUENCE']);
    const tablePrivileges=new Set(['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER','MAINTAIN']);
    const sequencePrivileges=new Set(['SELECT','UPDATE','USAGE']);
    const q=name=>'"'+name.replaceAll('"','""')+'"';
    const key=item=>JSON.stringify([item.schema_name,item.object_name]);
    const grantKey=item=>JSON.stringify([item.grantee,item.grantor,item.privilege_type]);
    const compare=(a,b)=>Buffer.compare(Buffer.from(a,'utf8'),Buffer.from(b,'utf8'));
    const name=value=>{assert.equal(typeof value,'string');assert.ok(value.length>0&&!value.includes('\0'));
     assert.ok(Buffer.byteLength(value,'utf8')<=63);assert.equal(Buffer.from(value,'utf8').toString('utf8'),value);return value;};
    const fields=(value,keys)=>{assert.ok(value&&typeof value==='object'&&!Array.isArray(value)&&!types.isProxy(value));
     assert.ok([Object.prototype,null].includes(Object.getPrototypeOf(value)));
     const properties=Object.getOwnPropertyDescriptors(value);assert.deepEqual(Reflect.ownKeys(properties).sort(),[...keys].sort());
     for(const k of keys)assert.ok(Object.hasOwn(properties[k],'value')&&properties[k].enumerable,'Plain ACL metadata required');return properties;};
    const array=value=>{assert.ok(Array.isArray(value)&&!types.isProxy(value));
     assert.equal(Object.getPrototypeOf(value),Array.prototype);
     assert.deepEqual(Reflect.ownKeys(value),[...Array.from({length:value.length},(_,i)=>String(i)),'length']);
     for(let i=0;i<value.length;i++)assert.ok(Object.hasOwn(Object.getOwnPropertyDescriptor(value,String(i)),'value'));return value;};
    const result=await client.query(`select jsonb_build_object(
     'kind',case c.relkind when 'r' then 'TABLE' when 'p' then 'PARTITIONED TABLE' when 'v' then 'VIEW'
       when 'm' then 'MATERIALIZED VIEW' when 'f' then 'FOREIGN TABLE' when 'S' then 'SEQUENCE' end,
     'schema_name',n.nspname::text,'object_name',c.relname::text,
     'identity','"'||replace(n.nspname::text,'"','""')||'"."'||replace(c.relname::text,'"','""')||'"',
     'owner_name',owner_role.rolname::text,'column_name',null,
     'grants',coalesce((select jsonb_agg(jsonb_build_object(
       'grantee',case when a.grantee=0 then 'PUBLIC' when grantee.rolname='PUBLIC' then null else grantee.rolname::text end,
       'grantor',grantor.rolname::text,'privilege_type',a.privilege_type,'is_grantable',a.is_grantable))
      from pg_catalog.aclexplode(coalesce(c.relacl,case when c.relkind='S'
        then pg_catalog.acldefault('s',c.relowner) else pg_catalog.acldefault('r',c.relowner) end)) a
      left join pg_catalog.pg_roles grantee on grantee.oid=a.grantee
      left join pg_catalog.pg_roles grantor on grantor.oid=a.grantor
      where a.grantee<>c.relowner),'[]'::jsonb)) descriptor
     from pg_catalog.pg_class c join pg_catalog.pg_namespace n on n.oid=c.relnamespace
     left join pg_catalog.pg_roles owner_role on owner_role.oid=c.relowner
     where n.nspname in ('public','auth','storage','custodial_release_identity')
       and c.relkind in ('r','p','v','m','f','S')`);
    const objects=[],seen=new Set();
    for(const row of array(result.rows)){
     fields(row,['descriptor']);const item=row.descriptor;
     fields(item,['kind','schema_name','object_name','identity','owner_name','column_name','grants']);
     assert.ok(kinds.has(item.kind)&&fixedSchemas.has(item.schema_name));
     name(item.schema_name);name(item.object_name);name(item.owner_name);assert.notEqual(item.owner_name,'PUBLIC');
     assert.equal(item.column_name,null);assert.equal(item.identity,q(item.schema_name)+'.'+q(item.object_name));
     assert.ok(!seen.has(key(item)),'Duplicate relation ACL object');seen.add(key(item));
     const grants=[],seenGrants=new Set(),allowed=item.kind==='SEQUENCE'?sequencePrivileges:tablePrivileges;
     for(const grant of array(item.grants)){
      fields(grant,['grantee','grantor','privilege_type','is_grantable']);name(grant.grantee);name(grant.grantor);
      assert.notEqual(grant.grantor,'PUBLIC');assert.notEqual(grant.grantee,item.owner_name);
      assert.ok(allowed.has(grant.privilege_type),'Unsupported relation privilege');assert.equal(typeof grant.is_grantable,'boolean');
      assert.ok(!seenGrants.has(grantKey(grant)),'Duplicate relation ACL grant');seenGrants.add(grantKey(grant));
      grants.push(Object.freeze({grantee:grant.grantee,grantor:grant.grantor,privilege_type:grant.privilege_type,is_grantable:grant.is_grantable}));
     }
     grants.sort((a,b)=>compare(grantKey(a),grantKey(b)));
     objects.push(Object.freeze({kind:item.kind,schema_name:item.schema_name,object_name:item.object_name,identity:item.identity,
      owner_name:item.owner_name,column_name:null,grants:Object.freeze(grants)}));
    }
    objects.sort((a,b)=>compare(key(a),key(b)));return Object.freeze(objects);
   }
   async function reconcileOriginalRelationAcls(target,original){
    const {types}=createRequire(import.meta.url)('node:util');
    // Detach and reject accessors/holes/proxies BEFORE the first await. This
    // authenticates nothing; Main supplies independently verified Source DATA.
    const copy=(value,depth=0)=>{
     assert.ok(depth<=4,'Unsupported ACL metadata nesting');
     if(value===null||typeof value==='string'||typeof value==='boolean')return value;
     assert.ok(value&&typeof value==='object'&&!types.isProxy(value),'Plain ACL metadata required');
     const props=Object.getOwnPropertyDescriptors(value),keys=Reflect.ownKeys(props);
     if(Array.isArray(value)){
      assert.equal(Object.getPrototypeOf(value),Array.prototype);
      assert.deepEqual(keys,[...Array.from({length:value.length},(_,i)=>String(i)),'length']);
      return Object.freeze(Array.from({length:value.length},(_,i)=>{
       const property=props[String(i)];assert.ok(Object.hasOwn(property,'value')&&property.enumerable);return copy(property.value,depth+1);}));
     }
     assert.ok([Object.prototype,null].includes(Object.getPrototypeOf(value)));const result=Object.create(null);
     for(const k of keys){assert.equal(typeof k,'string');const property=props[k];assert.ok(Object.hasOwn(property,'value')&&property.enumerable);
      Object.defineProperty(result,k,{value:copy(property.value,depth+1),enumerable:true});}
     return Object.freeze(result);
    };
    const expected=copy(original);assert.ok(Array.isArray(expected));
    const q=name=>'"'+name.replaceAll('"','""')+'"';
    const key=item=>JSON.stringify([item.schema_name,item.object_name]);
    const grantKey=item=>JSON.stringify([item.grantee,item.grantor,item.privilege_type]);
    const compare=(a,b)=>Buffer.compare(Buffer.from(a,'utf8'),Buffer.from(b,'utf8'));
    const fields=(value,keys)=>{assert.ok(value&&typeof value==='object'&&!Array.isArray(value));assert.deepEqual(Object.keys(value).sort(),[...keys].sort());};
    const name=value=>{assert.equal(typeof value,'string');assert.ok(value.length>0&&!value.includes('\0'));
     assert.ok(Buffer.byteLength(value,'utf8')<=63);assert.equal(Buffer.from(value,'utf8').toString('utf8'),value);};
    const tablePrivileges=new Set(['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER','MAINTAIN']);
    const sequencePrivileges=new Set(['SELECT','UPDATE','USAGE']);let previous=null;
    for(const item of expected){
     fields(item,['kind','schema_name','object_name','identity','owner_name','column_name','grants']);
     assert.ok(['TABLE','PARTITIONED TABLE','VIEW','MATERIALIZED VIEW','FOREIGN TABLE','SEQUENCE'].includes(item.kind));
     assert.ok(['public','auth','storage','custodial_release_identity'].includes(item.schema_name));
     name(item.object_name);name(item.owner_name);assert.notEqual(item.owner_name,'PUBLIC');assert.equal(item.column_name,null);
     assert.equal(item.identity,q(item.schema_name)+'.'+q(item.object_name));assert.ok(Array.isArray(item.grants));
     assert.ok(previous===null||compare(previous,key(item))<0,'Original relation descriptors must be unique/canonical');previous=key(item);
     let priorGrant=null;const allowed=item.kind==='SEQUENCE'?sequencePrivileges:tablePrivileges;
     for(const grant of item.grants){
      fields(grant,['grantee','grantor','privilege_type','is_grantable']);name(grant.grantee);name(grant.grantor);
      assert.notEqual(grant.grantor,'PUBLIC');assert.notEqual(grant.grantee,item.owner_name);
      assert.ok(allowed.has(grant.privilege_type));assert.equal(typeof grant.is_grantable,'boolean');
      assert.ok(priorGrant===null||compare(priorGrant,grantKey(grant))<0,'Original ACL grants must be unique/canonical');priorGrant=grantKey(grant);
     }
    }
    const actor=(await target.query('select current_user::text actor,session_user::text session_actor')).rows;
    assert.equal(actor.length,1);name(actor[0].actor);assert.equal(actor[0].actor,actor[0].session_actor);
    const current=await captureOriginalRelationAcls(target);assert.equal(current.length,expected.length,'Complete original relation set required');
    const metadata=item=>[item.kind,item.schema_name,item.object_name,item.identity,item.owner_name,item.column_name];
    const actions=[];
    // Validate ALL object identities and ALL expected rights before the first
    // revoke. Missing original grantor/option never authorizes a repair grant.
    for(let i=0;i<expected.length;i++){
     const wanted=expected[i],actual=current[i];assert.deepEqual(metadata(actual),metadata(wanted),'Original relation identity/owner changed');
     const wantedGrants=new Map(wanted.grants.map(g=>[grantKey(g),g]));
     const actualGrants=new Map(actual.grants.map(g=>[grantKey(g),g]));
     for(const grant of wanted.grants){const found=actualGrants.get(grantKey(grant));
      assert.ok(found&&(!grant.is_grantable||found.is_grantable),'Original relation privilege/grantor/option missing');}
     for(const grant of actual.grants){const wantedGrant=wantedGrants.get(grantKey(grant));
      if(!wantedGrant||(grant.is_grantable&&!wantedGrant.is_grantable)){
       // No role switching or ambiguous implicit-grantor adoption. Foreign
       // grantors/owners are an unsupported revoke, not permission to retry.
       assert.equal(actual.owner_name,actor[0].actor,'Relation revoke requires the same actual owning session');
       assert.equal(grant.grantor,actor[0].actor,'Foreign relation grantor revoke unsupported');
       actions.push({actual,grant,optionOnly:!!wantedGrant});
      }
     }
    }
    for(const action of actions){
     const {actual,grant,optionOnly}=action;
     const live=(await target.query('select current_user::text actor,session_user::text session_actor')).rows;assert.deepEqual(live,actor);
     const kind=actual.kind==='SEQUENCE'?'SEQUENCE':'TABLE';
     const grantee=grant.grantee==='PUBLIC'?'PUBLIC':q(grant.grantee);
     await target.query('REVOKE '+(optionOnly?'GRANT OPTION FOR ':'')+grant.privilege_type+' ON '+kind+' '
      +q(actual.schema_name)+'.'+q(actual.object_name)+' FROM '+grantee+' RESTRICT');
    }
    const final=await captureOriginalRelationAcls(target);
    assert.deepEqual((await target.query('select current_user::text actor,session_user::text session_actor')).rows,actor);
    // Fixed property order for metadata equality only; no original DATA row
    // is parsed/coerced/reserialized or used as a target survivor baseline.
    const logical=list=>list.map(item=>[...metadata(item),item.grants.map(g=>[g.grantee,g.grantor,g.privilege_type,g.is_grantable])]);
    assert.deepEqual(logical(final),logical(expected),'Final relation ACLs must equal the authenticated originals');
    return Object.freeze({revoked_privileges:actions.filter(a=>!a.optionOnly).length,revoked_grant_options:actions.filter(a=>a.optionOnly).length});
   }
   async function assertImmutableImportContextSourceLocked(target,invocation){
    assert.ok(invocation&&typeof invocation==='object'&&Object.getPrototypeOf(invocation)===Object.prototype);
    const properties=Object.getOwnPropertyDescriptors(invocation);
    assert.deepEqual(Reflect.ownKeys(properties).sort(),['pid','xid']);
    for(const key of ['pid','xid'])assert.ok(Object.hasOwn(properties[key],'value')&&properties[key].enumerable);
    const expectedPid=properties.pid.value,expectedXid=properties.xid.value;
    assert.ok(Number.isSafeInteger(expectedPid)&&expectedPid>0);assert.equal(typeof expectedXid,'string');assert.match(expectedXid,/^[1-9][0-9]*$/);
    const readSnapshot=async()=>{
     const result=await target.query(`select current_database() database_name,
      (select oid::text from pg_catalog.pg_database where datname=current_database()) database_oid,
      pg_backend_pid() pid,txid_current()::text xid,current_user::text actor,session_user::text session_actor,
      (select pg_get_userbyid(relowner) from pg_catalog.pg_class where oid='custodial_dr.immutable_private_import_context'::regclass) context_owner,
      has_table_privilege(current_user,'custodial_dr.immutable_private_import_context','SELECT') can_select,
      has_table_privilege(current_user,'custodial_dr.immutable_private_import_context','UPDATE') can_update,
      has_table_privilege(current_user,'custodial_dr.immutable_private_import_context','DELETE') can_delete,
      c.database_oid::text context_database_oid,c.backend_pid context_pid,c.transaction_id::text context_xid,
      c.restore_id::text restore_id,c.authority_generation::text authority_generation,c.archive_digest,
      public.static_weekly_digest_text((to_jsonb(c)-ARRAY['phase','active_table_oid','active_row_sha256'])::text) fixed_source_sha256,
      c.phase,c.active_table_oid::text active_table_oid,c.active_row_sha256,
      c.target_shape ? '__immutable_source_lock_probe__' target_probe_present,
      c.original_manifest ? '__immutable_source_lock_probe__' manifest_probe_present,
      (select public.static_weekly_digest_text(p.prosrc) from pg_catalog.pg_proc p
       where p.oid=to_regprocedure('custodial_dr.immutable_import_context_source_immutable()')) source_guard_sha256,
      (select count(*)::int from pg_catalog.pg_trigger t join pg_catalog.pg_proc p on p.oid=t.tgfoid
       where t.tgrelid='custodial_dr.immutable_private_import_context'::regclass
        and t.tgname='immutable_import_context_source_immutable' and t.tgenabled='A' and t.tgtype=27
        and not t.tgisinternal and t.tgqual is null and t.tgnargs=0 and octet_length(t.tgargs)=0
        and p.oid=to_regprocedure('custodial_dr.immutable_import_context_source_immutable()')
        and p.proowner=(select oid from pg_catalog.pg_roles where rolname=current_user)
        and p.prokind='f' and p.prorettype='trigger'::regtype and p.pronargs=0 and not p.prosecdef) source_guard_matches
      from custodial_dr.immutable_private_import_context c
      where c.database_oid=(select oid from pg_catalog.pg_database where datname=current_database())
       and c.backend_pid=pg_backend_pid() and c.transaction_id=txid_current()`);
     assert.equal(result.rowCount,1);assert.equal(result.rows.length,1);const current=result.rows[0];
     assert.equal(current.pid,expectedPid);assert.equal(current.xid,expectedXid);
     assert.equal(current.context_database_oid,current.database_oid);assert.equal(current.context_pid,expectedPid);assert.equal(current.context_xid,expectedXid);
     assert.equal(current.actor,current.session_actor);assert.equal(current.actor,current.context_owner);
     assert.equal(current.can_select,true);assert.equal(current.can_update,true);assert.equal(current.can_delete,true);
     assert.equal(current.source_guard_matches,1);assert.equal(current.phase,'FINISHED');
     assert.equal(current.active_table_oid,null);assert.equal(current.active_row_sha256,null);
     assert.match(current.fixed_source_sha256,/^[a-f0-9]{64}$/);assert.match(current.archive_digest,/^[a-f0-9]{64}$/);
     assert.match(current.source_guard_sha256,/^[a-f0-9]{64}$/); // DATA only; Main independently pins accepted Source.
     assert.equal(typeof current.restore_id,'string');assert.match(current.authority_generation,/^[1-9][0-9]*$/);
     assert.equal(current.target_probe_present,false);assert.equal(current.manifest_probe_present,false);
     return Object.freeze({...current});
    };
    const original=await readSnapshot(),names=[];
    // Fixed Source only. All four predicates select this same actual owning
    // database/PID/xid; invocation is an expectation, never a DML selector.
    const cases=[
     {name:'target_shape_replacement',message:'Original immutable import context cannot be replaced',
      sql:`update custodial_dr.immutable_private_import_context set target_shape=target_shape||'{"__immutable_source_lock_probe__":true}'::jsonb
       where database_oid=(select oid from pg_catalog.pg_database where datname=current_database()) and backend_pid=pg_backend_pid() and transaction_id=txid_current()`},
     {name:'original_manifest_replacement',message:'Original immutable import context cannot be replaced',
      sql:`update custodial_dr.immutable_private_import_context set original_manifest=original_manifest||'{"__immutable_source_lock_probe__":true}'::jsonb
       where database_oid=(select oid from pg_catalog.pg_database where datname=current_database()) and backend_pid=pg_backend_pid() and transaction_id=txid_current()`},
     {name:'archive_digest_replacement',message:'Original immutable import context cannot be replaced',
      sql:`update custodial_dr.immutable_private_import_context set archive_digest=(case left(archive_digest,1) when '0' then '1' else '0' end)||substr(archive_digest,2)
       where database_oid=(select oid from pg_catalog.pg_database where datname=current_database()) and backend_pid=pg_backend_pid() and transaction_id=txid_current()`},
     {name:'context_delete',message:'Original immutable import context cannot be removed',
      sql:`delete from custodial_dr.immutable_private_import_context
       where database_oid=(select oid from pg_catalog.pg_database where datname=current_database()) and backend_pid=pg_backend_pid() and transaction_id=txid_current()`},
    ];
    for(const test of cases){
     let firstFailure=null,savepointAttempted=false;
     const cleanupFailures=[];
     try{
      savepointAttempted=true;await target.query('SAVEPOINT immutable_context_source_lock_probe');
      let refusal=null;try{await target.query(test.sql);}catch(error){refusal=error;}
      if(!refusal)assert.fail('Immutable context mutation did not refuse: '+test.name);
      if(refusal.code!=='42501'||refusal.message!==test.message)throw refusal;
     }catch(error){firstFailure=error;}
     // Settle even an unexpected successful DML or uncertain SAVEPOINT.
     // A wrong SQLSTATE (including FK 23503) never becomes a passing case.
     if(savepointAttempted){
      try{await target.query('ROLLBACK TO SAVEPOINT immutable_context_source_lock_probe');}catch(error){cleanupFailures.push(error);}
      try{await target.query('RELEASE SAVEPOINT immutable_context_source_lock_probe');}catch(error){cleanupFailures.push(error);}
     }
     try{assert.deepEqual(await readSnapshot(),original,'Original fixed source/witness/phase changed after rollback');}catch(error){cleanupFailures.push(error);}
     if(cleanupFailures.length)throw new AggregateError(firstFailure?[firstFailure,...cleanupFailures]:cleanupFailures,
      'Immutable import context negative cleanup failed', {cause:firstFailure??cleanupFailures[0]});
     if(firstFailure)throw firstFailure;
     names.push(test.name);
    }
    return Object.freeze({names:Object.freeze(names),refusals:names.length});
   }
   function expandImmutableTargetShapeTriggerDictionary(value){
    // Comparison DATA only. No Source/currentness/acceptance authority and no
    // parsing, normalization or conversion of original ledger row bytes.
    const {types}=require('node:util'),active=new WeakSet();
    const copy=input=>{
     if(input===null||typeof input==='string'||typeof input==='boolean')return input;
     if(typeof input==='number'){assert.ok(Number.isFinite(input),'Finite JSON number required');return input;}
     assert.ok(input&&typeof input==='object'&&!types.isProxy(input),'Plain JSON DATA required');
     assert.ok(!active.has(input),'Cyclic JSON DATA refused');
     const array=Array.isArray(input),prototype=Object.getPrototypeOf(input);
     assert.ok(array?prototype===Array.prototype:prototype===Object.prototype||prototype===null,'Custom JSON prototype refused');
     const properties=Object.getOwnPropertyDescriptors(input),keys=Reflect.ownKeys(properties),result=array?[]:{};
     active.add(input);
     try{
      if(array){
       assert.equal(keys.length,properties.length.value+1,'Dense JSON array required');
       for(let i=0;i<properties.length.value;i++){
        const property=properties[String(i)];
        assert.ok(property&&Object.hasOwn(property,'value')&&property.enumerable,'Dense data-only JSON array required');
        Object.defineProperty(result,String(i),{value:copy(property.value),enumerable:true,writable:true,configurable:true});
       }
      }else for(const key of keys){
       assert.equal(typeof key,'string','JSON symbol key refused');const property=properties[key];
       assert.ok(Object.hasOwn(property,'value')&&property.enumerable,'JSON accessor/hidden property refused');
       Object.defineProperty(result,key,{value:copy(property.value),enumerable:true,writable:true,configurable:true});
      }
      return result;
     }finally{active.delete(input);}
    };
    const fields=(item,keys)=>{
     assert.ok(item&&typeof item==='object'&&!Array.isArray(item));
     assert.deepEqual(Object.keys(item).sort(),[...keys].sort(),'Closed trigger DATA fields required');
    };
    const oid=text=>{
     assert.equal(typeof text,'string','Canonical JSON OID text required');
     assert.match(text,/^[1-9][0-9]{0,9}(?![\s\S])/);
     assert.ok(text.length<10||text<='4294967295','Canonical OID text exceeds range');
    };
    const strings=list=>{assert.ok(list===null||Array.isArray(list));if(list!==null)for(const item of list)assert.equal(typeof item,'string');};
    const result=copy(value);
    assert.ok(result&&typeof result==='object'&&!Array.isArray(result));
    assert.ok(Object.hasOwn(result,'relations')&&Array.isArray(result.relations),'Complete relation array required');
    assert.ok(Object.hasOwn(result,'trigger_functions'),'Trigger dictionary required');
    const dictionary=result.trigger_functions,byOid=new Map(),used=new Set();let previous=0n,allNull=true;
    if(dictionary!==null){
     assert.ok(Array.isArray(dictionary)&&dictionary.length>0,'No-function dictionary must be NULL');
     for(const entry of dictionary){
      fields(entry,['oid','definition','owner','acl','definer','config']);oid(entry.oid);oid(entry.owner);
      const numericOid=BigInt(entry.oid);
      assert.ok(numericOid>previous,'Unique ascending dictionary OIDs required');previous=numericOid;
      assert.equal(typeof entry.definition,'string');assert.equal(typeof entry.definer,'boolean');
      strings(entry.acl);strings(entry.config);byOid.set(entry.oid,entry);
     }
    }
    for(const relation of result.relations){
     assert.ok(relation&&typeof relation==='object'&&!Array.isArray(relation)&&Object.hasOwn(relation,'triggers'),'Relation triggers required');
     if(relation.triggers===null)continue;
     allNull=false;assert.ok(Array.isArray(relation.triggers)&&relation.triggers.length>0,'No-trigger aggregate must be NULL');
     relation.triggers=relation.triggers.map(trigger=>{
      fields(trigger,['definition','enabled','type','function_oid']);
      assert.equal(typeof trigger.definition,'string');assert.ok(['O','D','R','A'].includes(trigger.enabled),'Catalog trigger enabled value required');
      assert.ok(Number.isInteger(trigger.type),'JSON trigger type integer required');oid(trigger.function_oid);
      const entry=byOid.get(trigger.function_oid);assert.ok(entry,'Missing trigger function DATA');used.add(entry.oid);
      return {definition:trigger.definition,enabled:trigger.enabled,type:trigger.type,function:entry.definition,
       owner:entry.owner,acl:entry.acl===null?null:entry.acl.slice(),definer:entry.definer,config:entry.config===null?null:entry.config.slice()};
     });
    }
    assert.equal(dictionary===null,allNull,'Dictionary NULL must match all-NULL trigger aggregates');
    assert.equal(used.size,byOid.size,'Unused/foreign trigger function DATA refused');
    delete result.trigger_functions;return result;
   }
   async function assertImmutableMutationWitnessRefusals(target,manifest,intent){
    const {types}=require('node:util');
    assert.ok(target&&!types.isProxy(target)&&Object.getPrototypeOf(target)===Client.prototype&&!Object.hasOwn(target,'query'),'Original pg.Client required');
    // Detach verified-input DATA before any await; never construct an archive
    // manifest or a permission/intent from the observed target.
    const active=new WeakSet(),copy=value=>{
     if(value===null||typeof value==='string'||typeof value==='boolean')return value;
     if(typeof value==='number'){assert.ok(Number.isFinite(value));return value;}
     assert.ok(value&&typeof value==='object'&&!types.isProxy(value)&&!active.has(value),'Plain acyclic input DATA required');
     const array=Array.isArray(value),prototype=Object.getPrototypeOf(value);
     assert.ok(array?prototype===Array.prototype:prototype===Object.prototype||prototype===null);
     const properties=Object.getOwnPropertyDescriptors(value),keys=Reflect.ownKeys(properties),result=array?[]:{};active.add(value);
     try{
      if(array){assert.equal(keys.length,properties.length.value+1);
       for(let i=0;i<properties.length.value;i++){const property=properties[String(i)];assert.ok(property&&Object.hasOwn(property,'value')&&property.enumerable);
        Object.defineProperty(result,String(i),{value:copy(property.value),enumerable:true});}
      }else for(const key of keys){assert.equal(typeof key,'string');const property=properties[key];assert.ok(Object.hasOwn(property,'value')&&property.enumerable);
       Object.defineProperty(result,key,{value:copy(property.value),enumerable:true});}
      return Object.freeze(result);
     }finally{active.delete(value);}
    };
    const fields=(value,keys)=>{assert.ok(value&&typeof value==='object'&&!Array.isArray(value));assert.deepEqual(Object.keys(value).sort(),[...keys].sort());};
    const witnessKeys=['database_oid','backend_pid','transaction_id','restore_id','authority_generation','archive_digest'];
    const uuid=value=>{assert.equal(typeof value,'string');assert.match(value,/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/);};
    const digest=value=>{assert.equal(typeof value,'string');assert.match(value,/^[a-f0-9]{64}$/);};
    const witness=value=>{const result=copy(value);fields(result,witnessKeys);
     assert.equal(typeof result.database_oid,'string');
     assert.match(result.database_oid,/^[1-9][0-9]{0,9}(?![\s\S])/);
     assert.ok(result.database_oid.length<10||result.database_oid<='4294967295','Canonical OID text exceeds range');
     assert.ok(Number.isInteger(result.backend_pid)&&result.backend_pid>0&&result.backend_pid<=2147483647);
     for(const key of ['transaction_id','authority_generation']){assert.equal(typeof result[key],'string');assert.match(result[key],/^[1-9][0-9]*$/);}
     uuid(result.restore_id);digest(result.archive_digest);return result;};
    const originalManifest=copy(manifest),originalIntent=copy(intent);
    fields(originalManifest,['schema','archive_digest','source_identity_sha256','source_project_ref','target_project_ref','actor','expires_at','target_migration_head','target_release_identity','catalog','private_data_members']);
    assert.equal(originalManifest.schema,'custodial.immutable-private-import-manifest.v1');
    assert.ok(Array.isArray(originalManifest.catalog)&&Array.isArray(originalManifest.private_data_members));
    uuid(originalIntent.restore_id);digest(originalIntent.archive_digest);
    assert.ok(Number.isSafeInteger(originalIntent.authority_generation)&&originalIntent.authority_generation>0);
    for(const key of ['archive_digest','source_identity_sha256','source_project_ref','target_project_ref','actor','expires_at','target_migration_head','target_release_identity'])
     assert.deepEqual(originalManifest[key],originalIntent[key],'Verified manifest/intent binding differs');
    const manifestJson=JSON.stringify(originalManifest),names=[];
    const readSnapshot=async()=>{
     const result=await target.query(`select jsonb_build_object(
      'database_oid',(select oid from pg_catalog.pg_database where datname=current_database()),
      'backend_pid',pg_backend_pid(),'transaction_id',txid_current()::text,'actor',current_user,'session_actor',session_user,
      'control',(select to_jsonb(c) from custodial_dr.restore_control c where singleton),
      'leases',(select coalesce(jsonb_agg(to_jsonb(l) order by to_jsonb(l)::text collate "C"),'[]'::jsonb) from custodial_dr.application_mutation_leases l),
      'contexts',(select coalesce(jsonb_agg(jsonb_build_object(
       'context',jsonb_build_object('database_oid',c.database_oid,'backend_pid',c.backend_pid,'transaction_id',c.transaction_id::text,
        'restore_id',c.restore_id,'authority_generation',c.authority_generation::text,'archive_digest',c.archive_digest),
       'phase',c.phase,'active_table_oid',c.active_table_oid,'active_row_sha256',c.active_row_sha256,'original_control',c.original_control,
       'fixed_source_sha256',public.static_weekly_digest_text((to_jsonb(c)-ARRAY['phase','active_table_oid','active_row_sha256'])::text))),'[]'::jsonb)
       from custodial_dr.immutable_private_import_context c where c.database_oid=(select oid from pg_catalog.pg_database where datname=current_database())
        and c.backend_pid=pg_backend_pid() and c.transaction_id=txid_current()),
      'private_staging_count',(select count(*)::text from custodial_dr.immutable_private_import_rows s
       where s.database_oid=(select oid from pg_catalog.pg_database where datname=current_database()) and s.backend_pid=pg_backend_pid() and s.transaction_id=txid_current()),
      'ordinary_staging_count',(select count(*)::text from custodial_dr.immutable_ordinary_import_rows s
       where s.database_oid=(select oid from pg_catalog.pg_database where datname=current_database()) and s.backend_pid=pg_backend_pid() and s.transaction_id=txid_current()),
      'ordinary_target_count',(select count(*)::text from only public.system_settings),
      'group_original_count',(select count(*)::text from only custodial_release_identity.group_original_creations),
      'employee_original_count',(select count(*)::text from only custodial_release_identity.employee_message_original_outcomes)) as snapshot`);
     assert.equal(result.rowCount,1);assert.equal(result.rows.length,1);fields(result.rows[0],['snapshot']);
     const snapshot=copy(result.rows[0].snapshot);
     assert.equal(snapshot.actor,snapshot.session_actor);assert.ok(snapshot.control&&typeof snapshot.control==='object');
     assert.ok(Array.isArray(snapshot.contexts)&&Array.isArray(snapshot.leases));
     for(const key of ['private_staging_count','ordinary_staging_count','ordinary_target_count','group_original_count','employee_original_count']){
      assert.equal(typeof snapshot[key],'string');assert.match(snapshot[key],/^(0|[1-9][0-9]*)$/);}
     return snapshot;
    };
    const original=await readSnapshot();assert.deepEqual(original.contexts,[]);assert.deepEqual(original.leases,[]);
    assert.equal(original.private_staging_count,'0');assert.equal(original.ordinary_staging_count,'0');
    let firstFailure=null,outerAttempted=false;const cleanupFailures=[];
    try{
     outerAttempted=true;await target.query('SAVEPOINT immutable_mutation_witness_probe');
     const begun=await target.query('select custodial_dr.begin_immutable_private_import($1::uuid,$2::bigint,$3::text,$4::jsonb) as context',
      [originalIntent.restore_id,String(originalIntent.authority_generation),originalIntent.archive_digest,manifestJson]);
     assert.equal(begun.rowCount,1);assert.equal(begun.rows.length,1);fields(begun.rows[0],['context']);const actual=witness(begun.rows[0].context);
     for(const key of ['database_oid','backend_pid','transaction_id'])assert.equal(actual[key],original[key],'Actual transaction witness differs');
     assert.equal(actual.restore_id,originalIntent.restore_id);assert.equal(actual.authority_generation,String(originalIntent.authority_generation));
     assert.equal(actual.archive_digest,originalIntent.archive_digest);
     const staging=await readSnapshot();assert.equal(staging.contexts.length,1);const context=staging.contexts[0];
     assert.deepEqual(witness(context.context),actual);assert.equal(context.phase,'STAGING');
     assert.equal(context.active_table_oid,null);assert.equal(context.active_row_sha256,null);
     assert.deepEqual(context.original_control,staging.control);digest(context.fixed_source_sha256);
     assert.deepEqual({...staging,contexts:[]},original,'Begin changed original control/leases/staging/target counts');
     const wrong=JSON.stringify({...actual,backend_pid:actual.backend_pid+1});
     const cases=[
      {name:'stage_private_wrong_witness',sql:'select custodial_dr.stage_immutable_private_row($1::text,$2::text,$3::text,$4::jsonb) as context',args:['custodial_release_identity','group_original_creations','{}',wrong]},
      {name:'stage_ordinary_wrong_witness',sql:'select custodial_dr.stage_immutable_ordinary_row($1::text,$2::text,$3::text,$4::jsonb) as context',args:['public','system_settings','{}',wrong]},
      {name:'insert_ordinary_wrong_witness',sql:'select custodial_dr.insert_immutable_ordinary_row($1::text,$2::text,$3::text,$4::jsonb) as context',args:['public','system_settings','{}',wrong]},
      {name:'insert_staged_set_wrong_witness',sql:'select custodial_dr.insert_staged_immutable_ordinary_table($1::text,$2::text,$3::jsonb) as context',args:['public','system_settings',wrong]},
     ];
     for(const test of cases){
      let failure=null,innerAttempted=false;const innerCleanup=[];
      try{
       innerAttempted=true;await target.query('SAVEPOINT immutable_mutation_witness_case');
       let refusal=null;try{await target.query(test.sql,test.args);}catch(error){refusal=error;}
       if(!refusal)assert.fail('Wrong original mutation witness did not refuse: '+test.name);
       if(refusal.code!=='55000'||refusal.message!=='Immutable import original mutation witness differs')throw refusal;
      }catch(error){failure=error;}
      if(innerAttempted){
       try{await target.query('ROLLBACK TO SAVEPOINT immutable_mutation_witness_case');}catch(error){innerCleanup.push(error);}
       try{await target.query('RELEASE SAVEPOINT immutable_mutation_witness_case');}catch(error){innerCleanup.push(error);}
      }
      try{assert.deepEqual(await readSnapshot(),staging,'Wrong witness changed original context/control/staging/target counts');}catch(error){innerCleanup.push(error);}
      if(innerCleanup.length)throw new AggregateError(failure?[failure,...innerCleanup]:innerCleanup,'Mutation witness case cleanup failed',{cause:failure??innerCleanup[0]});
      if(failure)throw failure;names.push(test.name);
     }
    }catch(error){firstFailure=error;}
    if(outerAttempted){
     try{await target.query('ROLLBACK TO SAVEPOINT immutable_mutation_witness_probe');}catch(error){cleanupFailures.push(error);}
     try{await target.query('RELEASE SAVEPOINT immutable_mutation_witness_probe');}catch(error){cleanupFailures.push(error);}
    }
    try{assert.deepEqual(await readSnapshot(),original,'Probe rollback must remove only its context and preserve original control/leases/staging/target counts');}catch(error){cleanupFailures.push(error);}
    if(cleanupFailures.length)throw new AggregateError(firstFailure?[firstFailure,...cleanupFailures]:cleanupFailures,'Mutation witness probe cleanup failed',{cause:firstFailure??cleanupFailures[0]});
    if(firstFailure)throw firstFailure;
    return Object.freeze({names:Object.freeze(names),refusals:names.length});
   }
   const guardIds=['custodial_release_identity.guard_group_original_creation()','custodial_dr.guard_application_mutation()'];
   const guardHashes=['29708f9ca161950f4e3b4b71b2e7dd85b2f31a6031407a353635713678a3386f',
    'aba484a103212b76c82f119ece6279c917fce4b0806e07381ef4fce527a9bc95'];
   const sourceClient=new Client({...options,user:'supabase_admin'});clients.add(sourceClient);sourceClient.on('error',()=>{});
   assert.match(ownedContainerName,/^mz_schema_rebuild_held_product_[a-f0-9]{16}$/);
   const targetName='postgres';
   let snapshot=false,target=null,targetTransaction=false,archive=null,firstFailure=null;
   try{
    await sourceClient.connect();
    assert.deepEqual((await sourceClient.query('select current_user actor,session_user session_actor')).rows[0],{actor:'supabase_admin',session_actor:'supabase_admin'});
    // Keep this same original-owner connection idle for Main's one read-only
    // diagnostic; do not repeat producers, source SQL writes or pg_dump.
    phase='authenticate retained exact v16 original archive and table selection';
    archive=archiveApi.materializeVerifiedArchive({sourceDir:source,archiveVerifyKey:archiveKey,archiveVerifyKeyId:archiveKeyId,
     supportedFormats:['memphis-zoo-disaster-recovery.v4'],requiredEntries:['backup-summary.json',
      'inventory/application-schema.sql','inventory/table-catalog.json','inventory/migration-ledger.json',
      'inventory/cron-jobs.json','inventory/extensions.json','inventory/source-pins.json',
      'inventory/original-relations.json','inventory/original-guards.json','inventory/original-acls.json']});
    const binding=archiveApi.readVerifiedArchiveSourceBinding(archive);
    const currentSource=()=>assert.equal(archiveApi.readVerifiedArchiveSourceBinding(archive),binding);
    requirePins();
    assert.deepEqual(Object.keys(binding).sort(),['format','project_ref','archive_digest','source_identity','source_identity_sha256','summary'].sort());
    assert.equal(binding.format,'memphis-zoo-disaster-recovery.v4');assert.equal(binding.project_ref,'abcdefghijklmnopqrst');
    assert.equal(binding.archive_digest,'969fde44613e2153f5eebce6df7308efcdfc00c7cd7c80dd69ce316b62941132');
    assert.equal(binding.source_identity_sha256,'9d7952435f060f6b69a57469e973fe2bdc2a1d4538def02084202e38359d9af4');
    const archiveDigest=binding.archive_digest,summary=binding.summary,identity=binding.source_identity;
    assert.deepEqual(Object.keys(summary).sort(),['format','ok','consistent_database_snapshot','project_ref','backed_up_schemas','table_count','database_row_count','source_identity'].sort());
    assert.deepEqual(Object.keys(identity).sort(),['database_catalog_sha256','application_schema_sha256','migration_head',
     'migration_ledger_count','migration_ledger_sha256','cron_job_count','cron_jobs_sha256','extensions_sha256',
     'release','source_pins_sha256','original_relations_sha256','original_guards_sha256','original_acls_sha256'].sort());
    assert.deepEqual(summary.backed_up_schemas,schemas);assert.equal(summary.table_count,279);
    assert.ok(Number.isSafeInteger(summary.database_row_count)&&summary.database_row_count>0);
    // Read only the materializer's owned read-only snapshot. Every fixed
    // metadata member is independently bound to the SAME signed identity,
    // not a public checksum map, a loose source path or current target output.
    const inventoryBytes=Object.create(null),flags=fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW;
    const inventoryFd=fs.openSync(path.join(archive.directory,'inventory'),flags|fs.constants.O_DIRECTORY);
    try{
     const directory=fs.fstatSync(inventoryFd);assert.ok(directory.isDirectory());
     for(const [name,field]of [
      ['table-catalog.json','database_catalog_sha256'],['application-schema.sql','application_schema_sha256'],
      ['migration-ledger.json','migration_ledger_sha256'],['cron-jobs.json','cron_jobs_sha256'],
      ['extensions.json','extensions_sha256'],['source-pins.json','source_pins_sha256'],
      ['original-relations.json','original_relations_sha256'],['original-guards.json','original_guards_sha256'],
      ['original-acls.json','original_acls_sha256']]){
      currentSource();assert.equal(typeof identity[field],'string');assert.match(identity[field],/^[a-f0-9]{64}$/);
      const fd=fs.openSync('/proc/self/fd/'+inventoryFd+'/'+name,flags);
      try{
       const before=fs.fstatSync(fd);assert.ok(before.isFile()&&before.nlink===1&&Number.isSafeInteger(before.size)&&before.size>0&&before.size<=32*1024*1024);
       const data=fs.readFileSync(fd),after=fs.fstatSync(fd);
       const state=s=>[s.dev,s.ino,s.size,s.mtimeMs,s.ctimeMs,s.nlink];
       assert.deepEqual(state(after),state(before));assert.equal(data.length,before.size);assert.equal(sha(data),identity[field],name);
       const named=fs.openSync('/proc/self/fd/'+inventoryFd+'/'+name,flags);
       try{assert.deepEqual(state(fs.fstatSync(named)),state(before));}finally{fs.closeSync(named);}
       const namedDirectory=fs.lstatSync(path.join(archive.directory,'inventory'));
       assert.ok(namedDirectory.isDirectory()&&!namedDirectory.isSymbolicLink());
       assert.equal(namedDirectory.dev,directory.dev);assert.equal(namedDirectory.ino,directory.ino);
       currentSource();inventoryBytes[name]=data;
      }finally{fs.closeSync(fd);}
     }
    }finally{fs.closeSync(inventoryFd);}
    const decode=bytes=>new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);
    const jsonMember=name=>JSON.parse(decode(inventoryBytes[name]));
    const catalog=jsonMember('table-catalog.json'),ledger=jsonMember('migration-ledger.json'),
     cron=jsonMember('cron-jobs.json'),extensions=jsonMember('extensions.json'),
     relations=jsonMember('original-relations.json'),originalGuards=jsonMember('original-guards.json'),
     capturedSourcePins=jsonMember('source-pins.json');
    const bytes=inventoryBytes['application-schema.sql'],originalAclBytes=inventoryBytes['original-acls.json'];
    assert.ok(Array.isArray(ledger));assert.equal(ledger.length,identity.migration_ledger_count);
    assert.equal(ledger.at(-1)?.version,identity.migration_head);
    assert.deepEqual(ledger,plan.files.map(file=>({version:file.slice(0,14),name:file.slice(15,-4),
     statements:[fs.readFileSync(B+'/supabase/migrations/'+file,'utf8')]})));
    assert.ok(Array.isArray(cron));assert.equal(cron.length,identity.cron_job_count);assert.ok(Array.isArray(extensions));
    assert.ok(Array.isArray(relations)&&relations.length===catalog.length);
    assert.ok(relations.every(r=>r.relation_kind==='r'&&r.is_partition===false),'No omitted partition/foreign original DATA');
    assert.deepEqual(Object.keys(capturedSourcePins).sort(),[...pinPaths].sort());
    for(const digest of Object.values(capturedSourcePins)){assert.equal(typeof digest,'string');assert.match(digest,/^[a-f0-9]{64}$/);}
    assert.ok(Array.isArray(originalGuards));assert.equal(originalGuards.length,guardIds.length);
    for(let i=0;i<guardIds.length;i++){
     const g=originalGuards[i];assert.deepEqual(Object.keys(g).sort(),['definition','owner','prosrc']);
     assert.equal(g.owner,'supabase_admin');assert.equal(typeof g.prosrc,'string');assert.equal(sha(g.prosrc),guardHashes[i]);
     assert.ok(g.definition.startsWith('CREATE OR REPLACE FUNCTION '+guardIds[i]+'\n'));
     assert.ok(g.definition.endsWith('AS $function$'+g.prosrc+'$function$\n'));
    }
    const originalRelease=identity.release;
    assert.ok(originalRelease&&typeof originalRelease==='object'&&!Array.isArray(originalRelease));
    assert.equal(originalRelease.migration_head,ledger.at(-1).version);assert.equal(originalRelease.migration_manifest_sha256,plan.manifestSha256);
    const parsed=planEventOwnerRestore(decode(bytes));
    put('ACTUAL_SCHEMA_INPUT.json',{source_database:'postgres',source_owner:'supabase_admin',
     source_commit:originalRelease.backend_commit,source_pins:sourcePins,retained_capture_source_pins:capturedSourcePins,
     source_replay:plan.manifestSha256,sha256:sha(bytes),bytes:bytes.length,statements:parsed.statementCount,
     events:parsed.eventCount,archive_digest:archiveDigest,source_identity_sha256:binding.source_identity_sha256,
     origin:'retained authenticated v16 original pg_dump; no new producer, capture or pg_dump proof'});
    const originalAcls=JSON.parse(decode(originalAclBytes));
    assert.deepEqual(Object.keys(originalAcls).sort(),['routines','relations','namespaces_columns'].sort());
    const aclGraph=[originalAcls];while(aclGraph.length){const value=aclGraph.pop();
     if(value&&typeof value==='object'){aclGraph.push(...Object.values(value));Object.freeze(value);}}
    const selected=archiveApi.readVerifiedRestoreTableSelection(archive,{databaseOnly:true});
    assert.deepEqual(selected.databaseTables,catalog);assert.equal(selected.databaseTables.length,279);
    for(const name of ['group_original_creations','employee_message_original_outcomes'])
     assert.equal(catalog.find(t=>t.schema_name==='custodial_release_identity'&&t.table_name===name)?.row_count,'1');
    phase='consume every retained authenticated original table to fresh exact EOF before target initialization';
    const metadata=new Map(),eofs=[];
    for(const table of selected.databaseTables){
     const data=archiveApi.openVerifiedRestoreTableData(archive,table.schema_name,table.table_name),guard=archiveApi.createRestoreRowUtf8Guard();
     const settled=pipeline(data.stream,guard);settled.catch(()=>{});const lines=createInterface({input:guard,crlfDelay:Infinity});
     const raw=[];let count=0;
     try{for await(const line of lines){currentSource();const text=archiveApi.decodeRestoreTableRowLine(line,table);count++;
      if(table.schema_name==='public'&&['release_deployment_manifest','custodial_release_authority_restore_inventory'].includes(table.table_name))raw.push(text);
     }await settled;const eof=await data.verified;assert.equal(String(count),table.row_count);eofs.push({...eof,rows:count});
     }finally{lines.close();data.stream.destroy();guard.destroy();await settled.catch(()=>{});await data.close();}
     if(raw.length)metadata.set(table.table_name,raw);
    }
    assert.equal(metadata.get('release_deployment_manifest')?.length,1);assert.ok(metadata.get('custodial_release_authority_restore_inventory')?.length>0);
    assert.deepEqual(JSON.parse(metadata.get('release_deployment_manifest')[0]),originalRelease);
    assert.equal(eofs.reduce((n,eof)=>n+eof.rows,0),summary.database_row_count);
    put('AUTHENTICATED_SOURCE_COMPLETE.json',{archive_digest:archiveDigest,source_identity_sha256:binding.source_identity_sha256,
     unit_signatures_only:true,all_members:eofs,group_original_rows:catalog.find(t=>t.table_name==='group_original_creations').row_count,
     raw_postgres_text_preserved:true,selected_schemas:schemas});
    currentSource();requirePins(); // Original-owner diagnostic client remains connected, idle and outside any snapshot transaction.
    target=new Client({...options,user:'supabase_admin',database:targetName});clients.add(target);target.on('error',()=>{});await target.connect();
    assert.deepEqual((await target.query('select current_database() database,current_user actor,session_user session_actor')).rows[0],
     {database:targetName,actor:'supabase_admin',session_actor:'supabase_admin'});
    await target.query("set statement_timeout='12s';set lock_timeout='2s'");
    await target.query('begin');targetTransaction=true;
    await target.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-admission',0))");
    await target.query("select pg_advisory_xact_lock(hashtextextended('memphis-zoo-application-mutation-fence',0))");
    const invocation=(await target.query('select pg_backend_pid() pid,txid_current()::text xid')).rows[0];
    currentSource();requirePins();phase='normal clean initializer after authenticated original EOF';
    const restored=await executeEventOwnerPlan(target,parsed);
    const tables=(await target.query(`select n.nspname schema_name,c.relname table_name,c.relowner::text owner_oid,
     c.relrowsecurity,c.relforcerowsecurity from pg_class c join pg_namespace n on n.oid=c.relnamespace
     where n.nspname=any($1::text[]) and c.relkind='r' and not c.relispartition order by n.nspname,c.relname`,
     [['public','auth','storage','custodial_release_identity']])).rows;
    assert.ok(tables.length>0);
    for(const row of tables){
     const count=(await target.query('select count(*)::text n from ONLY '+quoteIdentifier(row.schema_name)+'.'+quoteIdentifier(row.table_name))).rows[0].n;
     assert.equal(count,'0','Fresh schema target has unexpected application DATA');row.row_count=count;
    }
    assert.deepEqual(tables.map(({row_count,owner_oid,...r})=>r),relations.map(({relation_kind,is_partition,owner_name,...r})=>r),'Full fixed target relation/RLS scope');
    const owner=(await target.query(`select (select pg_get_userbyid(datdba) from pg_database where datname=current_database()) database_owner,
     (select pg_get_userbyid(relowner) from pg_class where oid='custodial_dr.restore_control'::regclass) control_owner,
     (select pg_get_userbyid(relowner) from pg_class where oid='custodial_release_identity.group_original_creations'::regclass) group_owner`)).rows[0];
    assert.deepEqual(owner,{database_owner:'postgres',control_owner:'supabase_admin',group_owner:'supabase_admin'});
    const actualOwners=(await target.query(`select n.nspname schema_name,c.relname table_name,pg_get_userbyid(c.relowner) owner_name
     from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname=any($1::text[]) and c.relkind in ('r','p','f') order by n.nspname,c.relname`,[schemas])).rows;
    assert.deepEqual(actualOwners,relations.map(({schema_name,table_name,owner_name})=>({schema_name,table_name,owner_name})));
    // Normal DDL guards require genuine control-plane initialization, even
    // before application DATA. This target is still unexposed and holds both
    // actual admission and mutation xact fences; no app lease is resumed.
    // Insert the normal non-restored READY control row before proposal DDL,
    // never disable the guard or let it adopt an absent generation.
    phase='exclusive unexposed initial control before Source DDL';
    assert.equal((await target.query('select count(*)::int n from custodial_dr.restore_control')).rows[0].n,0);
    await target.query('insert into custodial_dr.restore_control(singleton) values(true)');
    phase='exact original ACL fidelity by revocation only before Source proposal';
    currentSource();requirePins();await target.query('set local search_path=pg_catalog');
    const originalAclRecovery={
     routines:await reconcileOriginalRoutineAcls(target,originalAcls.routines),
     relations:await reconcileOriginalRelationAcls(target,originalAcls.relations),
     namespaces_columns:await reconcileOriginalNamespaceColumnAcls(target,originalAcls.namespaces_columns)
    };
    currentSource();requirePins();
    assert.deepEqual((await target.query('select pg_backend_pid() pid,txid_current()::text xid')).rows[0],invocation);
    put('ORIGINAL_ACL_RECONCILIATION.json',{scope:'same fresh unexposed target; extras revoked only, no automatic grant/role/default-ACL change',
     signed_original_acls_sha256:binding.source_identity.original_acls_sha256,actual:originalAclRecovery,
     same_original_transaction:true,admission_resumed:false});
    // Derive exactly TWENTY-THREE new definitions from the independently observed
    // original definitions/prosrc and the pinned proposal recipe, NEVER from
    // the post-change pg_get_functiondef value being admitted.
    // A callback inserts literal Source bytes. SQL regex endings can contain
    // JavaScript's special $' replacement token; never expand those bytes as
    // replacement syntax while deriving the independent expected definition.
    const replaceOnce=(s,old,next)=>{assert.equal(s.split(old).length,2);return s.replace(old,()=>next);};
    const oldGroup='      and t.original_group_creation=NEW.original_tuple) then';
    let expectedGroup=replaceOnce(originalGuards[0].definition,'    or not exists(select 1 from public.msg_threads t where t.id=NEW.group_uuid',
     '    or (not exists(select 1 from public.msg_threads t where t.id=NEW.group_uuid');
    expectedGroup=replaceOnce(expectedGroup,oldGroup,'      and t.original_group_creation=NEW.original_tuple)\n    and not custodial_dr.immutable_import_matches_staged(TG_RELID,to_jsonb(NEW))) then');
    const oldOrdinary='  perform custodial_dr.acquire_application_mutation_fence();';
    const newOrdinary="  if TG_OP = 'INSERT' and TG_LEVEL = 'STATEMENT' and TG_WHEN = 'BEFORE'\n"
     +"    and current_user = session_user\n"
     +"    and (select oid from pg_catalog.pg_roles where rolname = session_user)\n"
     +"      = (select relowner from pg_catalog.pg_class where oid = 'custodial_dr.restore_control'::regclass)\n"
     +"    and exists (select 1 from custodial_dr.immutable_private_import_context c\n"
     +"      where c.database_oid = (select oid from pg_catalog.pg_database where datname = current_database())\n"
     +"        and c.backend_pid = pg_backend_pid() and c.transaction_id = txid_current()\n"
     +"        and c.phase in ('INSERTING_ORDINARY','INSERTING_ORDINARY_SET') and c.active_table_oid = TG_RELID\n"
     +"        and c.active_row_sha256 ~ '^[a-f0-9]{64}$') then\n"
     +"    perform custodial_dr.immutable_import_assert_context();\n    return null;\n  end if;\n"+oldOrdinary;
    const expectedDefs=[expectedGroup,replaceOnce(originalGuards[1].definition,oldOrdinary,newOrdinary)];
    // These three fixed Source files are additional inputs for Main's outer
    // source-pin list. Keep the owning capture/intent/admission region intact.
    const additionalGuardPins={
     'proposals/immutable-original-event-restore.sql':'e96326ecf6b7fcaa0f22d4a2c6eac9495958a18a72a0cae5fd0609efa4eec236',
     'proposals/immutable-original-employee-restore.sql':'283a7f010dd72bf371018db08ee6143b84e6a33ca55feeb99526f7dc29cec208',
     'proposals/immutable-original-messenger-restore.sql':'857ea9ac7b67b45ecfda0cae37c26ee5c9764924dcf2aedc0ad9da9260c74354',
     'proposals/immutable-original-message-effects-restore.sql':'0b28beda0231ff0940f9bdda392327b4dd24b14f86a2154139ca39feb9154604',
     'proposals/immutable-original-message-guards-restore.sql':'f2c99f1fe58c8c569a1b3cf1b70d69c049607caca8e73f4d2f0479bad1a7768c',
     'proposals/immutable-original-device-boundary-restore.sql':'57e66370a7bf892c54a87da520ca00b2bfd25c69341f77be1f6679a3552f1222',
     'proposals/immutable-original-message-audit-restore.sql':'bfdd883690411b2a79a26ceac6ef80c008c5e24055b5d3b1af64b2232da2109a',
     'proposals/immutable-original-message-receipts-restore.sql':'98a4f593caf9c62eb42dfae893c67d0e2f84fc5e6b518965b27a92927ac00f88',
    };
    const guardSources=Object.fromEntries(Object.entries(additionalGuardPins).map(([file,digest])=>{
     const source=fs.readFileSync(B+'/'+file,'utf8');assert.equal(sha(source),digest,file);return [file,source];
    }));
    const requireGuardSources=()=>{currentSource();for(const [file,digest]of Object.entries(additionalGuardPins))assert.equal(sha(fs.readFileSync(B+'/'+file)),digest,file);};
    const bodyOf=definition=>{const tag='AS $function$';assert.equal(definition.split(tag).length,2);
     assert.ok(definition.endsWith('$function$\n'));return definition.slice(definition.indexOf(tag)+tag.length,-'$function$\n'.length);};
    function composeOriginalMessageEffectRecipes(sql){
     assert.equal(typeof sql,'string');
     const profiles=JSON.parse(literalBetween(sql,'$original_message_effects_profiles$'));
     const branch=literalBetween(sql,'$exact_message_effects_branch$');
     assert.ok(branch.length>0);
     const expected=[
      ['msg_enqueue_background_work()','trg_msg_enqueue_background_work','first_begin'],
      ['msg_memphis_pre_generate_schedule()','trg_msg_memphis_pre_generate_schedule','outer_original_block'],
      ['msg_audit_persisted_message()','trg_msg_message_immutable_audit','first_begin'],
      ['mz_enqueue_employee_message_push()','trg_mz_enqueue_employee_message_push','first_begin'],
      ['ops_manager_enqueue_message_push()','trg_ops_manager_enqueue_message_push','first_begin'],
     ];
     const keys=['identity','lookup_identity','table_name','trigger_name','trigger_type','strategy',
      'before_definition','before_definition_sha256','before_prosrc_sha256','before_grant_definition',
      'before_grant_sha256','after_prosrc_sha256','after_definition_sha256'].sort();
     const hashKeys=['before_definition_sha256','before_prosrc_sha256','before_grant_sha256',
      'after_prosrc_sha256','after_definition_sha256'];
     assert.ok(Array.isArray(profiles));assert.equal(profiles.length,expected.length);
     return Object.freeze(profiles.map((profile,index)=>{
      assert.ok(profile!==null&&typeof profile==='object'&&!Array.isArray(profile));
      assert.deepEqual(Object.keys(profile).sort(),keys);
      for(const key of keys)if(key!=='trigger_type')assert.equal(typeof profile[key],'string',key);
      for(const key of hashKeys)assert.match(profile[key],/^[0-9a-f]{64}$/,key);
      const [registryIdentity,trigger,strategy]=expected[index];
      assert.equal(profile.identity,registryIdentity);
      assert.equal(profile.lookup_identity,'public.'+registryIdentity);
      assert.equal(profile.table_name,'msg_messages');assert.equal(profile.trigger_name,trigger);
      assert.equal(profile.trigger_type,5);assert.equal(profile.strategy,strategy);
      const before=profile.before_definition,originalBody=bodyOf(before);
      assert.ok(before.startsWith('CREATE OR REPLACE FUNCTION '+profile.lookup_identity+'\n'));
      assert.equal(sha(before),profile.before_definition_sha256);
      assert.equal(sha(originalBody),profile.before_prosrc_sha256);
      assert.equal(sha(profile.before_grant_definition),profile.before_grant_sha256);
      let after;
      if(strategy==='first_begin'){
       after=replaceOnce(before,'\nbegin\n','\nbegin\n'+branch);
       assert.equal(replaceOnce(after,branch,''),before);
      }else{
       const prefix='\nbegin\n'+branch,suffix='end;\n',afterBody=prefix+originalBody+suffix;
       after=replaceOnce(before,'AS $function$'+originalBody+'$function$\n',
        'AS $function$'+afterBody+'$function$\n');
       assert.equal(bodyOf(after),afterBody);
       assert.equal(afterBody.slice(prefix.length,-suffix.length),originalBody);
       assert.equal(replaceOnce(after,afterBody,originalBody),before);
      }
      assert.equal(sha(after),profile.after_definition_sha256);
      assert.equal(sha(bodyOf(after)),profile.after_prosrc_sha256);
      return Object.freeze({identity:profile.lookup_identity,registry_identity:registryIdentity,
       before,after,beforeBodyHash:profile.before_prosrc_sha256,afterBodyHash:profile.after_prosrc_sha256});
     }));
    }
    const guardRecipes=new Map();
    const addGuardRecipe=(identity,before,after,beforeBodyHash,afterBodyHash)=>{
     assert.ok(!guardRecipes.has(identity));assert.match(identity,/^(public|custodial_dr|custodial_release_identity)\.[a-z_][a-z0-9_]*\(\)$/);
     assert.equal(sha(bodyOf(before)),beforeBodyHash);assert.equal(sha(bodyOf(after)),afterBodyHash);
     guardRecipes.set(identity,Object.freeze({identity,before,after,beforeHash:sha(before),afterHash:sha(after),beforeBodyHash,afterBodyHash}));
    };
    for(let i=0;i<guardIds.length;i++)addGuardRecipe(guardIds[i],originalGuards[i].definition,expectedDefs[i],guardHashes[i],sha(bodyOf(expectedDefs[i])));
    const eventSql=guardSources['proposals/immutable-original-event-restore.sql'];
    const literalBetween=(source,tag)=>{assert.equal(source.split(tag).length,3);return source.split(tag)[1];};
    const eventBranch=literalBetween(eventSql,'$original_event_branch$');
    const eventProfiles=JSON.parse(literalBetween(eventSql,'$original_event_profiles$'));
    assert.deepEqual(eventProfiles.map(p=>p.identity),[
     'public.app_event_place_admission_guard()','public.app_event_supersession_guard()',
     'public.events_app_events_set_end_date()','public.events_app_validate_scope_venue()','public.events_app_isolate_needs_review()']);
    for(const profile of eventProfiles){
     assert.deepEqual(Object.keys(profile).sort(),['identity','before_definition','before_definition_sha256','before_prosrc_sha256','after_prosrc_sha256','after_definition_sha256'].sort());
     assert.equal(sha(profile.before_definition),profile.before_definition_sha256);
     const after=replaceOnce(profile.before_definition,'\nbegin\n','\nbegin\n'+eventBranch);
     assert.equal(sha(after),profile.after_definition_sha256);
     assert.equal(replaceOnce(after,eventBranch,''),profile.before_definition,'Event normal body is preserved');
     addGuardRecipe(profile.identity,profile.before_definition,after,profile.before_prosrc_sha256,profile.after_prosrc_sha256);
    }
    const employeeSql=guardSources['proposals/immutable-original-employee-restore.sql'];
    const employeeIdentity='public.static_weekly_v15_advance_recurring_generation()';
    const employeeHeader='CREATE OR REPLACE FUNCTION '+employeeIdentity+'\n';
    assert.equal(employeeSql.split(employeeHeader).length,2);assert.equal(employeeSql.split('\n$function$;').length,2);
    const employeeStart=employeeSql.indexOf(employeeHeader),employeeEnd=employeeSql.indexOf('\n$function$;',employeeStart);
    assert.ok(employeeEnd>employeeStart);
    // The fixed whole CREATE literal is the expected AFTER, not a target read.
    const employeeAfter=employeeSql.slice(employeeStart,employeeEnd+'\n$function$'.length)+'\n';
    const employeeBegin='AS $function$\nbegin\n',employeeContinuation="  if tg_table_name='employees' then\n";
    assert.equal(employeeAfter.split(employeeBegin).length,2);assert.equal(employeeAfter.split(employeeContinuation).length,2);
    const employeeBodyStart=employeeAfter.indexOf(employeeBegin)+employeeBegin.length;
    const employeeResume=employeeAfter.indexOf(employeeContinuation,employeeBodyStart);assert.ok(employeeResume>employeeBodyStart);
    const employeeBefore=employeeAfter.slice(0,employeeBodyStart)+employeeAfter.slice(employeeResume);
    assert.equal(sha(employeeBefore),'4a94f5e0cc6f6dcdd8e9547036266f05964306a04e4eb7621f8b70b811bd635c','Employee literal preserves the exact original body');
    addGuardRecipe(employeeIdentity,employeeBefore,employeeAfter,sha(bodyOf(employeeBefore)),sha(bodyOf(employeeAfter)));
    function composeOriginalMessageAuditRecipe(sql){
     // Fixed Source representation only; Main separately pins the proposal.
     assert.equal(typeof sql,'string');
     const profiles=JSON.parse(literalBetween(sql,'$original_message_audit_profiles$'));
     const branch=literalBetween(sql,'$original_message_audit_branch$');
     assert.ok(Array.isArray(profiles));assert.equal(profiles.length,1);assert.ok(branch.length>0);
     const profile=profiles[0];
     assert.ok(profile&&Object.getPrototypeOf(profile)===Object.prototype);
     const keys=['identity','lookup_identity','table_name','trigger_name','trigger_type','trigger_columns','owner',
      'before_definition','before_definition_sha256','before_prosrc_sha256','before_grant_definition',
      'before_grant_sha256','before_trigger_definition','before_trigger_sha256','after_prosrc_sha256','after_definition_sha256'];
     assert.deepEqual(Object.keys(profile).sort(),[...keys].sort());
     for(const key of keys)if(key!=='trigger_type')assert.equal(typeof profile[key],'string',key);
     assert.equal(profile.identity,'msg_reject_retired_ops_manager_shared_message_audit_mutation()');
     assert.equal(profile.lookup_identity,'public.'+profile.identity);
     assert.equal(profile.table_name,'msg_message_audit');
     assert.equal(profile.trigger_name,'trg_msg_reject_retired_ops_manager_shared_audit_guard');
     assert.equal(profile.trigger_type,31);assert.equal(profile.trigger_columns,'');assert.equal(profile.owner,'supabase_admin');
     for(const key of ['before_definition_sha256','before_prosrc_sha256','before_grant_sha256',
      'before_trigger_sha256','after_prosrc_sha256','after_definition_sha256'])assert.match(profile[key],/^[a-f0-9]{64}$/);
     const before=profile.before_definition;
     assert.ok(before.startsWith('CREATE OR REPLACE FUNCTION '+profile.lookup_identity+'\n'));
     assert.equal(sha(before),'6c3717ebd362bd4bf9abfc00a3ece56963f21542f6f808780fcf6d5b6bcf3bb7');
     assert.equal(sha(before),profile.before_definition_sha256);
     assert.equal(sha(bodyOf(before)),profile.before_prosrc_sha256);
     assert.equal(sha(profile.before_grant_definition),profile.before_grant_sha256);
     assert.equal(sha(profile.before_trigger_definition),profile.before_trigger_sha256);
     const after=replaceOnce(before,'\nbegin\n','\nbegin\n'+branch);
     assert.equal(sha(after),profile.after_definition_sha256);
     assert.equal(sha(bodyOf(after)),profile.after_prosrc_sha256);
     assert.equal(replaceOnce(after,branch,''),before,'Audit normal/UPDATE/DELETE body is preserved exactly');
     return Object.freeze({identity:profile.lookup_identity,registry_identity:profile.identity,before,after,
      beforeBodyHash:profile.before_prosrc_sha256,afterBodyHash:profile.after_prosrc_sha256});
    }
    function composeOriginalMessageGuardRecipes(sql){
     // Representation only: Main pins this Source separately. No target read,
     // registry write or admission follows from an arbitrary supplied string.
     assert.equal(typeof sql,'string');
     const profiles=JSON.parse(literalBetween(sql,'$original_message_guard_profiles$'));
     const branch=literalBetween(sql,'$original_message_guard_branch$');
     assert.ok(Array.isArray(profiles));assert.equal(profiles.length,2);assert.ok(branch.length>0);
     const keys=['identity','lookup_identity','table_name','trigger_name','trigger_type','trigger_columns','owner',
      'before_definition','before_definition_sha256','before_prosrc_sha256','before_grant_definition',
      'before_grant_sha256','before_trigger_definition','before_trigger_sha256','after_prosrc_sha256','after_definition_sha256'];
     for(const profile of profiles){
      assert.ok(profile&&Object.getPrototypeOf(profile)===Object.prototype);
      assert.deepEqual(Object.keys(profile).sort(),[...keys].sort());
     }
     assert.deepEqual(profiles.map(p=>[p.identity,p.lookup_identity,p.trigger_name,p.trigger_type]),[
      ['msg_reject_retired_ops_manager_shared_message_mutation()','public.msg_reject_retired_ops_manager_shared_message_mutation()',
       'trg_msg_reject_retired_ops_manager_shared_message_mutation',31],
      ['mz_reject_event_messenger_message()','public.mz_reject_event_messenger_message()',
       'trg_mz_reject_event_messenger_message',7]]);
     return profiles.map(profile=>{
      assert.equal(profile.table_name,'msg_messages');assert.equal(profile.trigger_columns,'');assert.equal(profile.owner,'supabase_admin');
      for(const key of ['before_definition','before_grant_definition','before_trigger_definition'])assert.equal(typeof profile[key],'string');
      for(const key of ['before_definition_sha256','before_prosrc_sha256','before_grant_sha256','before_trigger_sha256','after_prosrc_sha256','after_definition_sha256']){
       assert.equal(typeof profile[key],'string');assert.match(profile[key],/^[a-f0-9]{64}$/);
      }
      const before=profile.before_definition;
      assert.equal(sha(before),profile.before_definition_sha256);
      assert.equal(sha(bodyOf(before)),profile.before_prosrc_sha256);
      assert.equal(sha(profile.before_grant_definition),profile.before_grant_sha256);
      assert.equal(sha(profile.before_trigger_definition),profile.before_trigger_sha256);
      const after=replaceOnce(before,'\nbegin\n','\nbegin\n'+branch);
      assert.equal(sha(after),profile.after_definition_sha256);
      assert.equal(sha(bodyOf(after)),profile.after_prosrc_sha256);
      assert.equal(replaceOnce(after,branch,''),before,'Message guard normal body is preserved exactly');
      return {identity:profile.lookup_identity,registry_identity:profile.identity,before,after,
       beforeBodyHash:profile.before_prosrc_sha256,afterBodyHash:profile.after_prosrc_sha256};
     });
    }
    function composeOriginalMessageReceiptRecipe(sql){
     // Source representation only; Main separately pins/authenticates the
     // original recipe and owns all target/admission/registry operations.
     assert.equal(typeof sql,'string');
     const profiles=JSON.parse(literalBetween(sql,'$original_message_receipt_profiles$'));
     const branch=literalBetween(sql,'$original_message_receipt_branch$');
     assert.ok(Array.isArray(profiles));assert.equal(profiles.length,1);assert.ok(branch.length>0);
     const profile=profiles[0];assert.ok(profile&&Object.getPrototypeOf(profile)===Object.prototype);
     const keys=['identity','lookup_identity','table_name','trigger_name','trigger_type','trigger_columns','owner',
      'before_definition','before_definition_sha256','before_prosrc_sha256','before_grant_definition',
      'before_grant_sha256','before_trigger_definition','before_trigger_sha256','after_prosrc_sha256','after_definition_sha256'];
     assert.deepEqual(Object.keys(profile).sort(),[...keys].sort());
     assert.equal(profile.identity,'msg_reject_retired_ops_manager_shared_receipt_mutation()');
     assert.equal(profile.lookup_identity,'public.msg_reject_retired_ops_manager_shared_receipt_mutation()');
     assert.equal(profile.table_name,'msg_receipts');assert.equal(profile.trigger_type,31);assert.equal(profile.trigger_columns,'');
     assert.equal(profile.trigger_name,'trg_msg_reject_retired_ops_manager_shared_receipt_mutation');assert.equal(profile.owner,'supabase_admin');
     for(const key of ['before_definition','before_grant_definition','before_trigger_definition'])assert.equal(typeof profile[key],'string');
     for(const key of ['before_definition_sha256','before_prosrc_sha256','before_grant_sha256','before_trigger_sha256','after_prosrc_sha256','after_definition_sha256']){
      assert.equal(typeof profile[key],'string');assert.match(profile[key],/^[a-f0-9]{64}$/);
     }
     const before=profile.before_definition;
     assert.equal(profile.before_definition_sha256,'8f81b7a8d54778ef9b05f24d48075271686d88cf03de3f19d1642cb0d2591ad0');
     assert.equal(sha(before),profile.before_definition_sha256);assert.equal(sha(bodyOf(before)),profile.before_prosrc_sha256);
     assert.equal(sha(profile.before_grant_definition),profile.before_grant_sha256);
     assert.equal(sha(profile.before_trigger_definition),profile.before_trigger_sha256);
     const after=replaceOnce(before,'\nbegin\n','\nbegin\n'+branch);
     assert.equal(sha(after),profile.after_definition_sha256);assert.equal(sha(bodyOf(after)),profile.after_prosrc_sha256);
     assert.equal(replaceOnce(after,branch,''),before,'Original receipt guard normal body is preserved exactly');
     return {identity:profile.lookup_identity,registry_identity:profile.identity,before,after,
      beforeBodyHash:profile.before_prosrc_sha256,afterBodyHash:profile.after_prosrc_sha256};
    }
    const messengerSql=guardSources['proposals/immutable-original-messenger-restore.sql'];
    const messengerProfiles=JSON.parse(literalBetween(messengerSql,'$original_messenger_profiles$'));
    assert.deepEqual(messengerProfiles.map(p=>[p.identity,p.lookup_identity]),[
     ['msg_enforce_canonical_active_pair_participants()','public.msg_enforce_canonical_active_pair_participants()'],
     ['msg_enforce_canonical_active_pair_thread()','public.msg_enforce_canonical_active_pair_thread()'],
     ['public.msg_preserve_original_group_creation()','public.msg_preserve_original_group_creation()'],
     ['msg_reject_retired_ops_manager_shared_participation()','public.msg_reject_retired_ops_manager_shared_participation()'],
     ['msg_reject_retired_ops_manager_shared_thread_mutation()','public.msg_reject_retired_ops_manager_shared_thread_mutation()']]);
    const messengerRegistryIdentities=new Map();
    for(const profile of messengerProfiles){
     assert.deepEqual(Object.keys(profile).sort(),['identity','lookup_identity','table_name','trigger_name','trigger_type',
      'before_definition','before_definition_sha256','before_prosrc_sha256','before_grant_definition',
      'before_grant_sha256','restore_branch','after_prosrc_sha256','after_definition_sha256'].sort());
     assert.equal(sha(profile.before_definition),profile.before_definition_sha256);
     assert.equal(sha(profile.before_grant_definition),profile.before_grant_sha256);
     const after=replaceOnce(profile.before_definition,'\nbegin\n','\nbegin\n'+profile.restore_branch);
     assert.equal(sha(after),profile.after_definition_sha256);
     assert.equal(replaceOnce(after,profile.restore_branch,''),profile.before_definition,'Messenger normal body is preserved');
     addGuardRecipe(profile.lookup_identity,profile.before_definition,after,profile.before_prosrc_sha256,profile.after_prosrc_sha256);
     assert.ok(!messengerRegistryIdentities.has(profile.lookup_identity));
     messengerRegistryIdentities.set(profile.lookup_identity,profile.identity);
    }
    // These independently pinned Source recipes do not execute DDL or adopt
    // a target definition. Preserve each original registry identity verbatim.
    const effectSql=guardSources['proposals/immutable-original-message-effects-restore.sql'];
    const messageGuardSql=guardSources['proposals/immutable-original-message-guards-restore.sql'];
    const auditSql=guardSources['proposals/immutable-original-message-audit-restore.sql'];
    const receiptSql=guardSources['proposals/immutable-original-message-receipts-restore.sql'];
    const extraMessageRecipes=[...composeOriginalMessageEffectRecipes(effectSql),...composeOriginalMessageGuardRecipes(messageGuardSql),
     composeOriginalMessageAuditRecipe(auditSql),composeOriginalMessageReceiptRecipe(receiptSql)];
    assert.equal(extraMessageRecipes.length,9);
    for(const recipe of extraMessageRecipes){
     addGuardRecipe(recipe.identity,recipe.before,recipe.after,recipe.beforeBodyHash,recipe.afterBodyHash);
     assert.ok(!messengerRegistryIdentities.has(recipe.identity));messengerRegistryIdentities.set(recipe.identity,recipe.registry_identity);
    }
    const deviceSql=guardSources['proposals/immutable-original-device-boundary-restore.sql'];
    const deviceBefore=literalBetween(deviceSql,'$original_device_definition$').slice(1);
    assert.equal(sha(deviceBefore),'011cc5921cefe8714f52b821b915686359ac5edb873abd33fec8696cc050f19a');
    const deviceBranch=literalBetween(deviceSql,'$original_device_restore_branch$');
    const deviceAfter=replaceOnce(deviceBefore,'\nbegin\n','\nbegin\n'+deviceBranch);
    assert.equal(sha(deviceAfter),'3e56db21581c31567ac00c74477dff55ad30a46c54624caaf9bf5c7559ac6017');
    assert.equal(replaceOnce(deviceAfter,deviceBranch,''),deviceBefore);
    addGuardRecipe('public.custodial_record_offline_authority_activation_boundary()',deviceBefore,deviceAfter,
     '78ca52bb75851e47e110a3674c744210fec37c0b9c000c2416d3ddf9e785bf05','a7c6b2ff8dea2807f859198aa653857bfb8f1604d8c64034c22fc02dfaeae483');
    messengerRegistryIdentities.set('public.custodial_record_offline_authority_activation_boundary()',
     'custodial_record_offline_authority_activation_boundary()');
    assert.equal(guardRecipes.size,23);
    // Match the closed recipe identities to the SAME authenticated raw rows.
    // Public-qualified/unqualified aliases are finite lookup forms ONLY;
    // stored object_identity and every other original field remain untouched.
    const originalRegistry=metadata.get('custodial_release_authority_restore_inventory').map(raw=>{
     const row=JSON.parse(raw);assert.equal(row.definition_sha256,sha(row.definition_sql));return {raw,row};
    });
    for(const profile of messengerProfiles){
     const grants=originalRegistry.filter(({row})=>row.object_kind==='grant'&&row.object_identity===profile.identity);
     assert.equal(grants.length,1,'Exactly one unchanged original Messenger grant row for '+profile.identity);
     assert.equal(grants[0].row.definition_sql,profile.before_grant_definition);
     assert.equal(grants[0].row.definition_sha256,profile.before_grant_sha256);
    }
    const registryRecipes=new Map();
    for(const recipe of guardRecipes.values()){
     const aliases=messengerRegistryIdentities.has(recipe.identity)?[messengerRegistryIdentities.get(recipe.identity)]:
      recipe.identity.startsWith('public.')?[recipe.identity,recipe.identity.slice('public.'.length)]:[recipe.identity];
     const matches=originalRegistry.filter(({row})=>row.object_kind==='function'&&aliases.includes(row.object_identity));
     // This single Dr guard is NON-RESTORED control Source, not archived app
     // DATA. Still verify its exact predecessor/after and owner below; never
     // create/adopt a missing application registry row for that definition.
     if(recipe.identity==='custodial_dr.guard_application_mutation()'){
      assert.equal(matches.length,0,'Non-restored Dr guard must not acquire an application registry row');continue;
     }
     assert.equal(matches.length,1,'Exactly one original registry row for '+recipe.identity);
     const {row}=matches[0];assert.equal(row.definition_sql,recipe.before);assert.equal(row.definition_sha256,recipe.beforeHash);
     assert.ok(!registryRecipes.has(row.object_identity));registryRecipes.set(row.object_identity,recipe);
    }
    assert.equal(registryRecipes.size,22);
    for(const recipe of guardRecipes.values()){
     requireGuardSources();const original=(await target.query(`select pg_get_functiondef(oid) definition,prosrc,
      pg_get_userbyid(proowner) owner from pg_proc where oid=$1::regprocedure`,[recipe.identity])).rows;
     assert.equal(original.length,1);assert.equal(original[0].owner,'supabase_admin');
     assert.equal(original[0].definition,recipe.before);assert.equal(sha(original[0].prosrc),recipe.beforeBodyHash);requireGuardSources();
    }
    // No nested BEGIN/COMMIT can drop this invocation's exclusive fence.
    assert.match(proposal,/^--[\s\S]*?\nBEGIN;/);assert.match(proposal,/\nCOMMIT;\s*$/);
    phase='source-exact immutable base proposal in original target transaction';
    await target.query(proposal.replace(/\nBEGIN;/,'\n').replace(/\nCOMMIT;\s*$/,'\n'));
    for(let i=0;i<guardIds.length;i++)assert.equal((await target.query('select pg_get_functiondef($1::regprocedure) definition',[guardIds[i]])).rows[0].definition,expectedDefs[i]);
    // Both new private performance primitives must be actual Source, not
    // caller cache data or a post-change value adopted as its own expected hash.
    for(const [name,resultType]of [['immutable_import_context_source_immutable','trigger'],['immutable_import_source_inventory_state','jsonb']]){
     const marker='CREATE FUNCTION custodial_dr.'+name+'()';assert.equal(proposal.split(marker).length,2);
     const start=proposal.indexOf('AS $fn$',proposal.indexOf(marker)),end=proposal.indexOf('$fn$;',start+7);
     assert.ok(start>0&&end>start);const expectedBody=proposal.slice(start+7,end);
     const observed=(await target.query(`select p.prosrc,pg_get_userbyid(p.proowner) owner,p.prosecdef,p.prokind,p.provolatile,p.pronargs,
      p.prorettype=$2::regtype result_type,p.proconfig,
      exists(select 1 from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee<>p.proowner) nonowner_execute
      from pg_proc p where p.oid=$1::regprocedure`,['custodial_dr.'+name+'()',resultType])).rows;
     assert.equal(observed.length,1);const {prosrc,...properties}=observed[0];assert.equal(sha(prosrc),sha(expectedBody));
     assert.deepEqual(properties,{owner:'supabase_admin',prosecdef:false,prokind:'f',provolatile:'v',pronargs:0,result_type:true,
      proconfig:['search_path=pg_catalog'],nonowner_execute:false});
    }
    phase='source-exact event guard proposal in original target transaction';
    requireGuardSources();await target.query(eventSql);requireGuardSources();
    // Strip ONLY the employee proposal's declared outer transaction markers;
    // retain SET LOCAL, owner/predecessor checks and its whole CREATE literal.
    assert.equal(employeeSql.split('\nBEGIN;\n').length,2);assert.match(employeeSql,/\nCOMMIT;\s*$/);
    const employeeApply=employeeSql.replace('\nBEGIN;\n','\n').replace(/\nCOMMIT;\s*$/,'\n');
    phase='source-exact employee guard proposal in original target transaction';
    await target.query(employeeApply);requireGuardSources();
    phase='source-exact messenger guard predecessor and proposal in original target transaction';
    await target.query(messengerSql);requireGuardSources();
    phase='source-exact original message before/after guard proposals in original target transaction';
    await target.query(messageGuardSql);requireGuardSources();await target.query(effectSql);requireGuardSources();
    phase='source-exact original audit and receipt history guards in original target transaction';
    await target.query(auditSql);requireGuardSources();await target.query(receiptSql);requireGuardSources();
    assert.equal(deviceSql.split('\nBEGIN;\n').length,2);assert.match(deviceSql,/\nCOMMIT;\s*$/);
    phase='source-exact original device activation boundary proposal in original target transaction';
    await target.query(deviceSql.replace('\nBEGIN;\n','\n').replace(/\nCOMMIT;\s*$/,'\n'));requireGuardSources();
    assert.deepEqual((await target.query('select pg_backend_pid() pid,txid_current()::text xid')).rows[0],invocation,'All guard proposals retain Main original transaction');
    for(const recipe of guardRecipes.values()){
     const actual=(await target.query(`select pg_get_functiondef(oid) definition,prosrc,
      pg_get_userbyid(proowner) owner from pg_proc where oid=$1::regprocedure`,[recipe.identity])).rows;
     assert.equal(actual.length,1);assert.equal(actual[0].owner,'supabase_admin');
     assert.equal(actual[0].definition,recipe.after);assert.equal(sha(actual[0].prosrc),recipe.afterBodyHash);requireGuardSources();
    }
    phase='exclusive unexposed Source metadata bootstrap before pause';currentSource();requirePins();
    await target.query('select custodial_dr.immutable_import_owner_fence()');
    for(const row of ledger)await target.query('insert into supabase_migrations.schema_migrations(version,name,statements) values($1,$2,$3::text[])',[row.version,row.name,row.statements]);
    assert.equal((await target.query('select count(*)::int n from cron.job')).rows[0].n,0);
    for(const row of cron)await target.query('insert into cron.job select * from json_populate_record(null::cron.job,$1::json)',[JSON.stringify(row)]);
    const releaseRaw=metadata.get('release_deployment_manifest')[0];
    await target.query('insert into public.release_deployment_manifest select * from json_populate_record(null::public.release_deployment_manifest,$1::json)',[releaseRaw]);
    assert.equal((await target.query(`select count(*)::int n from public.release_deployment_manifest t where
     to_jsonb(t)=to_jsonb(json_populate_record(null::public.release_deployment_manifest,$1::json))`,[releaseRaw])).rows[0].n,1);
    assert.equal((await target.query('select count(*)::int n from public.custodial_release_authority_restore_inventory')).rows[0].n,0,'Curate only a genuinely empty registry');
    put('SOURCE_METADATA_BOOTSTRAP_ENTERED.json',{phase,original_rows:metadata.get('custodial_release_authority_restore_inventory').length,
     original_transaction:invocation,admission_resumed:false});
    let curated=0;const curatedIdentities=new Set(),sourceRecipes=Object.create(null);
    const originalRegistryRows=metadata.get('custodial_release_authority_restore_inventory');
    for(const raw of originalRegistryRows){
     const row=JSON.parse(raw);assert.equal(row.definition_sha256,sha(row.definition_sql));
     const recipe=row.object_kind==='function'?registryRecipes.get(row.object_identity):null;
     if(recipe){requireGuardSources();assert.equal(row.definition_sql,recipe.before);assert.equal(row.definition_sha256,recipe.beforeHash);
      assert.ok(!curatedIdentities.has(recipe.identity));curatedIdentities.add(recipe.identity);curated++;
      sourceRecipes[row.object_identity]={definition_sql:recipe.after,definition_sha256:recipe.afterHash};
     }
    }
    assert.equal(curated,22);assert.deepEqual([...curatedIdentities].sort(),[...registryRecipes.values()].map(r=>r.identity).sort());requireGuardSources();
    // Same independently checked Source recipes and original JSON TEXT, but
    // one ordinary INSERT statement instead of fourteen thousand round trips.
    // Unchanged members never pass through a JS or SQL JSONB normalization.
    // This is ONLY the fresh, empty, unexposed fixture's Source bootstrap;
    // it neither consumes archived target authority nor changes import guards.
    const sourceRegistryArgs=['['+originalRegistryRows.join(',')+']',JSON.stringify(sourceRecipes)];
    const sourceRegistryExpected=`with original as (
     select value as image,ordinality from json_array_elements($1::json) with ordinality
    ), expected as (
     select case when image->>'object_kind'='function' and $2::jsonb ? (image->>'object_identity')
      then jsonb_set(jsonb_set(image::jsonb,'{definition_sql}',$2::jsonb->(image->>'object_identity')->'definition_sql'),
       '{definition_sha256}',$2::jsonb->(image->>'object_identity')->'definition_sha256')::json
      else image end as image,ordinality from original
    )`;
    currentSource();requireGuardSources();
    const initializedRegistry=await target.query(sourceRegistryExpected+`
     insert into public.custodial_release_authority_restore_inventory
     select r.* from expected e cross join lateral json_populate_record(
      null::public.custodial_release_authority_restore_inventory,e.image) r order by e.ordinality`,sourceRegistryArgs);
    assert.equal(initializedRegistry.command,'INSERT');assert.equal(initializedRegistry.rowCount,originalRegistryRows.length);
    currentSource();requireGuardSources();
    // Expected originals are derived again from the SAME Source bytes/recipes,
    // never from target output. Retain exact original UUID + full typed row
    // equality for EVERY member, including all uncurated metadata and fields.
    const differingRegistry=(await target.query(sourceRegistryExpected+`
     select count(*)::int n from expected e left join public.custodial_release_authority_restore_inventory t
      on t.inventory_id=(e.image->>'inventory_id')::uuid
     where t.inventory_id is null or to_jsonb(t) is distinct from
      to_jsonb(json_populate_record(null::public.custodial_release_authority_restore_inventory,e.image))`,sourceRegistryArgs)).rows;
    assert.deepEqual(differingRegistry,[{n:0}]);currentSource();requireGuardSources();
    const metadataBefore=(await target.query('select row_to_json(r)::text row from public.custodial_release_authority_restore_inventory r order by inventory_id')).rows;
    assert.equal(metadataBefore.length,metadata.get('custodial_release_authority_restore_inventory').length);
    // The pinned replay plan is deliberately not chronological. Read the
    // relation in that same original ordinal order; retain exact version,
    // name and statement bytes plus full row-count/equality checks below.
    const migrationAfter=(await target.query(`select version::text,name::text,statements from supabase_migrations.schema_migrations
     order by array_position($1::text[],version::text)`,[ledger.map(row=>row.version)])).rows;
    assert.deepEqual(migrationAfter,ledger);
    assert.deepEqual((await target.query('select row_to_json(j)::text row from cron.job j order by jobid')).rows.map(r=>JSON.parse(r.row)),cron);
    const extensionAfter=(await target.query('select e.extname,e.extversion,n.nspname schema_name from pg_extension e join pg_namespace n on n.oid=e.extnamespace order by e.extname')).rows;
    assert.deepEqual(extensionAfter,extensions);
    const targetRelease=(await target.query('select release_id,backend_commit,frontend_commit,migration_head,migration_manifest_sha256 from public.release_deployment_manifest')).rows;
    assert.equal(targetRelease.length,1);assert.equal(targetRelease[0].release_id,originalRelease.release_id);
    const intent={restore_id:randomUUID(),authority_generation:1,retry_of_restore_id:null,archive_digest:binding.archive_digest,
     source_project_ref:binding.project_ref,target_project_ref:binding.project_ref,source_identity_sha256:binding.source_identity_sha256,
     target_migration_head:ledger.at(-1).version,target_release_identity:targetRelease[0],actor:'UNIT same-original immutable DATA fixture',
     approved_at:new Date().toISOString(),expires_at:new Date(Date.now()+15*60*1000).toISOString(),resume_after_verification:false};
    const originalIntentEnvelope={format:'memphis-zoo-production-restore-intent.v1',algorithm:'hmac-sha256',key_id:intentKeyId,intent,
     signature:cryptoApi.signBinding(cryptoApi.restoreIntentBinding(intent),intentKey)};
    const verifiedIntent=cryptoApi.captureVerifiedOriginalRestoreIntent(originalIntentEnvelope,intentKey,intentKeyId);
    assert.deepEqual(verifiedIntent,intent);
    const releaseIdentity={archive:originalRelease,target:targetRelease[0],retry_of_restore_id:intent.retry_of_restore_id};
    const paused=await target.query(`update custodial_dr.restore_control set authority_generation=$1,mutations_paused=true,state='PREPARING',restore_id=$2,
     archive_digest=$3,source_project_ref=$4,target_project_ref=$4,started_by=$5,started_at=clock_timestamp(),release_identity=$6::jsonb
     where singleton=true and state='READY' and not mutations_paused`,
     [intent.authority_generation,intent.restore_id,intent.archive_digest,intent.source_project_ref,intent.actor,JSON.stringify(releaseIdentity)]);
    assert.equal(paused.rowCount,1);
    await target.query('insert into custodial_dr.restore_manifests(restore_id,authority_generation,archive_digest) values($1,$2,$3)',[intent.restore_id,intent.authority_generation,intent.archive_digest]);
    const assertHeld=async()=>{currentSource();assert.deepEqual((await target.query('select pg_backend_pid() pid,txid_current()::text xid')).rows[0],invocation);
     assert.deepEqual((await target.query('select state,mutations_paused,restore_id,archive_digest,release_identity from custodial_dr.restore_control where singleton')).rows[0],
      {state:'PREPARING',mutations_paused:true,restore_id:intent.restore_id,archive_digest:intent.archive_digest,release_identity:releaseIdentity});
     assert.deepEqual((await target.query('select row_to_json(r)::text row from public.custodial_release_authority_restore_inventory r order by inventory_id')).rows,metadataBefore);
     await target.query('select custodial_dr.immutable_import_owner_fence()');};
    await assertHeld();put('DATA_IMPORT_INPUT.json',{source_pins:sourcePins,archive_digest:binding.archive_digest,invocation,intent,
     unit_archive_and_independent_unit_intent:true,all_source_EOFs:eofs,curated_guard_rows:curated,metadata_unchanged_rows:metadataBefore.length-curated,
     control_state:'PREPARING',admission_resumed:false,normal_controller_budget_unchanged:true});
    phase='shipping authenticated immutable DATA importer in same target transaction';requirePins();
    if(immutableContextPlan){
     phase='one read-only current target-shape query plan; no import replay';
     // Same Source/owner/global fence and fresh target, but NO private or
     // ordinary DATA import. Observe the actual current query, not guessed
     // performance settings; do not change JIT, privileges or time budgets.
     await target.query('LOCK TABLE public.custodial_release_authority_restore_inventory IN SHARE MODE');
     const marker='CREATE FUNCTION custodial_dr.immutable_import_target_shape()';
     assert.equal(proposal.split(marker).length,2);
     const definition=proposal.slice(proposal.indexOf(marker));
     const begin=definition.indexOf('AS $fn$')+'AS $fn$'.length,end=definition.indexOf('$fn$;',begin);
     assert.ok(begin>marker.length&&end>begin);
     const query=definition.slice(begin,end);assert.match(query,/^\s*WITH selected_relations AS MATERIALIZED/);
     const settings=(await target.query(`select current_user actor,session_user session_actor,
      pg_backend_pid() pid,txid_current()::text xid,current_setting('jit') jit,
      current_setting('jit_above_cost') jit_above_cost,current_setting('jit_inline_above_cost') jit_inline_above_cost,
      current_setting('jit_optimize_above_cost') jit_optimize_above_cost`)).rows;
     assert.equal(settings.length,1);assert.equal(settings[0].actor,'supabase_admin');
     assert.equal(settings[0].session_actor,'supabase_admin');assert.equal(settings[0].pid,invocation.pid);assert.equal(settings[0].xid,invocation.xid);
     const measured=await target.query('EXPLAIN (ANALYZE, BUFFERS, TIMING TRUE, SUMMARY TRUE, FORMAT JSON) '+query);
     // EXPLAIN's protocol command tag has no affected-row count. Preserve
     // the actual observation before validating its rows, not an INSERT-like
     // rowCount assertion that would discard a successfully returned plan.
     put('CONTEXT_SHAPE_PLAN_OBSERVED.json',{diagnostic_only:true,command:measured.command,
      row_count_tag:measured.rowCount,rows:measured.rows});
     assert.equal(measured.command,'EXPLAIN');assert.equal(measured.rowCount,null);
     assert.equal(measured.rows.length,1);assert.ok(Array.isArray(measured.rows[0]['QUERY PLAN']));
     currentSource();requirePins();
     await target.query('rollback');targetTransaction=false;
     put('CONTEXT_SHAPE_PLAN_RESULT.json',{scope:'ONE_READ_ONLY_ACTUAL_CONTEXT_QUERY_PLAN_NOT_DATA_IMPORT_OR_GATE_PASS',
      settings,query_sha256:sha(query),base_sql_sha256:sha(proposal),actual_plan:measured.rows[0]['QUERY PLAN'],
      transaction:'ROLLED_BACK_WITHOUT_DATA_IMPORT',archive_digest:binding.archive_digest,complete_restore:false,production:false});
    }else{
    // v22 reached the importer only after the four fixed witness probes and
    // cleanup assertions returned. That is retained path evidence, not a
    // completed whole-run/component verdict. The SQL/witness contract is
    // unchanged in this batch-reader join: do not replay those probes here.
    // Shipping begin/mutation/currentness/finish checks remain mandatory.
    const mutationWitnessRefusals=Object.freeze({replayed:false,
     prior_result_sha256:'eccc94dfea394558a9cdb5f24514252fc7d45e693a62fe61ede16fc48aca1525',
     prior_scope:'V22_REACHED_IMPORT_AFTER_PROBE_ASSERTIONS_THEN_TIMEOUT_NOT_COMPONENT_OR_WHOLE_PASS'});
    currentSource();await assertHeld();
    phase='shipping authenticated immutable DATA importer in same target transaction';
    // One bounded, read-only observation through the already-owned original
    // fixture connection. It discriminates an actual SQL wait from local
    // source-reader time if this changed import again reaches its cutoff.
    // No SQL body/parameters or private DATA are persisted; not a test gate,
    // new connection, retry, authority, observer process or polling loop.
    let importWaitObservation=null;
    const importWaitTimer=setTimeout(()=>{
     importWaitObservation=sourceClient.query(`select current_user observer_actor,session_user observer_session,
      a.pid,a.backend_xid::text transaction_id,a.state,a.wait_event_type,a.wait_event,
      extract(epoch from clock_timestamp()-a.query_start)::float8 statement_age_seconds,
      case when a.query like '%begin_immutable_private_import%' then 'ENTRY'
       when a.query like '%finish_immutable_private_import%' then 'FINISH'
       when a.query like '%immutable_import_assert_context%' then 'CONTEXT_READ'
       when a.query like '%stage_immutable_%' then 'STAGE'
       when a.query like '%insert_immutable_%' then 'INSERT'
       else 'OTHER_FIXED_STATEMENT' end statement_kind
      from pg_catalog.pg_stat_activity a where a.pid=$1 and a.datname=current_database()
       and a.usename=session_user`,[invocation.pid])
      .then(result=>put('DATA_IMPORT_SINGLE_WAIT_OBSERVATION.json',{diagnostic_only:true,rows:result.rows}),
       error=>put('DATA_IMPORT_SINGLE_WAIT_OBSERVATION.json',{diagnostic_only:true,observation_unavailable:true,
        code:error?.code||null,message:String(error?.message||error)}));
    },15000);importWaitTimer.unref();
    let imported,primaryImportFailure;
    try{imported=await stageVerifiedImmutablePrivateData({db:target,verifiedArchive:archive,originalIntentEnvelope,intentVerifyKey:intentKey,intentVerifyKeyId:intentKeyId});}
    catch(error){primaryImportFailure=error;throw error;}
    finally{clearTimeout(importWaitTimer);if(importWaitObservation)try{await importWaitObservation;}
     catch(error){if(primaryImportFailure)throw new AggregateError([primaryImportFailure,error],
       'Immutable import and its owned diagnostic settlement failed',{cause:primaryImportFailure});throw error;}}
    // Save the actual returned component before fixture comparison. A later
    // comparator failure must not discard real SQL progress or require an
    // unchanged import solely to recover its already-produced observations.
    put('IMMUTABLE_IMPORT_RETURNED.json',{scope:'ACTUAL_SHIPPING_DATA_FINISH_RETURNED_NOT_COMMIT_OR_WHOLE_RESTORE_PASS',
     imported,archive_digest:binding.archive_digest,source_pins:sourcePins,production:false,
     complete_restore:false,admission_resumed:false,target_rollback_required:targetTransaction});
    phase='compare actual sealed Source catalog projections after importer returned';
    const originalShape=(await target.query(originalTargetShapeQuery)).rows;
    const setwiseShape=(await target.query('select custodial_dr.immutable_import_target_shape() as jsonb_build_object')).rows;
    put('TARGET_SHAPE_OBSERVED.json',{scope:'ACTUAL_READ_ONLY_SOURCE_CATALOG_DATA_NOT_AUTHORITY',
     archive_digest:binding.archive_digest,original:originalShape,compact:setwiseShape,production:false});
    assert.equal(originalShape.length,1);assert.equal(Object.keys(originalShape[0]).length,1);
    assert.equal(setwiseShape.length,1);assert.deepEqual(Object.keys(setwiseShape[0]),['jsonb_build_object']);
    const expandedShape=[{jsonb_build_object:expandImmutableTargetShapeTriggerDictionary(setwiseShape[0].jsonb_build_object)}];
    assert.deepEqual(expandedShape,originalShape,'Compact target shape must retain every sealed original complete catalog attribute');
    await assertHeld();
    for(const table of selected.databaseTables){const n=(await target.query('select count(*)::text n from ONLY '+qualified(table))).rows[0].n;
     assert.equal(n,table.schema_name==='public'&&table.table_name==='release_deployment_manifest'?'1':table.row_count);}
    assert.equal(imported.transaction_authority,false);assert.equal(imported.admission_resumed,false);
    phase='new fixed-original context source guard refusals after actual import';
    const fixedSourceRefusals=await assertImmutableImportContextSourceLocked(target,invocation);
    assert.equal(fixedSourceRefusals.refusals,4);await assertHeld();
    phase='new retry-history denial guard against actual canonical private control tables';
    const {refuseUnreconciledImmutableRetry}=await import(B+'/scripts/disaster-recovery-state.mjs');
    const retryHistoryCases=[];let retryProbeAttempted=false,retryProbeFailure=null;
    try{
     retryProbeAttempted=true;await target.query('SAVEPOINT immutable_retry_history_probe');
     const changed=await target.query("update custodial_dr.restore_control set state='PAUSED_FAILURE' where singleton and restore_id=$1 and authority_generation=$2 and mutations_paused and state='PREPARING'",
      [intent.restore_id,String(intent.authority_generation)]);assert.equal(changed.rowCount,1);
     await target.query("insert into custodial_dr.restore_events(restore_id,authority_generation,phase,outcome,actor,evidence_json) values($1,$2,'UNIT_RETRY_READ_PROFILE','FAILED',$3,'{}'::jsonb)",
      [intent.restore_id,String(intent.authority_generation),intent.actor]);
     for(const kind of ['known_legacy_denial_only_read','unknown_history_refuses','committed_private_marker_refuses','foreign_generation_refuses']){
      let caseAttempted=false,caseFailure=null;const cleanup=[];
      try{
       caseAttempted=true;await target.query('SAVEPOINT immutable_retry_history_case');
       if(kind==='unknown_history_refuses')await target.query("insert into custodial_dr.restore_events(restore_id,authority_generation,phase,outcome,actor,evidence_json) values($1,$2,'UNIT_UNKNOWN_HISTORY_PROFILE','FAILED',$3,$4::jsonb)",
        [intent.restore_id,String(intent.authority_generation),intent.actor,JSON.stringify({outcome:'UNKNOWN',retry_safe:false})]);
       if(kind==='committed_private_marker_refuses'){
        // Contrived negative marker inside this rollback-only fixture, NOT a
        // COMMIT observation or permission to expose this restored target.
        const marked=await target.query('update custodial_dr.restore_manifests set database_verified=true,database_evidence=$2::jsonb where restore_id=$1',
         [intent.restore_id,JSON.stringify({original_data_import:imported})]);assert.equal(marked.rowCount,1);
       }
       const generation=kind==='foreign_generation_refuses'?(BigInt(intent.authority_generation)+1n).toString():String(intent.authority_generation);
       let result,refusal;try{result=await refuseUnreconciledImmutableRetry(target,{restoreId:intent.restore_id,generation});}catch(error){refusal=error;}
       if(kind==='known_legacy_denial_only_read'){if(refusal)throw refusal;assert.equal(result,undefined);}
       else{
        assert.equal(refusal?.code,'RESTORE_RETRY_RECONCILIATION_REQUIRED');assert.equal(refusal?.outcome,'UNKNOWN');assert.equal(refusal?.retry_safe,false);
        assert.match(refusal.message,kind==='foreign_generation_refuses'?/original history binding is incomplete or contradictory/:/original history contains uncertain, committed private DATA, or contradictory evidence/);
        assert.deepEqual(refusal.requested_original_restore,{restore_id:intent.restore_id,authority_generation:generation});
        assert.ok(Object.isFrozen(refusal.requested_original_restore));
       }
      }catch(error){caseFailure=error;}
      if(caseAttempted){
       try{await target.query('ROLLBACK TO SAVEPOINT immutable_retry_history_case');}catch(error){cleanup.push(error);}
       try{await target.query('RELEASE SAVEPOINT immutable_retry_history_case');}catch(error){cleanup.push(error);}
      }
      if(cleanup.length)throw new AggregateError(caseFailure?[caseFailure,...cleanup]:cleanup,'Retry-history case cleanup failed',{cause:caseFailure??cleanup[0]});
      if(caseFailure)throw caseFailure;retryHistoryCases.push(kind);
     }
    }catch(error){retryProbeFailure=error;throw error;}
    finally{
     const cleanup=[];
     if(retryProbeAttempted){
      try{await target.query('ROLLBACK TO SAVEPOINT immutable_retry_history_probe');}catch(error){cleanup.push(error);}
      try{await target.query('RELEASE SAVEPOINT immutable_retry_history_probe');}catch(error){cleanup.push(error);}
     }
     try{await assertHeld();}catch(error){cleanup.push(error);}
     if(cleanup.length)throw new AggregateError(retryProbeFailure?[retryProbeFailure,...cleanup]:cleanup,'Retry-history probe cleanup failed',{cause:retryProbeFailure??cleanup[0]});
    }
    assert.equal(retryHistoryCases.length,4);currentSource();requirePins();
    put('RETRY_HISTORY_SQL_READ_RESULT.json',{scope:'NEW_ADDITIONAL_DENIAL_GUARD_ACTUAL_CANONICAL_SQL_READ_NOT_RETRY_ADMISSION',
     cases:retryHistoryCases,case_count:4,profile_changes_rolled_back:true,original_control_held:true,
     marker_profile_is_not_commit_proof:true,retry_authority:false,production:false});
    await target.query('rollback');targetTransaction=false;
    put('PRODUCT_RESULT.json',{scope:'NEW changed shipping immutable DATA import of retained authenticated v16 full four-schema original, same exclusive fresh fixture transaction',
     imported,mutation_witness_refusals:mutationWitnessRefusals,fixed_source_refusals:fixedSourceRefusals,retry_history_SQL_cases:retryHistoryCases,complete_schema_projection_equivalence:true,
     original_catalog_projection_utf8_bytes:Buffer.byteLength(JSON.stringify(originalShape)),
     compact_catalog_projection_utf8_bytes:Buffer.byteLength(JSON.stringify(setwiseShape)),
     original_producer_replayed:false,source_sha256:sha(bytes),restored,owner,archive_digest:binding.archive_digest,source_members:eofs,
     transaction:'ROLLED_BACK_AFTER_ACTUAL_IMPORT_AND_READBACK',committed_DATA_restore:false,complete_restore:false,admission_resumed:false,production:false});
    }
   }catch(error){
    firstFailure=error;
    put('IMMUTABLE_DATA_FIRST_FAILURE.json',{phase,code:error?.code||null,sql_state:error?.sql_state||null,message:String(error?.message||error),detail:error?.detail||null,
     source_retained:source,target_rollback_required:targetTransaction,no_fallback:true,sql_success_claimed:false});
    throw error;
   }finally{
    const cleanupFailures=[];
    try{requirePins();}catch(error){cleanupFailures.push(error);}
    if(targetTransaction)try{await target.query('rollback');targetTransaction=false;}catch(error){cleanupFailures.push(error);}
    if(snapshot)try{await sourceClient.query('rollback');}catch(error){cleanupFailures.push(error);}
    if(target){try{await target.end();}catch(error){cleanupFailures.push(error);}clients.delete(target);}
    try{await sourceClient.end();}catch(error){cleanupFailures.push(error);}clients.delete(sourceClient);
    if(archive)try{archive.cleanup();}catch(error){cleanupFailures.push(error);}
    if(cleanupFailures.length)throw new AggregateError(firstFailure?[firstFailure,...cleanupFailures]:cleanupFailures,
     'Original immutable fixture cleanup failed',firstFailure?{cause:firstFailure}:undefined);
   }
  }else if(stage==='finish'&&immutableBoundOwnerContext){
   // A distinct, predeclared ORIGINAL-source-owner qualification, not a retry
   // of the refused postgres operation under another connection. Schema/guard
   // ownership, authentication, grants and HBA are never repaired by this case.
   // The controller separately pins the exact reviewed proposal Source bytes.
   phase='new fixed original-object-owner proposal and transaction fence';
   const proposal=fs.readFileSync(B+'/proposals/immutable-private-owner-context.sql','utf8');
   assert.equal(sha(proposal),'e5fc09dca7dc5a691b85e5d8aa78b710c437a1faae4f43430d4f7a9a16e2155d');
   assert.match(proposal,/COMMIT;\s*$/);
   const names=[...proposal.matchAll(/^CREATE FUNCTION custodial_dr\.([a-z_]+)\(/gm)].map(x=>x[1]).sort();
   assert.equal(names.length,11);assert.equal(new Set(names).size,11);
   const original=new Client({...options,user:'supabase_admin'});clients.add(original);original.on('error',()=>{});
   let rolledBack=false;
   try{
    await original.connect();
    const identity=(await original.query(`select current_user actor,session_user session_actor,current_database() database,
     (select pg_get_userbyid(datdba) from pg_database where datname=current_database()) database_owner,
     (select pg_get_userbyid(nspowner) from pg_namespace where nspname='custodial_dr') dr_namespace_owner,
     (select pg_get_userbyid(relowner) from pg_class where oid='custodial_dr.restore_control'::regclass) control_owner,
     (select pg_get_userbyid(relowner) from pg_class where oid='custodial_release_identity.employee_message_original_outcomes'::regclass) employee_owner,
     (select pg_get_userbyid(relowner) from pg_class where oid='custodial_release_identity.group_original_creations'::regclass) group_owner,
     (select pg_get_userbyid(proowner) from pg_proc where oid='custodial_release_identity.guard_group_original_creation()'::regprocedure) group_guard_owner,
     (select pg_get_userbyid(proowner) from pg_proc where oid='custodial_dr.guard_application_mutation()'::regprocedure) ordinary_guard_owner`)).rows[0];
    assert.deepEqual(identity,{actor:'supabase_admin',session_actor:'supabase_admin',database:'postgres',database_owner:'postgres',
     dr_namespace_owner:'postgres',control_owner:'supabase_admin',employee_owner:'supabase_admin',group_owner:'supabase_admin',
     group_guard_owner:'supabase_admin',ordinary_guard_owner:'supabase_admin'});
    put('FIXED_ORIGINAL_OBJECT_OWNER.json',{identity,operator:'predeclared normal Source creating owner, not selected after refusal',
     role_switches:0,connection_fallbacks:0,owner_changes:0,grant_changes:0,HBA_changes:0});
    await original.query("set statement_timeout='12s';set lock_timeout='2s'");
    // History rows are fixture prerequisites only, from the same exact replay.
    await original.query('create schema supabase_migrations;create table supabase_migrations.schema_migrations(version text primary key,name text not null,statements text[] not null default \'{}\')');
    for(const file of plan.files)await original.query('insert into supabase_migrations.schema_migrations(version,name) values($1,$2)',[file.slice(0,14),file.slice(15,-4)]);
    await original.query(proposal.replace(/COMMIT;\s*$/,''));
    const compiled=(await original.query(`select proname,prosecdef,pg_get_userbyid(proowner) owner from pg_proc
     where pronamespace='custodial_dr'::regnamespace and proname=any($1::text[]) order by proname`,[names])).rows;
    assert.deepEqual(compiled.map(x=>x.proname),names);
    assert.ok(compiled.every(x=>x.prosecdef===false&&x.owner===identity.actor));
    const boundaries=(await original.query(`select c.relname,c.relrowsecurity,c.relforcerowsecurity,
     pg_get_userbyid(c.relowner) owner,
     (select count(*)::int from aclexplode(coalesce(c.relacl,acldefault('r',c.relowner))) a where a.grantee<>c.relowner) foreign_grants,
     (select count(*)::int from pg_trigger t where t.tgrelid=c.oid and not t.tgisinternal and t.tgenabled<>'A') non_always_guards
     from pg_class c where c.oid=any(array[
      'custodial_release_identity.employee_message_original_outcomes'::regclass,
      'custodial_release_identity.group_original_creations'::regclass,
      'custodial_dr.immutable_private_import_context'::regclass,
      'custodial_dr.immutable_private_import_rows'::regclass,
      'custodial_dr.immutable_ordinary_import_rows'::regclass]) order by c.relname`)).rows;
    assert.equal(boundaries.length,5);
    assert.ok(boundaries.every(x=>x.relrowsecurity&&x.relforcerowsecurity&&x.owner===identity.actor&&x.foreign_grants===0&&x.non_always_guards===0));
    assert.equal((await original.query(`select count(*)::int n from pg_proc p cross join lateral
     aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where p.pronamespace='custodial_dr'::regnamespace
      and p.proname=any($1::text[]) and a.grantee<>p.proowner`,[names])).rows[0].n,0);
    await original.query('savepoint missing_global_fence');
    await assert.rejects(original.query('select custodial_dr.immutable_import_owner_fence()'),e=>e.code==='55000');
    await original.query('rollback to savepoint missing_global_fence');
    await original.query("select pg_advisory_xact_lock(pg_catalog.hashtextextended('memphis-zoo-application-mutation-fence',0))");
    await original.query('select custodial_dr.immutable_import_owner_fence()');
    const shape=(await original.query('select custodial_dr.immutable_import_target_shape() shape')).rows[0].shape;
    await original.query('rollback');rolledBack=true;
    assert.equal((await original.query("select to_regclass('custodial_dr.immutable_private_import_context') missing")).rows[0].missing,null);
    const ownerPrologue=proposal.match(/DO \$owner\$[\s\S]*?END \$owner\$;/)?.[0];
    assert.ok(ownerPrologue&&!ownerPrologue.includes('$mismatch_source$'));
    const denied=peerSQL(peerIdentity+`do $mismatch$ begin begin
     execute $mismatch_source$${ownerPrologue}$mismatch_source$;
     raise exception 'Mismatched postgres caller was accepted';
     exception when sqlstate '42501' then null;end;
     if to_regclass('custodial_dr.immutable_private_import_context') is not null
      then raise exception 'Mismatch created private context';end if;end $mismatch$;`);
    put('MISMATCHED_ORIGINAL_CALLER_REFUSAL.stdout',denied);
    put('PRODUCT_RESULT.json',{checks:['NEW exact original-object-owner Source proposal compiles without privilege/ownership changes',
     'NEW original owner without exclusive global fence refuses55000','NEW same original owner plus actual transaction-held fence accepted',
     'NEW rollback removes draft objects and guard changes','NEW changed Source prologue still refuses mismatched original postgres caller42501 without effects'],identity,compiled,boundaries,shape,proposal_sha256:sha(proposal),
     private_DATA_import:'NOT_RUN',complete_restore:false,production:false,connection_fallbacks:0,grant_role_owner_HBA_changes:0});
   }catch(error){await original.query('rollback').catch(()=>{});rolledBack=true;throw error;}
   finally{if(!rolledBack)await original.query('rollback').catch(()=>{});await original.end().catch(()=>{});clients.delete(original);}
  }else if(stage==='finish'){
   phase='current immutable proposal compile and missing-global-fence refusal under original OS-peer owner';
   const proposal=fs.readFileSync(B+'/proposals/immutable-private-owner-context.sql','utf8');
   assert.equal(sha(proposal),'46026287b404221da937022300cce4fbc0b8b5ade822b954c8eeb1c339bf8aaa');
   assert.match(proposal,/COMMIT;\s*$/);
   const names=[...proposal.matchAll(/^CREATE FUNCTION custodial_dr\.([a-z_]+)\(/gm)].map(x=>x[1]).sort();
   assert.equal(names.length,11);assert.equal(new Set(names).size,11);
   const functions="ARRAY["+names.map(n=>"'"+n+"'").join(',')+"]::text[]";
   const history="create schema supabase_migrations;create table supabase_migrations.schema_migrations(version text primary key,name text not null,statements text[] not null default '{}');\n"+
    plan.files.map(file=>`insert into supabase_migrations.schema_migrations(version,name) values('${file.slice(0,14)}','${file.slice(15,-4)}');`).join('\n');
   const checksSQL=`do $compiled$ begin
    if (select count(*) from pg_proc where pronamespace='custodial_dr'::regnamespace and proname=any(${functions}))<>11
     or exists(select 1 from pg_proc where pronamespace='custodial_dr'::regnamespace and proname=any(${functions}) and (prosecdef or proowner<>(select oid from pg_roles where rolname='postgres')))
    then raise exception 'Current eleven private invoker functions not compiled under original owner';end if;
    begin perform custodial_dr.immutable_import_owner_fence();
     raise exception 'Missing actual exclusive global fence was accepted';
    exception when sqlstate '55000' then null;end;
    end $compiled$;
    rollback;
    do $rollback$ begin if to_regclass('custodial_dr.immutable_private_import_context') is not null
     then raise exception 'Private draft objects survived rollback';end if;end $rollback$;`;
   // Named psql progress markers only, not SQL/body rewrites or assertions.
   // Preserve the original diagnostic instead of collapsing42601 to a code.
   const compileSource=proposal.replace(/COMMIT;\s*$/,'').replace(/^CREATE FUNCTION custodial_dr\.([a-z_]+)\(/gm,
    (line,name)=>'\\echo ORIGINAL_PROPOSAL_FUNCTION '+name+'\n'+line);
   const readback=peerSQL(peerIdentity+history+compileSource+'\n'+checksSQL);
   fs.writeFileSync(out+'/ORIGINAL_OWNER_PROPOSAL.stdout',readback,{flag:'wx',mode:0o600});
   put('PRODUCT_RESULT.json',{checks:['Current283 exact migrations under original managed OS-peer owner with automatic grants absent','Current eleven proposal invoker functions compile under original owner','Missing actual exclusive global fence refuses','Rollback removes private draft objects'],
    identity:{actor:'postgres',session_actor:'postgres',OS_peer:'postgres',superuser:false},
    proposal_sha256:sha(proposal),replay_sha256:plan.manifestSha256,functions:names,
    private_DATA_import:'NOT_RUN',complete_restore:false,production:false,role_grants_changed:false,HBA_changed:false});
  }
  console.log(stage==='start'?'SCHEMA200_NORMAL_SOURCE_OWNER_READY':'CURRENT_IMMUTABLE_OWNER_PROPOSAL_COMPILED_NOT_DATA_RESTORE');
  process.exit(0);
 }
 const ownerStartupErrors=[];
 for(let n=0,ready=0;n<40;n++){const c=new Client(options);c.on('error',()=>{});
  try{await c.connect();if((await c.query("select count(*)::int n from pg_roles where rolname in ('anon','authenticated','service_role','supabase_admin')")).rows[0].n===4){if(++ready===4){admin=c;break;}}else ready=0;}catch(error){ready=0;if(immutableOwnerContext)ownerStartupErrors.push({code:error.code??null,message:error.message});}
  await c.end().catch(()=>{});await new Promise(r=>setTimeout(r,500));
 }if(immutableOwnerContext)put('ORIGINAL_OWNER_CONNECTION_RESULT.json',{connected:!!admin,errors:ownerStartupErrors,credential_source:'original ephemeral fixture bootstrap only',alternate_role_used_for_application:false});
 assert.ok(admin);
 if(stage==='start')await admin.query(revoke);
 for(const file of stage==='start'?plan.files.slice(0,200):plan.files.slice(200,recoveryRegistrationStatus?273:recoveryRegistration?271:recoveryPreparation?270:undefined)){
  phase='schema '+file;const bytes=fs.readFileSync(B+'/supabase/migrations/'+file);
  if(recoveryNativeCompletion&&file==='20261015040830_same_original_retained_completion_read.sql'){
   // First concrete predecessor mismatch: inspect ONLY its retained grant
   // representation before DDL. No replayed guard is skipped or rewritten.
   const diagnostic=(await admin.query(`select i.restore_order,i.object_identity,i.definition_sql,
     i.definition_sha256,public.custodial_release_authority_current_grant_definition(i.object_identity) current_grant,
     public.static_weekly_digest_text(public.custodial_release_authority_current_grant_definition(i.object_identity)) current_grant_sha256,
     p.proowner::regrole::text owner,p.proacl::text acl
     from public.custodial_release_authority_restore_inventory i join pg_proc p
       on p.oid=to_regprocedure(i.object_identity)
     where i.object_kind='grant' and i.object_identity like '%(%'
       and p.oid='public.custodial_release_canary_authority_surface()'::regprocedure`)).rows;
   put('COMPLETION_CANARY_GRANT_PREDECESSOR.json',{diagnostic,mutating_SQL:false,guard_preserved:true});
  }
  if(!currentSchema&&!immutableOwnerContext)assert.equal(sha(bytes),sha(fs.readFileSync(oldRoot+'/supabase/migrations/'+file)));
  if(purpose==='staffing-schema'&&file==='20261012004258_staffing_absence_cancellation_target_fields.sql'){
   const identity='public.static_weekly_v3_read_manager_snapshot(date)';
   const diagnosis=(await admin.query("select (select jsonb_agg(to_jsonb(s)) from public.custodial_release_canary_authority_surface() s where s.object_kind in('function','grant') and s.object_identity like '%(%' and to_regprocedure(s.object_identity)=$1::regprocedure) canary_rows,(select jsonb_agg(jsonb_build_object('kind',i.object_kind,'identity',i.object_identity,'sha256',i.definition_sha256,'hash_matches',i.definition_sha256=public.static_weekly_digest_text(i.definition_sql))) from public.custodial_release_authority_restore_inventory i where i.object_kind in('function','grant') and i.object_identity like '%(%' and to_regprocedure(i.object_identity)=$1::regprocedure) inventory_rows,(select count(*) from public.custodial_release_authority_restore_inventory where definition_sha256 is distinct from public.static_weekly_digest_text(definition_sql)) bad_inventory_hashes",[identity])).rows[0];
   put('SNAPSHOT_CANARY_PREDECESSOR.json',diagnosis);
  }
  try{await admin.query(bytes.toString());}
  catch(error){
   if(consoleOriginal&&file==='20261013113033_gemini_original_turn_preservation.sql'){
    await admin.query('rollback');
    const diagnostic=(await admin.query(`select p.oid::regprocedure::text identity,
      public.static_weekly_digest_text(p.prosrc) body_sha256,octet_length(convert_to(p.prosrc,'UTF8')) body_bytes,
      (select count(*) from public.custodial_release_authority_restore_inventory i where i.object_kind='function'
        and i.object_identity like '%(%' and to_regprocedure(i.object_identity)=p.oid) registered_functions,
      (select count(*) from public.custodial_release_authority_restore_inventory i where i.object_kind='function'
        and i.object_identity like '%(%' and to_regprocedure(i.object_identity)=p.oid and i.definition_sql=pg_get_functiondef(p.oid)) exact_functions,
      (select count(*) from public.custodial_release_authority_restore_inventory i where i.object_kind='grant'
        and i.object_identity like '%(%' and to_regprocedure(i.object_identity)=p.oid) registered_grants,
      (select count(*) from public.custodial_release_authority_restore_inventory i where i.definition_sha256
        is distinct from public.static_weekly_digest_text(i.definition_sql)) bad_inventory_hashes
      from pg_proc p where p.oid in('public.gemini_console_begin_turn(uuid,uuid,uuid,text,uuid[],uuid)'::regprocedure,
        'public.gemini_console_complete_turn(uuid,text,text,text,uuid,jsonb)'::regprocedure)`)).rows;
    put('CONSOLE_269_PREDECESSOR_FAILURE.json',{diagnostic,guard_preserved:true,qualification_pass:false});
   }
   if(purpose==='feedback'&&file==='20261011214943_custodial_feedback_triage_receipt_reader.sql'){
    await admin.query('rollback');
    // Diagnosis ONLY inside a rolled-back disposable transaction. Keep the
    // product safety assertion intact; never invoke or commit this reader.
    const prefix=bytes.toString().split('-- Abort rather than silently inherit')[0];
    try{await admin.query(prefix);
     const info=(await admin.query("select current_user creator,pg_get_userbyid(p.proowner) reader_owner,pg_get_userbyid(w.proowner) writer_owner,array(select jsonb_build_object('grantee',case when a.grantee=0 then 'PUBLIC' else pg_get_userbyid(a.grantee) end,'privilege',a.privilege_type,'grantable',a.is_grantable) from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a) acl from pg_proc p cross join pg_proc w where p.oid='public.custodial_feedback_triage_receipt(uuid,uuid,uuid,uuid,text,text)'::regprocedure and w.oid='public.custodial_feedback_triage(uuid,uuid,uuid,uuid,text,text)'::regprocedure")).rows;
     put('FAILED_READER_OWNER_ACL_DIAGNOSIS.json',{info,product_guard_not_changed:true,reader_invoked:false,accepted:false,rollback_required:true});
    }finally{await admin.query('rollback');}
   }
   throw error;
  }
  if((await admin.query(defaults)).rows[0].n!==0){assert.equal(sha(bytes),DEFAULT_EXCEPTIONS[file]);assert.ok(!/\bcreate\s+(?:unlogged\s+)?(?:table|sequence)\b/i.test(bytes.toString()));await admin.query(revoke);}
  assert.equal((await admin.query(defaults)).rows[0].n,0);replayed.push(file);
 }
 put('SCHEMA_'+stage+'.json',{replayed,old_tests_NOT_repeated:true});
 if(immutableOwnerContext&&stage==='finish'){
  // Same existing restore-drill migration-history prerequisite. Only versions
  // whose actual exact bytes were replayed above are recorded; no invented
  // production target/source identity, ownership or restore admission.
  await admin.query("create schema supabase_migrations");
  await admin.query("create table supabase_migrations.schema_migrations(version text primary key,name text not null,statements text[] not null default '{}')");
  for(const file of plan.files)await admin.query("insert into supabase_migrations.schema_migrations(version,name) values($1,$2)",[file.slice(0,14),file.slice(15,-4)]);
 }
 if(stage==='start') {console.log('SCHEMA200_READY');}
 else {
 if(privateFunctionCatalog){
   phase='ONE current canonical283 production private-function catalog READ ONLY snapshot';
   const catalogSource=B+'/scripts/schema-fingerprint-catalog.mjs',readerSource=B+'/scripts/schema-catalog-readonly-client.mjs';
   const catalogHash=sha(fs.readFileSync(catalogSource)),readerHash=sha(fs.readFileSync(readerSource));
   assert.equal(catalogHash,'de073aac8ee59679c95b632a2131d4341392d875060b98aad843698f1fe0218d');
   assert.equal(readerHash,'c0aa6989d893e399a2f50841c2fa17dec8c5a435a9290071f782b1dc3db9288b');
   const {captureSchemaCatalog,fingerprintSchemaCatalog,stableSchemaJson,SCHEMA_CATALOG_QUERIES}=await import(pathToFileURL(catalogSource));
   const {NATIVE_CRON_CATALOG_SQL}=await import(pathToFileURL(readerSource));
   // Same fixed direct cron-table projection as the normal release reader.
   // Do not execute even the metadata helper, nor any custodial_recovery
   // function, merely to qualify function/ACL catalog custody.
   const jsonRows=async sql=>{
    const result=await admin.query("select coalesce(json_agg(row_to_json(q)),'[]'::json) as catalog_rows from ("+sql+") q");
    assert.equal(result.rows.length,1);assert.ok(Array.isArray(result.rows[0].catalog_rows));return result.rows[0].catalog_rows;
   };
   let rolledBack=false;
   await admin.query('begin isolation level repeatable read read only deferrable');
   try{
    await admin.query('set local row_security = off');
    const context=(await admin.query("select current_user actor,session_user session_actor,current_database() database,current_setting('transaction_read_only') readonly")).rows[0];
    assert.deepEqual(context,{actor:'supabase_admin',session_actor:'supabase_admin',database:'postgres',readonly:'on'});
    const catalog=await captureSchemaCatalog({query:async sql=>({rows:await jsonRows(
     sql===SCHEMA_CATALOG_QUERIES.cron_jobs?NATIVE_CRON_CATALOG_SQL:sql)})});
    const originals=await jsonRows(`select n.nspname as schema_name,p.proname as function_name,
     pg_get_function_identity_arguments(p.oid) as identity_arguments,pg_get_userbyid(p.proowner) as raw_owner,
     case when pg_get_userbyid(p.proowner) in ('postgres','supabase_admin') then 'migration_owner'
       else pg_get_userbyid(p.proowner) end as owner_name,
     pg_get_functiondef(p.oid) as definition,obj_description(p.oid,'pg_proc') as object_comment,
     p.prosecdef,p.proconfig
     from pg_namespace n join pg_proc p on p.pronamespace=n.oid
     where n.nspname in ('public','custodial_recovery')
     order by n.nspname,p.proname,pg_get_function_identity_arguments(p.oid)`);
    const keys=['schema_name','function_name','identity_arguments','owner_name','definition','object_comment'];
    assert.deepEqual(stableSchemaJson(catalog.functions),stableSchemaJson(originals.map(row=>Object.fromEntries(keys.map(key=>[key,row[key]])))));
    const identity=row=>JSON.stringify([row.schema_name,row.function_name,row.identity_arguments]);
    assert.equal(new Set(catalog.functions.map(identity)).size,originals.length);
    const privateFunctions=originals.filter(row=>row.schema_name==='custodial_recovery');
    assert.ok(privateFunctions.length>0);assert.ok(originals.some(row=>row.schema_name==='public'));
    // The first failed live run retained no header. Save bounded ORIGINAL
    // header bytes-as-text/native properties before interpreting any options.
    // This snapshot is evidence only; exact full-definition equality above
    // and native pg_proc comparisons below remain the security assertions.
    const headerSnapshot=row=>{
     const boundary=/^(?:AS |BEGIN |RETURN )/m.exec(row.definition);
     const header=boundary?row.definition.slice(0,boundary.index):row.definition;
     return {schema_name:row.schema_name,function_name:row.function_name,
      identity_arguments:row.identity_arguments.slice(0,1024),identity_arguments_truncated:row.identity_arguments.length>1024,
      definition_sha256:sha(row.definition),header_length:header.length,original_header:header.slice(0,4096),header_truncated:header.length>4096,
      body_boundary_found:!!boundary,prosecdef:row.prosecdef,
      proconfig:row.proconfig===null?null:row.proconfig.slice(0,16).map(value=>({original:value.slice(0,512),truncated:value.length>512})),
      proconfig_count:(row.proconfig??[]).length};
    };
    put('PRIVATE_FUNCTION_CATALOG_HEADERS.json',{source:'original pg_get_functiondef / pg_proc in same READ ONLY snapshot',
     function_count:privateFunctions.length,snapshot_limit:128,omitted_functions:Math.max(0,privateFunctions.length-128),
     headers:privateFunctions.slice(0,128).map(headerSnapshot)});
    for(const row of privateFunctions){
     // These pg_proc properties are represented by the exact captured DDL,
     // not new fingerprint columns or fictitious privilege marker rows.
     try{
      const header=privateCatalogFunctionHeader(row.definition);
      assert.equal(header.securityDefiner,row.prosecdef);
      assert.equal(header.searchPath,(row.proconfig??[]).some(value=>value.startsWith('search_path=')));
     }catch(error){put('PRIVATE_FUNCTION_CATALOG_HEADER_FAILURE.json',headerSnapshot(row));throw error;}
    }
    const routineAcl=await jsonRows(`select n.nspname as schema_name,p.proname as function_name,
     pg_get_function_identity_arguments(p.oid) as identity_arguments,
     case when a.grantee in ('postgres'::regrole,'supabase_admin'::regrole) then 'migration_owner'
       when a.grantee=0 then 'PUBLIC' else pg_get_userbyid(a.grantee) end as grantee,
     case when pg_get_userbyid(a.grantor) in ('postgres','supabase_admin') then 'migration_owner'
       else pg_get_userbyid(a.grantor) end as grantor,a.privilege_type,a.is_grantable
     from pg_namespace n join pg_proc p on p.pronamespace=n.oid
     cross join lateral aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a
     where n.nspname in ('public','custodial_recovery') and (n.nspname='custodial_recovery'
       or a.grantee not in ('postgres'::regrole,'supabase_admin'::regrole))
     order by n.nspname,p.proname,pg_get_function_identity_arguments(p.oid),grantee,grantor,a.privilege_type`);
    assert.deepEqual(stableSchemaJson(catalog.routine_grants),stableSchemaJson(routineAcl));
    const schemaAcl=await jsonRows(`select n.nspname as schema_name,
     case when a.grantee in ('postgres'::regrole,'supabase_admin'::regrole) then 'migration_owner'
       when a.grantee=0 then 'PUBLIC' else pg_get_userbyid(a.grantee) end as grantee,
     case when pg_get_userbyid(a.grantor) in ('postgres','supabase_admin') then 'migration_owner'
       else pg_get_userbyid(a.grantor) end as grantor,a.privilege_type,a.is_grantable
     from pg_namespace n cross join lateral aclexplode(coalesce(n.nspacl,acldefault('n',n.nspowner))) a
     where n.nspname in ('public','custodial_recovery') order by n.nspname,grantee,grantor,a.privilege_type`);
    assert.deepEqual(stableSchemaJson(catalog.schema_grants),stableSchemaJson(schemaAcl));
    assert.ok(routineAcl.some(row=>row.schema_name==='custodial_recovery'));
    assert.ok(schemaAcl.some(row=>row.schema_name==='custodial_recovery'));
    const fingerprint=fingerprintSchemaCatalog(catalog).fingerprint;assert.match(fingerprint,/^[a-f0-9]{64}$/);
    assert.deepEqual((await admin.query("select current_user actor,session_user session_actor,current_database() database,current_setting('transaction_read_only') readonly")).rows[0],context);
    assert.equal(sha(fs.readFileSync(catalogSource)),catalogHash);assert.equal(sha(fs.readFileSync(readerSource)),readerHash);
    await admin.query('rollback');rolledBack=true;
    checks.push('NEW283 production catalog contains every actual private overload/owner/exact security-definition bytes and expanded routine/schema ACL member in one verified READ ONLY snapshot');
    witness.push({...context,scope:'ONLY_PRIVATE_FUNCTION_CATALOG_CAPTURE',transaction_rolled_back:true});
    put('PRODUCT_RESULT.json',{scope:'NEW283_READ_ONLY_PRIVATE_HELPER_CATALOG_CAPTURE_NOT_RESTORE_OR_ACK',
     checks,source:{backend_commit:'ed5f4023a4238e98778de32262209b7f35f311dc',canonical:plan.manifestSha256,
      catalog_sha256:catalogHash,normal_reader_sha256:readerHash},
     transactions:witness,catalog,fingerprint,original_function_catalog:originals,
     private_function_identities:privateFunctions.map(identity),private_function_count:privateFunctions.length,
     original_routine_acl:routineAcl,original_namespace_acl:schemaAcl,
     security_properties_retained_in:'exact pg_get_functiondef bytes; prosecdef/proconfig independently observed, not added to fingerprint format',
     independent_namespace_owner_property:'NOT_REPRESENTED_BY_EXISTING_FORMAT',
     actual_SQL:true,normal_schema_fixture_only:true,old_groups_repeated:false,
     private_function_calls:0,target_data_writes:0,restore:false,native:false,HTTP:false,ACK:false,finalizer:false,key_removal:false});
    console.log('NEW_PRIVATE_HELPER_CATALOG_ACTUAL_READ_ONLY_CAPTURE_COMPLETE_NOT_RESTORE_OR_ACK');
   }catch(error){await admin.query('rollback').catch(()=>{});rolledBack=true;throw error;}
   finally{if(!rolledBack)await admin.query('rollback');}
 }else if(privateSchemaOwnerCatalog){
   phase='ONE current canonical283 production namespace-owner catalog READ ONLY snapshot';
   const {fingerprintSchemaCatalog}=await import(pathToFileURL(B+'/scripts/schema-fingerprint-catalog.mjs'));
   // This unchanged normal reader calls captureSchemaCatalog on THIS same
   // snapshot, including unsupported-object refusal and row_security=off.
   const {captureCatalogFromSnapshot}=await import(pathToFileURL(B+'/scripts/schema-catalog-readonly-client.mjs'));
   const sourcePins=()=>{for(const [file,digest]of Object.entries(schemaOwnerInputPins))assert.equal(sha(fs.readFileSync(path.join(B,file))),digest);};
   const readContext=async()=>{
    const result=await admin.query("select current_user actor,session_user session_actor,current_database() database,current_setting('transaction_read_only') readonly,current_setting('transaction_isolation') isolation,current_setting('row_security') row_security");
    assert.equal(result.rows.length,1);return result.rows[0];
   };
   let rolledBack=false;
   sourcePins();
   await admin.query('begin isolation level repeatable read read only deferrable');
   try{
    await admin.query('set local row_security = off');
    const context=await readContext();
    assert.deepEqual(context,{actor:'supabase_admin',session_actor:'supabase_admin',database:'postgres',readonly:'on',isolation:'repeatable read',row_security:'off'});
    const catalog=await captureCatalogFromSnapshot(admin);
    // Independent native owner observation, not the capture query nor an ACL
    // or function-owner substitute. Empty/filtered/unavailable is NOT absence.
    const originalOwners=(await admin.query(`select n.nspname as schema_name,
     pg_get_userbyid(n.nspowner) as raw_owner_name
     from pg_catalog.pg_namespace n where n.nspname='custodial_recovery'
     order by n.nspname`)).rows;
    assert.equal(originalOwners.length,1,'Actual fixed private namespace owner required');
    const original=originalOwners[0];
    assert.equal(original.schema_name,'custodial_recovery');
    assert.equal(typeof original.raw_owner_name,'string');assert.ok(original.raw_owner_name.length>0&&!original.raw_owner_name.includes('\0'));
    const normalizedOwners=[{schema_name:original.schema_name,
     owner_name:['postgres','supabase_admin'].includes(original.raw_owner_name)?'migration_owner':original.raw_owner_name}];
    assert.deepEqual(catalog.recovery_schema_owners,normalizedOwners);
    const fingerprint=fingerprintSchemaCatalog(catalog).fingerprint;
    assert.match(fingerprint,/^[a-f0-9]{64}$/);
    // Detached DATA omission only: no ALTER OWNER, roles, grants, or catalog
    // writes. The normal full hash must include the actual captured owner.
    const withoutOwner=structuredClone(catalog);delete withoutOwner.recovery_schema_owners;
    const ownerOmittedFingerprint=fingerprintSchemaCatalog(withoutOwner).fingerprint;
    assert.notEqual(fingerprint,ownerOmittedFingerprint);
    assert.deepEqual(catalog.recovery_schema_owners,normalizedOwners);
    assert.deepEqual(await readContext(),context);sourcePins();
    await admin.query('rollback');rolledBack=true;
    checks.push('NEW283 actual fixed namespace owner matches production normal catalog capture and participates in its full fingerprint in one verified READ ONLY repeatable snapshot');
    witness.push({...context,scope:'ONLY_PRIVATE_SCHEMA_OWNER_CATALOG_CAPTURE',transaction_rolled_back:true});
    put('PRODUCT_RESULT.json',{scope:'NEW283_READ_ONLY_PRIVATE_SCHEMA_OWNER_CAPTURE_NOT_RESTORE_OR_ACK',
     checks,source:{backend_commit:'c628cecf33468ae399a1b9b059294a0045ee906a',backend_tree:'08689b0f747df46a6d77b54d5cbf93e043f48536',
      canonical:plan.manifestSha256,input_pins:schemaOwnerInputPins},
     transactions:witness,catalog,fingerprint,original_namespace_owners:originalOwners,
     normalized_namespace_owners:normalizedOwners,owner_omitted_detached_DATA_fingerprint:ownerOmittedFingerprint,
     actual_SQL:true,normal_schema_fixture_only:true,old_groups_repeated:false,
     private_function_calls:0,target_data_writes:0,owner_role_grant_changes:0,
     restore:false,native:false,HTTP:false,ACK:false,finalizer:false,key_removal:false});
    console.log('NEW_PRIVATE_SCHEMA_OWNER_ACTUAL_READ_ONLY_CAPTURE_COMPLETE_NOT_RESTORE_OR_ACK');
   }catch(error){await admin.query('rollback').catch(()=>{});rolledBack=true;throw error;}
   finally{if(!rolledBack)await admin.query('rollback');}
 }else if(immutableOwnerContext){
   phase='new immutable import proposal actual managed owner SQL compile in rollback';
   const proposal=fs.readFileSync(B+'/proposals/immutable-private-owner-context.sql','utf8');
   assert.equal(sha(proposal),'515da4decae3d0d6fce5a06463e56c3d00030a9f9bff5f06bbf1e462cda61819');
   assert.match(proposal,/COMMIT;\s*$/);
   // This is the declared managed owner from the SOURCE contract, never a
   // fallback for a denied role. A mismatch is retained without SET ROLE,
   // owner replacement, grants, or an application credential.
   const owner=new Client({...options,user:'postgres'});clients.add(owner);owner.on('error',()=>{});
   try{
     await owner.connect();
     const identity=(await owner.query("select current_user actor,session_user session_actor,current_database() database,(select pg_get_userbyid(nspowner) from pg_namespace where nspname='custodial_dr') dr_owner,(select pg_get_userbyid(proowner) from pg_proc where oid='custodial_release_identity.guard_group_original_creation()'::regprocedure) group_owner")).rows[0];
     put('IMPORT_OWNER_BINDING.json',identity);
     assert.equal(identity.actor,'postgres');assert.equal(identity.session_actor,'postgres');
     await owner.query("set statement_timeout='12s';set lock_timeout='2s'");
     await owner.query(proposal.replace(/COMMIT;\s*$/,''));
     const expectedFunctions=[...proposal.matchAll(/^CREATE FUNCTION custodial_dr\.([a-z_]+)\(/gm)].map(x=>x[1]).sort();
     assert.equal(expectedFunctions.length,11);assert.equal(new Set(expectedFunctions).size,11);
     const compiled=(await owner.query("select proname,oid::regprocedure::text signature,prosecdef,pg_get_userbyid(proowner) owner from pg_proc where pronamespace='custodial_dr'::regnamespace and proname=any($1::text[]) order by proname",[expectedFunctions])).rows;
     assert.deepEqual(compiled.map(x=>x.proname),expectedFunctions);assert.ok(compiled.every(x=>x.prosecdef===false&&x.owner==='postgres'));
     await owner.query('savepoint expected_refusal');
     await assert.rejects(owner.query('select custodial_dr.immutable_import_owner_fence()'),e=>e.code==='55000');
     await owner.query('rollback to savepoint expected_refusal');
     await owner.query('rollback');
     assert.equal((await owner.query("select to_regclass('custodial_dr.immutable_private_import_context') missing")).rows[0].missing,null);
     put('PRODUCT_RESULT.json',{checks:['NEW proposal SQL compiles under declared original owner','NEW missing actual exclusive global fence refuses','NEW rollback removes draft objects'],identity,compiled,private_DATA_import:'NOT_RUN',complete_restore:false,production:false});
     checks.push('NEW private import owner/compile/refusal only; actual immutable DATA/whole restore NOT_RUN');
   }catch(error){await owner.query('rollback').catch(()=>{});throw error;}
   finally{await owner.end().catch(()=>{});clients.delete(owner);}
 }else if(recoveryNativeCompletion){
   if(recoveryNativeAcceptedCompletion){
    phase='ONE native START/actual commit/capture before separation -> current signed Source manager -> accepted fixed276 READ';
    const acceptedCompletionBinding=await preflightSameOriginalNativeAcceptedCompletionInputs(B,recoverySavedBrowser,recoveryWriterHold);
    if(recoveryLeasePair){
     const root='/home/eric/Documents/Codex/2026-10-09/task-7/same-prepared-manager-lease-pair-20261015-v1';
     const exact=(name,digest)=>assert.equal(sha(fs.readFileSync(root+'/'+name)),digest);
     exact('source/NativePrivateCustodyReturnedPieceSetTest.java','414b42ccf413ca841da2a4aee88e4ed2ec62f069f11b48520ce1b93d2faf32df');
     exact('COMPILE_RESULT.json','bd51e047434a1de313d143af64aedaf254925b70117a364a77539817285d4e18');
     exact('CLASS_MANIFEST.json','04815394d306d2bb79cbe064789e43d82f2630751517011270b3f83cd796cab4');
     exact('INPUTS.json','b7e13bfde6f45437a3ac831093ab3575a386998a7e6008b509960a74259a441d');
     const receipt=JSON.parse(fs.readFileSync(root+'/COMPILE_RESULT.json'));
     assert.equal(receipt.compile.exit_code,0);assert.equal(receipt.inputs.unchanged,true);assert.equal(receipt.resources.owned_processes,0);
     const output=root+'/qualification',st=fs.lstatSync(output),rows=[];
     assert.equal(st.isSymbolicLink(),false);assert.equal(st.dev,2082);assert.equal(st.ino,4849914);
     const walk=d=>{for(const n of fs.readdirSync(d).sort()){const file=path.join(d,n),s=fs.lstatSync(file);assert.equal(s.isSymbolicLink(),false);
      if(s.isDirectory())walk(file);else if(n.endsWith('.class'))rows.push([path.relative(output,file),s.size,sha(fs.readFileSync(file))]);}};
     walk(output);assert.equal(rows.length,14);assert.equal(sha(JSON.stringify(rows)),'cf4de7805ad5be96dc573c7b16227d1e73f2c1a81a93896d94848df6950f53d9');
     // Only the existing caller changes. Current production Engine is first;
     // none of its classes are present in this test-only output.
     acceptedCompletionBinding.classpath.unshift(output);
     acceptedCompletionBinding.testClassSha256='e5a5b8b33900a2882b027820bab31f323815022293381595fae2a7a23a15863d';
     acceptedCompletionBinding.leasePairOnly=true;
    }
    const result=await qualifySameOriginalNativePositive({admin,backendRoot:B,out,acceptedCompletionBinding});
    checks.push(...result.native_SQL.checks);put('PRODUCT_RESULT.json',result);
    console.log('NEW_STAGED_ACCEPTED_NATIVE_COMPLETION_SQL_WORKFLOW_COMPLETE_NOT_ACK');
   }else{
   phase='ONE same live original native owner -> signed Source manager preparation -> fixed276 exact original completion READ';
   const completionBinding=await preflightSameOriginalNativeCompletionInputs(B);
   const result=await qualifySameOriginalNativePositive({admin,backendRoot:B,out,completionBinding});
   checks.push(...result.native_SQL.checks);put('PRODUCT_RESULT.json',result);
   console.log('NEW_SAME_ORIGINAL_NATIVE_COMPLETION_SQL_WORKFLOW_COMPLETE_NOT_ACK');
   }
 }else if(recoveryNativeManagerPreparation){
   phase='ONE current manager page confirmation -> existing-only native preparation -> fixed275 SQL reader';
   const managerPreparationBinding=await preflightSameOriginalNativeManagerPreparationInputs(B);
   const result=await qualifySameOriginalNativePositive({admin,backendRoot:B,out,managerPreparationBinding});
   checks.push(...result.native_SQL.checks);put('PRODUCT_RESULT.json',result);
   console.log('NEW_SAME_ORIGINAL_NATIVE_CURRENT_MANAGER_PREPARATION_SQL_WORKFLOW_COMPLETE');
 }else if(inventoryPositive){
   phase='ONE actual original setup -> new inventory registration lost reply -> fixed READ ONLY status';
   const result=await qualifySameOriginalNativePositive({admin,backendRoot:B,out,inventoryRegistrationJoin:true,inventoryConfirmationGuard:inventoryConfirmation,inventoryManifestChunks,inventoryManifestStatus,inventoryManifestManagerSource,inventoryManifestSemanticReview,inventoryManagerDecision,inventoryManagerDecisionHttp});
   checks.push(...result.inventory_SQL.checks);put('PRODUCT_RESULT.json',result);
   console.log('NEW_NATIVE_INVENTORY_REGISTRATION_STATUS_SQL_JOIN_COMPLETE');
 }else if(inventoryStatusFloor){
   phase='ONLY NEW current signed original inventory status intended READ ONLY SQL boundary';
   const {qualifyNativeInventoryStatusSqlFloor}=await import(pathToFileURL(B+'/scripts/native-original-inventory-request-sql-tests.mjs'));
   const result=await qualifyNativeInventoryStatusSqlFloor({admin,backendRoot:B});
   checks.push(...result.checks);put('PRODUCT_RESULT.json',result);console.log('NEW_NATIVE_INVENTORY_STATUS_SQL_READ_FLOOR_COMPLETE_NOT_POSITIVE_RECEIPT');
 }else if(inventoryRequestFloor){
   phase='ONLY NEW native original inventory registration transaction source/role/closed-input floor';
   const {qualifyNativeInventoryRequestSqlFloor}=await import(pathToFileURL(B+'/scripts/native-original-inventory-request-sql-tests.mjs'));
   const result=await qualifyNativeInventoryRequestSqlFloor({admin,backendRoot:B});
   checks.push(...result.checks);put('PRODUCT_RESULT.json',result);console.log('NEW_NATIVE_INVENTORY_REQUEST_SQL_FLOOR_COMPLETE_NOT_POSITIVE_REGISTRATION');
 }else if(recoveryManagerReadFloor){
   phase='ONLY new275 fixed intended READ ONLY current manager preparation reader floor';
   const {qualifyCurrentNativeManagerPreparationReadFloor}=await import(pathToFileURL(B+'/scripts/same-original-recovery-local-database-tests.mjs'));
   const result=await qualifyCurrentNativeManagerPreparationReadFloor({admin,backendRoot:B});
   checks.push(...result.checks);put('PRODUCT_RESULT.json',result);console.log('NEW_CURRENT_MANAGER_READ_SQL_FLOOR_ONLY_COMPLETE');
 }else if(recoveryNativeStatus){
   phase='ONE actual original native saved-status fixed read-only SQL receipt';
   const statusBinding=await preflightSameOriginalNativeStatusInputs(B);
   const result=await qualifySameOriginalNativePositive({admin,backendRoot:B,out,statusBinding});
   checks.push(...result.native_SQL.checks);put('PRODUCT_RESULT.json',result);
   console.log('NEW_SAME_ORIGINAL_NATIVE_SAVED_STATUS_SQL_WORKFLOW_COMPLETE');
 }else if(recoveryNativePositive){
   phase='ONE actual original native HTTP SQL registration and manager page workflow';
   const result=await qualifySameOriginalNativePositive({admin,backendRoot:B,out});
   checks.push(...result.native_SQL.checks);put('PRODUCT_RESULT.json',result);
   console.log('NEW_SAME_ORIGINAL_NATIVE_SQL_MANAGER_PAGE_WORKFLOW_COMPLETE');
 }else if(recoveryRegistrationStatus){
   phase='ONLY NEW274 original registration status actual SQL negative floor';
   const {qualifySameOriginalRegistrationStatusDatabase}=await import(pathToFileURL(B+'/scripts/same-original-recovery-local-database-tests.mjs'));
   const result=await qualifySameOriginalRegistrationStatusDatabase({admin,backendRoot:B});checks.push(...result.checks);put('PRODUCT_RESULT.json',result);
   console.log('NEW_ORIGINAL_REGISTRATION_STATUS_SQL_NO_WRITE_FLOOR_ONLY');
 }else if(recoveryRegistration){
   phase='ONLY NEW272/273 private target/registration actual SQL negative authority floor';
   const {qualifySameOriginalRegistrationDatabase}=await import(pathToFileURL(B+'/scripts/same-original-recovery-local-database-tests.mjs'));
   const result=await qualifySameOriginalRegistrationDatabase({admin,backendRoot:B});checks.push(...result.checks);put('PRODUCT_RESULT.json',result);
   console.log('NEW_SAME_ORIGINAL_REGISTRATION_SQL_NEGATIVE_FLOOR_NO_POSITIVE_NATIVE_APPROVAL');
 }else if(recoveryPreparation){
   phase='NEW isolated preparation schema/ACL/current manager floor, not challenge/approval/native authority';
   const {qualifySameOriginalPreparationDatabase}=await import(pathToFileURL(B+'/scripts/same-original-recovery-local-database-tests.mjs'));
   const result=await qualifySameOriginalPreparationDatabase({admin,backendRoot:B});
   checks.push(...result.checks);put('PRODUCT_RESULT.json',result);
   console.log('NEW_SAME_ORIGINAL_PREPARATION_SQL_FLOOR_PASS_NO_NATIVE_APPROVAL');
 }else if(groupOriginal||groupRecovery){
   phase=groupRecovery?'Only NEW270 group metadata restore and original DATA preservation':'Only NEW270 group original RPC and purge lifetime';
   const result=execFileSync(process.execPath,[B+'/scripts/empty-database-rebuild-check.mjs',groupRecovery?'--group-original-recovery-only':'--group-original-binding-only'],{
    cwd:B,encoding:'utf8',timeout:90000,maxBuffer:1024*1024,
    env:{...process.env,SCHEMA_REBUILD_DOCKER_CONTAINER:ownedContainerName,SCHEMA_REBUILD_DATABASE_NAME:'postgres'}});
   put(groupRecovery?'GROUP_RECOVERY_SQL_RESULT.json':'GROUP_ORIGINAL_SQL_RESULT.json',{output:result.trim(),source:{canonical:plan.manifestSha256},actual_SQL:true,
    real_manager_browser:false,device:false,recovery_registration_NOT_qualified:!groupRecovery,arbitrary_owner_drift_or_lost_data_restore_qualified:false});
   console.log(result.trim());
 }else if(consoleOriginalHttp){
   phase='Current269 Console original outcome normal HTTP';
   const expectedBackend=consoleHttpBinding.backend,sourcePins=consoleHttpBinding.files;
   const managerId=randomUUID(),otherManagerId=randomUUID(),credentialId=randomUUID(),otherCredentialId=randomUUID();
   const conversationId=randomUUID(),deviceId='SYNTHETIC_CONSOLE_ORIGINAL_HTTP',otherDeviceId='SYNTHETIC_CONSOLE_FOREIGN_HTTP';
   const clientId=randomUUID(),correlationId=randomUUID(),attachments=[randomUUID(),randomUUID()];
   const originalBody="Synthetic original Console HTTP turn; exact ordered attachments ñ '";
   // Only disposable fixture principals; no real manager/session is enrolled.
   for(const [manager,credential,device,label] of [[managerId,credentialId,deviceId,'Synthetic Console original owner'],
     [otherManagerId,otherCredentialId,otherDeviceId,'Synthetic Console foreign owner']]){
    await admin.query("insert into public.ops_manager_managers(manager_id,display_name,roles,active,is_system_principal,metadata_json) values($1,$2,array['OPS_MANAGER'],true,false,'{\"fixture\":true}'::jsonb)",[manager,label]);
    await admin.query("insert into public.ops_manager_trusted_devices(credential_id,device_id,device_label,token_hash,max_access_level,manager_id,expires_at,metadata_json) values($1,$2,$3,$4,'full_access',$5,now()+interval '1 hour','{\"fixture\":true}'::jsonb)",[credential,device,label,sha(randomBytes(32)),manager]);
   }
   await admin.query("insert into public.gemini_console_conversations(conversation_id,owner_manager_id,title) values($1,$2,'Synthetic original HTTP fixture')",[conversationId,managerId]);
   for(const [index,attachment] of attachments.entries())await admin.query(`insert into public.gemini_console_attachments
    (attachment_id,conversation_id,manager_id,storage_path,original_filename,mime_type,extension,size_bytes,sha256)
    values($1,$2,$3,$4,$5,'text/plain','.txt',4,$6)`,[attachment,conversationId,managerId,
      'synthetic-original-http/'+attachment,'evidence-'+index+'.txt',sha('synthetic attachment '+index)]);
   const begin=async(client,correlation,body,ids=[])=>
    (await tx('select public.gemini_console_begin_turn($1::uuid,$2::uuid,$3::uuid,$4::text,$5::uuid[],$6::uuid) data',
      [conversationId,managerId,client,body,ids,correlation],'service_role',true)).rows[0].data;
   const complete=async(user,correlation)=>
    (await tx('select public.gemini_console_complete_turn($1::uuid,$2::text,$3::text,$4::text,$5::uuid,$6::jsonb) data',
      [user,'Synthetic persisted assistant','synthetic_fixture_no_provider','fixture-model',correlation,
        JSON.stringify({fixture:'console-original-http',external_provider:false})],'service_role',true)).rows[0].data;
   const started=await begin(clientId,correlationId,originalBody,attachments);
   assert.equal(started.claimed,true);assert.equal(started.inserted,true);
   assert.deepEqual(started.user_message.metadata_json.original_attachment_ids,attachments);
   assert.equal(started.user_message.metadata_json.original_client_time_policy,'LOCAL_DISPLAY_METADATA_NOT_SERVER_AUTHORITY');
   const assistant=await complete(started.user_message.message_id,correlationId);
   const original={client_message_id:clientId,correlation_id:correlationId,conversation_id:conversationId,
    body:originalBody,orderedattachment_ids:attachments,created_at:new Date().toISOString()};
   const persistedUser=(await admin.query('select to_jsonb(m) data from public.gemini_console_messages m where message_id=$1',[started.user_message.message_id])).rows[0].data;
   assert.equal(persistedUser.state,'completed');assert.equal(assistant.state,'completed');
   // Both models use normal begin/complete, then only the historical fixture
   // drops new metadata. No direct INSERT of an accepted message is permitted.
   const legacyClient=randomUUID(),legacyCorrelation=randomUUID(),legacyBody='Synthetic pre269 metadata fixture';
   const legacy=await begin(legacyClient,legacyCorrelation,legacyBody);
   await complete(legacy.user_message.message_id,legacyCorrelation);
   await admin.query("update public.gemini_console_messages set metadata_json='{\"source\":\"direct_authenticated_user\"}'::jsonb where message_id=$1",[legacy.user_message.message_id]);
   const pendingClient=randomUUID(),pendingCorrelation=randomUUID(),pendingBody='Synthetic incomplete original fixture';
   await begin(pendingClient,pendingCorrelation,pendingBody);
   const storedRows=async()=>({
    conversation:(await admin.query('select to_jsonb(c) data from public.gemini_console_conversations c where conversation_id=$1',[conversationId])).rows,
    messages:(await admin.query('select to_jsonb(m) data from public.gemini_console_messages m where conversation_id=$1 order by message_id',[conversationId])).rows,
    attachments:(await admin.query('select to_jsonb(a) data from public.gemini_console_attachments a where conversation_id=$1 order by attachment_id',[conversationId])).rows,
   });
   const originalRowsHash=sha(JSON.stringify(await storedRows()));
   const {createOpsManagerSession,makeOpsAccessMiddleware}=await import(pathToFileURL(B+'/src/auth/shared-access-auth.js'));
   const {createGeminiConsoleRouter}=await import(pathToFileURL(B+'/src/gemini-console-api.js'));
   const {createGeneralJsonMiddleware}=await import(pathToFileURL(B+'/src/request-json-parser.js'));
   const env={NODE_ENV:'test',OPS_MANAGER_SESSION_SECRET:randomBytes(32).toString('hex')};
   const store={async find(credential){const r=await tx(`select to_jsonb(d) data,to_jsonb(m) manager
    from public.ops_manager_trusted_devices d join public.ops_manager_managers m on m.manager_id=d.manager_id
    where d.credential_id=$1`,[credential]);return r.rows[0]?{...r.rows[0].data,manager:r.rows[0].manager}:null;}};
   const actorSession=async(manager,credential,device)=>createOpsManagerSession({env,
    manager:(await admin.query('select * from public.ops_manager_managers where manager_id=$1',[manager])).rows[0],
    credentialId:credential,deviceId:device,accessLevel:'full_access'});
   const ownerSession=await actorSession(managerId,credentialId,deviceId),foreignSession=await actorSession(otherManagerId,otherCredentialId,otherDeviceId);
   let firstReaderError=null,reads=0,revokeBeforeSnapshot=false,forbiddenUses=0;
   const read=async statement=>{
    reads++;
    if(revokeBeforeSnapshot){revokeBeforeSnapshot=false;await admin.query('update public.ops_manager_trusted_devices set revoked_at=clock_timestamp() where credential_id=$1',[credentialId]);}
    try{
     const rows=(await tx(statement,[],'custodial_application_reader',false)).rows;
     if(reads===1)put('CONSOLE_ORIGINAL_FIRST_READER_ROWS.json',{
       intended_role:'custodial_application_reader',read_only:true,SQL_sha256:sha(statement),
       synthetic_fixture_only:true,row_count:rows.length,rows,fallback_used:false,
       expected_original:original,fixture_persisted_user:persistedUser,fixture_persisted_assistant:assistant});
     return rows;
    }
    catch(error){if(!firstReaderError){firstReaderError=error;put('CONSOLE_ORIGINAL_FIRST_READER_ERROR.json',{
      role:'custodial_application_reader',read_only:true,code:error.code||null,message:String(error.message).slice(0,1000),
      SQL_sha256:sha(statement),fallback_used:false});}throw error;}
   };
   // The actual status route must consume only its fixed SQL reader. Any use
   // of the router's general service facade is a qualification failure.
   const forbidden=()=>{forbiddenUses++;throw Error('Original outcome route attempted service/provider mutation facade');};
   const app=express();app.use(createGeneralJsonMiddleware());
   app.use('/gemini-api',createGeminiConsoleRouter({supabase:{from:forbidden,rpc:forbidden,storage:{from:forbidden}},
    runReadOnlySql:read,requireOpsManagerAuth:makeOpsAccessMiddleware({env,trustedDeviceStore:store}),
    buildHealthPayload:()=>({ok:true}),appVersion:'FIXTURE_ONLY',releaseId:'NOT_RELEASED',schemaFingerprint:plan.manifestSha256}));
   api=await start(http.createServer(app));const origin='http://127.0.0.1:'+api.address().port;
   const path='/gemini-api/conversations/'+conversationId+'/messages/original-outcome',requests=[];
   const call=async(body,session=ownerSession)=>{
    const reply=await fetch(origin+path,{method:'POST',headers:{authorization:'Bearer '+session.token,
      'x-device-id':session.device_id,'content-type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(10000)});
    const payload=await reply.json();requests.push({path,status:reply.status,request_sha256:sha(JSON.stringify(body)),
      state:payload.data?.state||null});
    if(firstReaderError)throw firstReaderError;
    assert.equal(forbiddenUses,0);assert.equal(sha(JSON.stringify(await storedRows())),originalRowsHash,'status request changed stored originals');
    return{status:reply.status,body:payload};
   };
   const positive=await call(original);assert.equal(positive.status,200,JSON.stringify(positive.body));
   assert.deepEqual(positive.body,{ok:true,data:{schema:'custodial.console-original-outcome.v1',state:'PERSISTED_COMPLETED_TURN_ONLY',
    ...original,created_at_policy:'LOCAL_DISPLAY_METADATA_NOT_SERVER_AUTHORITY',user_message_id:persistedUser.message_id,
    assistant_message_id:assistant.message_id,user_completed_at:persistedUser.completed_at,assistant_completed_at:assistant.completed_at}});
   checks.push('NEW normal signed manager registry -> actual fixed original-outcome HTTP -> intended reader READ ONLY -> exact persisted original pair');
   const unknown={ok:true,data:{schema:'custodial.console-original-outcome.v1',state:'UNCONFIRMED_ORIGINAL_RETAINED'}};
   for(const [label,input,session] of [
    ['wrong body',{...original,body:original.body+' changed'}],
    ['wrong attachment order',{...original,orderedattachment_ids:[...attachments].reverse()}],
    ['wrong correlation',{...original,correlation_id:randomUUID()}],
    ['missing original',{...original,client_message_id:randomUUID()}],
    ['wrong manager',original,foreignSession],
    ['legacy metadata',{...original,client_message_id:legacyClient,correlation_id:legacyCorrelation,body:legacyBody,orderedattachment_ids:[]}],
    ['incomplete pair',{...original,client_message_id:pendingClient,correlation_id:pendingCorrelation,body:pendingBody,orderedattachment_ids:[]}],
   ]){const result=await call(input,session);assert.equal(result.status,200,label);assert.deepEqual(result.body,unknown,label);checks.push('NEW '+label+' retains original without a replacement turn');}
   const beforeGrammarReads=reads;
   const missingField={...original};delete missingField.correlation_id;
   for(const input of [{...original,extra:true},missingField]){const result=await call(input);assert.equal(result.status,422);assert.equal(result.body.ok,false);}
   assert.equal(reads,beforeGrammarReads,'closed-body rejection must precede SQL snapshot');
   await admin.query('update public.ops_manager_trusted_devices set manager_id=$2 where credential_id=$1',[credentialId,otherManagerId]);
   const changed=await call(original);assert.ok([401,403].includes(changed.status));assert.equal(changed.body.ok,false);
   await admin.query('update public.ops_manager_trusted_devices set manager_id=$2 where credential_id=$1',[credentialId,managerId]);
   await admin.query('update public.ops_manager_trusted_devices set revoked_at=clock_timestamp() where credential_id=$1',[credentialId]);
   const revoked=await call(original);assert.ok([401,403].includes(revoked.status));assert.equal(revoked.body.ok,false);
   await admin.query('update public.ops_manager_trusted_devices set revoked_at=null where credential_id=$1',[credentialId]);
   revokeBeforeSnapshot=true;
   const betweenAuthAndSnapshot=await call(original);assert.equal(betweenAuthAndSnapshot.status,200);assert.deepEqual(betweenAuthAndSnapshot.body,unknown);
   assert.equal(forbiddenUses,0);assert.equal(sha(JSON.stringify(await storedRows())),originalRowsHash);
   checks.push('NEW closed six-field request denial and actual changed/revoked credential gates; revocation after normal auth but before fixed SQL snapshot returns UNKNOWN');
   put('PRODUCT_RESULT.json',{at_utc:new Date().toISOString(),checks,source:{backend:expectedBackend,files:sourcePins,canonical:plan.manifestSha256},
    actual_SQL:true,normal_signed_manager_fixture_HTTP:true,technical_synthetic_fixture_only:true,
    intended_read_role:'custodial_application_reader',transactions:witness,requests,stored_rows_sha256:originalRowsHash,
    fixed_reader_calls:reads,service_or_provider_facade_calls:forbiddenUses,original_output:positive.body.data,
    real_human_manager_browser:false,provider_delivery:false,normal_hosted_PostgREST:false});
   console.log('CONSOLE_ORIGINAL_NORMAL_HTTP_INTENDED_READER_PASS');
  }else if(consoleOriginal){
   phase='Only NEW269 original Console immutable SQL preservation';
   const result=execFileSync(process.execPath,[B+'/scripts/gemini-console-database-tests.mjs','--original-preservation-only','--remaining-after-correlation'],{
    cwd:B,encoding:'utf8',timeout:90000,maxBuffer:1024*1024,
    env:{...process.env,GEMINI_CONSOLE_TEST_DOCKER_CONTAINER:ownedContainerName,GEMINI_CONSOLE_TEST_DATABASE:'postgres'}});
   put('CONSOLE_ORIGINAL_SQL_RESULT.json',JSON.parse(result.trim()));
   console.log(result.trim());
  }else if(staffingCurrentHttp){
   phase='Current268 staffing renderer/signed HTTP source binding';
   const F=D+'frontend';
   const sourceTuple=directory=>execFileSync('/usr/bin/git',['-C',directory,'rev-parse','HEAD','HEAD^{tree}'],{encoding:'utf8'}).trim().split('\n');
   assert.deepEqual(sourceTuple(B),['8afb0e02591064244a8546fb1b7cc00b6b64d76d','3176130807ef7c212ebe8d4b2b30c4904a461b54']);
   assert.deepEqual(sourceTuple(F),['797a98233d0fdc4bec7b43b2894abd6a81ceec9e','f8a78d9104ca32937b5fca831a5ef88a0f2ec712']);
   for(const directory of [B,F])assert.equal(execFileSync('/usr/bin/git',['-C',directory,'status','--porcelain'],{encoding:'utf8'}).trim(),'');
   async function sql(statement){const c=new Client(options);clients.add(c);c.on('error',()=>{});
    try{await c.connect();await c.query("set statement_timeout='20s';set lock_timeout='3s'");
     const result=await c.query(statement),list=Array.isArray(result)?result:[result],selected=list.filter(r=>r.rows?.length).at(-1);
     return selected?selected.rows.map(row=>Object.values(row).map(v=>typeof v==='boolean'?(v?'t':'f'):v===null?'':typeof v==='object'?JSON.stringify(v):String(v)).join('|')).join('\n'):'';
    }finally{await c.end().catch(()=>{});clients.delete(c);}}
   const owner=(await admin.query("select * from public.ops_manager_managers where system_key='eric_custodial_manager' and active and not is_system_principal and revoked_at is null")).rows[0];assert.ok(owner);
   const delegateId=id(820),ownerCredential=id(821),delegateCredential=id(822);
   await admin.query("insert into public.ops_manager_managers(manager_id,display_name,roles,active,is_system_principal) values($1,'Synthetic current staffing HTTP delegate',array['OPS_MANAGER'],true,false)",[delegateId]);
   const delegate=(await admin.query('select * from public.ops_manager_managers where manager_id=$1',[delegateId])).rows[0];
   const env={NODE_ENV:'test',SUPABASE_URL:'http://127.0.0.1:1',SUPABASE_SERVICE_ROLE_KEY:randomBytes(32).toString('hex'),OPS_MANAGER_SESSION_SECRET:randomBytes(32).toString('hex')};
   const {createOpsManagerSession,makeOpsAccessMiddleware}=await import(pathToFileURL(B+'/src/auth/shared-access-auth.js'));
   const store={async find(credential){const r=await tx('select to_jsonb(d) data,to_jsonb(m) manager from public.ops_manager_trusted_devices d join public.ops_manager_managers m on d.manager_id=m.manager_id where d.credential_id=$1',[credential]);return r.rows[0]?{...r.rows[0].data,manager:r.rows[0].manager}:null;}};
   async function normalActor(manager,credential,device,level,permission){
    await admin.query("insert into public.ops_manager_trusted_devices(credential_id,device_id,device_label,token_hash,max_access_level,manager_id,expires_at) values($1,$2,'Synthetic current staffing HTTP credential',repeat('b',64),$3,$4,now()+interval '1 hour')",[credential,device,level,manager.manager_id]);
    const session=createOpsManagerSession({env,manager,credentialId:credential,deviceId:device,accessLevel:level});
    const gate=makeOpsAccessMiddleware({env,trustedDeviceStore:store,requireWrite:permission==='write',requiredPermission:permission==='write'?null:permission});
    const req={headers:{authorization:'Bearer '+session.token,'x-device-id':device},header(name){return this.headers[String(name).toLowerCase()];}};let admitted=0;
    await gate(req,{status(code){throw Error('Normal staffing HTTP actor denied '+code);},json(){throw Error('Normal staffing HTTP actor denied');}},()=>admitted++);
    assert.equal(admitted,1);assert.equal(req.memphisAuth.manager_id,manager.manager_id);assert.equal(req.memphisAuth.credential_id,credential);
    return{session,actor:req.memphisAuth};
   }
   const normalOwner=await normalActor(owner,ownerCredential,'SYNTHETIC_STAFFING_HTTP_OWNER','full_access','write');
   const normalDelegate=await normalActor(delegate,delegateCredential,'SYNTHETIC_STAFFING_HTTP_DELEGATE','read_only','manage_absences');
   assert.equal(normalDelegate.actor.read_only,true);assert.equal(normalDelegate.actor.permissions.owner,false);
   phase='Current one-date normal baseline/manual capacity prerequisite';
   const {setupStaffingHandoutJoinFixture}=await import(pathToFileURL(B+'/scripts/fixtures/oc24-coverall-database-fixture.mjs'));
   const week='2026-10-12',keys=Array.from({length:3},()=>randomUUID());
   staffingFixture=await setupStaffingHandoutJoinFixture({sql,container:ownedContainerName,databaseOptions:options,
    manager:normalOwner.actor,weekStart:week,manualCapacityKey:keys[0],clientPrepareKey:keys[1],confirmationKey:keys[2],
    capacityLunch:{start:'11:00',end:'12:00'},capture:put,authenticatedRequests:true});
   // Existing normal runtime, same DB-backed credential store and fixed lease
   // callbacks as the owning vacancy HTTP member. No fabricated RPC response.
   const {Pool}=require('pg');staffingHttpPool=new Pool({...options,max:2});
   const rpc={custodial_begin_application_mutation_lease:[['p_request_id','uuid'],['p_service_name','text']],custodial_heartbeat_application_mutation_lease:[['p_request_id','uuid']],custodial_release_application_mutation_lease:[['p_request_id','uuid']]};
   const supabase={async rpc(name,args){assert.ok(rpc[name]);const params=rpc[name];assert.deepEqual(Object.keys(args).sort(),params.map(x=>x[0]).sort());try{const r=await tx('select public.'+name+'('+params.map((x,i)=>'$'+(i+1)+'::'+x[1]).join(',')+') data',params.map(x=>args[x[0]]),'service_role',true);return{data:r.rows[0].data,error:null};}catch(error){return{data:null,error:{code:error.code,message:error.message}};}}};
   const {createStaticWeeklyControlPlaneRuntime}=await import(pathToFileURL(B+'/src/static-weekly-control-plane-runtime.js'));
   const runtime=createStaticWeeklyControlPlaneRuntime({env,supabase,trustedDeviceStore:store,database:staffingHttpPool,controlPlane:staffingFixture.plane});
   api=await start(http.createServer(runtime.app));const url='http://127.0.0.1:'+api.address().port;
   assert.equal(api.address().address,'127.0.0.1');
   const trace=[],rawFetch=globalThis.fetch;
   const actualFetch=async(value,request={})=>{const target=new URL(value);assert.equal(target.origin,url,'own loopback HTTP only');
    const reply=await rawFetch(target,request),body=await reply.clone().json();
    trace.push({path:target.pathname+target.search,method:request.method||'GET',requestBody:request.body??null,status:reply.status,body});
    return reply;};
   const headers=()=>({authorization:'Bearer '+normalDelegate.session.token,'x-device-id':normalDelegate.session.device_id});
   const request=async path=>{const reply=await actualFetch(url+path,{headers:headers(),signal:AbortSignal.timeout(65000)}),body=await reply.json();
    assert.equal(reply.status,200,JSON.stringify(body));assert.equal(body.ok,true);return body.data;};
   phase='Actual current scheduler owning page fixture -> normal HTTP private preview';
   const frontRequire=createRequire(F+'/scripts/manager-scheduler-client-tests.mjs');
   const A=frontRequire('../memphis-scheduler-actions.js'),P=frontRequire('../memphis-approved-schedule.js');
   const tests=fs.readFileSync(F+'/scripts/manager-scheduler-client-tests.mjs','utf8');
   const fixtureStart=tests.indexOf('function fixture(){'),fixtureEnd=tests.indexOf('\nconst body=',fixtureStart);
   const pageStart=tests.indexOf('function pageFixture(){'),pageEnd=tests.indexOf("\ntest('scheduler integration:",pageStart);
   assert.ok(fixtureStart>=0&&fixtureEnd>fixtureStart&&pageStart>=0&&pageEnd>pageStart,'existing owning page callbacks must exist');
   // Load ONLY these existing fixture callbacks, never register/run old tests.
   // Their placeholder transport is made fatal; all product requests below
   // use the actual current page api -> actualFetch -> normal runtime routes.
   const pageSource=tests.slice(pageStart,pageEnd).replace('import.meta.url','schedulerTestsUrl');
   const callbacks=vm.createContext({fs,vm,A,P,assert,webcrypto,URL,URLSearchParams,AbortSignal,TextEncoder,console,
    schedulerTestsUrl:pathToFileURL(F+'/scripts/manager-scheduler-client-tests.mjs'),
    MID:delegateId,CID:delegateCredential,PID:staffingFixture.baseline.projectionId,SOURCE:staffingFixture.baseline.publicationId});
   vm.runInContext(tests.slice(fixtureStart,fixtureEnd)+'\n'+pageSource+'\nglobalThis.owningPage=pageFixture();',callbacks);
   const f=callbacks.owningPage;
   f.patch(normalDelegate.session);f.setMode('reject');
   f.auth.opsManagerAuthHeaders=async()=>headers();f.context.fetch=actualFetch;
   f.page.state.principal=A.principal(f.auth);f.page.state.baseUrl=url;
   f.page.els.week_start.value=week;f.page.els.service_date.value=week;f.page.els.absence_type.value='daily_absence';
   f.context.document.getElementById('absence-end-date').value=week;
   f.page.state.snapshot=await request('/static-weekly/manager-snapshot?week_start='+week);
   const basis=f.page.state.snapshot;assert.equal(basis.projection_status,'current');
   const slot=staffingFixture.baseline.employees[0].slot,employee=staffingFixture.baseline.employees[0].id;
   f.context.document.querySelectorAll=selector=>selector==='[data-callout-slot]:checked:not(:disabled)'?[{dataset:{calloutSlot:slot},checked:true,disabled:false}]:[];
   vm.runInContext('state.actions=window.MemphisSchedulerActions.create({auth:window.MemphisAuth,api,baseUrl:state.baseUrl,onState:r=>{state.pending=r;renderPending();}});',f.context);
   let userConfirmations=0;const dialog=f.page.els.action_confirm_dialog;
   dialog.showModal=()=>{userConfirmations++;dialog.open=true;queueMicrotask(()=>{dialog.returnValue='confirm';dialog.open=false;dialog.listeners.get('close')();});};
   try{
    await f.page.applyDayChanges();
    const pending=f.page.state.actions.pending();put('STAFFING_HTTP_PREVIEW.json',{pending,status:f.page.els.status.textContent});
    assert.ok(f.page.state.staffingPreview,'actual private HTTP preview must mount');
    assert.equal(pending.body.employee_id,employee);assert.equal(pending.body.start_date,week);assert.equal(pending.body.end_date,week);
    assert.equal(pending.body.expected_revision,basis.authority_revision);assert.equal(pending.command.phase,'PREPARED');
    assert.equal(userConfirmations,0);assert.equal((await request('/static-weekly/manager-snapshot?week_start='+week)).authority_revision,basis.authority_revision);
    const rows=f.nodes.get('approved-preview-rows').children,preview=f.page.state.staffingPreview.value;
    assert.equal(rows.length,preview.preview.weeks[0].assignments.length);assert.ok(rows.length>0);
    assert.ok(f.nodes.get('approved-preview-capacity-rows').children.length>0,'actual per-person availability renderer mounted');
    const confirm=f.nodes.get('staffing-confirm-btn');assert.equal(confirm.disabled,false,'normal delegate must be able to explicitly confirm');
    await confirm.listeners.get('click')();assert.equal(userConfirmations,1);
    const confirmation=trace.filter(row=>row.method==='POST'&&/\/staffing-commands\/[0-9a-f-]{36}\/confirm$/.test(row.path));
    assert.equal(confirmation.length,1);assert.equal(confirmation[0].status,200,JSON.stringify(confirmation[0].body));
    assert.equal(f.page.state.pending,null,'all current accepted readback required before UI saved work clears');assert.equal(f.map.size,0);
    const original=await request('/static-weekly/staffing-commands/'+pending.command.operationId),receipt=original.accepted_receipt;
    assert.equal(original.state,'ACCEPTED');assert.equal(original.prepared_by_manager_id,delegateId);
    assert.equal(receipt.original_preparer_manager_id,delegateId);assert.equal(original.accepted_revision,basis.authority_revision+1);
    const current=await request('/static-weekly/manager-snapshot?week_start='+week);
    assert.equal(current.authority_revision,receipt.authority_revision);assert.equal(current.latest_projection.projection_id,receipt.projections[week].projection_id);
    const persisted=(await admin.query("select c.semantic_body,c.client_prepare_key,c.confirmation_key,c.prepared_by_manager_id,c.accepted_revision,(select count(*)::int from public.static_weekly_staffing_command_receipts where operation_id=c.operation_id and event_kind='ACCEPTED') receipt_count from public.static_weekly_staffing_commands c where operation_id=$1",[original.operation_id])).rows[0];
    assert.equal(persisted.receipt_count,1);assert.equal(persisted.client_prepare_key,pending.body.client_prepare_key);
    assert.equal(persisted.confirmation_key,JSON.parse(confirmation[0].requestBody).confirmation_key);
    assert.equal(persisted.prepared_by_manager_id,delegateId);
    phase='Actual normal current HTTP EN/ES handout from renderer accepted date/revision link';
    const link=f.nodes.get('coverall-print-link');assert.equal(link.hidden,false);
    const selection=new URL(link.href,url);assert.equal(selection.searchParams.get('date'),week);
    assert.equal(selection.searchParams.get('expected_revision'),String(receipt.authority_revision));
    assert.equal(selection.searchParams.get('projection_id'),current.latest_projection.projection_id);
    const pair=await request('/static-weekly/coverall-print?'+new URLSearchParams({week_start:week,service_date:week,
     expected_revision:String(receipt.authority_revision),projection_id:current.latest_projection.projection_id}));
    const C=frontRequire('../coverall-print.js');C.validate(pair,{date:week,revision:receipt.authority_revision,
     projectionId:current.latest_projection.projection_id,publicationId:current.current_publication.publication_id,
     replayDigest:current.latest_projection.replay_digest,managerId:delegateId});
    assert.deepEqual(pair.document.contractors.map(row=>row.slotId).sort(),[staffingFixture.baseline.capacities[0].slot]);
    assert.equal(pair.document.contractorCompletionRecorder,'ERIC_OPERLE_PERSONAL_VERIFICATION');
    const {PDFDocument}=require('pdf-lib');for(const file of [...pair.files,pair.bilingualFile]){
     const bytes=Buffer.from(file.base64,'base64');assert.equal(sha(bytes),file.sha256);
     const pdf=await PDFDocument.load(bytes);assert.ok(pdf.getSubject().includes('projection='+current.latest_projection.projection_id+'; revision='+receipt.authority_revision));}
    const text=pair.texts.find(row=>row.language==='en-es');assert.equal(sha(text.text),text.sha256);
    assert.equal(pair.document.lunchDocumentIdentity,receipt.projections[week].lunch_document_identity);
    const after=await request('/static-weekly/manager-snapshot?week_start='+week);
    assert.equal(after.authority_revision,current.authority_revision);assert.equal(after.latest_projection.projection_id,current.latest_projection.projection_id);
    put('STAFFING_HTTP_HANDBOOK_READBACK.json',{original,current,persisted,pair,after});
    checks.push('current scheduler renderer + source action helper uses normal signed delegate HTTP private prepare/ONE explicit confirm/original GET/persisted revision and EN-ES matched handout');
    put('PRODUCT_RESULT.json',{scope:'one newly affected current renderer/source-DOM fixture -> actual signed normal HTTP/SQL staffing/EN-ES join',checks,
     source:{frontend:'797a98233d0fdc4bec7b43b2894abd6a81ceec9e',backend:'8afb0e02591064244a8546fb1b7cc00b6b64d76d',canonical268:plan.manifestSha256},
     operation_id:original.operation_id,authority_revision:receipt.authority_revision,projection_id:current.latest_projection.projection_id,
     confirmation_count:confirmation.length,actual_HTTP:true,actual_SQL:true,normal_current_signed_fixture_managers:true,
     existing_owning_page_fixture:true,real_named_manager_website:false,real_HTML_browser:false,print_page_bootstrap_NOT_executed:true,
     physical:false,old_groups_repeated:false,compilerPreparations:staffingFixture.compilerRuns.length,
     renderedRows:rows.length,files:[...pair.files,pair.bilingualFile].map(({language,filename,sha256})=>({language,filename,sha256}))});
    console.log('CURRENT_STAFFING_RENDERER_SIGNED_HTTP_SQL_HANDOUT_PASS_SYNTHETIC_FIXTURE');
   }finally{put('STAFFING_HTTP_TRACE.json',{trace,placeholderTransportCalls:f.calls.length});assert.equal(f.calls.length,0,'no placeholder callback may supply a product response');}
  }else if(purpose==='a1-delegate-multiweek'){
   phase='A1 normal current owner/delegate registry and signed session prerequisites';
   async function sql(statement){const c=new Client(options);clients.add(c);c.on('error',()=>{});
    try{await c.connect();await c.query("set statement_timeout='20s';set lock_timeout='3s'");
     const result=await c.query(statement),list=Array.isArray(result)?result:[result],selected=list.filter(r=>r.rows?.length).at(-1);
     return selected?selected.rows.map(row=>Object.values(row).map(v=>typeof v==='boolean'?(v?'t':'f'):v===null?'':typeof v==='object'?JSON.stringify(v):String(v)).join('|')).join('\n'):'';
    }finally{await c.end().catch(()=>{});clients.delete(c);}}
   const owner=(await admin.query("select * from public.ops_manager_managers where system_key='eric_custodial_manager' and active and not is_system_principal and revoked_at is null")).rows[0];assert.ok(owner);
   const delegateId=id(220),ownerCredential=id(221),delegateCredential=id(222);
   await admin.query("insert into public.ops_manager_managers(manager_id,display_name,roles,active,is_system_principal) values($1,'Synthetic A1 delegate',array['OPS_MANAGER'],true,false)",[delegateId]);
   const delegate=(await admin.query('select * from public.ops_manager_managers where manager_id=$1',[delegateId])).rows[0];
   const env={NODE_ENV:'test',OPS_MANAGER_SESSION_SECRET:randomBytes(32).toString('hex')};
   const {createOpsManagerSession,makeOpsAccessMiddleware}=await import(pathToFileURL(B+'/src/auth/shared-access-auth.js'));
   const store={async find(credential){const r=await tx('select to_jsonb(d) data,to_jsonb(m) manager from public.ops_manager_trusted_devices d join public.ops_manager_managers m on d.manager_id=m.manager_id where d.credential_id=$1',[credential]);return r.rows[0]?{...r.rows[0].data,manager:r.rows[0].manager}:null;}};
   async function normalActor(manager,credential,device,level,permission){
    await admin.query("insert into public.ops_manager_trusted_devices(credential_id,device_id,device_label,token_hash,max_access_level,manager_id,expires_at) values($1,$2,'Synthetic A1 current credential',repeat('b',64),$3,$4,now()+interval '1 hour')",[credential,device,level,manager.manager_id]);
    const session=createOpsManagerSession({env,manager,credentialId:credential,deviceId:device,accessLevel:level});
    const gate=makeOpsAccessMiddleware({env,trustedDeviceStore:store,requireWrite:permission==='write',requiredPermission:permission==='write'?null:permission});
    const req={headers:{authorization:'Bearer '+session.token,'x-device-id':device},header(name){return this.headers[String(name).toLowerCase()];}};let accepted=0;
    await gate(req,{status(code){throw Error('Normal A1 actor denied '+code);},json(){throw Error('Normal A1 actor denied');}},()=>accepted++);
    assert.equal(accepted,1);assert.equal(req.memphisAuth.manager_id,manager.manager_id);assert.equal(req.memphisAuth.credential_id,credential);return req.memphisAuth;
   }
   const normalOwner=await normalActor(owner,ownerCredential,'SYNTHETIC_A1_OWNER','full_access','write');
   const normalDelegate=await normalActor(delegate,delegateCredential,'SYNTHETIC_A1_DELEGATE','read_only','manage_absences');
   assert.equal(normalOwner.read_only,false);assert.equal(normalDelegate.read_only,true);assert.equal(normalDelegate.permissions.owner,false);assert.equal(normalDelegate.permissions.manage_absences,true);
   phase='A1 actual two-week delegated prepare/one confirm/current readback/cancel';
   const {setupStaffingHandoutJoinFixture}=await import(pathToFileURL(B+'/scripts/fixtures/oc24-coverall-database-fixture.mjs'));
   const keys=Array.from({length:9},()=>randomUUID());
   staffingFixture=await setupStaffingHandoutJoinFixture({sql,container:ownedContainerName,databaseOptions:options,
    manager:normalOwner,weekStart:'2026-10-19',endDate:'2026-10-26',manualCapacityKey:keys[0],
    manualCapacityKeys:{'2026-10-19':keys[0],'2026-10-26':keys[1]},clientPrepareKey:keys[2],confirmationKey:keys[3],
    capacityLunch:{start:'11:00',end:'12:00'},capture:(name,value)=>put(name,value),authenticatedRequests:true,
    secondPublicationKeys:{draft:keys[7],publish:keys[8]}});
   const result=await staffingFixture.continueDelegateTwoPublication({delegate:normalDelegate,cancelPrepareKey:keys[4],cancelConfirmationKey:keys[5],ownerProbeKey:keys[6]});
   put('PRODUCT_RESULT.json',{...result,actual_SQL:true,normal_current_signed_fixture_managers:true,owner_manager_id:owner.manager_id,delegate_manager_id:delegateId,
    compilerRuns:staffingFixture.compilerRuns,real_named_manager_website:false,actual_HTTP:false,physical:false,old_groups_repeated:false});
   console.log('A1_CURRENT_DELEGATE_MULTIWEEK_SQL_WORKFLOW_PASS_SYNTHETIC_ACTORS');
  }else if(purpose==='messenger-original'){
   phase='NEW268 private original Messenger actor/transaction/outcome';
   const deviceCode='KIOSK_08',employee=id(850),user=id(851),credential=id(852),thread=id(853),otherEmployee=id(854),otherUser=id(855),tokenHash='a'.repeat(64);
   await admin.query("insert into public.employees(id,employee_code,display_name,active,role) values($1,'EMP9850','Synthetic original sender',true,'staff'),($2,'EMP9854','Synthetic original recipient',true,'staff')",[employee,otherEmployee]);
   let device=(await admin.query('select id from public.devices where device_id=$1',[deviceCode])).rows[0]?.id;
   if(device)await admin.query('update public.devices set active=true,assigned_employee_id=$1 where id=$2',[employee,device]);
   else {device=id(856);await admin.query("insert into public.devices(id,device_id,device_name,active,assigned_employee_id) values($1,$2,'Synthetic original message device',true,$3)",[device,deviceCode,employee]);}
   await admin.query("insert into public.device_auth_credentials(credential_id,device_id,token_hash,confirmed_at,last_used_at,expires_at) values($1,$2,$3,now(),now(),now()+interval '1 hour')",[credential,device,tokenHash]);
   await admin.query("insert into public.msg_users(id,employee_id,display_name,role,is_active) values($1,$2,'Synthetic original sender','employee',true),($3,$4,'Synthetic original recipient','employee',true)",[user,employee,otherUser,otherEmployee]);
   await admin.query("insert into public.msg_device_assignments(device_identifier,msg_user_id,is_active) values($1,$2,true) on conflict(device_identifier) do update set msg_user_id=excluded.msg_user_id,is_active=true",[deviceCode,user]);
   await admin.query("insert into public.msg_threads(id,thread_type,title,created_by_user_id,is_active) values($1,'group','Synthetic original transaction thread',$2,true)",[thread,user]);
   await admin.query('insert into public.msg_thread_participants(thread_id,user_id) values($1,$2),($1,$3)',[thread,user,otherUser]);
   const epoch=String((await admin.query('select assignment_epoch from public.devices where id=$1',[device])).rows[0].assignment_epoch);
   const common={device_id:deviceCode,expected_employee_id:employee,expected_credential_id:credential,expected_assignment_epoch:epoch,user_id:user,thread_id:thread,credential_token_hash:tokenHash};
   const command=(name,payload,{write=true,role='service_role'}={})=>tx('select public.app_apply_operational_command($1,$2::jsonb) data',[name,JSON.stringify(payload)],role,write).then(r=>r.rows[0].data);
   const send={...common,body:'Synthetic original ñ message.',message_type:'text',metadata_json:{},client_message_id:'synthetic-original:'+randomUUID()};
   const original=await command('employee_message_original_send',send);assert.equal(original.state,'ORIGINAL_TRANSACTION_OUTCOME_RECORDED');assert.equal(original.original_outcome_recorded,true);assert.equal(original.result.body,send.body);
   assert.equal(original.original_actor.employee_id,employee);assert.equal(original.original_actor.credential_id,credential);assert.equal(original.original_actor.assignment_epoch,epoch);assert.equal(original.original_actor.user_id,user);
   assert.equal(original.original_request.credential_token_hash,undefined);
   const query=await command('employee_message_original_outcome',{...send,original_command:'employee_message_original_send'},{write:false});assert.deepEqual(query,original);
   assert.deepEqual(await command('employee_message_original_send',send),original);
   assert.equal((await admin.query('select count(*)::int n from public.msg_messages where client_message_id=$1',[send.client_message_id])).rows[0].n,1);
   const read={...common,through_message_id:original.result.id};
   const readReceipt=await command('employee_message_original_read',read);assert.equal(readReceipt.original_outcome_recorded,true);assert.equal(readReceipt.result.through_message_id,original.result.id);assert.equal(typeof readReceipt.result.marked,'number');
   assert.deepEqual(await command('employee_message_original_outcome',{...read,original_command:'employee_message_original_read'},{write:false}),readReceipt);
   const absent=await command('employee_message_original_outcome',{...read,through_message_id:id(859),original_command:'employee_message_original_read'},{write:false});assert.equal(absent.state,'ORIGINAL_OUTCOME_NOT_FOUND_UNKNOWN');assert.equal(absent.resend_allowed,false);
   for(const changed of [{expected_employee_id:otherEmployee},{expected_credential_id:id(858)},{expected_assignment_epoch:String(Number(epoch)+1)},{credential_token_hash:'b'.repeat(64)},{user_id:otherUser}]){
    await assert.rejects(()=>command('employee_message_original_send',{...send,...changed}),e=>e.code==='42501');
   }
   for(const role of ['anon','authenticated','custodial_application_reader'])await assert.rejects(()=>command('employee_message_original_send',send,{role}),e=>e.code==='42501');
   await assert.rejects(()=>command('employee_message_original_send',{...send,unexpected:true}),e=>e.code==='22023');
   await assert.rejects(()=>command('employee_message_original_send',{...send,expected_assignment_epoch:Number(epoch)}),e=>e.code==='22023');
   phase='NEW268 original Messenger DELETE with ordinary active device mapping';
   const deletion={...common,operation_id:randomUUID()};
   const deleted=await command('employee_message_original_delete',deletion);assert.equal(deleted.original_outcome_recorded,true);assert.equal(deleted.result.deleted,true);assert.equal(deleted.result.deletion_scope,'user');
   assert.deepEqual(await command('employee_message_original_outcome',{...deletion,original_command:'employee_message_original_delete'},{write:false}),deleted);
   await admin.query('update public.msg_device_assignments set is_active=false where device_identifier=$1',[deviceCode]);
   await assert.rejects(()=>command('employee_message_original_outcome',{...read,original_command:'employee_message_original_read'},{write:false}),e=>e.code==='42501');
   await admin.query('update public.msg_device_assignments set is_active=true where device_identifier=$1',[deviceCode]);
   await admin.query('update public.device_auth_credentials set revoked_at=now() where credential_id=$1',[credential]);
   await assert.rejects(()=>command('employee_message_original_outcome',{...read,original_command:'employee_message_original_read'},{write:false}),e=>e.code==='42501');
   const acl=(await admin.query("select has_table_privilege('service_role','custodial_release_identity.employee_message_original_outcomes','SELECT') service_direct_read,has_function_privilege('service_role','public.app_apply_operational_command(text,jsonb)','EXECUTE') service_existing_rpc,has_function_privilege('authenticated','public.app_apply_operational_command(text,jsonb)','EXECUTE') public_rpc")).rows[0];assert.deepEqual(acl,{service_direct_read:false,service_existing_rpc:true,public_rpc:false});
   const rows=(await admin.query('select request_fingerprint,original_command,outcome_json from custodial_release_identity.employee_message_original_outcomes order by request_fingerprint')).rows;assert.equal(rows.length,3);
   await assert.rejects(()=>admin.query('update custodial_release_identity.employee_message_original_outcomes set outcome_json=outcome_json'),e=>e.code==='55000');
   put('PRODUCT_RESULT.json',{scope:'ONLY NEW268 actual SQL original Messenger send/read/delete and exact fixed outcome, original current actor/role/withdrawal negatives',actual_SQL:true,actual_HTTP:false,normal_device_HTTP_auth:false,syntheticActors:true,realMessageDelivery:false,physical:false,acl,outcomes:rows,transactions:witness,old_groups_repeated:false});
   console.log('NEW268_ORIGINAL_MESSENGER_TRANSACTION_OUTCOME_SQL_PASS');
  }else if(purpose==='messenger-original-http'){
   phase='Current mounted original Messenger parser/native credential/HMAC/SQL outcome';
   const {makeDeviceCredentialMiddleware,deviceCredentialInternals,createSupabaseDeviceCredentialStore}=await import(pathToFileURL(B+'/src/auth/device-credential-auth.js'));
   const {createGeneralJsonMiddleware}=await import(pathToFileURL(B+'/src/request-json-parser.js'));
   const {createMessagingRouter}=await import(pathToFileURL(B+'/src/messaging-api.js'));
   const employee=id(870),user=id(871),credential=id(872),thread=id(873),otherEmployee=id(874),otherUser=id(875),deviceCode='KIOSK_08';
   const tokenSecret=randomBytes(32).toString('base64url'),authEnv={NODE_ENV:'test',DEVICE_CREDENTIAL_SECRET:randomBytes(32).toString('hex')};
   process.env.DEVICE_CREDENTIAL_SECRET=authEnv.DEVICE_CREDENTIAL_SECRET;
   await admin.query("insert into public.employees(id,employee_code,display_name,active,role) values($1,'EMP9870','Synthetic current Messenger sender',true,'staff'),($2,'EMP9874','Synthetic current Messenger recipient',true,'staff')",[employee,otherEmployee]);
   let device=(await admin.query('select id from public.devices where device_id=$1',[deviceCode])).rows[0]?.id;
   if(device)await admin.query('update public.devices set active=true,assigned_employee_id=$1 where id=$2',[employee,device]);
   else{device=id(876);await admin.query("insert into public.devices(id,device_id,device_name,active,assigned_employee_id) values($1,$2,'Synthetic original Messenger HTTP fixture',true,$3)",[device,deviceCode,employee]);}
   await admin.query("insert into public.device_auth_credentials(credential_id,device_id,token_hash,confirmed_at,last_used_at,expires_at,metadata_json) values($1,$2,$3,now(),now(),now()+interval '1 hour',$4::jsonb)",[credential,device,deviceCredentialInternals.tokenHash(tokenSecret,authEnv),JSON.stringify(deviceCredentialInternals.deviceCredentialSecretMetadata(authEnv))]);
   await admin.query("insert into public.msg_users(id,employee_id,display_name,role,is_active) values($1,$2,'Synthetic current Messenger sender','employee',true),($3,$4,'Synthetic current Messenger recipient','employee',true)",[user,employee,otherUser,otherEmployee]);
   await admin.query('insert into public.msg_device_assignments(device_identifier,msg_user_id,is_active) values($1,$2,true) on conflict(device_identifier) do update set msg_user_id=excluded.msg_user_id,is_active=true',[deviceCode,user]);
   const receiverCode='KIOSK_09',receiverCredential=id(878),receiverSecret=randomBytes(32).toString('base64url');
   let receiverDevice=(await admin.query('select id from public.devices where device_id=$1',[receiverCode])).rows[0]?.id;
   if(receiverDevice)await admin.query('update public.devices set active=true,assigned_employee_id=$1 where id=$2',[otherEmployee,receiverDevice]);
   else{receiverDevice=id(877);await admin.query("insert into public.devices(id,device_id,device_name,active,assigned_employee_id) values($1,$2,'Synthetic original Messenger recipient fixture',true,$3)",[receiverDevice,receiverCode,otherEmployee]);}
   await admin.query("insert into public.device_auth_credentials(credential_id,device_id,token_hash,confirmed_at,last_used_at,expires_at,metadata_json) values($1,$2,$3,now(),now(),now()+interval '1 hour',$4::jsonb)",[receiverCredential,receiverDevice,deviceCredentialInternals.tokenHash(receiverSecret,authEnv),JSON.stringify(deviceCredentialInternals.deviceCredentialSecretMetadata(authEnv))]);
   await admin.query('insert into public.msg_device_assignments(device_identifier,msg_user_id,is_active) values($1,$2,true) on conflict(device_identifier) do update set msg_user_id=excluded.msg_user_id,is_active=true',[receiverCode,otherUser]);
   await admin.query("insert into public.msg_threads(id,thread_type,title,created_by_user_id,is_active) values($1,'group','Synthetic current original Messenger HTTP thread',$2,true)",[thread,user]);
   await admin.query('insert into public.msg_thread_participants(thread_id,user_id) values($1,$2),($1,$3)',[thread,user,otherUser]);
   const epoch=String((await admin.query('select assignment_epoch from public.devices where id=$1',[device])).rows[0].assignment_epoch);
   const read=async sql=>(await tx(sql,[],'custodial_application_reader')).rows;
   const authDb={from(table){
    assert.ok(['device_auth_policy','device_auth_credentials','device_auth_events'].includes(table));let columns='*',filter;
    const query={select(value){assert.match(value,/^[a-z_,]+$/);columns=value;return query;},eq(key,value){assert.ok(['singleton','credential_id'].includes(key));filter=[key,value];return query;},
     async maybeSingle(){assert.ok(filter);try{return{data:(await tx('select '+columns+' from public.'+table+' where '+filter[0]+'=$1',[filter[1]],'service_role')).rows[0]||null,error:null};}catch(error){return{data:null,error};}},
     async insert(value){assert.equal(table,'device_auth_events');const fields=Object.keys(value);assert.ok(fields.every(key=>/^[a-z_]+$/.test(key)));try{await tx('insert into public.device_auth_events('+fields.join(',')+') values('+fields.map((_,i)=>'$'+(i+1)).join(',')+')',fields.map(key=>value[key]),'service_role',true);return{error:null};}catch(error){return{error};}}};return query;
   }};
   const store=createSupabaseDeviceCredentialStore(authDb);
   const auth=makeDeviceCredentialMiddleware({env:authEnv,store,runReadOnlySql:read,requireEnrolledCredential:true});
   const rpc=async(name,args)=>{
    assert.equal(name,'app_apply_operational_command','only new fixed original commands may write in this fixture');
    assert.ok(['employee_message_original_send','employee_message_original_read','employee_message_original_delete','employee_message_original_outcome'].includes(args.p_command));
    return(await tx('select public.app_apply_operational_command($1,$2::jsonb) data',[args.p_command,JSON.stringify(args.p_payload)],'service_role',args.p_command!=='employee_message_original_outcome')).rows[0].data;
   };
   const app=express();app.use(createGeneralJsonMiddleware());
   app.use('/messaging-api',createMessagingRouter({runReadOnlySql:read,runRpc:rpc,requireDeviceAccess:auth,requireOpsManagerAuth:(_req,res)=>res.status(403).json({ok:false}),buildHealthPayload:()=>({ok:true}),appVersion:'FIXTURE_ONLY',releaseId:'NOT_RELEASED',contractVersion:'messenger-original-fixture'}));
   app.use((error,_req,res,_next)=>res.status(error.status||500).json({ok:false,error:String(error.message)}));
   api=await start(http.createServer(app));
   const requests=[];
   const sender={deviceCode,credential,tokenSecret},receiver={deviceCode:receiverCode,credential:receiverCredential,tokenSecret:receiverSecret};
   const sendHttp=async(path,body,{method='POST',tamper=false,actor=sender}={})=>{
    const raw=body===undefined?Buffer.alloc(0):Buffer.from(JSON.stringify(body)),requestId=randomUUID(),timestamp=new Date().toISOString();
    const headers={authorization:'Device '+actor.credential+'.'+actor.tokenSecret,'x-device-id':actor.deviceCode,'x-memphis-app-edition':'custodial',origin:'https://localhost','x-memphis-native-attestation-version':'custodial-native-request.v1','x-memphis-native-request-id':requestId,'x-memphis-native-request-timestamp':timestamp};
    headers['x-memphis-native-request-attestation']=createHmac('sha256',actor.tokenSecret).update(['custodial-native-request.v1',actor.credential,actor.deviceCode,method,path,sha(raw),requestId,timestamp,'custodial'].join('\n')).digest('hex');
    if(tamper)headers['x-memphis-native-request-attestation']='0'.repeat(64);
    const r=await fetch('http://127.0.0.1:'+api.address().port+path,{method,headers:{...headers,...(body===undefined?{}:{'content-type':'application/json'})},...(body===undefined?{}:{body:raw}),signal:AbortSignal.timeout(10000)});
    const reply=await r.json();requests.push({method,path,requestId,original_body_sha256:sha(raw),status:r.status});return{status:r.status,body:reply};
   };
   const mapped=await sendHttp('/messaging-api/me/by-device?device_id='+deviceCode,undefined,{method:'GET'});
   assert.equal(mapped.status,200,JSON.stringify(mapped.body));assert.equal(mapped.body.data.msg_user_id,user);assert.equal(mapped.body.data.employee_id,employee);assert.equal(mapped.body.data.credential_id,credential);assert.equal(mapped.body.data.assignment_epoch,Number(epoch));
   const pins={device_id:deviceCode,expected_employee_id:employee,expected_credential_id:credential,expected_assignment_epoch:epoch};
   const send={...pins,sender_user_id:user,body:'Synthetic original HTTP ñ message.',message_type:'text',metadata_json:{},client_message_id:'synthetic-http:'+randomUUID()};
   const sent=await sendHttp('/messaging-api/thread/'+thread+'/message',send);assert.equal(sent.status,200,JSON.stringify(sent.body));assert.equal(sent.body.data.body,send.body);assert.equal(sent.body.meta.original_outcome.original_outcome_recorded,true);
   const received=await sendHttp('/messaging-api/thread/'+thread+'/messages?user_id='+otherUser+'&device_id='+receiverCode,undefined,{method:'GET',actor:receiver});assert.equal(received.status,200,JSON.stringify(received.body));assert.ok(received.body.data.some(row=>row.id===sent.body.data.id&&row.body===send.body));
   const receiverEpoch=String((await admin.query('select assignment_epoch from public.devices where id=$1',[receiverDevice])).rows[0].assignment_epoch);
   const readBody={device_id:receiverCode,expected_employee_id:otherEmployee,expected_credential_id:receiverCredential,expected_assignment_epoch:receiverEpoch,user_id:otherUser,through_message_id:sent.body.data.id};
   const firstRead=await sendHttp('/messaging-api/thread/'+thread+'/read',readBody,{actor:receiver});assert.equal(firstRead.status,200,JSON.stringify(firstRead.body));assert.equal(firstRead.body.data.marked,1);
   // Treat the first reply as lost. Reconciliation queries the same ORIGINAL
   // action body through the normal fixed route, never another read effect.
   const recovered=await sendHttp('/messaging-api/thread/'+thread+'/read/original-outcome',readBody,{actor:receiver});
   assert.equal(recovered.status,200,JSON.stringify(recovered.body));assert.deepEqual(recovered.body.meta.original_outcome,firstRead.body.meta.original_outcome);assert.equal(recovered.body.data.through_message_id,readBody.through_message_id);
   const unknown=await sendHttp('/messaging-api/thread/'+thread+'/read/original-outcome',{...readBody,through_message_id:id(879)},{actor:receiver});assert.equal(unknown.status,200);assert.equal(unknown.body.meta.original_outcome.state,'ORIGINAL_OUTCOME_NOT_FOUND_UNKNOWN');assert.equal(unknown.body.meta.original_outcome.resend_allowed,false);
   const invalid=await sendHttp('/messaging-api/thread/'+thread+'/read/original-outcome',readBody,{tamper:true,actor:receiver});assert.equal(invalid.status,403);
   const deleteBody={...pins,user_id:user,operation_id:randomUUID()};
   const deleted=await sendHttp('/messaging-api/thread/'+thread+'/delete',deleteBody);assert.equal(deleted.status,200,JSON.stringify(deleted.body));assert.equal(deleted.body.data.deleted,true);assert.equal(deleted.body.meta.original_outcome.original_actor.user_id,user);assert.deepEqual(deleted.body.data,deleted.body.meta.original_outcome.result);
   const deleteQuery=await sendHttp('/messaging-api/thread/'+thread+'/delete/original-outcome',deleteBody);assert.equal(deleteQuery.status,200);assert.deepEqual(deleteQuery.body.meta.original_outcome,deleted.body.meta.original_outcome);
   const stillReceived=await sendHttp('/messaging-api/thread/'+thread+'/messages?user_id='+otherUser+'&device_id='+receiverCode,undefined,{method:'GET',actor:receiver});assert.equal(stillReceived.status,200);assert.ok(stillReceived.body.data.some(row=>row.id===sent.body.data.id),'sender deletion must not delete recipient history');
   await admin.query('update public.device_auth_credentials set revoked_at=now() where credential_id=$1',[receiverCredential]);
   const withdrawn=await sendHttp('/messaging-api/thread/'+thread+'/read/original-outcome',readBody,{actor:receiver});assert.equal(withdrawn.status,401);
   const outcomes=(await admin.query('select original_command,outcome_json from custodial_release_identity.employee_message_original_outcomes order by original_command')).rows;assert.equal(outcomes.length,3);
   phase='NEW private original Messenger ledger exact seeded-row recovery/ACL/ALWAYS guard';
   const inventory=(await admin.query("select object_kind,object_identity,definition_sql,definition_sha256 from public.custodial_release_authority_restore_inventory where object_identity like 'custodial_release_identity.employee_message_original_outcomes%' order by restore_order,object_kind,object_identity")).rows;
   assert.equal(inventory.length,15);assert.ok(inventory.every(row=>sha(row.definition_sql)===row.definition_sha256));
   await admin.query('begin');
   try{
    for(const row of inventory)await admin.query(row.definition_sql);
    const restored=(await admin.query('select original_command,outcome_json from custodial_release_identity.employee_message_original_outcomes order by original_command')).rows;assert.deepEqual(restored,outcomes);
    const restoredGuards=(await admin.query("select c.relrowsecurity,c.relforcerowsecurity,(select tgenabled from pg_trigger where tgrelid=c.oid and tgname='employee_message_original_outcomes_immutable') immutable,(select tgenabled from pg_trigger where tgrelid='public.custodial_release_authority_restore_inventory'::regclass and tgname='trg_custodial_release_authority_restore_inventory_immutable') inventory_immutable,has_table_privilege('service_role',c.oid,'SELECT') service_select,has_table_privilege('custodial_application_reader',c.oid,'SELECT') reader_select from pg_class c where c.oid='custodial_release_identity.employee_message_original_outcomes'::regclass")).rows[0];
    assert.deepEqual(restoredGuards,{relrowsecurity:true,relforcerowsecurity:true,immutable:'A',inventory_immutable:'A',service_select:false,reader_select:false});
    await admin.query('commit');
   }catch(error){await admin.query('rollback');throw error;}
   put('PRODUCT_RESULT.json',{scope:'ONLY newly mounted current original Messenger HTTP parser/native credential/HMAC/SQL transaction/fixed readback and private ledger owning seeded-row recovery',actual_SQL:true,actual_HTTP:true,actual_source_general_parser:true,normal_current_device_credential:true,normal_native_request_HMAC:true,private_ledger_recovery:{members:inventory.length,seeded_rows_preserved:outcomes.length,role_grants_expanded:false,ALWAYS_immutable_preserved:true},syntheticActors:true,realMessageDelivery:false,realNamedManager:false,physical:false,consumer_native_storage:false,requests,outcomes,transactions:witness,old_groups_repeated:false});
   console.log('CURRENT_ORIGINAL_MESSENGER_NORMAL_AUTH_HMAC_HTTP_SQL_JOIN_PASS_FIXTURE_ONLY');
  }else if(purpose==='feedback-current-original'){
   phase='Current normal employee credential and actual Feedback SQL/HTTP original recovery';
   const {makeDeviceCredentialMiddleware,deviceCredentialInternals}=await import(pathToFileURL(B+'/src/auth/device-credential-auth.js'));
   const {makeFeedbackSubmitAuthority,authoritativeFeedbackPayload}=await import(pathToFileURL(B+'/src/feedback-authority.js'));
   const {authenticatePresentedOpsAccessRequest}=await import(pathToFileURL(B+'/src/auth/shared-access-auth.js'));
   const {normalizeFeedbackInput}=await import(pathToFileURL(B+'/src/public-submission-controls.js'));
   const {attachFeedbackDelivery,employeeFeedbackReceipt}=await import(pathToFileURL(B+'/src/feedback-delivery-status.js'));
   const {runEmployeeFeedbackSubmissionJoin}=await import(pathToFileURL(D+'frontend/scripts/feedback-outbox-binding-tests.mjs')+'?currentSubmissionMember=1');
   const employee=id(810),credential=id(811),deviceCode='KIOSK_08',tokenSecret=randomBytes(32).toString('base64url');
   const authEnv={NODE_ENV:'test',DEVICE_CREDENTIAL_SECRET:randomBytes(32).toString('hex')};
   await admin.query("insert into public.employees(id,employee_code,display_name,active,role) values($1,'EMP9810','Synthetic current Feedback employee',true,'staff')",[employee]);
   let device=(await admin.query('select id from public.devices where device_id=$1',[deviceCode])).rows[0]?.id;
   if(device)await admin.query('update public.devices set active=true,assigned_employee_id=$1 where id=$2',[employee,device]);
   else {device=id(812);await admin.query("insert into public.devices(id,device_id,device_name,active,assigned_employee_id) values($1,$2,'Synthetic Feedback fixture',true,$3)",[device,deviceCode,employee]);}
   await admin.query("insert into public.device_auth_credentials(credential_id,device_id,token_hash,confirmed_at,last_used_at,expires_at,metadata_json) values($1,$2,$3,now(),now(),now()+interval '1 hour',$4::jsonb)",[credential,device,deviceCredentialInternals.tokenHash(tokenSecret,authEnv),JSON.stringify(deviceCredentialInternals.deviceCredentialSecretMetadata(authEnv))]);
   const read=async statement=>(await tx(statement,[],'custodial_application_reader')).rows;
   const store={getPolicy:async()=>({mode:'enforce'}),findCredential:async key=>(await tx('select * from public.device_auth_credentials where credential_id=$1',[key],'service_role')).rows[0]};
   const gate=makeFeedbackSubmitAuthority({requireEmployeeDeviceCredential:makeDeviceCredentialMiddleware({env:authEnv,store,runReadOnlySql:read,requireEnrolledCredential:true}),
    requireOpsManagerWrite:(_req,res)=>res.status(403).json({ok:false}),authenticatePresentedOpsAccessRequest});
   const index=fs.readFileSync(B+'/src/index.js','utf8'),express=require('express'),app=express();
   app.use(express.json({verify(req,_res,buf){req.scanAuthorityRawBody=Buffer.from(buf);}}));
   const rpc=async(name,args)=>{
    assert.ok(['app_apply_operational_command','custodial_feedback_delivery_status'].includes(name));
    const query=name==='app_apply_operational_command'?'select public.app_apply_operational_command($1,$2::jsonb) data':'select * from public.custodial_feedback_delivery_status($1::uuid[])';
    try{const result=await tx(query,name==='app_apply_operational_command'?[args.p_command,JSON.stringify(args.p_payload)]:[args.p_feedback_ids],'service_role',name==='app_apply_operational_command');return{data:name==='app_apply_operational_command'?result.rows[0].data:result.rows,error:null};}catch(error){return{data:null,error};}
   };
   const nullImage=value=>{assert.ok(value==null,'new image acquisition excluded');return null;};
   const context={app,Buffer,createHash,randomUUID,console:{error(){}},normalizeFeedbackInput,authoritativeFeedbackPayload,
    requireFeedbackSubmitAuthority:gate,employeeFeedbackReceipt,attachFeedbackDelivery,supabaseAdmin:{rpc},
    APP_VERSION:'synthetic-current-source',RELEASE_ID:'fixture-only',FEEDBACK_CONTRACT_VERSION:'feedback.v3.enrolled-authority',
    publicSubmissionRateLimit:()=>((_req,_res,next)=>next()),runReadOnlySql:read,
    ensureSystemFeedbackSchema:async()=>{assert.equal((await read("select to_regclass('public.system_feedback_items') is not null present"))[0].present,true);},
    runOperationalCommand:async(command,payload)=>{const r=await rpc('app_apply_operational_command',{p_command:command,p_payload:payload});if(r.error)throw r.error;return r.data;},
    sqlLiteral:value=>value==null?'null':"'"+String(value).replaceAll("'","''")+"'",isUuid:value=>typeof value==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(value),
    stableRequestFingerprint:value=>sha(JSON.stringify(value)),requestOperationId:req=>req.body.operation_id||req.get('idempotency-key'),
    validateSystemFeedbackImageAttachment:nullImage,storeSystemFeedbackImageAttachment:async(_id,_op,image)=>nullImage(image),
    persistedSystemFeedbackImageMetadata:nullImage,removeUnreferencedSystemFeedbackImage:async image=>nullImage(image)};
   const summaryStart=index.indexOf('function summarizeSystemFeedback('),writerEnd=index.indexOf('\nasync function ',index.indexOf('async function createSystemFeedbackItem(')+10);
   const routeStart=index.indexOf('function feedbackSubmissionActor(req)'),routeEnd=index.indexOf('\napp.get("/guest-api/status"',routeStart);
   assert.ok(summaryStart>=0&&writerEnd>summaryStart&&routeStart>=0&&routeEnd>routeStart);vm.createContext(context);
   vm.runInContext(index.slice(summaryStart,writerEnd),context);vm.runInContext(index.slice(routeStart,routeEnd),context);
   api=await start(http.createServer(app));const url='http://127.0.0.1:'+api.address().port;
   const identity=async()=>{const row=(await read("select d.device_id,d.assigned_employee_id,d.assignment_epoch from public.devices d where d.id='"+device+"'::uuid"))[0];return{deviceId:row.device_id,employeeId:row.assigned_employee_id,credentialId:credential,assignmentEpoch:String(row.assignment_epoch)};};
   const identityBefore=JSON.stringify(await identity());
   const request=async(path,options)=>{assert.equal(path,'/feedback-api/submit');const raw=JSON.stringify(options.body);
    const reply=await fetch(url+path,{method:options.method,headers:{...options.headers,'Content-Type':'application/json','Authorization':'Device '+credential+'.'+tokenSecret,'X-Device-Id':deviceCode},body:raw});
    const body=await reply.json();if(!reply.ok)throw Object.assign(Error(body.error||'Current Feedback fixture denied'),{status:reply.status});return body;};
   const joined=await runEmployeeFeedbackSubmissionJoin({request,sql:(statement,args)=>tx(statement,args,'custodial_application_reader'),identity,
    mutate:async work=>{assert.equal(JSON.stringify(await identity()),identityBefore);const result=await work({deviceId:deviceCode,generation:1,assertCurrent(){}});assert.equal(JSON.stringify(await identity()),identityBefore);return result;}});
   put('PRODUCT_RESULT.json',{...joined,actual_SQL:true,actual_HTTP:true,current_normal_employee_credential:true,index_source_sha256:sha(index),
    actual_native_FIFO:false,browser_storage:'synthetic owning outbox storage',mutation_owner:'recorded synthetic currentness callback; not native',rate_limit:'fixture disabled',
    real_named_manager:false,real_email_test:false,provider_send:false,physical:false,transactions:witness});
   console.log('CURRENT_FEEDBACK_NORMAL_CREDENTIAL_SQL_HTTP_ORIGINAL_RECOVERY_PASS_NO_MAIL');
  }else if(['completion-positive','completion-protected-positive','completion-protected-http'].includes(purpose)){
   phase='Normal original START/completion, current credential fixed read and Dashboard';
   const {currentOriginalCompletionDashboardProof}=await import(pathToFileURL(B+'/scripts/verified-visit-completion-integration-tests.mjs'));
   const {originalCompletionDashboardPresentationProof}=await import(pathToFileURL(D+'frontend/scripts/operations-dashboard-tests.mjs'));
   const {readOriginalScanCompletion}=await import(pathToFileURL(B+'/src/scan-completion-readback.js'));
   const {authenticateDeviceCredentialRequest,verifyNativeDeviceRequestAttestation,deviceCredentialInternals}=await import(pathToFileURL(B+'/src/auth/device-credential-auth.js'));
   const employee=id(601),location=id(602),credential=id(603),deviceCode='KIOSK_10',locationCode='AUDIT_COMPLETION';
   const executionSecret=randomBytes(32).toString('hex'),routeSecret=randomBytes(32).toString('hex'),tokenSecret=randomBytes(32).toString('hex');
   const authEnv={DEVICE_CREDENTIAL_SECRET:randomBytes(32).toString('hex')};
   await admin.query('select public.custodial_configure_backend_execution_key($1,$2)',[sha(executionSecret),'synthetic-original-completion']);
   await admin.query('select public.custodial_configure_native_route_proof_key($1,$2)',[sha(routeSecret),'synthetic-original-completion']);
   await admin.query("insert into public.employees(id,employee_code,display_name,active,role) values($1,'EMP9601','Synthetic Original Cleaner',true,'staff')",[employee]);
   const existing=(await admin.query('select id from public.devices where device_id=$1',[deviceCode])).rows[0];
   const device=existing?.id||id(604);
   if(existing)await admin.query('update public.devices set active=true,assigned_employee_id=$1 where id=$2',[employee,device]);
   else await admin.query("insert into public.devices(id,device_id,device_name,active,assigned_employee_id) values($1,$2,'Synthetic Original Device',true,$3)",[device,deviceCode,employee]);
   await admin.query("insert into public.locations(id,location_code,location_name,location_type,form_type,active) values($1,$2,'Synthetic Original Restroom','restroom','restroom',true)",[location,locationCode]);
   await admin.query("insert into public.device_auth_credentials(credential_id,device_id,token_hash,confirmed_at,last_used_at,expires_at,metadata_json) values($1,$2,$3,now(),now(),now()+interval '1 hour',$4::jsonb)",[credential,device,deviceCredentialInternals.tokenHash(tokenSecret,authEnv),JSON.stringify(deviceCredentialInternals.deviceCredentialSecretMetadata(authEnv))]);
   await admin.query("insert into public.custodial_employee_device_assignment_history(device_id,device_identifier,new_employee_id,new_employee_name,change_reason,source) values($1,$2,$3,'Synthetic Original Cleaner','isolated fixture','test')",[device,deviceCode,employee]);
   const snapshot=(await tx('select public.tool_get_offline_scan_authority_snapshot($1,$2,$3) data',[deviceCode,credential,executionSecret],'service_role',true)).rows[0].data;
   const session=randomUUID(),completion=randomUUID(),startScan=randomUUID(),finishScan=randomUUID();
   const started=new Date(Date.parse(snapshot.generated_at)+1).toISOString(),ended=new Date(Date.parse(snapshot.generated_at)+2).toISOString();
   const context=(await tx('select public.tool_start_offline_occurrence($1,$2,$3,$4,$5,$6,$7::integer,$8,$9,$10,$11,$12,$13,$14) data',[deviceCode,locationCode,session,started,snapshot.snapshot_id,snapshot.employee_id,snapshot.assignment_epoch,credential,credential,startScan,'custodial-native-start.v1','a'.repeat(64),routeSecret,executionSecret],'service_role',true)).rows[0].data;
   const response={work_result:'details',services_performed:['Sweep the floor'],note:'漢'.repeat(50000)};
   const evidence=[{client_event_id:finishScan,event_type:'scan_finish',result:'ok',notes:'SYNTHETIC ORIGINAL FIXTURE',scanned_at:ended,payload_json:{entry_source:'native-nfc'}}];
   const correlation='synthetic-original-completion';
   const payload={p_device_id:deviceCode,p_client_session_id:session,p_client_completion_id:completion,p_location_code:locationCode,p_client_started_at:started,p_client_ended_at:ended,p_response_json:{...response,__custodial_offline_reconciliation_v1:{context_id:context.context_id,submission_proof:context.submission_proof}},p_scan_evidence:evidence,p_correlation_id:correlation,p_native_finish_scan_entry_id:finishScan,p_native_completion_attestation_version:'custodial-native-completion.v2',p_native_completion_attestation:'b'.repeat(64)};
   const body={completion_payload:payload},raw=Buffer.from(JSON.stringify(body)),timestamp=new Date().toISOString(),requestId=randomUUID();
   const request={method:'POST',originalUrl:'/scan-api/original-completion',url:'/scan-api/original-completion',body,scanAuthorityRawBody:raw,headers:{authorization:'Device '+credential+'.'+tokenSecret,'x-device-id':deviceCode,'x-memphis-native-attestation-version':'custodial-native-request.v1','x-memphis-native-request-id':requestId,'x-memphis-native-request-timestamp':timestamp,'x-memphis-app-edition':'custodial'}};
   request.header=name=>request.headers[name.toLowerCase()];
   request.headers['x-memphis-native-request-attestation']=createHmac('sha256',tokenSecret).update(['custodial-native-request.v1',credential,deviceCode,'POST',request.originalUrl,sha(raw),requestId,timestamp,'custodial'].join('\n')).digest('hex');
   const read=async sql=>{try{return(await tx(sql,[],'custodial_application_reader')).rows;}
    catch(error){put('ORIGINAL_READ_SQL_FAILURE.json',{code:error.code,message:error.message.slice(0,300),SQL_sha256:sha(sql),role:'custodial_application_reader',role_fallback:false});throw error;}};
   const store={getPolicy:async()=>({mode:'enforced'}),findCredential:async key=>(await tx('select * from public.device_auth_credentials where credential_id=$1',[key],'service_role')).rows[0]};
   const authenticate=async req=>{const auth=await authenticateDeviceCredentialRequest(req,{env:authEnv,store,runReadOnlySql:read,requireEnrolledCredential:true});assert.equal(auth.ok,true,auth.code);req.memphisDevice=auth.device;req.memphisDeviceCredential=auth.credential;req.memphisNativeRequestAttestation=verifyNativeDeviceRequestAttestation(req);return auth;};
   let httpRead=null,httpSourceHash=null;
   if(purpose==='completion-protected-http'){
    const {makeDeviceCredentialMiddleware}=await import(pathToFileURL(B+'/src/auth/device-credential-auth.js'));
    const {deferJsonParserErrors}=await import(pathToFileURL(B+'/src/offline-authority-http.js'));
    // Existing source-owned HTTP fixture, not a new server/framework. Actual
    // auth module/store factory executes against these fixed SQL SDK members.
    const supabaseAdmin={from(table){
     assert.ok(['device_auth_policy','device_auth_credentials','device_auth_events'].includes(table));
     let columns='*',filter=null;
     const query={select(value){assert.match(value,/^[a-z_,]+$/);columns=value;return query;},eq(key,value){assert.ok(['singleton','credential_id'].includes(key));filter=[key,value];return query;},
      async maybeSingle(){assert.ok(filter);try{return{data:(await tx('select '+columns+' from public.'+table+' where '+filter[0]+'=$1',[filter[1]],'service_role')).rows[0]||null,error:null};}catch(error){return{data:null,error};}},
      async insert(value){assert.equal(table,'device_auth_events');const fields=Object.keys(value);assert.ok(fields.every(key=>/^[a-z_]+$/.test(key)));try{await tx('insert into public.device_auth_events('+fields.join(',')+') values('+fields.map((_,i)=>'$'+(i+1)).join(',')+')',fields.map(key=>value[key]),'service_role',true);return{error:null};}catch(error){return{error};}}};return query;
    }};
    // Standalone owning fixture process only; normal revalidation's default
    // env uses the same test secret that enrolled this original credential.
    process.env.DEVICE_CREDENTIAL_SECRET=authEnv.DEVICE_CREDENTIAL_SECRET;
    const source=fs.readFileSync(B+'/src/index.js','utf8'),app=express();
    const parserStart=source.indexOf('const MAX_SCAN_RPC_BYTES ='),parserEnd=source.indexOf('\nasync function rejectInvalidAuthenticatedScanAuthorityJson',parserStart);
    const rateStart=source.indexOf('function scanRpcRateLimit('),rateEnd=source.indexOf('\nfunction isHealthPath',rateStart);
    const helperStart=source.indexOf('function clientIp('),helperEnd=source.indexOf('\nfunction canonicalizeScanArguments',helperStart);
    const routeStart=source.indexOf('app.post(SCAN_COMPLETION_READBACK_PATH,'),routeEnd=source.indexOf('\napp.post("/scan-api/rpc"',routeStart);
    assert.ok([parserStart,rateStart,helperStart,routeStart].every(n=>n>=0));
    const owning=[source.slice(parserStart,parserEnd),source.slice(helperStart,helperEnd),source.slice(rateStart,rateEnd),source.slice(routeStart,routeEnd)].join('\n');httpSourceHash=sha(owning);
    vm.runInNewContext(owning,{app,express,Buffer,Date,Map,SCAN_COMPLETION_READBACK_PATH:'/scan-api/original-completion',
     deferJsonParserErrors,requireEmployeeDeviceCredential:makeDeviceCredentialMiddleware({env:authEnv,supabase:supabaseAdmin,runReadOnlySql:read,requireEnrolledCredential:true}),
     RATE_LIMIT_WINDOW_MS:60000,SCAN_READ_LIMIT_PER_MINUTE:120,SCAN_WRITE_LIMIT_PER_MINUTE:30,SCAN_SHARED_IP_EMERGENCY_LIMIT_PER_MINUTE:1000,
     scanRateLimitBuckets:new Map(),SCAN_READ_FUNCTIONS:new Set(['tool_get_offline_scan_authority_snapshot']),
     supabaseAdmin,runReadOnlySql:read,authenticateDeviceCredentialRequest,verifyNativeDeviceRequestAttestation,readOriginalScanCompletion});
    api=await start(http.createServer(app));
    httpRead=async(headers=request.headers)=>{const r=await fetch('http://127.0.0.1:'+api.address().port+request.originalUrl,{method:'POST',headers:{...headers,'content-type':'application/json'},body:raw,signal:AbortSignal.timeout(10000)});const reply=Buffer.from(await r.arrayBuffer());return{status:r.status,body:JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(reply)),raw_reply_base64:reply.toString('base64')};};
    const pending=await httpRead();assert.equal(pending.status,200,JSON.stringify(pending.body));assert.deepEqual(pending.body,{ok:true,data:{found:false}});
    checks.push('NEW normal HTTP parser/auth/request HMAC/private intended-role lookup returns pending without a completion write');
   }
   if(purpose==='completion-protected-positive'){
    const sql='select * from custodial_release_identity.read_original_scan_completion_v1($1::uuid,$2,$3::uuid,$4::bigint,$5::uuid,$6::jsonb)';
    const args=[device,deviceCode,employee,snapshot.assignment_epoch,credential,JSON.stringify(payload)];
    for(const role of ['anon','authenticated','service_role','static_weekly_control_plane','static_weekly_release_operator']){
     await assert.rejects(()=>tx(sql,args,role),error=>error.code==='42501');
     await assert.rejects(()=>tx('select * from custodial_release_identity.read_current_original_dashboard_completions_v1()',[],role),error=>error.code==='42501');
    }
    assert.equal((await tx(sql,args,'custodial_application_reader')).rows.length,0);
    checks.push('NEW267 both actual private readers deny all five runtime/API roles; intended missing original stays unknown');
   }
   const result=await currentOriginalCompletionDashboardProof({runReadOnlySql:read,readRole:'custodial_application_reader',sourceFixture:{employee_id:employee,employee_name:'Synthetic Original Cleaner',location_id:location,device_id:device,credential_id:credential,context_id:context.context_id,occurrence_id:context.occurrence_id,snapshot_id:snapshot.snapshot_id,assignment_epoch:String(snapshot.assignment_epoch),client_session_id:session,client_completion_id:completion,started_at:started,completed_at:ended,work_result:response.work_result,services_performed:response.services_performed},
    commitOriginalVisit:async()=>(await tx('select public.tool_commit_cleaning_workflow_authoritative($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb,$9,$10,$11,$12,$13,$14,$15,$16,$17) data',[session,completion,deviceCode,locationCode,started,ended,JSON.stringify(response),JSON.stringify(evidence),correlation,context.context_id,context.submission_proof,credential,finishScan,'custodial-native-completion.v2','b'.repeat(64),routeSecret,executionSecret],'service_role',true)).rows[0].data,
    readOriginalCompletion:async()=>{let data,replyBase64=null;if(httpRead){const r=await httpRead();assert.equal(r.status,200,JSON.stringify(r.body));assert.equal(r.body.ok,true);data=r.body.data;replyBase64=r.raw_reply_base64;}else data=await readOriginalScanCompletion({runReadOnlySql:read,request,completionPayload:payload,revalidateCurrentRequest:authenticate});
     if(!data.found){
      const visibilitySql=`select
        (select count(*)::int from public.custodial_offline_reconciliation_records where client_completion_id=$1) receipt,
        (select count(*)::int from public.custodial_offline_actor_contexts where context_id=$2::uuid) context,
        (select count(*)::int from public.custodial_offline_submission_proofs where context_id=$2::uuid) proof,
        (select count(*)::int from public.sessions where client_session_id=$3) session,
        (select count(*)::int from public.completion_responses where client_completion_id=$1) response`;
      put('ORIGINAL_ROW_VISIBILITY.json',{intended_reader:(await tx(visibilitySql,[completion,context.context_id,session],'custodial_application_reader')).rows,
       fixture_diagnosis_only:(await admin.query(visibilitySql,[completion,context.context_id,session])).rows,authority_fallback:false});
      const diagnostic=(await tx(`select r.state receipt_state,c.status context_state,p.state proof_state,s.status session_state,
        c.snapshot_id=$1 snapshot_matches,c.snapshot_employee_id=r.original_employee_id snapshot_employee_matches,
        c.snapshot_assignment_epoch=c.assignment_epoch snapshot_epoch_matches,
        c.native_completion_attestation_sha256=$2 attestation_matches,
        c.native_finish_scan_entry_id=$3::uuid finish_matches,
        r.payload_json->'response_json'=$4::jsonb response_matches,cr.response_json=r.payload_json->'response_json' saved_response_matches,
        r.payload_json->'scan_evidence'=$5::jsonb evidence_matches,
        r.payload_fingerprint=public.custodial_offline_payload_fingerprint(c,$6,$7::timestamptz,$8::timestamptz,$4::jsonb,$5::jsonb,$9) fingerprint_matches,
        p.proof_digest=$10 proof_matches,r.result_json->>'session_uuid'=s.session_uuid result_session_matches,
        r.result_json->>'completion_response_id'=cr.id::text result_response_matches,
        r.result_json->>'occurrence_id'=c.occurrence_id::text result_occurrence_matches,
        r.result_json->>'original_employee_id'=c.employee_id::text result_employee_matches,
        exists(select 1 from public.custodial_offline_scan_event_evidence e where e.reconciliation_id=r.reconciliation_id
          and e.event_payload->>'scanned_at'=$8::text) finish_time_matches
        from public.custodial_offline_reconciliation_records r join public.custodial_offline_actor_contexts c on c.context_id=r.context_id
        join public.custodial_offline_submission_proofs p on p.context_id=c.context_id join public.sessions s on s.id=r.session_id
        join public.completion_responses cr on cr.id=r.completion_response_id where r.client_completion_id=$6`,
       [snapshot.snapshot_id,sha('b'.repeat(64)),finishScan,JSON.stringify(response),JSON.stringify(evidence),completion,started,ended,correlation,sha(context.submission_proof)],'custodial_application_reader')).rows;
      put('ORIGINAL_READ_PREDICATE_DIAGNOSIS.json',{diagnostic,read_only:true,accepted:false,role_fallback:false});
     }
     put('TEMP_SYNTHETIC_NATIVE_JOURNAL_INPUT.json',{request_body:body,readback:data,...(replyBase64?{request_body_base64:raw.toString('base64'),response_body_base64:replyBase64}:{})});return data;},presentDashboard:originalCompletionDashboardPresentationProof});
   if(purpose==='completion-protected-positive'){
    const sql='select * from custodial_release_identity.read_original_scan_completion_v1($1::uuid,$2,$3::uuid,$4::bigint,$5::uuid,$6::jsonb)',args=[device,deviceCode,employee,snapshot.assignment_epoch,credential,JSON.stringify(payload)];
    for(const changed of [[device,deviceCode,id(699),snapshot.assignment_epoch,credential,JSON.stringify(payload)],
     [device,deviceCode,employee,snapshot.assignment_epoch+1,credential,JSON.stringify(payload)],
     [device,deviceCode,employee,snapshot.assignment_epoch,id(698),JSON.stringify(payload)],
     [device,deviceCode,employee,snapshot.assignment_epoch,credential,JSON.stringify({...payload,p_response_json:{...payload.p_response_json,note:'changed'}})]])
      assert.equal((await tx(sql,changed,'custodial_application_reader')).rows.length,0);
    const identities=['custodial_release_identity.read_original_scan_completion_v1(uuid,text,uuid,bigint,uuid,jsonb)','custodial_release_identity.read_current_original_dashboard_completions_v1()'];
    for(const identity of identities){
     const before=(await admin.query('select pg_get_functiondef($1::regprocedure) definition,proowner,proacl from pg_proc where oid=$1::regprocedure',[identity])).rows[0];
     const defs=(await admin.query("select object_kind,definition_sql,definition_sha256 from public.custodial_release_authority_restore_inventory where object_identity like '%(%' and to_regprocedure(object_identity)=$1::regprocedure and object_kind in('function','grant') order by case object_kind when 'function' then 0 else 1 end",[identity])).rows;
     assert.equal(defs.length,2);for(const d of defs)assert.equal(sha(d.definition_sql),d.definition_sha256);
     await admin.query('begin');try{await admin.query('drop function '+identity);for(const d of defs)await admin.query(d.definition_sql);assert.deepEqual((await admin.query('select pg_get_functiondef($1::regprocedure) definition,proowner,proacl from pg_proc where oid=$1::regprocedure',[identity])).rows[0],before);}finally{await admin.query('rollback');}
    }
    await admin.query('update public.device_auth_credentials set revoked_at=now() where credential_id=$1',[credential]);
    assert.equal((await tx(sql,args,'custodial_application_reader')).rows.length,0);
    checks.push('NEW267 wrong employee/epoch/credential/body and actual credential withdrawal give no original; exact function/owner/ACL recovery verified in rollback');
   }
   if(httpRead){
    const denied=await httpRead({...request.headers,'x-memphis-native-request-attestation':'0'.repeat(64)});assert.equal(denied.status,403);assert.equal(denied.body.ok,false);
    await admin.query('update public.device_auth_credentials set revoked_at=now() where credential_id=$1',[credential]);
    const revoked=await httpRead();assert.equal(revoked.status,401);assert.equal(revoked.body.ok,false);
    checks.push('NEW actual HTTP wrong request HMAC and revoked current credential refused; no completion resend');
   }
   put('PRODUCT_RESULT.json',{...result,checks,actual_SQL:true,current_credential_and_request_HMAC:true,actual_HTTP:!!httpRead,http_owning_source_sha256:httpSourceHash,SDK_facade_NOT_hosted_PostgREST:true,real_manager:false,physical:false,native_journal_ACK:false,transactions:witness});
   console.log('CURRENT_ORIGINAL_COMPLETION_SQL_AUTH_DASHBOARD_PASS');
  }else if(purpose==='completion-readback-permission'){
   phase='First actual original completion helper/original START relation role capability';
   const signature='public.custodial_offline_payload_fingerprint(public.custodial_offline_actor_contexts,text,timestamp with time zone,timestamp with time zone,jsonb,jsonb,text)';
   const result=(await tx("select current_user role,has_function_privilege(current_user,$1,'EXECUTE') fingerprint_execute,has_table_privilege(current_user,'public.custodial_offline_actor_contexts','SELECT') context_select,has_column_privilege(current_user,'public.custodial_offline_submission_proofs','state','SELECT') proof_state_select",[signature],'custodial_application_reader',false)).rows[0];
   assert.equal(result.role,'custodial_application_reader');
   put('PRODUCT_RESULT.json',{scope:'FIRST actual dedicated-reader catalog capability ONLY; no new grant/mutation or product acceptance',capability:result,actual_SQL:true,positive_original_completion:false,actual_HTTP:false,real_manager:false,physical:false,provider_send:false,solver_invocations:0});
   console.log(JSON.stringify({actual_catalog:result,no_grant_or_role_fallback:true}));
   if(!result.fingerprint_execute)throw Error('Existing intended reader cannot EXECUTE original completion fingerprint; source reader unqualified, no privilege fallback');
  }else if(purpose==='dashboard-original-source'){
   phase='Current original Dashboard fixed SELECT under intended reader';
   const main=fs.readFileSync(B+'/src/index.js','utf8');
   const first=main.indexOf('select distinct on (receipt.location_id) receipt.location_id,');
   const last=main.indexOf('`),',first);assert.ok(first>=0&&last>first);
   const sql=main.slice(first,last);
   assert.ok(sql.includes("'schema','custodial.dashboard-original-completion.v1'"));
   const result=await tx(sql,[],'custodial_application_reader',false);
   assert.ok(Array.isArray(result.rows));
   checks.push('new exact original completion SELECT executed with unchanged intended read-only application role');
   put('PRODUCT_RESULT.json',{scope:'new fixed original Dashboard SQL intended-role admission only; no synthetic accepted record inserted',checks,actual_SQL:true,row_count:result.rows.length,positive_original_completion:false,actual_HTTP:false,real_manager:false,physical:false,provider_send:false,solver_invocations:0});
   console.log('CURRENT_ORIGINAL_DASHBOARD_INTENDED_READER_SQL_PASS');
  }else if(purpose==='event-date-source'){
   phase='NEW266 exact event civil-day/instant SQL and owning recovery';
   const identity='public.mz_mark_employee_event_opened(uuid,text)';
   const before=(await admin.query('select pg_get_functiondef($1::regprocedure) definition,p.proowner,p.proacl,p.prosrc from pg_proc p where oid=$1::regprocedure',[identity])).rows[0];
   assert.equal(sha(before.prosrc),'6b3b1591f0c72316c9f168fb38668fed60de2cfc7764aea5b42b6a96d7a8bcd9');
   assert.ok(before.prosrc.includes('or e.event_date is distinct from original.service_date'));
   assert.ok(before.prosrc.includes('where s.scheduled_for=original.scheduled_for)<>1'));
   assert.ok(!before.prosrc.includes('s.reminder_date=original.service_date'));
   checks.push('actual new266 body binds original event civil date and exact scheduled instant separately');
   const defs=(await admin.query("select object_kind,definition_sql,definition_sha256 from public.custodial_release_authority_restore_inventory where object_kind in('function','grant') and object_identity like '%(%' and to_regprocedure(object_identity)=$1::regprocedure order by case object_kind when 'function' then 0 else 1 end",[identity])).rows;
   assert.equal(defs.length,2);for(const r of defs)assert.equal(sha(r.definition_sql),r.definition_sha256);
   await admin.query('begin');try{await admin.query('drop function '+identity);for(const r of defs)await admin.query(r.definition_sql);assert.deepEqual((await admin.query('select pg_get_functiondef($1::regprocedure) definition,p.proowner,p.proacl,p.prosrc from pg_proc p where oid=$1::regprocedure',[identity])).rows[0],before);}finally{await admin.query('rollback');}
   checks.push('new266 owning body/owner/ACL restore exactly in rollback; existing canary and unrelated inventory guards applied');
   put('PRODUCT_RESULT.json',{scope:'only new266 actual SQL event-date/instant body and recovery; positive current Event HTTP NOT_RUN',checks,actual_SQL:true,positive_current_event:false,actual_HTTP:false,provider_send:false,real_manager:false,physical:false,solver_invocations:0});
   console.log('NEW266_EVENT_DATE_SOURCE_RECOVERY_PASS');
  }else if(purpose==='event-source'){
   phase='NEW264 Event original recipient guard/source/ACL/recovery';
   const identity='public.mz_mark_employee_event_opened(uuid,text)';
   const body=fs.readFileSync(B+'/supabase/migrations/20261012052430_employee_event_open_original_receipt.sql','utf8').split('$new_body$')[1];assert.ok(body);
   const before=(await admin.query('select pg_get_functiondef($1::regprocedure) definition,p.proowner,p.proacl,p.prosrc from pg_proc p where oid=$1::regprocedure',[identity])).rows[0];assert.equal(before.prosrc,body);
   for(const role of ['anon','authenticated','custodial_application_reader','static_weekly_control_plane','static_weekly_release_operator'])await assert.rejects(()=>tx('select public.mz_mark_employee_event_opened($1::uuid,$2::text)',[id(401),'unavailable-original'],role),e=>e.code==='42501');
   for(const [credential,key]of [[null,'original'],[id(401),''],[id(401),'x'.repeat(241)],[id(401),'prefix\u0001suffix']])await assert.rejects(()=>tx('select public.mz_mark_employee_event_opened($1::uuid,$2::text)',[credential,key],'service_role',true),e=>e.code==='22023');
   await assert.rejects(()=>tx('select public.mz_mark_employee_event_opened($1::uuid,$2::text)',[id(401),'unavailable-original'],'service_role',true),e=>e.code==='42501');
   checks.push('actual exact new source, existing five denied roles, invalid key and missing original recipient refusal');
   const defs=(await admin.query("select object_kind,definition_sql,definition_sha256 from public.custodial_release_authority_restore_inventory where object_kind in('function','grant') and object_identity like '%(%' and to_regprocedure(object_identity)=$1::regprocedure order by case object_kind when 'function' then 0 else 1 end",[identity])).rows;assert.equal(defs.length,2);for(const r of defs)assert.equal(sha(r.definition_sql),r.definition_sha256);
   await admin.query('begin');try{await admin.query('drop function '+identity);for(const r of defs)await admin.query(r.definition_sql);assert.deepEqual((await admin.query('select pg_get_functiondef($1::regprocedure) definition,p.proowner,p.proacl,p.prosrc from pg_proc p where oid=$1::regprocedure',[identity])).rows[0],before);}finally{await admin.query('rollback');}
   checks.push('exact new body/owner/ACL restored in rollback, prior control boundary retained');
   put('PRODUCT_RESULT.json',{scope:'only new264 actual Event source/recipient-negative/ACL/recovery, positive current Event HTTP NOT_RUN',checks,actual_SQL:true,provider_send:false,real_manager:false,physical:false,solver_invocations:0});
   console.log('NEW264_ORIGINAL_EVENT_GUARD_SOURCE_ACL_RECOVERY_PASS');
  }else if(['vacancy-workflow','vacancy-retained'].includes(purpose)){
   phase='NEW263 normal vacancy authenticated rollback-preview/one-confirm/original-readback';
   const {Pool}=require('pg');
   const {createStaticWeeklyControlPlane}=await import(pathToFileURL(B+'/src/static-weekly-control-plane.js'));
   const {createStaticWeeklyControlPlaneRuntime}=await import(pathToFileURL(B+'/src/static-weekly-control-plane-runtime.js'));
   const {compileStaticWeeklyScheduleIsolated,compileAndPrepareStaticWeeklyScheduleIsolated}=await import(pathToFileURL(B+'/src/static-weekly-schedule-compiler-runtime.js'));
   const {createOpsManagerSession,makeOpsAccessMiddleware}=await import(pathToFileURL(B+'/src/auth/shared-access-auth.js'));
   const {buildCurrentVacancyFixtureSource,currentVacancyPreviewConfirmOriginalReadbackProof}=await import(pathToFileURL(B+'/scripts/static-weekly-midweek-vacancy-database-fixture.mjs'));
   const owner=(await admin.query("select * from public.ops_manager_managers where system_key='eric_custodial_manager' and active and not is_system_principal and revoked_at is null")).rows[0];assert.ok(owner);
   const credentialId=id(301),deviceId='SYNTHETIC_CURRENT_VACANCY';
   await admin.query("insert into public.ops_manager_trusted_devices(credential_id,device_id,device_label,token_hash,max_access_level,manager_id,expires_at) values($1,$2,'Synthetic current vacancy',repeat('b',64),'full_access',$3,now()+interval '1 hour')",[credentialId,deviceId,owner.manager_id]);
   const env={NODE_ENV:'test',SUPABASE_URL:'http://127.0.0.1:1',SUPABASE_SERVICE_ROLE_KEY:randomBytes(32).toString('hex'),OPS_MANAGER_SESSION_SECRET:randomBytes(32).toString('hex')};
   const store={async find(credential){const r=await tx("select to_jsonb(d) data,to_jsonb(m) manager from public.ops_manager_trusted_devices d join public.ops_manager_managers m on d.manager_id=m.manager_id where d.credential_id=$1",[credential]);return r.rows[0]?{...r.rows[0].data,manager:r.rows[0].manager}:null;}};
   const session=createOpsManagerSession({env,manager:owner,credentialId,deviceId,accessLevel:'full_access'});
   const gate=makeOpsAccessMiddleware({env,trustedDeviceStore:store,requireWrite:true});
   const req={headers:{authorization:'Bearer '+session.token,'x-device-id':deviceId},header(name){return this.headers[String(name).toLowerCase()];}};let authenticated=0;
   await gate(req,{status(s){throw Error('Normal current vacancy fixture denied '+s);},json(){throw Error('Normal current vacancy fixture denied');}},()=>authenticated++);assert.equal(authenticated,1);
   const sql=statement=>execFileSync('/usr/bin/docker',['--host','unix:///var/run/docker.sock','exec','-i',ownedContainerName,'psql','-X','-q','-v','ON_ERROR_STOP=1','-At','-U','supabase_admin','-d','postgres'],{input:statement,encoding:'utf8',timeout:15000,maxBuffer:16*1024*1024});
   const locationId=id(306),employees=[{id:id(302),slotId:id(304),displayName:'Synthetic Vacancy Original'},{id:id(303),slotId:id(305),displayName:'Synthetic Vacancy Remaining'}];
   await admin.query("insert into public.employees(id,employee_code,display_name,role,active) values($1,'EMP9302',$2,'staff',true),($3,'EMP9303',$4,'staff',true)",[employees[0].id,employees[0].displayName,employees[1].id,employees[1].displayName]);
   await admin.query("insert into public.locations(id,location_code,location_name,location_type,form_type,active) values($1,'CURRENT_VACANCY','Synthetic vacancy place','restroom','restroom',true);",[locationId]);
   await admin.query("insert into public.location_groups(id,group_code,group_name,active) values($1,'CURRENT_VACANCY','Synthetic vacancy place',true)",[locationId]);
   await admin.query('insert into public.location_group_memberships(location_id,location_group_id,active) values($1,$1,true)',[locationId]);
   const week=(await admin.query('select (d-(extract(isodow from d)::integer-1))::text week from (select public.sch_service_date(statement_timestamp()) d) q')).rows[0].week;
   const source=buildCurrentVacancyFixtureSource({weekStart:week,employees,locationId,locationCode:'CURRENT_VACANCY',locationName:'Synthetic vacancy place',slotId:employees[0].slotId});
   let preparationCount=0;const preparationRecords=[];
   const compilerPreparer=async(input,preparation,limits)=>{const projection=await compileAndPrepareStaticWeeklyScheduleIsolated(input,preparation,limits);const record={input,preparation,projection};preparationRecords.push(structuredClone(record));put('vacancy-preparation-'+(++preparationCount)+'.json',record);return projection;};
   let pool=new Pool({...options,max:4}),plane=createStaticWeeklyControlPlane({database:pool,compilerPreparer});
   staffingFixture={async close(){await plane.close();}};
   const rpc={custodial_begin_application_mutation_lease:[['p_request_id','uuid'],['p_service_name','text']],custodial_heartbeat_application_mutation_lease:[['p_request_id','uuid']],custodial_release_application_mutation_lease:[['p_request_id','uuid']]};
   const supabase={async rpc(name,args){assert.ok(rpc[name]);const params=rpc[name];assert.deepEqual(Object.keys(args).sort(),params.map(x=>x[0]).sort());try{const r=await tx('select public.'+name+'('+params.map((x,i)=>'$'+(i+1)+'::'+x[1]).join(',')+') data',params.map(x=>args[x[0]]),'service_role',true);return {data:r.rows[0].data,error:null};}catch(e){return {data:null,error:{code:e.code,message:e.message}};}}};
   const runtime=createStaticWeeklyControlPlaneRuntime({env,supabase,trustedDeviceStore:store,database:pool,controlPlane:plane});api=await start(http.createServer(runtime.app));
   const request=async({method,path,body})=>{const r=await fetch('http://127.0.0.1:'+api.address().port+path,{method,headers:{authorization:'Bearer '+session.token,'x-device-id':deviceId,'content-type':'application/json'},...(body===undefined?{}:{body})});return {status:r.status,body:await r.json()};};
   const recreateLifecycle=async()=>{
     api.closeAllConnections();await new Promise(resolve=>api.close(resolve));await plane.close();
     pool=new Pool({...options,max:4});plane=createStaticWeeklyControlPlane({database:pool,compilerPreparer});
     const next=createStaticWeeklyControlPlaneRuntime({env,supabase,trustedDeviceStore:store,database:pool,controlPlane:plane});api=await start(http.createServer(next.app));
     return {plane,request};
   };
   const result=await currentVacancyPreviewConfirmOriginalReadbackProof({sql,container:ownedContainerName,plane,manager:req.memphisAuth,source,slotId:employees[0].slotId,employeeId:employees[0].id,vacancySourceId:id(307),idempotencyKey:'current-vacancy-one-confirm',reason:'Synthetic current vacancy',compiler:compileStaticWeeklyScheduleIsolated,request,capture:put,getPreparationRecords:()=>preparationRecords,recreateLifecycle});
   put('PRODUCT_RESULT.json',result);console.log('NEW263_VACANCY_ROLLBACK_ONE_CONFIRM_ORIGINAL_READBACK_PASS');
  }else if(purpose==='vacancy-source'){
   phase='NEW263 original vacancy reader exact source/ACL/recovery';
   const identity='public.static_weekly_read_original_staffing_outcome_v1(uuid,text,text)';
   const before=(await admin.query("select pg_get_functiondef($1::regprocedure) definition,p.proowner,p.proacl,encode(extensions.digest(p.prosrc,'sha256'),'hex') body_sha from pg_proc p where oid=$1::regprocedure",[identity])).rows[0];
   assert.equal(before.body_sha,'be807e394929b9c077713113c3e98a9af37cfc62b314699f6a299b816fa93789');
   for(const role of ['anon','authenticated','service_role','custodial_application_reader','static_weekly_release_operator'])await assert.rejects(()=>tx('select public.static_weekly_read_original_staffing_outcome_v1($1::uuid,$2::text,$3::text)',[id(201),'original-vacancy-key','vacate_roster_slot'],role),e=>e.code==='42501');
   checks.push('new exact original reader source and existing five runtime denials');
   const defs=(await admin.query("select object_kind,definition_sql,definition_sha256 from public.custodial_release_authority_restore_inventory where object_kind in('function','grant') and object_identity like '%(%' and to_regprocedure(object_identity)=$1::regprocedure order by case object_kind when 'function' then 0 else 1 end",[identity])).rows;
   assert.equal(defs.length,2);assert.equal(defs[0].definition_sql,before.definition);for(const row of defs)assert.equal(sha(row.definition_sql),row.definition_sha256);
   await admin.query('begin');try{await admin.query('drop function '+identity);for(const row of defs)await admin.query(row.definition_sql);const restored=(await admin.query("select pg_get_functiondef($1::regprocedure) definition,p.proowner,p.proacl,encode(extensions.digest(p.prosrc,'sha256'),'hex') body_sha from pg_proc p where oid=$1::regprocedure",[identity])).rows[0];assert.deepEqual(restored,before);}finally{await admin.query('rollback');}
   checks.push('new original reader exact body/owner/ACL restore and rollback');
   put('PRODUCT_RESULT.json',{scope:'only new263 actual migration source/ACL/recovery; positive vacancy and HMAC application NOT_RUN',checks,actual_SQL:true,solver_invocations:0,confirmation_calls:0,real_manager:false,physical:false});
   console.log('NEW263_ORIGINAL_READER_SOURCE_ACL_RECOVERY_PASS');
  }else if(purpose==='staffing-schema'){
   phase='NEW261 normal manager snapshot source/ACL/recovery';
   const identity='public.static_weekly_v3_read_manager_snapshot(date)';
   const source=(await admin.query('select encode(extensions.digest(p.prosrc,\'sha256\'),\'hex\') body_sha,p.proowner,p.proacl from pg_proc p where oid=$1::regprocedure',[identity])).rows[0];
   assert.equal(source.body_sha,'47cb329374e8fd436e445842da41d15758b36799332cd9d6e259e3e3e00aca6b');
   for(const role of ['anon','authenticated','service_role','custodial_application_reader','static_weekly_release_operator'])await assert.rejects(()=>tx('select public.static_weekly_v3_read_manager_snapshot($1::date) data',['2026-10-12'],role),e=>e.code==='42501');
   checks.push('new exact snapshot source applied with prior runtime denial boundary');
   const before=(await admin.query('select pg_get_functiondef($1::regprocedure) definition,p.proowner,p.proacl from pg_proc p where oid=$1::regprocedure',[identity])).rows[0];
   const defs=(await admin.query("select object_kind,definition_sql,definition_sha256 from public.custodial_release_authority_restore_inventory where object_kind in('function','grant') and object_identity like '%(%' and to_regprocedure(object_identity)=$1::regprocedure order by case object_kind when 'function' then 0 else 1 end",[identity])).rows;
   assert.equal(defs.length,2);assert.equal(defs[0].definition_sql,before.definition);for(const row of defs)assert.equal(sha(row.definition_sql),row.definition_sha256);
   await admin.query('begin');try{await admin.query('drop function '+identity);for(const row of defs)await admin.query(row.definition_sql);assert.deepEqual((await admin.query('select pg_get_functiondef($1::regprocedure) definition,p.proowner,p.proacl from pg_proc p where oid=$1::regprocedure',[identity])).rows[0],before);}finally{await admin.query('rollback');}
   checks.push('new exact snapshot body/owner/prior serialized ACL restored within rollback');
   put('PRODUCT_RESULT.json',{scope:'only new261 snapshot actual-source/ACL/recovery; no positive cancellation/target data claim',checks,actual_SQL:true,solver_invocations:0,confirmation_invocations:0,realManagerBrowser:false,production:false,metadata_positive_NOT_RUN:true});
   console.log('NEW261_SNAPSHOT_SOURCE_ACL_RECOVERY_PASS_NOT_CANCELLATION');
  }else if(['staffing-positive','staffing-date','staffing-cancel','staffing-replaced'].includes(purpose)){
   phase='new current staffing normal fixture setup';
   async function sql(statement){const c=new Client(options);clients.add(c);c.on('error',()=>{});
    try{await c.connect();await c.query("set statement_timeout='20s';set lock_timeout='3s'");
     const result=await c.query(statement),results=Array.isArray(result)?result:[result];
     const selected=results.filter(r=>r.rows?.length).at(-1);if(!selected)return '';
     return selected.rows.map(row=>Object.values(row).map(value=>typeof value==='boolean'?(value?'t':'f'):value===null?'':typeof value==='object'?JSON.stringify(value):String(value)).join('|')).join('\n');
    }catch(e){e.stderr=String(e.code||'SQL_ERROR')+' '+String(e.message);throw e;}
    finally{await c.end().catch(()=>{});clients.delete(c);}}
   const owner=(await admin.query("select * from public.ops_manager_managers where system_key='eric_custodial_manager' and active and not is_system_principal and revoked_at is null")).rows[0];assert.ok(owner);
   const credentialId=id(81),deviceId='SYNTHETIC_STAFFING_JOIN';
   await admin.query("insert into public.ops_manager_trusted_devices(credential_id,device_id,device_label,token_hash,max_access_level,manager_id,expires_at) values($1,$2,'Synthetic staffing join',repeat('b',64),'full_access',$3,now()+interval '1 hour')",[credentialId,deviceId,owner.manager_id]);
   const {createOpsManagerSession,makeOpsAccessMiddleware}=await import(pathToFileURL(B+'/src/auth/shared-access-auth.js'));
   const env={NODE_ENV:'test',OPS_MANAGER_SESSION_SECRET:randomBytes(32).toString('hex')};
   const store={async find(credential){const r=await tx("select to_jsonb(d) data,to_jsonb(m) manager from public.ops_manager_trusted_devices d join public.ops_manager_managers m on d.manager_id=m.manager_id where d.credential_id=$1",[credential]);return r.rows[0]?{...r.rows[0].data,manager:r.rows[0].manager}:null;}};
   const session=createOpsManagerSession({env,manager:owner,credentialId,deviceId,accessLevel:'full_access'});
   const gate=makeOpsAccessMiddleware({env,trustedDeviceStore:store,requireWrite:true});
   const req={headers:{authorization:'Bearer '+session.token,'x-device-id':deviceId},header(name){return this.headers[String(name).toLowerCase()];}};let accepted=0;
   await gate(req,{status(s){throw Error('Normal fixture manager denied '+s);},json(){throw Error('Normal fixture manager denied');}},()=>accepted++);
   assert.equal(accepted,1);assert.equal(req.memphisAuth.manager_id,owner.manager_id);
   if(purpose==='staffing-date'){
    // Only the previously unexecuted trailing negative. Retain the completed
    // preview/one-confirm/persisted/PDF member; no seed, solver or writer replay.
    const elapsed=(await admin.query('select (public.sch_service_date(statement_timestamp())-1)::text as service_day')).rows[0].service_day;
    const body={commandKind:'cancel_absence',absenceKind:null,employeeId:id(98),startDate:elapsed,endDate:elapsed,targetAbsenceId:id(86)};
    await assert.rejects(()=>tx('select public.static_weekly_v10_begin_staffing_command($1::jsonb,$2::uuid,$3::bigint,$4::uuid)',[body,id(85),0,owner.manager_id],'static_weekly_control_plane',true),e=>e.code==='23514'&&String(e.message).includes('elapsed service date'));
    assert.equal((await admin.query('select count(*)::int n from public.static_weekly_staffing_commands where client_prepare_key=$1',[id(85)])).rows[0].n,0);
    put('PRODUCT_RESULT.json',{scope:'only new fresh elapsed cancellation typed SQL negative; no repeated accepted member',actual_SQL:true,normal_signed_fixture_actor:true,rejected_before_effect:true,elapsed_service_date:elapsed,SQL_transactions:witness,solver_invocations:0,confirmation_invocations:0,realManagerBrowser:false,production:false});
    console.log('FRESH_ELAPSED_CANCELLATION_TYPED_SQL_REJECTED');
   }else if(purpose==='staffing-replaced'){
    const {setupStaffingHandoutJoinFixture,staffingPreviewToCoverAllHandoutProof}=await import(pathToFileURL(B+'/scripts/fixtures/oc24-coverall-database-fixture.mjs'));
    staffingFixture=await setupStaffingHandoutJoinFixture({sql,container:ownedContainerName,databaseOptions:options,manager:req.memphisAuth,weekStart:'2026-10-12',manualCapacityKey:id(82),clientPrepareKey:id(83),confirmationKey:id(84),capacityLunch:{start:'11:00',end:'12:00'},capture:(name,value)=>put(name,value)});
    phase='necessary NEW accepted original prerequisite for changed-person cancellation, no PDF';
    const original=await staffingPreviewToCoverAllHandoutProof({...staffingFixture,includeHandout:false});
    phase='NEW normal replacement/inactive original -> current-plan cancellation';
    const changed=await staffingFixture.continueChangedPersonCancellation({originalOperationId:original.operationId,replacementName:'Synthetic current replacement',replacementKey:id(87),clientPrepareKey:id(85),confirmationKey:id(86)});
    put('PRODUCT_RESULT.json',{...changed,actual_SQL:true,normal_signed_fixture_actor:true,original_absence_confirmation_calls:original.confirmationCalls,compilerRuns:staffingFixture.compilerRuns,real_human_browser:false,physical:false,old_PDF_and_proof_groups_repeated:false});
    console.log('NEW262_REPLACED_ORIGINAL_CURRENT_PLAN_CANCELLATION_PASS');
   }else if(purpose==='staffing-cancel'){
    const {setupStaffingHandoutJoinFixture,staffingPreviewToCoverAllHandoutProof}=await import(pathToFileURL(B+'/scripts/fixtures/oc24-coverall-database-fixture.mjs'));
    staffingFixture=await setupStaffingHandoutJoinFixture({sql,container:ownedContainerName,databaseOptions:options,manager:req.memphisAuth,weekStart:'2026-10-12',manualCapacityKey:id(82),clientPrepareKey:id(83),confirmationKey:id(84),capacityLunch:{start:'11:00',end:'12:00'},capture:(name,value)=>put(name,value)});
    phase='necessary NEW normal accepted absence prerequisite, no old handout/ACL proof replay';
    const original=await staffingPreviewToCoverAllHandoutProof({...staffingFixture,includeHandout:false});
    phase='NEW original canonical target/current civil day cancellation';
    const cancellation=await staffingFixture.continueOriginalCancellation({originalOperationId:original.operationId,clientPrepareKey:id(91),confirmationKey:id(92)});
    put('PRODUCT_RESULT.json',{...cancellation,actual_SQL:true,normal_signed_fixture_actor:true,original_absence_confirmation_calls:original.confirmationCalls,cancellation_confirmation_calls:cancellation.confirmationCalls,compilerRuns:staffingFixture.compilerRuns,real_human_browser:false,physical:false,old_PDF_and_ACL_groups_repeated:false});
    console.log('NEW261_ORIGINAL_CANCELLATION_CURRENT_PLAN_READBACK_PASS');
   }else{
   const {setupStaffingHandoutJoinFixture,staffingPreviewToCoverAllHandoutProof}=await import(pathToFileURL(B+'/scripts/fixtures/oc24-coverall-database-fixture.mjs'));
   staffingFixture=await setupStaffingHandoutJoinFixture({sql,container:ownedContainerName,databaseOptions:options,manager:req.memphisAuth,weekStart:'2026-10-12',manualCapacityKey:id(82),clientPrepareKey:id(83),confirmationKey:id(84),capacityLunch:{start:'11:00',end:'12:00'},capture:(name,value)=>put(name,value)});
   const originalAccept=staffingFixture.plane.acceptStaffingCommand;
   staffingFixture.plane.acceptStaffingCommand=async function(args){
    const prepared=await staffingFixture.plane.getStaffingCommand({manager:req.memphisAuth,operationId:args.operationId});
    const staged=(await admin.query("select payload_json payload from public.static_weekly_staffing_staged_candidates where operation_id=$1 and candidate_kind='projection'",[args.operationId])).rows[0].payload;
    const week=prepared.preview.weeks[0],envelope=staged.envelope,availability=envelope.authority.projectionAvailability;
    assert.equal(week.publicationId,staged.publicationId);assert.equal(week.versionId,envelope.authority.compilerInput.version.id);
    assert.equal(week.database_projection_identity,envelope.database_projection_identity);
    assert.equal(week.replayDigest,envelope.replay_digest);assert.equal(week.sourceDigest,envelope.authority.inputDigest);
    assert.equal(week.projectionAvailability.length,availability.length);
    assert.deepEqual(week.projectionAvailability.map(x=>[x.slotId,x.dayOfWeek,x.incumbentPersonId,x.shift,x.lunch]),availability.map(x=>[x.slotId??null,x.dayOfWeek??null,x.incumbentPersonId??null,x.shift?{start:x.shift.start??null,end:x.shift.end??null}:null,x.lunch?{start:x.lunch.start??null,end:x.lunch.end??null}:null]));
    assert.ok(week.projectionAvailability.every(x=>!('restrictionProvenance' in x)&&!('restrictions' in x)&&!('productiveCapacityProvenance' in x)&&!('acceptedRouteProvenance' in x)));
    assert.ok(availability.some(x=>x.incumbentPersonId===null),'actual nonemployee capacity identities retained');
    assert.deepEqual(week.metrics.daily.map(d=>d.loads.map(x=>[x.slotId,x.productiveCapacityMinutes])),envelope.metrics.daily.map(d=>d.loads.map(x=>[x.slotId,x.productiveCapacityMinutes])));
    checks.push('actual staged availability/metric/source binding and privacy retained');
    for(const role of ['anon','authenticated','service_role','custodial_application_reader','static_weekly_release_operator'])await assert.rejects(()=>tx('select public.static_weekly_v10_read_staffing_command($1::uuid,$2::uuid)',[args.operationId,owner.manager_id],role),e=>e.code==='42501');
    // Existing manager actor takes FOR SHARE. Use its ordinary transaction,
    // not a new SQL READ ONLY envelope that forbids the normal actor fence.
    assert.equal((await tx('select public.static_weekly_v10_read_staffing_command($1::uuid,$2::uuid) data',[id(97),owner.manager_id],'static_weekly_control_plane',true)).rows[0].data,null);
    checks.push('new reader normal CP actor and denied roles/missing original');
    for(const identity of ['public.static_weekly_v10_read_staffing_command(uuid,uuid)','public.static_weekly_v11_accept_staffing_command(uuid,text,uuid,uuid)']){
     await admin.query('begin');try{
      const before=(await admin.query("select pg_get_functiondef($1::regprocedure) definition,p.proacl,p.proowner from pg_proc p where p.oid=$1::regprocedure",[identity])).rows[0];
      const defs=(await admin.query("select object_kind,definition_sql,definition_sha256 from public.custodial_release_authority_restore_inventory where object_kind in ('function','grant') and object_identity like '%(%' and to_regprocedure(object_identity)=$1::regprocedure order by case object_kind when 'function' then 0 else 1 end",[identity])).rows;
      assert.equal(defs.length,2);assert.equal(defs[0].definition_sql,before.definition);assert.equal(sha(defs[0].definition_sql),defs[0].definition_sha256);
      await admin.query('drop function '+identity);for(const row of defs)await admin.query(row.definition_sql);
      assert.deepEqual((await admin.query("select pg_get_functiondef($1::regprocedure) definition,p.proacl,p.proowner from pg_proc p where p.oid=$1::regprocedure",[identity])).rows[0],before);
     }finally{await admin.query('rollback');}
    }
    checks.push('both new function bodies/exact existing grants restored inside rollback');
    put('NEW_STAFFING_READBACK_CHECKS.json',{checks,original_operation:args.operationId,confirmation_key:args.confirmationKey,SQL_actual:true,synthetic_only:true});
    return originalAccept.call(this,args);
   };
   phase='new actual staffing preview one confirmation persisted handout';
   const result=await staffingPreviewToCoverAllHandoutProof(staffingFixture);
   const replay=await staffingFixture.plane.beginStaffingCommand({manager:req.memphisAuth,...staffingFixture.request});
   assert.equal(replay.operation_id,result.operationId);assert.equal(replay.replayed,true);assert.equal(replay.state,'ACCEPTED');
   const elapsed=(await admin.query('select (public.sch_service_date(statement_timestamp())-1)::text as service_day')).rows[0].service_day;
   await assert.rejects(()=>staffingFixture.plane.beginStaffingCommand({manager:req.memphisAuth,commandKind:'cancel_absence',employeeId:staffingFixture.request.employeeId,startDate:elapsed,endDate:elapsed,targetAbsenceId:id(86),clientPrepareKey:id(85),expectedRevision:result.accepted.authority_revision}),e=>e.code==='23514'&&String(e.message).includes('elapsed service date'));
   result.typed_begin_original_key_replay=true;result.fresh_elapsed_cancellation_SQL_rejected=true;
   put('PRODUCT_RESULT.json',{...result,new_readback_checks:checks,baseline:staffingFixture.baseline,compilerRuns:staffingFixture.compilerRuns,normal_source_SQL_named_fixture:true,real_human_browser:false,provider_delivery:false,physical:false});
   console.log('CURRENT_STAFFING_PREVIEW_CONFIRMED_PERSISTED_HANDOUT_PASS');
   }
  }else if(purpose==='feedback'){
   phase='new immutable original SQL fixture';
   process.argv.push('--affected-sql-member-only');
   const {runFeedbackTriageStatusDatabaseTests}=await import(pathToFileURL(B+'/scripts/feedback-triage-status-tests.mjs'));
   async function fixtureSql(statement){
    const c=new Client(options);clients.add(c);c.on('error',()=>{});
    try{await c.connect();await c.query("set statement_timeout='8s';set lock_timeout='2s'");
     const result=await c.query(statement),results=Array.isArray(result)?result:[result];
     const selected=results.filter(r=>r.rows?.length).at(-1);if(!selected)return '';
     const value=Object.values(selected.rows[0])[0];
     return typeof value==='boolean'?(value?'t':'f'):value===null?'':typeof value==='object'?JSON.stringify(value):String(value);
    }catch(e){e.stderr=String(e.code||'SQL_ERROR')+' '+String(e.message);throw e;}
    finally{await c.end().catch(()=>{});clients.delete(c);}
   }
   const prior=JSON.parse(fs.readFileSync('/home/eric/Documents/Codex/2026-09-13/i-x20/work/autonomous-repair-20260923/overnight-readiness-20261006/lean-held-correction-integration-20261011/original-feedback-valid-managers-EcbCsA/RESULT.json','utf8'));
   const passed=JSON.parse(fs.readFileSync('/home/eric/Documents/Codex/2026-09-13/i-x20/work/autonomous-repair-20260923/overnight-readiness-20261006/lean-held-correction-integration-20261011/original-feedback-valid-managers-EcbCsA/FAILURE_finish.json','utf8'));
   assert.equal(prior.source_before.commit,'a44293d9fea73d658a36d7b35c2405a767a57349');assert.equal(prior.source_unchanged,true);
   assert.equal(prior.source_before.replay_sha256,plan.manifestSha256);assert.equal(prior.cleanup.container_absent,true);assert.equal(prior.cleanup.socket_absent,true);
   assert.ok(passed.completed_checks.includes('NEW 56 actual immutable-original SQL/role/nonmutation observations'));
   assert.equal(sha(fs.readFileSync(B+'/scripts/feedback-triage-status-tests.mjs')),'2220c486b8261cb38feec82bfc74e796df9e6a0b89d9f795217988f58a6d770a');
   checks.push('RETAINED exact-current-source56 actual original SQL cases already PASS; not replayed. New execution starts at owning restore/HTTP.');
   phase='new exact function grant serialization restore';
   const identity='public.custodial_feedback_triage_receipt(uuid,uuid,uuid,uuid,text,text)';
   const rows=(await admin.query("select object_kind,definition_sql,definition_sha256 from public.custodial_release_authority_restore_inventory where object_identity=$1 order by restore_order",[identity])).rows;
   assert.deepEqual(rows.map(r=>r.object_kind),['function','grant']);for(const r of rows)assert.equal(sha(r.definition_sql),r.definition_sha256);
   const before=(await admin.query("select pg_get_functiondef($1::regprocedure) definition,public.custodial_release_authority_current_grant_definition($1::text) acl",[identity])).rows[0];
   await admin.query('begin');
   try{await admin.query('drop function '+identity);assert.equal((await admin.query('select to_regprocedure($1) missing',[identity])).rows[0].missing,null);
    for(const r of rows)await admin.query(r.definition_sql);
    assert.deepEqual((await admin.query("select pg_get_functiondef($1::regprocedure) definition,public.custodial_release_authority_current_grant_definition($1::text) acl",[identity])).rows[0],before);
   }finally{await admin.query('rollback');}
   checks.push('NEW exact source-bound two stored function/grant definitions restore in rollback; not full recovery-matrix or production admission');
   phase='normal current signed manager HTTP original receipt read';
   const owner=(await admin.query("select * from public.ops_manager_managers where system_key='eric_custodial_manager' and active and not is_system_principal and revoked_at is null")).rows[0];assert.ok(owner);
   const credentialId=id(71),feedbackId=id(72),requestId=id(74),deviceId='SYNTHETIC_ORIGINAL_RECEIPT_HTTP';
   await admin.query("insert into public.ops_manager_trusted_devices(credential_id,device_id,device_label,token_hash,max_access_level,manager_id,expires_at) values($1,$2,'Synthetic HTTP original receipt',repeat('b',64),'full_access',$3,now()+interval '1 hour')",[credentialId,deviceId,owner.manager_id]);
   await admin.query("insert into public.system_feedback_items(id,operation_id,request_fingerprint,category,priority,message,submitted_by,hub_context,device_id,metadata_json) select $1,$2,repeat('e',64),'other','normal','Synthetic original HTTP fixture',m.display_name,'manager',upper(d.device_id),jsonb_build_object('identity_verification',jsonb_build_object('status','verified','kind','named_manager_session','manager_id',m.manager_id,'credential_id',d.credential_id,'device_id',upper(d.device_id))) from public.ops_manager_managers m join public.ops_manager_trusted_devices d on d.manager_id=m.manager_id where m.manager_id=$3 and d.credential_id=$4 and m.active and m.revoked_at is null and not m.is_system_principal and d.revoked_at is null and d.expires_at>clock_timestamp() and d.created_at<=clock_timestamp() and d.max_access_level='full_access'",[feedbackId,id(73),owner.manager_id,credentialId]);
   const version=(await tx('select public.custodial_feedback_triage_version(status,updated_at) value from public.system_feedback_items where id=$1',[feedbackId],'custodial_application_reader')).rows[0].value;
   const original={request_id:requestId,status:'acknowledged',expected_version:version,expected_manager_id:owner.manager_id,expected_credential_id:credentialId};
   const accepted=(await tx('select public.custodial_feedback_triage($1::uuid,$2::uuid,$3::uuid,$4::uuid,$5::text,$6::text) data',[requestId,owner.manager_id,credentialId,feedbackId,original.status,version],'service_role',true)).rows[0].data;
   const {createOpsManagerSession,makeOpsAccessMiddleware}=await import(pathToFileURL(B+'/src/auth/shared-access-auth.js'));
   const env={NODE_ENV:'test',OPS_MANAGER_SESSION_SECRET:randomBytes(32).toString('hex')};
   const store={async find(credential){const r=await tx("select to_jsonb(d) data,to_jsonb(m) manager from public.ops_manager_trusted_devices d join public.ops_manager_managers m on d.manager_id=m.manager_id where d.credential_id=$1",[credential]);return r.rows[0]?{...r.rows[0].data,manager:r.rows[0].manager}:null;}};
   const session=createOpsManagerSession({env,manager:owner,credentialId,deviceId,accessLevel:'full_access'}),write=makeOpsAccessMiddleware({env,trustedDeviceStore:store,requireWrite:true});
   let reads=0,revokeDuringRead=false;
   const runRpc=async(name,args)=>{assert.equal(name,'custodial_feedback_triage_receipt');reads++;
    const result=(await tx('select public.custodial_feedback_triage_receipt($1::uuid,$2::uuid,$3::uuid,$4::uuid,$5::text,$6::text) data',[args.p_request,args.p_manager,args.p_credential,args.p_feedback,args.p_action,args.p_expected_version],'service_role',true)).rows[0].data;
    if(revokeDuringRead)await admin.query('update public.ops_manager_trusted_devices set revoked_at=clock_timestamp() where credential_id=$1',[credentialId]);return result;};
   const {feedbackTriageStatusHandler}=await import(pathToFileURL(B+'/src/feedback-triage-status.js'));
   const app=express();app.use(express.json({limit:'32kb'}));
   const mount=fs.readFileSync(B+'/src/index.js','utf8').split('\n').filter(l=>l.startsWith('app.post("/dashboard-api/system-feedback/:feedbackId/triage-status"'));
   assert.equal(mount.length,1);vm.runInNewContext(mount[0],{app,feedbackTriageStatusHandler,runRpc,requireOpsManagerWrite:write});
   api=await start(http.createServer(app));const url='http://127.0.0.1:'+api.address().port+'/dashboard-api/system-feedback/'+feedbackId+'/triage-status';
   const call=async(body)=>{const r=await fetch(url,{method:'POST',headers:{authorization:'Bearer '+session.token,'x-device-id':deviceId,'content-type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(10000)});return{status:r.status,body:await r.json()};};
   const response=await call(original);assert.equal(response.status,200,JSON.stringify(response.body));assert.equal(response.body.outcome,'APPLIED');assert.deepEqual(response.body.receipt,accepted.receipt);
   const missing=await call({...original,request_id:id(75)});assert.equal(missing.status,200);assert.equal(missing.body.outcome,'UNKNOWN');assert.equal(missing.body.retry_safe,false);
   revokeDuringRead=true;const revoked=await call(original);assert.ok([401,403].includes(revoked.status));assert.equal(revoked.body.outcome,'UNKNOWN');assert.equal(revoked.body.retry_safe,false);assert.equal(revoked.body.receipt,undefined);
   assert.equal(reads,3);assert.equal((await admin.query('select count(*)::int n from public.system_feedback_triage_receipts where request_id=$1',[requestId])).rows[0].n,1);
   checks.push('NEW owning actual HTTP route and normal signed-session/DB registry + exact original SQL receipt; missing original unknown; mid-read revocation withholds receipt; no reader writer fallback');
   put('PRODUCT_RESULT.json',{at_utc:new Date().toISOString(),checks,actual_SQL:true,normal_signed_manager_fixture_HTTP:true,real_human_manager_browser:false,provider_delivery:false,technical_synthetic_fixture_only:true,no_real_mail:true,transactions:witness,closed_original_receipt_command:original,acceptance_receipt:accepted.receipt,normal_hosted_PostgREST:false});
   console.log('ORIGINAL_FEEDBACK_RECEIPT_SQL_HTTP_PASS');
  }else{
  phase='new correction migration';await admin.query(fs.readFileSync(B+'/supabase/migrations/20261011121818_custodial_held_event_correction_v2.sql','utf8'));
  if(purpose==='staffing'){
   phase='new original staffing reader';await admin.query(fs.readFileSync(B+'/supabase/migrations/20261011150049_staffing_original_outcome_reader.sql','utf8'));
   const manager=(await admin.query("select manager_id from public.ops_manager_managers where system_key='eric_custodial_manager' and active and revoked_at is null")).rows[0];assert.ok(manager);
   const before=(await admin.query('select count(*)::int n from public.weekly_schedule_command_receipts')).rows[0].n;
   const query='select public.static_weekly_read_original_staffing_outcome_v1($1::uuid,$2::text,$3::text) data';
   const args=[manager.manager_id,'SYNTHETIC_NOT_DISPATCHED_OR_RESENDABLE','vacate_roster_slot'];
   // Match the normal control-plane transaction: its existing manager actor
   // assertion takes FOR SHARE. A GET has no command write, but its database
   // transaction must remain lock-capable; do not weaken that actor guard.
   const missing=(await tx(query,args,'static_weekly_control_plane',true)).rows[0].data;
   assert.equal(missing.schema,'custodial.original-staffing-outcome.v1');assert.equal(missing.state,'OUTCOME_UNCONFIRMED');
   assert.equal(missing.retry_safe,false);assert.equal(missing.phone_released,false);assert.equal(Object.hasOwn(missing,'receipt'),false);
   for(const role of ['anon','authenticated','service_role','custodial_application_reader','static_weekly_release_operator']){
    await assert.rejects(tx(query,args,role,true),e=>e.code==='42501');checks.push('NEW actual denied original-outcome role '+role);
   }
   await assert.rejects(tx(query,[manager.manager_id,args[1],'departed'],'static_weekly_control_plane',true),e=>e.code==='22023');
   assert.equal((await admin.query('select count(*)::int n from public.weekly_schedule_command_receipts')).rows[0].n,before);
   const identities=(await admin.query("select object_kind,definition_sha256 from public.custodial_release_authority_restore_inventory where object_identity='public.static_weekly_read_original_staffing_outcome_v1(uuid,text,text)' order by object_kind")).rows;
   assert.equal(identities.length,2);assert.deepEqual(identities.map(x=>x.object_kind),['function','grant']);
   checks.push('NEW actual fixed readonly missing-original outcome has no receipt/resend/phone authority; no writer/receipt count change; exact function+grant recovery rows');
   put('PRODUCT_RESULT.json',{at_utc:new Date().toISOString(),checks,new_original_reader_SQL_missing_and_denied_PASS:true,
    positive_signed_original_command:'NOT_RUN',normal_manager_HTTP_browser:'NOT_RUN',existing_stale_duplicate_compiled_or_UI_suites_NOT_replayed:true,
    technical_synthetic_fixture_only:true,no_mail_fetch_import:true,transactions:witness,recovery:identities});
   console.log('STAFFING_ORIGINAL_READER_MISSING_DENIED_SQL_PASS');
  }else{
  const acl=(await admin.query("select relrowsecurity rls,relforcerowsecurity force_rls,has_table_privilege('anon',oid,'select') anon,has_table_privilege('authenticated',oid,'select') authenticated from pg_class where oid='public.custodial_held_event_previews_v2'::regclass")).rows[0];
  assert.deepEqual(acl,{rls:true,force_rls:true,anon:false,authenticated:false});
  // Existing unchanged direct-RPC ACL negatives retained, not replayed.
  // Exercise the unchanged OWNER-only write policy with the reconstructed
  // source owner's registry row. This remains an ephemeral technical session,
  // NOT Eric's live credential, login, browser session or production identity.
  const ownerRow=(await admin.query("select * from public.ops_manager_managers where system_key='eric_custodial_manager' and active and not is_system_principal and revoked_at is null")).rows[0];
  assert.ok(ownerRow);
  const managerId=ownerRow.manager_id,credentialId=id(3),ledgerId=id(4),deviceId='SYNTHETIC_G10_LOCAL_ONLY';
  await admin.query("insert into public.ops_manager_trusted_devices(credential_id,device_id,device_label,token_hash,max_access_level,manager_id,expires_at) values($1,$2,'SYNTHETIC G10 local',repeat('a',64),'full_access',$3,now()+interval '1 hour')",[credentialId,deviceId,managerId]);
  const venue=(await admin.query("select id,display_name from public.event_venues where active and eligible_event_venue and location_group_id is not null and event_scope in ('SINGLE_VENUE','ZOO_WIDE') order by id limit 1")).rows[0];assert.ok(venue);
  const source={source:{mailbox:'eoperle@memphiszoo.org',message_id:'SYNTHETIC_G10_NOT_REAL_EMAIL',content_sha256:sha('synthetic source'),evidence_kind:'original_event_notice',source_at:'2026-10-10T13:00:00.000Z',received_at:'2026-10-10T13:00:00.000Z'},source_event_key:'synthetic-g10',reason:'SOURCE_CONTENT_AMBIGUOUS'};
  await admin.query("insert into public.events_app_outlook_sync(id,outlook_message_id,source_event_key,received_at,payload_hash,sync_status,source_payload) values($1,$2,$3,'2026-10-10T13:00:00Z',encode(extensions.digest(jsonb_build_object('action','review','observation',$4::jsonb)::text,'sha256'),'hex'),'NEEDS_REVIEW',$4::jsonb)",[ledgerId,source.source.message_id,'custodial-outlook-events-v1/event/'+source.source_event_key,source]);
  const original=(await admin.query("select source_payload,payload_hash,outlook_message_id,source_event_key,received_at from public.events_app_outlook_sync where id=$1",[ledgerId])).rows[0];
  const key=randomBytes(32).toString('hex');
  const columns={
   events_app_outlook_sync:'id,event_id,received_at,payload_hash,sync_status,outlook_message_id,source_event_key,source_payload,source_subject,created_at,updated_at,sync_note',
   event_venues:'id,display_name,location_group_id,event_scope,active,eligible_event_venue,updated_at',
   events_app_events:'id,revision,status,event_name,event_date,start_time,end_date,end_time,start_instant_utc,end_instant_utc,primary_venue_id,location_group_id,display_location,operation_id,source_format,manually_overridden,needs_review,created_by_manager_id,updated_by_manager_id,created_by,overridden_by,event_timezone',
   custodial_held_event_previews_v2:'preview_id,preview_sha256,ledger_id,source_provenance_digest,original_payload_sha256,original_message_id,original_event_key,original_received_at,original_subject,original_created_at,original_updated_at,venue_id,normalized_event,manager_id,credential_id,device_id,session_fingerprint,state,event_id,applied_at',
   ops_manager_trusted_devices:'credential_id,device_id,device_label,token_hash,max_access_level,manager_id,platform_summary,metadata_json,created_at,last_used_at,expires_at,revoked_at,revoked_reason',
   ops_manager_managers:'manager_id,display_name,contact_label,roles,active,revoked_at,revoked_reason,created_at,last_access_at,system_key,is_system_principal'};
  const rpc={
   custodial_held_event_preview_v2:[['p_ledger_id','uuid'],['p_expected_review_snapshot_sha256','text'],['p_source_provenance_digest','text'],['p_manager_id','uuid'],['p_credential_id','uuid'],['p_device_id','text'],['p_session_fingerprint','text'],['p_event_name','text'],['p_start_at','timestamptz'],['p_end_at','timestamptz'],['p_venue_ref','uuid'],['p_manager_fact_confirmation','text']],
   custodial_held_event_confirm_v2:[['p_preview_id','uuid'],['p_preview_sha256','text'],['p_manager_id','uuid'],['p_credential_id','uuid'],['p_device_id','text'],['p_session_fingerprint','text']]};
  let confirmWrites=0,loseConfirm=true;
  gateway=await start(http.createServer(async(req,res)=>{try{
   assert.equal(req.headers.apikey,key);assert.equal(req.headers.authorization,'Bearer '+key);
   const u=new URL(req.url,'http://127.0.0.1'),rpcName=u.pathname.replace('/rest/v1/rpc/','');
   res.setHeader('content-type','application/json');
   if(req.method==='POST'&&rpc[rpcName]){
    let body='';for await(const x of req){body+=x;assert.ok(body.length<32000);}
    const args=JSON.parse(body),params=rpc[rpcName];assert.deepEqual(Object.keys(args).sort(),params.map(x=>x[0]).sort());
    const r=await tx('select public.'+rpcName+'('+params.map((x,i)=>'$'+(i+1)+'::'+x[1]).join(',')+') data',params.map(x=>args[x[0]]),'service_role',true);
    if(rpcName==='custodial_held_event_confirm_v2'){
      confirmWrites++;
      if(loseConfirm){loseConfirm=false;res.statusCode=503;res.end(JSON.stringify({code:'SYNTHETIC_COMMITTED_REPLY_LOST',message:'Owned test committed SQL then lost its reply'}));return;}
    }
    res.end(JSON.stringify(r.rows[0].data));return;
   }
   assert.equal(req.method,'GET');const table=u.pathname.replace('/rest/v1/','');assert.ok(columns[table]);
   const selected=u.searchParams.get('select').split(',');assert.ok(selected.length&&selected.every(x=>columns[table].split(',').includes(x)));
   const args=[],where=[];let order='';let limit=1000,offset=0;
   for(const [k,v] of u.searchParams){if(k==='select')continue;if(k==='order'){assert.match(v,/^(id|display_name)\.(asc|desc)$/);order=' order by '+v.replace('.',' ');continue;}if(k==='limit'||k==='offset'){assert.match(v,/^\d{1,4}$/);if(k==='limit')limit=Number(v);else offset=Number(v);continue;}
    assert.ok(columns[table].split(',').includes(k));
    if(v==='not.is.null'){where.push(k+' is not null');continue;}
    if(v.startsWith('in.(')){const values=v.slice(4,-1).split(',');where.push(k+' in ('+values.map(value=>{args.push(value);return '$'+args.length;}).join(',')+')');continue;}
    assert.match(v,/^(eq|like)\./);args.push(v.slice(v.indexOf('.')+1));where.push(k+(v.startsWith('eq.')?' = ':' like ')+'$'+args.length);
   }
   assert.ok(limit<=1000&&offset<=1000);const sql='with selected as materialized(select '+selected.join(',')+' from public.'+table+(where.length?' where '+where.join(' and '):'')+') select (select count(*)::int from selected) total,coalesce((select jsonb_agg(to_jsonb(r)) from (select * from selected'+order+' limit '+limit+' offset '+offset+')r),\'[]\'::jsonb) data';
   const r=(await tx(sql,args)).rows[0];res.setHeader('content-range','0-'+Math.max(0,r.data.length-1)+'/'+r.total);
   if(String(req.headers.accept).includes('application/vnd.pgrst.object+json')){assert.equal(r.data.length,1);res.end(JSON.stringify(r.data[0]));}else res.end(JSON.stringify(r.data));
  }catch(e){put('SQL_BOUNDARY_FAILURE_'+witness.length+'.json',{code:e.code||null,message:String(e.message).slice(0,1000),constraint:e.constraint||null});res.statusCode=e.code==='42501'?403:503;res.end(JSON.stringify({code:e.code||'FIXED_SQL_FACADE',message:'Synthetic fixed SQL boundary rejected'}));}}));
  const client=createClient('http://127.0.0.1:'+gateway.address().port,key,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
  const {createOpsManagerSession,makeOpsAccessMiddleware,createSupabaseTrustedDeviceStore}=await import(pathToFileURL(B+'/src/auth/shared-access-auth.js'));
  const env={NODE_ENV:'production',OPS_MANAGER_SESSION_SECRET:randomBytes(32).toString('hex')};
  const manager=(await admin.query('select * from public.ops_manager_managers where manager_id=$1',[managerId])).rows[0];
  const session=createOpsManagerSession({env,manager,credentialId,deviceId,accessLevel:'full_access'});
  const store=createSupabaseTrustedDeviceStore(client),auth=makeOpsAccessMiddleware({env,trustedDeviceStore:store}),write=makeOpsAccessMiddleware({env,trustedDeviceStore:store,requireWrite:true});
  const {installManagerHeldEventCorrectionRoutes}=await import(pathToFileURL(B+'/src/manager-held-event-correction-route.js'));
  const {installBoundManagerHeldReviewRoute}=await import(pathToFileURL(B+'/src/manager-held-event-review-reader.js'));
  const {listSharedEvents}=await import(pathToFileURL(B+'/src/events-api.js'));
  const {makeSharedManagerEventsHandler}=await import(pathToFileURL(B+'/src/shared-events-feed.js'));
  const app=express();app.use(express.json({limit:'32kb'}));installBoundManagerHeldReviewRoute(app,{client,requireOpsManagerAuth:auth});
  installManagerHeldEventCorrectionRoutes(app,{client,requireOpsManagerWrite:write});
  app.get('/dashboard-api/events-feed',auth,makeSharedManagerEventsHandler({readEvents:()=>listSharedEvents(async sql=>(await tx(sql,[],'custodial_application_reader')).rows)}));
  api=await start(http.createServer(app));const url='http://127.0.0.1:'+api.address().port,base='/dashboard-api/held-event-reviews';
  async function call(path,body=null,token=session.token){const r=await fetch(url+path,{method:body?'POST':'GET',headers:{authorization:'Bearer '+token,'x-device-id':deviceId,...(body?{'content-type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(10000)});return {status:r.status,body:await r.json()};}
  phase='normal signed source-owner fixture original held row/places';const held=await call(base),places=await call(base+'/corrections/places');assert.equal(held.status,200,JSON.stringify(held.body));assert.equal(places.status,200,JSON.stringify(places.body));assert.ok(places.body.data.places.some(p=>p.venue_ref===venue.id));
  const input={schema:'custodial.held-event-correction-preview-request.v2',ledger_id:ledgerId,expected_review_snapshot_sha256:held.body.data.snapshot_sha256,source_provenance_digest:original.payload_hash,correction:{event_name:'SYNTHETIC G10 manager-confirmed event',start_at:'2099-10-12T13:30:00.000Z',end_at:'2099-10-12T15:00:00.000Z',venue_ref:venue.id},manager_fact_confirmation:'MANAGER_CONFIRMED_MISSING_ORIGINAL_FACTS'};
  checks.push('Existing normal auth/places and old canonical write used as prerequisites, unchanged stale/revocation/duplicate groups NOT replayed');
  phase='actual frontend controller preview confirm SQL persisted readback';
  const {createHeldEventCorrectionController}=await import(pathToFileURL(D+'frontend/manager-held-event-correction.mjs'));
  const states=[];let previewResult;
  const controller=createHeldEventCorrectionController({session:{requireCurrentManager:()=>({manager_id:managerId,session_epoch:credentialId})},setView:v=>states.push(v.state),api:{
   previewCorrectionV2:async body=>{previewResult=await call(base+'/corrections/preview',body);assert.equal(previewResult.status,200,JSON.stringify(previewResult.body));return previewResult.body.data;},
   confirmCorrectionV2:async body=>{const r=await call(base+'/corrections/confirm',body);assert.equal(r.status,503,JSON.stringify(r.body));assert.equal(r.body.state,'OUTCOME_UNKNOWN');throw Object.assign(new Error('OUTCOME_UNKNOWN'),{code:'OUTCOME_UNKNOWN'});},
   statusCorrectionV2:async body=>{const r=await call(base+'/corrections/status',body);assert.equal(r.status,200,JSON.stringify(r.body));return r.body.data;}
  }});
  controller.open(held.body.data.rows.find(r=>r.ledger_id===ledgerId),held.body.data.snapshot_sha256);controller.chooseManagerConfirmed(input.correction);await controller.preview();
  assert.equal((await admin.query('select event_id from public.events_app_outlook_sync where id=$1',[ledgerId])).rows[0].event_id,null);
  const originalPreview=previewResult.body.data;
  const pending=await call(base+'/corrections/status',{schema:'custodial.held-event-correction-status-request.v2',preview_id:originalPreview.preview_id,preview_sha256:originalPreview.preview_sha256});
  assert.equal(pending.status,200);assert.equal(pending.body.data.state,'HELD');assert.equal(pending.body.data.retry_safe,false);
  await assert.rejects(controller.confirm(),e=>e.code==='OUTCOME_UNKNOWN');assert.equal(controller.getState(),'OUTCOME_UNKNOWN');assert.equal(confirmWrites,1);
  const saved=await controller.checkSavedOutcome();assert.equal(controller.getState(),'ACCEPTED');assert.equal(saved.manager_feed_verified,false);assert.equal(confirmWrites,1);
  assert.deepEqual((await admin.query("select source_payload,payload_hash,outlook_message_id,source_event_key,received_at from public.events_app_outlook_sync where id=$1",[ledgerId])).rows[0],original);
  const ledger=(await admin.query('select event_id,sync_status from public.events_app_outlook_sync where id=$1',[ledgerId])).rows[0];assert.equal(ledger.event_id,saved.event_id);assert.equal(ledger.sync_status,'APPLIED');
  const wrongStatus=await call(base+'/corrections/status',{schema:'custodial.held-event-correction-status-request.v2',preview_id:saved.preview_id,preview_sha256:'f'.repeat(64)});
  assert.equal(wrongStatus.status,200);assert.equal(wrongStatus.body.data.state,'READBACK_UNCONFIRMED');assert.equal(wrongStatus.body.data.retry_safe,false);assert.equal(confirmWrites,1);
  const feed=await call('/dashboard-api/events-feed');assert.equal(feed.status,200,JSON.stringify(feed.body));
  assert.ok(feed.body.feed.rows.some(r=>r.id===saved.event_id&&r.revision===saved.revision));
  assert.equal((await call(base)).body.data.rows.some(r=>r.ledger_id===ledgerId),false);
  checks.push('NEW pending status HELD/no retry; actual SQL confirm commits once and its reply is lost; existing frontend reconciliation→owning status HTTP→pinned SDK fixed reads yields same exact event without any resend; wrong original preview hash stays unconfirmed');
  put('PRODUCT_RESULT.json',{at_utc:new Date().toISOString(),checks,states,event_id:saved.event_id,ledger_id:ledgerId,preview_id:saved.preview_id,revision:saved.revision,source_provenance_digest:original.payload_hash,canonical_event_readback_sha256:saved.canonical_event_readback_sha256,normal_DB_backed_auth_and_actual_SQL:true,technical_synthetic_fixture_only:true,SDK_HTTP_facade_NOT_hosted_PostgREST:true,real_human_manager_browser:false,no_mail_fetch_import:true,source_acl:acl,transactions:witness});
  console.log('HELD_LOST_RESPONSE_RECOVERY_PASS');
  }
 }
  }
}catch(e){put('FAILURE_'+stage+'.json',{phase,message:String(e.message).slice(0,1800),detail:e.detail||null,code:e.code||null,completed_checks:checks});throw e;}
finally{await staffingFixture?.close();for(const s of [api,gateway])if(s){s.closeAllConnections();await new Promise(r=>s.close(r));}await staffingHttpPool?.end();for(const c of clients)await c.end().catch(()=>{});if(admin)await admin.end().catch(()=>{});put('CLOSED_'+stage+'.json',{PG_clients_closed:true,HTTP_servers_closed:!api?.listening&&!gateway?.listening,staffing_owned_pool_compiler_closed:!!staffingFixture});}

async function preflightSameOriginalNativeInputs(backendRoot) {
 const base='/home/eric/Documents/Codex/2026-10-09/task-7/g08-original-write-sql-join-capture-20261014-v1';
 function pin(file,digest){const bytes=fs.readFileSync(file);assert.equal(sha(bytes),digest,file);return bytes;}
 const manifest=JSON.parse(pin(base+'/HTTPCLIENT_CORRECTED_CLASS_MANIFEST.json','593bbe7ef0837c99421cd5211482b229411a2afab244c158291adb117655e752'));
 const recipe=JSON.parse(pin(base+'/HTTPCLIENT_CORRECTED_COMPILE_INPUTS.json','9ced8cf92c0aaba29226aeaef430a0dc3b1faf496f9ea92b97f6d56efd7f2b8b'));
 const compiled=JSON.parse(pin(base+'/HTTPCLIENT_CORRECTED_COMPILE_RESULT.json','a404d119a74dc002950fa26dabaad437aef6bdce8059fb1a5f3113829651fd8c'));
 assert.equal(compiled.exit,0);assert.equal(recipe.standard_module,'java.net.http');
 const production=recipe.production_and_dependencies;
 assert.equal(recipe.source_count,24);assert.equal(recipe.source_pins.length,24);
 for(const f of recipe.source_pins){
  assert.ok(!f.path.split('/').includes('..'));
  const source=path.isAbsolute(f.path)?f.path:path.join(path.dirname(base),f.path);
  assert.equal(pin(source,f.sha256).length,f.bytes);
 }
 pin(base+'/source/NativePrivateCustodyReturnedPieceSetTest.java','82779653974b2d035c33f436f000aad3b6a002725b4d1005e92fe21229111a0d');
 pin(base+'/source/NativeSeparationContextTest.java','ed30a99a3afe8c85b997ba111a4db4013398fa5c2a716c3e05c96d29f2226f5d');
 pin('/home/eric/Documents/Codex/2026-10-09/task-7/g08-fresh-host-original-capture-20261014-v1/source/NativeRetainedOwnerTest.java','3d9a78472a5102ec45eae7c540667cd9cce949f2a5fc9b5b1fb073e109bf94ce');
 const identity=(file,dev,ino)=>{const s=fs.lstatSync(file);assert.equal(s.isSymbolicLink(),false);assert.equal(s.dev,dev);assert.equal(s.ino,ino);};
 identity(manifest.root,manifest.device,manifest.inode);identity(manifest.test_root,manifest.test_device,manifest.test_inode);
 assert.equal(manifest.count,120);assert.equal(manifest.files.length,120);
 for(const f of manifest.files){assert.ok(!path.isAbsolute(f.path)&&!f.path.split('/').includes('..'));const file=path.join(manifest.root,f.path);assert.equal(fs.lstatSync(file).isSymbolicLink(),false);assert.equal(pin(file,f.sha256).length,f.bytes);}
 pin(manifest.test_root+'/org/memphiszoo/custodial/vault/NativePrivateCustodyReturnedPieceSetTest.class','37d0cf58fbfb9a062aac491f3c3f060498ab45f98d70aa7726fae4bee36167be');
 const prod=JSON.parse(pin(production.manifest,'a85ec34e4551848a21a07884c6be47e463e0007ccfab0fc1b35b910cacb29d76'));
 assert.equal(prod.compile_exit,0);assert.equal(prod.HOST_JCE,false);assert.equal(prod.files.length,417);identity(prod.root,prod.device,prod.inode);
 for(const f of prod.files)assert.equal(pin(path.join(prod.root,f.path),f.sha256).length,f.bytes);
 for(const f of [...prod.normal_dependencies,...prod.jdk,...production.host])assert.equal(pin(f.path,f.sha256).length,f.bytes);
 const adapter='/tmp/custodial-current-frame-lifetime-nAN3W8/adapter';
 pin(adapter+'/org/memphiszoo/custodial/vault/AndroidKeystoreCipher.class','cb927f74c6b6a960bd911c081fac130ae7e10c0508aacff5ea051c499288a8e3');
 const classpath=recipe.argv[recipe.argv.indexOf('-cp')+1].split(':');assert.ok(classpath.includes(prod.root));assert.equal(classpath.length,62);
 assert.ok(!classpath.some(p=>/retained.*test|task7.*compile/.test(p)));
 assert.equal(typeof (await import(pathToFileURL(backendRoot+'/scripts/same-original-recovery-local-database-tests.mjs'))).createSameOriginalNativeRegistrationTestGateway,'function');
 return {base,manifest,recipe,java:prod.jdk.find(x=>path.basename(x.path)==='java').path,classpath:[adapter,manifest.test_root,...classpath]};
}
async function preflightSameOriginalNativeStatusInputs(backendRoot){
 const file=D+'g08-native-sql-status-test-rf2kvou4/TEST_CLASS_LOAN.json';
 const pin=(file,digest,size)=>{assert.equal(fs.lstatSync(file).isSymbolicLink(),false);const bytes=fs.readFileSync(file);assert.equal(sha(bytes),digest,file);if(size!==undefined)assert.equal(bytes.length,size,file);return bytes;};
 const loan=JSON.parse(pin(file,'e408e2cf271c49676dc8561f2097afa8070c1b0aa5bf1c2befaf2d06700ea770'));
 const prod=JSON.parse(pin(loan.production_loan,'5a543ebd6f265ccda7dd9cc6e54cfacd57404b95da45a73dd5658dc2413544d7'));
 const identity=m=>{const s=fs.lstatSync(m.root);assert.equal(s.isDirectory(),true);assert.equal(s.isSymbolicLink(),false);assert.equal(s.dev,m.device);assert.equal(s.ino,m.inode);};
 const verify=async()=>{
  pin(file,'e408e2cf271c49676dc8561f2097afa8070c1b0aa5bf1c2befaf2d06700ea770');
  pin(loan.production_loan,'5a543ebd6f265ccda7dd9cc6e54cfacd57404b95da45a73dd5658dc2413544d7');
  assert.equal(loan.exit,0);assert.equal(loan.timed_out,false);assert.equal(loan.interrupted,false);assert.equal(loan.source_unchanged,true);
  assert.equal(loan.files.length,120);assert.equal(loan.source_pins.length,24);assert.equal(prod.files.length,418);assert.equal(prod.source_files.length,148);
  assert.equal(prod.compile_exit,0);assert.equal(prod.HOST_JCE,false);identity(loan);identity(prod);
  for(const m of [loan,prod])for(const r of m.files){assert.ok(!path.isAbsolute(r.path)&&!r.path.split('/').includes('..'));pin(path.join(m.root,r.path),r.sha256,r.bytes);}
  for(const r of loan.source_pins)pin(r.path,r.sha256,r.bytes);
  for(const r of prod.source_files)pin(path.isAbsolute(r.path)?r.path:path.join(path.dirname(backendRoot),'frontend',r.path),r.sha256,r.bytes);
  for(const r of [...loan.HOST3,...prod.normal_dependencies,...prod.jdk])pin(r.path,r.sha256,r.bytes);
  pin(loan.synthetic_fixture.path,'cb927f74c6b6a960bd911c081fac130ae7e10c0508aacff5ea051c499288a8e3',8399);
  pin('/home/eric/Documents/Codex/2026-10-09/task-7/g08-native-sql-status-capture-20261014-v1/source/NativePrivateCustodyReturnedPieceSetTest.java','22bbf227e902998da032abc3dae595109c571cab50daff85e2aafc4229c45277');
  pin(loan.root+'/org/memphiszoo/custodial/vault/NativePrivateCustodyReturnedPieceSetTest.class','f20b81f072201de109b64d3bb5fa685005c10dc7168007c05abbe76d1a8ac34a');
 };
 await verify();
 const adapter=path.resolve(loan.synthetic_fixture.path,'../../../../..');
 assert.equal(path.join(adapter,'org/memphiszoo/custodial/vault/AndroidKeystoreCipher.class'),loan.synthetic_fixture.path);
 return {base:'/home/eric/Documents/Codex/2026-10-09/task-7/g08-original-write-sql-join-capture-20261014-v1',
  java:prod.jdk.find(r=>path.basename(r.path)==='java').path,
  classpath:[...loan.HOST3.map(r=>r.path),adapter,loan.root,prod.root,...prod.normal_dependencies.map(r=>r.path)],
  testClassSha256:'f20b81f072201de109b64d3bb5fa685005c10dc7168007c05abbe76d1a8ac34a',verify};
}
async function preflightSameOriginalNativeManagerPreparationInputs(backendRoot){
 const file=D+'g08-native-current-manager-test-ogcmyrzd/TEST_CLASS_LOAN.json';
 const pin=(file,digest,size)=>{assert.equal(fs.lstatSync(file).isSymbolicLink(),false);const bytes=fs.readFileSync(file);assert.equal(sha(bytes),digest,file);if(size!==undefined)assert.equal(bytes.length,size,file);return bytes;};
 const loan=JSON.parse(pin(file,'2b8764c7bc7a1abd57a234fa8bdaae7661d2464fcb134e9eb869eb2993815ee3'));
 const prod=JSON.parse(pin(loan.production_loan,'86b84ac2185dfab341288aa517f994a495be990afacfa7a86f1426e1c2d0d1af'));
 // Reuse the same producer and unaffected compiled helpers. Only named,
 // actually compiled shipping dependencies replace the historical overlay;
 // an unrelated commit never rebinds a passing source or test group.
 const producerPath='/home/eric/Documents/Codex/2026-10-09/task-7/current-manager-completion-capture-20261014-v1/CLASS_MANIFEST.json';
 const producer=JSON.parse(pin(producerPath,'0673d86e4b665a73ff2d82168a952bdb3f99ed295785ce537130065255368c89'));
 const compiledSpecs=[
  ['fixed-read-census-core-N361IJ/SOURCE_CLASS_LOAN.json','657825a321b53cd4aa9de419a4cd185292157e6754bee73b0bd0f420b42a08e4'],
  ['current-completion-manager-k9YWQ0/ENGINE_COMPILE.json','46b12d0d865de0ee2d86fdbfaa77b5d772d61925744d11b69d9b8bb7685844c4'],
  ['current-frame-copy-repair-SUKLSR/COMBINED_SOURCE_RESULT.json','b9bff047473667d2f825f3fa774744e5bb43807a9404c10e75b95c69c82d3e47'],
  ['protected-local-runtime-7EjSTj/RESULT.json','482f79fc2e7f8fb046934c50809ba9c0d2c79b7fc6b00908a632e463afd9417a'],
  ['protected-original-work-entry-9suA35/RESULT.json','8da5b59de3db38d5317c3957fbd5a5272df018a8345fbc944def8cf61bf1207a'],
  ['piece-journal-recovery-dv7aUx/RESULT.json','53ea4cc19927509c6acb0fe9d0444e520aab587a10a3a39731598f03275c4076'],
  ['protected-finite-core-kL9fSd/RESULT.json','0b87c8b4df7af0bfb98d5e2a18958f3b360809af4cf10fe9379f64e0d3332472'],
  ['exchange-original-identity-ZubZT3/RESULT.json','2196077e8318490d23c5b2038a59eb0f9ea5f24ead2a51f38d0eb3a9b67a6cb9'],
  ['first-retention-owning-FTRjBZ/RESULT.json','d451e74eb08dfa72cec911880bed3820ff9d368b498cec6edc3bffc6c196bb98']
 ];
 const compiled=compiledSpecs.map(([file,digest])=>JSON.parse(pin(D+file,digest)));
 const sourceOverrides=new Map(),classRows=[];
 for(const value of compiled){
  const sources=value.sources??value.bindings?.sources??(value.source?[value.source]:value.assembler_source?[value.assembler_source]:[]);
  for(const row of sources)if(row.path.includes('/src/main/java/')&&!sourceOverrides.has(row.path))sourceOverrides.set(row.path,row);
  classRows.push(...(value.classes??value.bindings?.production??value.production??[]));
 }
 // A declared current source must have the exact named compiled replacement.
 // Unused Activity/test sources in older composite receipts are not asserted
 // current merely because their compiled helper is retained below.
 const currentFamilies=new Set(['NativeCompletionJournal.java','NativeRetainedCompletionCensus.java','NativeRetainedNamespaceCompletionJoin.java',
  'AndroidPrivateCustodyOwnerRecovery.java','AndroidProtectedWorkPreferences.java','CustodialNativeRuntime.java',
  'NativePrivateCapsuleFileStore.java','NativePrivateCustodyCurrentFrameAssembler.java','NativePrivateCustodyOperationStore.java',
  'NativePrivateMutationEpochStore.java','NativeProviderJournal.java','NativeSeparationFreeze.java','VaultEngine.java']);
 const identity=m=>{const s=fs.lstatSync(m.root);assert.equal(s.isDirectory(),true);assert.equal(s.isSymbolicLink(),false);assert.equal(s.dev,m.device);assert.equal(s.ino,m.inode);};
 const verify=async()=>{
  pin(file,'2b8764c7bc7a1abd57a234fa8bdaae7661d2464fcb134e9eb869eb2993815ee3');
  pin(loan.handoff,'9ea7abedb9cb65974a3703525314532102d8290bb1425a5ec552bf58f11668d1');
  pin(loan.production_loan,'86b84ac2185dfab341288aa517f994a495be990afacfa7a86f1426e1c2d0d1af');
  assert.equal(loan.exit,0);assert.equal(loan.timed_out,false);assert.equal(loan.interrupted,false);assert.equal(loan.output_truncated,false);assert.equal(loan.source_unchanged,true);
  assert.equal(loan.files.length,120);assert.equal(loan.source_pins.length,24);assert.equal(prod.files.length,420);assert.equal(prod.source_files.length,149);
  assert.equal(prod.compile_exit,0);assert.equal(prod.HOST_JCE,false);identity(loan);identity(prod);
  pin(producerPath,'0673d86e4b665a73ff2d82168a952bdb3f99ed295785ce537130065255368c89');
  assert.equal(producer.compile_exit,0);assert.equal(producer.count,12);identity(producer);
  pin(producer.source.path,producer.source.sha256,producer.source.bytes);
  for(const r of producer.files){assert.ok(!path.isAbsolute(r.path)&&!r.path.split('/').includes('..'));pin(path.join(producer.root,r.path),r.sha256,r.bytes);}
  for(const [file,digest]of compiledSpecs)pin(D+file,digest);
  for(const r of classRows){assert.ok(path.isAbsolute(r.path)&&r.path.startsWith(D));pin(r.path,r.sha256,r.bytes);}
  for(const m of [loan,prod])for(const r of m.files){assert.ok(!path.isAbsolute(r.path)&&!r.path.split('/').includes('..'));pin(path.join(m.root,r.path),r.sha256,r.bytes);}
  // The immutable old test-class loan is reused, not claimed as a fresh run
  // of unrelated mutable test source files. Its owning producer is pinned above.
  for(const r of prod.source_files){const source=path.isAbsolute(r.path)?r.path:path.join(prod.source_root,r.path);
   if(currentFamilies.has(path.basename(source))){const replacement=sourceOverrides.get(source);assert.ok(replacement,source+' compiled replacement required');pin(source,replacement.sha256,replacement.bytes);}
   else pin(source,r.sha256,r.bytes);}
  for(const r of [...loan.HOST3,...prod.normal_dependencies,...prod.jdk])pin(r.path,r.sha256,r.bytes);
  pin(loan.synthetic_fixture.path,'cb927f74c6b6a960bd911c081fac130ae7e10c0508aacff5ea051c499288a8e3',8399);
  pin('/home/eric/Documents/Codex/2026-10-09/task-7/g08-native-sql-manager-preparation-capture-20261014-v1/source/NativePrivateCustodyReturnedPieceSetTest.java','de00784a0b4560a30821690607136e68403d61e6eaaca9f4fb31b135cc345eff',208614);
  pin(loan.root+'/org/memphiszoo/custodial/vault/NativePrivateCustodyReturnedPieceSetTest.class','097e04fe78de808d81d829a277ad956806f3d8bd3924c37e54879956aeeea36d');
  pin(backendRoot+'/scripts/same-original-recovery-local-database-tests.mjs','ed1ba8243a87cc342c3e6f1cc3151780a734b65de53a1fdcb9a35c7c954b4b32');
 };
 await verify();
 const adapter=path.resolve(loan.synthetic_fixture.path,'../../../../..');
 assert.equal(path.join(adapter,'org/memphiszoo/custodial/vault/AndroidKeystoreCipher.class'),loan.synthetic_fixture.path);
 return {base:'/home/eric/Documents/Codex/2026-10-09/task-7/g08-original-write-sql-join-capture-20261014-v1',
  java:prod.jdk.find(r=>path.basename(r.path)==='java').path,
  classpath:[...loan.HOST3.map(r=>r.path),adapter,producer.root,D+'fixed-read-census-core-N361IJ/production',
   ...producer.production_and_helper_classpath,...prod.normal_dependencies.map(r=>r.path)],
  testClassSha256:'097e04fe78de808d81d829a277ad956806f3d8bd3924c37e54879956aeeea36d',verify};
}
// Newly affected caller only. Reuse the normal compiled parents and original
// protected runner; these fixture pins grant no product effect authority.
async function preflightSameOriginalNativeAcceptedCompletionInputs(backendRoot,savedBrowser=false,writerHold=false){
 assert.equal(typeof savedBrowser,'boolean');
 assert.equal(typeof writerHold,'boolean');if(writerHold)assert.equal(savedBrowser,true);
 if(savedBrowser){
  // Newly changed local-before-current owning invocation only. Historical
  // accepted-completion bindings below are retained, never silently rebound.
  const base='/home/eric/Documents/Codex/2026-10-09/task-9/browser-local-prefetch-owning-flow-20261015-v1';
  const own=path.dirname(backendRoot),native=own+'/frontend/mobile/plugins/custodial-native-vault/android/src/main/java/org/memphiszoo/custodial/vault/';
  const adapter='/tmp/custodial-current-frame-lifetime-nAN3W8/adapter';
  const exact=(file,digest,size)=>{const stat=fs.lstatSync(file);assert.equal(stat.isSymbolicLink(),false);assert.equal(stat.isFile(),true);
   const bytes=fs.readFileSync(file);assert.equal(sha(bytes),digest,file);if(size!==undefined)assert.equal(bytes.length,size);return bytes;};
  const before=JSON.parse(exact(base+'/TEST_COMPILE_ACTION_BOUNDARY_BEFORE.json','cea55ddf724a81ac24dc50756c79ee80754762c15c86168e85594e365ea151f3'));
  const compiled=JSON.parse(exact(base+'/TEST_COMPILE_RESULT.v2.json','7780773034fb3d59ae0cef8ef0177c0446b7a4538bc502c7cf97ed7a96fa9a96'));
  const shipping=JSON.parse(exact(own+'/browser-local-before-current-sdk-source-OAgQwc/RESULT.json','1137fe28345a05a4ed14c8283b63995a555001428482ba5358f77e20cb5ac1bd'));
  const revoked=JSON.parse(exact(own+'/browser-local-refusal-revocation-vojJhs/RESULT.json','82f5427aba5fee31ee76e229dc181c9a1f743b5425fa48dd6b45609e5f0010c2'));
  const savedManager=JSON.parse(exact(own+'/saved-browser-manager-recheck-2T3qTz/RESULT.json','3a436132ee19f359efea815f6c1a0604b98d02e099935aa73e0552a163218cfe'));
  const coalesced=JSON.parse(exact(own+'/saved-browser-validation-coalesced-w3BBxn/RESULT.json','e746300aa18eef0ed1a8aa58884552515219fe04553fa3a89b034c6d5081ee47'));
  const fixedRead=JSON.parse(exact(own+'/saved-manager-fixed-read-source-WJq8CW/RESULT.json','b0524115ff1a70aa5c6f5ba08b37680e197a29655507444517177e309abc5fd6'));
  const ancestryRoot='/home/eric/Documents/Codex/2026-10-09/task-9/prepared-original-ancestry-product-20261015-v1';
  const ancestryInputs=JSON.parse(exact(ancestryRoot+'/INPUTS.json','a945221b399dc354d6f973a35e519126c54b1b1af66bf1790c47afdfed191011'));
  const ancestryAfter=JSON.parse(exact(ancestryRoot+'/AFTER_INPUTS.json','e76fbf2d9e5caceffdd532c9e72a3d3fea943d74826cf4bbfd3734cd681bb734'));
  const epochRoot='/home/eric/Documents/Codex/2026-10-09/task-7/native-epoch-refused-handle-product-20261015-v1';
  const epochClasses=JSON.parse(exact(epochRoot+'/CLASS_MANIFEST.json','c858b4a40c037eef7151561a889578294ec06a8e33d9eeebfe378a64c19de1e1'));
  const writerRoot='/home/eric/Documents/Codex/2026-10-09/task-7/native-epoch-writer-refusal-product-20261015-v1';
  const writerClasses=JSON.parse(exact(writerRoot+'/CLASS_MANIFEST.json','2018e1ff05655076388da15e42eecd697e2ef120b1fed85b60dd70b94afd06fc'));
  const clockRoot='/home/eric/Documents/Codex/2026-10-09/task-7/browser-saved-manager-flow-20261015-v1/fresh-running-host-before-originals';
  const clockManifest=JSON.parse(exact(clockRoot+'/CLASS_MANIFEST.json','7a0e819f1b73abe7e459e7bdf7b3bb37f88d4fa66d57ab301f23c6d183ecf95a'));
  const currentSources={'VaultEngine.java':'7f5f47b58539b2ff0c00c56cdd972522855da6c54d453b2434b1e1a25eabcdab',
   'AndroidPrivateCustodyOwnerRecovery.java':'46f8d91c3f4b67be3102279c0aa57648fa8a427211b3c9a571f08afeb2bf081d',
   'CustodialNativeRuntime.java':'64d5970eb0eccfdd21befb24df96422837f3d485d3f4ddb7cf29bd8ac7593d71',
   'NativeOriginalBrowserValueFrame.java':'412c626c491b3b86a095a31df1c838e492719949bd21dc168fb8d7b60432a2f6',
   'NativeOriginalBrowserPreparation.java':'abeb28203ca67a91f485bd67a1770784818058f73015912f9b2fc02605f8af35',
   'NativeOriginalBrowserPreparationWire.java':'ea601b96063502f1c5d6c6dbf63065d72b65733890e7a6343d142ef8991a74f4',
   'NativeOriginalBrowserQueuePayload.java':'c38106f435dfc2c1911b98ebedbaeb8520cc3b5dfbf1cd725de35e6ccfc6fcbb',
   'NativeRetainedNamespaceSemanticJoin.java':'427d3b050184499fb896896d66170120f103f4975286e60447ff40a8c2d09baf',
   'NativePrivateMutationEpochStore.java':'75f5715b3144138388e758fd144e79c0fa5ab930f16ba073a0fbdcd1b4549887'};
  const holdRoot='/home/eric/Documents/Codex/2026-10-09/task-9/native-durable-writer-hold-token-product-20261015-v1';
  const holdEngine={path:own+'/native-writer-hold-source-q9B1TH',dev:2082,ino:4768001,class_count:57,
   class_tree_sha256:'027ad32723995fc4bcbad2dac95c61762e1b41335346875803e03d1b22e16b9f'};
  const holdShipping={path:own+'/native-writer-hold-shipping-QyMYr2',dev:2082,ino:4768170,class_count:28,
   class_tree_sha256:'f19ac4cabf192d55e9403b9bc4858e7c33e95525fd2edec35db600c1dac8ed7d'};
  const stampRoot='/home/eric/Documents/Codex/2026-10-09/task-7/native-fixed-owner-stamp-product-20261015-v1';
  const holdCurrent={path:own+'/native-held-reconstruction-shipping-Xpq8Bi',dev:2082,ino:4769258,class_count:89,
   class_tree_sha256:'c79d1fd19acf5f59909bf2a2df9d3b0848ac38ab9c834df9b6af1c80b9328759'};
  const heldPreferences={path:own+'/native-installed-held-status-shipping-RqB5gh',dev:2082,ino:4769171,class_count:15,
   class_tree_sha256:'bad8bb776fe4c02c17a4ac35cd2635444d901bdc6737a8c23ee620dd7db6fc81'};
  const heldActivity={path:own+'/native-held-verification-activity-rLRC8I',dev:2082,ino:4769062,class_count:2,
   class_tree_sha256:'f0fb61cc92649303c13c0a9a6c08041a4e62913fcca0c28da6643cb6c1e639d1'};
  const fullReconstructionRoot=holdRoot+'/fresh-process-held/held-read-positive/full-reconstruction/ordered-original-dispatch/diagnostic-projection-linearization';
  const attributeProduction={path:'/home/eric/Documents/Codex/2026-10-09/task-7/native-epoch-attribute-read-product-20261015-v1/qualification/production',
   dev:2082,ino:4768690,class_count:15,class_tree_sha256:'f31393032b19ea9d3f5d1cb8c058a20107183f0bbee1cb21f93ae39d78b752a5'};
  const currentReadProduction={path:'/home/eric/Documents/Codex/2026-10-09/task-7/native-epoch-current-read-boundary-product-20261015-v1/qualification/production',
   dev:2082,ino:4769489,class_count:15,classes_sha256:'da3a5c01708c26799c1ca6169bbfd5ab282e03131444c97340100fa57fcc9329'};
  const fullShippingRoot='/home/eric/Documents/Codex/2026-10-09/task-7/current-shipping-native-module-compile-20261015-v1';
  const fullShipping={path:fullShippingRoot+'/classes',dev:2082,ino:4769598,class_count:476,
   class_tree_sha256:'091b6f5a23181c6b17f2af74529406929c20c4fe6a714cd79ecb834d6ed444ba'};
  const linearProofRoot='/home/eric/Documents/Codex/2026-10-09/task-7/native-owning-read-projection-product-20261015-v1';
  const linearProofProduction={path:linearProofRoot+'/qualification/production',dev:2082,ino:4770208,class_count:58,
   class_tree_sha256:'98cafb971459dcb7779caf2e5f3994097bcb0fb9244fbdaa14fff683df2b5208'};
  let holdReceipt,stampClasses,holdFresh;
  const managerTerminalRoot=own+'/native-manager-terminal-join-0Cho4t';
  const managerTerminalProduction={path:managerTerminalRoot+'/production',dev:2082,ino:4771372,class_count:59,
   class_tree_sha256:'9208379225352a3f30cf1460ce4383fd689bb1e52179a3976aa81e581bdfb433'};
  const packetExportRoot='/home/eric/Documents/Codex/2026-10-09/task-7/original-query-packet-export-product-join-20261015-v1';
  const packetExportProduction={path:packetExportRoot+'/qualification',dev:2082,ino:4772142,class_count:14,
   class_tree_sha256:'8ed6f8801a47a5a1e6651c0e4fbd3a68bd188bfca0211ee3c30cc8d1c2369b9d'};
  const runtimeOrderedRoot='/home/eric/Documents/Codex/2026-10-09/task-7/actual-runtime-ordered-writer-hold-product-20261015-v1';
  const runtimeOrderedProduction={path:runtimeOrderedRoot+'/qualification',dev:2082,ino:4772952,class_count:14,
   class_tree_sha256:'8f2b5dba05bc4182be7211f95538a4bf2b77c68a5e5429b4430b0edad4aecbbd'};
  const retainedCauseRoot=runtimeOrderedRoot+'/retained-cause-v1';
  const historicalRetainedCauseProduction={path:retainedCauseRoot+'/qualification',dev:2082,ino:4775576,class_count:14,
   class_tree_sha256:'8b3e18944a128aaf23423bc84ef2b3b7ee199a260815156b3388be22ffa943f3'};
  // Changed existing caller exports the actual held-cycle response buffers;
  // historical caller and failed packet remain immutable, not repaired in place.
  const responseExportRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/held-runtime-response-export-20261016-v1');
  const retainedCauseProduction={path:responseExportRoot+'/qualification',dev:2082,ino:4890892,class_count:14,
   class_tree_sha256:'b3fe903552aea4732b297a57f9e76cae79bb6700f16b09bb8ee58779b258b92a'};
  const coldHeldRoot=own+'/native-cold-held-cause-join-uHXasH';
  const warmHeldRoot=own+'/native-warm-held-entry-UXO5Tf';
  const warmHeldProduction={path:warmHeldRoot+'/production',dev:2082,ino:58778176,class_count:2,
   class_tree_sha256:'922226a5a17f8dec95ef4c549c62525c1cfdc19d8d206031500fbca8751b34b8'};
  const coldHeldProduction={path:coldHeldRoot+'/production',dev:2082,ino:57074251,class_count:63,
   class_tree_sha256:'aa1147c02bda605b78588fe2275f3b0345d24031e54f4206b6b60dc52920527f'};
  const resultCauseRoot=own+'/native-browser-result-cause-Tc9oJE';
  const resultCauseProduction={path:resultCauseRoot+'/production',dev:2082,ino:57467452,class_count:59,
   class_tree_sha256:'ae6ff23911ae528bcd106d2122f2ba93b81de202cdf43e46fc461cee42a8fb2c'};
  const managerSharedRoot=own+'/native-manager-shared-prepared-BFintn';
  const managerSharedProduction={path:managerSharedRoot+'/production',dev:2082,ino:57729634,class_count:59,
   class_tree_sha256:'18812e27986246bab1130a690d7cbbad75db9822b71c97010f9f6d23227e40b2'};
  const detachedPlanRoot=own+'/native-detached-plan-boundary-umsUN1';
  const detachedPlanProduction={path:detachedPlanRoot+'/production',dev:2082,ino:57851987,class_count:59,
   class_tree_sha256:'32cd3e4712c8459174089ff80ac39e2573e1f3fd5452f6d7098917ca2606112e'};
  const epochHoldEntryRoot=own+'/native-epoch-hold-entry-M3SY77';
  const epochAbsenceRoot=own+'/native-epoch-absence-r2YuRj';
  const epochAbsenceProduction={path:epochAbsenceRoot+'/production',dev:2082,ino:58778152,class_count:16,
   class_tree_sha256:'ed3e68161e435057ffd7ca1fe23391e105c40cb3bc001ff23d172277978e7af2'};
  const epochBaseBatchRoot='/home/eric/Documents/Codex/2026-10-09/task-7/native-epoch-base-validation-batch-20261015-v1';
  const epochBaseBatchProduction={path:epochBaseBatchRoot+'/production',dev:2082,ino:4863104,class_count:16,
   class_tree_sha256:'7dd405d44ecc2d37b6339e32d5535f13bfb30123f8f00d5c958f89ba62bc354e'};
  const heldSourceBatchRoot=own+'/native-held-source-batch-WNEPNE';
  const heldCtorRoot=own+'/native-held-ctor-xQuw4D';
  const heldCtorProduction={path:heldCtorRoot+'/production',dev:2082,ino:58647081,class_count:59,
   class_tree_sha256:'fff6dc0bc9222d9154aef8f2d55418735cf98c90f258c7206c524e5770eabce0'};
  const browserBatchRoot=own+'/native-browser-batch-37przd';
  const browserBatchProduction={path:browserBatchRoot+'/production',dev:2082,ino:58778242,class_count:59,
   class_tree_sha256:'809b40fabeba162033cc98facd48a95f6545e4878b4d6cb57c0a1dbd125a717c'};
  const presenceRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/exchange-presence-fail-closed-20261015-v1/qualification');
  const presenceProduction={path:presenceRoot+'/production',dev:2082,ino:4863213,class_count:59,
   class_tree_sha256:'6d45443316f3d6b3b3c5e7a7b26a0bca27d0cd0f8a4ea44e1560f99b900fc70b'};
  const capsulePresenceRoot='/home/eric/Documents/Codex/2026-10-09/task-7/native-capsule-presence-fail-closed-20261015-v1';
  const capsulePresenceProduction={path:capsulePresenceRoot+'/production',dev:2082,ino:4863374,class_count:6,
   class_tree_sha256:'8470bba87eda5d77309c7c9aaa3c696fa187b6464b3c64f77e17249bee06dd20'};
  const sealedQueryRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/sealed-current-query-lock-composition-20261015-v1/qualification');
  const sealedQueryProduction={path:sealedQueryRoot+'/production',dev:2082,ino:4864721,class_count:59,
   class_tree_sha256:'113dc3e8faaebc494c692537c20df37f148079191f6dde3ed52d3395de0a1c9a'};
  const sealedPreparedRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/sealed-recovery-prepared-lock-composition-20261015-v1/qualification');
  const sealedPreparedProduction={path:sealedPreparedRoot+'/production',dev:2082,ino:4866190,class_count:59,
   class_tree_sha256:'00a972f8323670d478e6cfd9a32f7181c4b3a1da89b708741d5008c314fa4b8a'};
  const savedBrowserManagerRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/native-saved-browser-manager-validation-20261015-v1/qualification');
  const savedBrowserManagerProduction={path:savedBrowserManagerRoot+'/production',dev:2082,ino:4872366,class_count:59,
   class_tree_sha256:'1267703f6538d7a3c33f933ccf672f973912a6464f56cca141e0c290bab7584a'};
  const currentQueryRestorationRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/native-current-query-restoration-batch-20261016-v1/qualification');
  const currentQueryRestorationProduction={path:currentQueryRestorationRoot+'/production',dev:2082,ino:4878446,class_count:59,
   class_tree_sha256:'f68c4670209a3691b01c2f6678e469fcc802ecf27440c3bca1cbecf2789c6774'};
  const savedStatusCurrentRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/native-saved-status-current-batch-20261016-v1/qualification');
  const savedStatusCurrentProduction={path:savedStatusCurrentRoot+'/production',dev:2082,ino:4884603,class_count:59,
   class_tree_sha256:'70ba86435defeeeefc78c84d58ad04cd6c3d96d34a38ce6446c8c4d8a8a1ed10'};
  const currentQueryDispatchRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/native-current-query-dispatch-batch-20261016-v1/qualification');
  const historicalCurrentQueryDispatchProduction={path:currentQueryDispatchRoot+'/production',dev:2082,ino:4890720,class_count:59,
   class_tree_sha256:'b7629ba695a53cf80ab5d0fcf5a37bbba0cbad588e67deb5a4656dae028b8353'};
  const terminalBrowserReturnRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/native-saved-browser-terminal-return-20261016-v1/qualification');
  const currentQueryDispatchProduction={path:terminalBrowserReturnRoot+'/production',dev:2082,ino:4896961,class_count:59,
   class_tree_sha256:'fc669873d34eed5095762424fb8f0908fb552411bb3bc10384bb7c8c22f0f76e'};
  const heldSourceBatchProduction={path:heldSourceBatchRoot+'/production',dev:2082,ino:58384958,class_count:59,
   class_tree_sha256:'985ec304b65efa1461a74ef4aef604924e7215a67b9aa8b2197909e4d5b5dbc6'};
  const epochHoldEntryProduction={path:epochHoldEntryRoot+'/production',dev:2082,ino:57852220,class_count:27,
   class_tree_sha256:'66df7205f7b48f5aec14d5f10121a22e19d1ff28f5b801b5ad71e0ef4ad7c111'};
  const privateValuesRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/private-values-duplicate-hash-20261015-v1');
  const privateValuesProduction={path:privateValuesRoot+'/qualification/production',dev:2082,ino:4849795,class_count:6,
   class_tree_sha256:'256cb73f83e2832bf492f217ba6e98629316e7e3a45012d1fc632e4391693af9'};
  const actionStartRoot=path.resolve(own,'../private-operation-crash-recovery-20261013/protected-action-start-20261015-v1');
  const actionStartProduction={path:actionStartRoot+'/qualification/classes',dev:2082,ino:34656491,class_count:2,
   class_tree_sha256:'889348095805778967d50a9e35d1b9e34ff7a65757d0c0c6363465707b622c45'};
  const managerCryptoRoot=own+'/native-manager-crypto-join-xM30FV';
  const managerCryptoProduction={path:managerCryptoRoot+'/production',dev:2082,ino:4772298,class_count:59,
   class_tree_sha256:'1c398f3ae7613cdd16e82df9c23f1e5e8488f8612e635a4a2657efe98b57e8a7'};
  const completionTerminalRoot=own+'/native-completion-terminal-join-Rsmszb';
  const completionTerminalProduction={path:completionTerminalRoot+'/production',dev:2082,ino:4772775,class_count:59,
   class_tree_sha256:'f6b18f64b1c749607e03d3c21e4cb2ea09816ef7527926d5acd1c3bc5aa4fb3b'};
  const coreUidProduction={path:'/home/eric/Documents/Codex/2026-10-09/task-9/native-epoch-fresh-uid-owner-product-20261015-v1/production-object-anchor',dev:2082,ino:4771412,class_count:16,
   class_tree_sha256:'05018689f36098feafb52660b123ce3ee14290ea18bea4fe5e7e31ff1e95aee7'};
  const planEntryProduction={"path":"/home/eric/Documents/Codex/2026-09-13/i-x20/work/autonomous-repair-20260923/overnight-readiness-20261006/lean-held-correction-integration-20261011/native-plan-entry-owner-5YJ9Ut/production","dev":2082,"ino":4771059,"class_count":58,"class_tree_sha256":"6626777f958d52deab5164cf59997a1bc6595a2ea0af7500a93f3beabe582d04"};
  const fixedFamilyProduction={path:'/home/eric/Documents/Codex/2026-10-09/task-9/fixed-family-namespace-read-boundary-product-20261015-v1/production',dev:2082,ino:4770975,class_count:4,
   class_tree_sha256:'a6d4c2ad8c1ab2c9e167f55753b7bba509a289b4fdc02c65fed9ba0ea66a553c'};
  const combinedReadProduction={"path":"/home/eric/Documents/Codex/2026-09-13/i-x20/work/autonomous-repair-20260923/overnight-readiness-20261006/lean-held-correction-integration-20261011/native-combined-current-read-e6173A/production","dev":2082,"ino":4770739,"class_count":64,"class_tree_sha256":"9840c5a4acc706d809ac04b556c74c6df254a9b4303d5d7f95bd0fe8a7ba4156"};
  const liveBaselineProduction={path:'/home/eric/Documents/Codex/2026-10-09/task-7/native-epoch-baseline-live-identity-product-20261015-v1/qualification/production',dev:2082,ino:4770498,class_count:15,
   class_tree_sha256:'b2c9e1cf889414c3735f13c65f2f4b93769d072829b01f57a5455843451432c9'};
  // Only this changed V3 owning join overlays current production. Historical
  // component receipts below keep their own original source identities.
  const joinedHeldRoot=path.resolve(own,'../native-browser-held-binding-join-20261016-j41IfZ');
  const joinedHeldProduction={path:joinedHeldRoot+'/production',dev:2082,ino:58513628,class_count:86,
   class_tree_sha256:'5b8fca4a226ad15e04dfdc34cc1300cc52b913e3d61f5d9b4da754e208219912'};
  const liveBrowserProduction={path:path.resolve(own,'../native-browser-source-lifetime-20261016-o8zGhV/production'),
   dev:2082,ino:56812196,class_count:64,class_tree_sha256:'6f0e1acb6fb164237c8fdb4e4a9bf9dec93183b6db83c0d6d74c03427b7c584a'};
  const joinedHeldSources={
   'VaultEngine.java':'1decc568e8c65a9539f00e4cc2a84b9981fc9c21f6474bb5c7873e1a1ad3c975',
   'AndroidProtectedWorkPreferences.java':'b50c080a4d5c5c2c7f0940b7e26da6d135225f074b33da7a4993af08dbf16ab0',
   'NativePrivateMutationEpochStore.java':'10238c09226db0cf87f7417bae1f79189a142579dfec78a1629e8e5e5df6911e',
   'NativeOriginalBrowserPreparation.java':'f4f4894014cd188b3304845a1d6c29a2d65c13e173fd5aeab15fb6cf088ef205',
   'NativeOriginalBrowserPreparationWire.java':'f6a0072ada666cad1620420c3385d5dd8b7a7481450afcc533dd08cba6be0af5',
   'NativePrivateCustodyOperationStore.java':'6b0f392a7f6b0882ced77c8b2e21b079884bba8994da3f6913caf2f72067f598'};
  // Changed Store owning entries, not a requalification of the historical
  // component receipts below. Current production resolves before old loans.
  const operationJoinRoot='/home/eric/Documents/Codex/2026-10-09/task-7/held-operation-store-owning-join-20261016-v1';
  const operationJoinProduction={path:operationJoinRoot+'/qualification',dev:2082,ino:4898116,class_count:14,
   class_tree_sha256:'55bd9ba4e2a88449a0dbbf74bd31b22f2e754569520d067c67abf04db45edf4b'};
  const currentEngineRoot='/home/eric/Documents/Codex/2026-10-09/task-7/enrollment-dispatch-existing-fence-product-20261016-v1';
  const currentEngineProduction={path:currentEngineRoot+'/production-readback-fixed',dev:2082,ino:4897941,class_count:59,
   class_tree_sha256:'626d3b9d0b2baa2316bf43ffa91d07f15edeedf7f1c5f8e77e25f8a41506cccf'};
  const operationRoot='/home/eric/Documents/Codex/2026-10-09/task-7/native-operation-writer-held-fence-product-20261016-v2';
  const operationProduction={path:operationRoot+'/production',dev:2082,ino:4898018,class_count:10,
   class_tree_sha256:'85ed4c334e1a02ca9b2448f50b3d8d3e303b4d68ebfc2397ed564b1474ebaf7e'};
  const currentBrowserProduction={path:path.resolve(own,'../native-queued-command-lifetime-20261016-MgwatB/production'),
   dev:2082,ino:59794088,class_count:65,class_tree_sha256:'18debd327751ccc3c4f384a505d41476e49edf0e05752f5d134f2ec0d19b79dc'};
  const currentWireProduction={path:path.resolve(own,'../native-existing-held-browser-source-20261016-xTiKUO/production'),
   dev:2082,ino:59793861,class_count:68,class_tree_sha256:'c715cc48d59c3c3b84c152d9cb44b1c80727b27c000056abd1f232f3d18a0aad'};
  if(writerHold){
   holdFresh=JSON.parse(exact(fullReconstructionRoot+'/COMPILE_RESULT.json','325e78f108c25f5f70110bdc459bfe9595f6f9ab0683bad72f1b2588d68437d3'));
   stampClasses=JSON.parse(exact(stampRoot+'/CLASS_MANIFEST.json','4040bdc817f76a194e627aa68b31acaeae642fd23702ea1b293fdabe8361ee86'));
   holdReceipt=JSON.parse(exact(holdRoot+'/HELD_PROMOTION_HANDOFF.json','a0fb34c16d9e9a15fdeb2829c434c0f3e4aacf7c447ecfd0de97a419d8e0f2d7'));
   Object.assign(currentSources,{'VaultEngine.java':'f8618e99f0acf8b3c277c8322660be5229640b311dd2298096e7103e2e3882c9',
    'NativePrivateCapsuleFileStore.java':'ea9dfb1a1ac48f1ffc6c8eac0fe3bae219df055719d984f0181974baef2aad9e',
    'NativeRetainedNamespaceValues.java':'401cfbf8492dd06ae5589e1012d83ec449358f7496e7e7ac0260397cc6a6bd62',
    'NativeRetainedNamespacePrivateCapsule.java':'938157e7a52184823656ad81cce3b4697d64996c3f12b4f7515f5d8d454e50fc',
    'NativePrivateCustodyHttp.java':'f70657a392aa0b6d25227622e6c52d764657a3f7f7965aca5c24e75a6ccb7e88',
    'AndroidPrivateCustodyOwnerRecovery.java':'b9675393c8662cb2eb0ffe9b46190563261e4b4a75655fdfa9d25b07e8c5eed6',
     'NativePrivateMutationEpochStore.java':'b2cb63443fd8be9fd55c86c6fc7f508a15809e50a1aeeea85a5d7a19cd9398f8',
    'AndroidProtectedWorkPreferences.java':'4211f1e2db9b3390722c3c6140b7eea9670c4094e8e1d412c42473e7d4bb8a10',
    'CustodialNativeRuntime.java':'c3d2ab512d1d89f443554b861aeb2324410faebd1945c43d5a12300432889089',
    'NativeProtectedRecoveryPreparationActivity.java':'db392019a091121f4a4d1c9c805a11698769d72354a89b0495cdfe0842e8a149',
    'NativeProtectedNamespaceObservation.java':'88634879f4afd2bf68a64b85e126d915793fef6ef0c0a26e1536cd6e72355bc7',
    'AndroidProtectedNamespaceReaders.java':'5030cd24ea86b0cf99e5204a2e0123cb424b09b393ccbc58d885352b06f6f608'});
  }
  // Retained receipts explicitly name one of the two existing tree recipes.
  // Refuse absent/ambiguous recipes; do not reinterpret a historical digest.
  const directory=row=>{const stat=fs.lstatSync(row.path);assert.equal(stat.isSymbolicLink(),false);assert.equal(stat.isDirectory(),true);
   assert.equal(stat.dev,row.dev);assert.equal(stat.ino,row.ino);const rows=[];
   const objects=Object.hasOwn(row,'classes_sha256');assert.notEqual(objects,Object.hasOwn(row,'class_tree_sha256'));
   const walk=dir=>{const names=fs.readdirSync(dir);objects?names.sort((a,b)=>a.localeCompare(b)):names.sort();
    for(const name of names){const file=path.join(dir,name),s=fs.lstatSync(file);
    assert.equal(s.isSymbolicLink(),false);if(s.isDirectory())walk(file);else if(name.endsWith('.class')){
     const rel=path.relative(row.path,file),digest=sha(fs.readFileSync(file));
     rows.push(objects?{path:rel,bytes:s.size,sha256:digest}:[rel,s.size,digest]);}}};
   walk(row.path);assert.equal(rows.length,row.class_count);assert.equal(sha(JSON.stringify(rows)),objects?row.classes_sha256:row.class_tree_sha256,row.path);
  };
  const pin=row=>Object.hasOwn(row,'class_count')?directory(row):exact(row.path,row.sha256,row.bytes);
  const previousPin=row=>{
   if(writerHold&&row.path===native+'NativePrivateCapsuleFileStore.java'){
    assert.equal(row.sha256,'17a78aa4a14b96435afc57c6fe304c2c01ed9bb63415c3263e00504ebb8cd5f4');
    return exact(row.path,currentSources['NativePrivateCapsuleFileStore.java']);
   }
   if(writerHold&&Object.hasOwn({'NativeProtectedNamespaceObservation.java':'5b44ffc356c006e6ecaca2f8488a702366d973c7ac9a21a78dcd45371d776694','AndroidProtectedNamespaceReaders.java':'b5dfc51b384fc1342bb523b03882b2fe960bf218d5e8971911daa7a3f67e4238'},path.basename(row.path))&&row.path===native+path.basename(row.path)){
    assert.equal(row.sha256,{'NativeProtectedNamespaceObservation.java':'5b44ffc356c006e6ecaca2f8488a702366d973c7ac9a21a78dcd45371d776694','AndroidProtectedNamespaceReaders.java':'b5dfc51b384fc1342bb523b03882b2fe960bf218d5e8971911daa7a3f67e4238'}[path.basename(row.path)]);
    return exact(row.path,currentSources[path.basename(row.path)]);
   }
   if(row.path===native+'VaultEngine.java'){
    assert.equal(row.sha256,'fc9eecbe27a9aeec0b9d2c48b437928fa062ad4de5149374102a4c9e1bc37624');
    assert.equal(row.bytes,512090);
    // This retained input describes the old compiled component, not today's
    // owning V3 join. Check its historical declaration above and the explicitly
    // compiled current Engine independently; never rewrite the old receipt.
    return exact(row.path,writerHold?joinedHeldSources['VaultEngine.java']:currentSources['VaultEngine.java'],writerHold?undefined:521678);
   }
   if(writerHold&&row.path===native+'CustodialNativeRuntime.java'){
    assert.equal(row.sha256,'64d5970eb0eccfdd21befb24df96422837f3d485d3f4ddb7cf29bd8ac7593d71');
    return exact(row.path,currentSources['CustodialNativeRuntime.java']);
   }
   if(writerHold&&row.path===native+'AndroidPrivateCustodyOwnerRecovery.java'){
    assert.equal(row.sha256,'46f8d91c3f4b67be3102279c0aa57648fa8a427211b3c9a571f08afeb2bf081d');
    return exact(row.path,currentSources['AndroidPrivateCustodyOwnerRecovery.java']);
   }
   return pin(row);
  };
  const verify=async()=>{
   exact(own+'/browser-local-refusal-revocation-vojJhs/RESULT.json','82f5427aba5fee31ee76e229dc181c9a1f743b5425fa48dd6b45609e5f0010c2');
   exact(own+'/saved-browser-manager-recheck-2T3qTz/RESULT.json','3a436132ee19f359efea815f6c1a0604b98d02e099935aa73e0552a163218cfe');
   exact(own+'/saved-browser-validation-coalesced-w3BBxn/RESULT.json','e746300aa18eef0ed1a8aa58884552515219fe04553fa3a89b034c6d5081ee47');
   exact(own+'/saved-manager-fixed-read-source-WJq8CW/RESULT.json','b0524115ff1a70aa5c6f5ba08b37680e197a29655507444517177e309abc5fd6');
   exact(epochRoot+'/CLASS_MANIFEST.json','c858b4a40c037eef7151561a889578294ec06a8e33d9eeebfe378a64c19de1e1');
   const epochResult=JSON.parse(exact(epochRoot+'/RESULT.json','9a17cb82218be3d6ba7c49450c9763c748b79b7c6894020af866118838503a35'));
   assert.equal(epochResult.compile.terminal.exit_code,0);assert.equal(epochResult.old_groups_replayed,0);
   assert.equal(epochResult.borrowed_unchanged_at_terminal,true);assert.equal(epochResult.resources.active_helper,0);
   assert.deepEqual(epochResult.runs.map(r=>r.terminal.exit_code),[1,0,0,0]);
   assert.equal(epochResult.sources['NativePrivateMutationEpochStore.java'],'7df3f3a41ec559f6086e8e1e9beae252040f5df492a2a65d308d5b4e5d26624e');
   assert.equal(epochClasses.path,epochRoot+'/qualification-with-evidence-helper/classes');
   assert.equal(epochClasses.class_count,22);directory(epochClasses);
   const epochProduction=epochClasses.classes.filter(r=>/^org\/memphiszoo\/custodial\/vault\/NativePrivateMutationEpochStore(?:\$[^/]+)?\.class$/.test(r.path));
   assert.equal(epochProduction.length,12);assert.equal(sha(JSON.stringify(epochProduction)),'6a69ece96f08cbc1d015e42d82edb164ba6debed6906722318e50cdbb59b339c');
   exact(writerRoot+'/CLASS_MANIFEST.json','2018e1ff05655076388da15e42eecd697e2ef120b1fed85b60dd70b94afd06fc');
   const writerResult=JSON.parse(exact(writerRoot+'/RESULT.json','ab104f287639c5ba7fd84af315b0a9a89c39c0843f6d9b09bce42d59e6270cfb'));
   assert.equal(writerResult.compile.terminal.exit_code,0);assert.equal(writerResult.old_groups_replayed,0);
   assert.equal(writerResult.borrowed_unchanged_at_terminal,true);assert.equal(writerResult.resources.cleanup_errors,0);
   assert.deepEqual(writerResult.runs.map(r=>r.terminal.exit_code),[1,0,0,0]);
   assert.equal(writerResult.sources.find(r=>r.path.endsWith('/NativePrivateMutationEpochStore.java')).sha256,'75f5715b3144138388e758fd144e79c0fa5ab930f16ba073a0fbdcd1b4549887');
   assert.equal(writerClasses.path,writerRoot+'/qualification/classes');assert.equal(writerClasses.class_count,22);directory(writerClasses);
   const writerProduction=writerClasses.classes.filter(r=>/^org\/memphiszoo\/custodial\/vault\/NativePrivateMutationEpochStore(?:\$[^/]+)?\.class$/.test(r.path));
   assert.equal(writerProduction.length,12);assert.equal(sha(JSON.stringify(writerProduction)),'86c4f031a31c6db1e63eae81dc39049d25cd6a945e63881a50f3214d23756589');
   exact(clockRoot+'/CLASS_MANIFEST.json','7a0e819f1b73abe7e459e7bdf7b3bb37f88d4fa66d57ab301f23c6d183ecf95a');
   const clockCompile=JSON.parse(exact(clockRoot+'/COMPILE_RESULT.json','99d81b340764254db8641fadcce331e2797e8760c508066a3f522b0ab54feda8'));
   assert.equal(clockCompile.terminal.exit_code,0);assert.equal(clockManifest.path,clockRoot+'/qualification/classes');
   assert.equal(clockManifest.class_count,17);directory(clockManifest);
   exact(base+'/TEST_COMPILE_ACTION_BOUNDARY_BEFORE.json','cea55ddf724a81ac24dc50756c79ee80754762c15c86168e85594e365ea151f3');
   exact(base+'/TEST_COMPILE_RESULT.v2.json','7780773034fb3d59ae0cef8ef0177c0446b7a4538bc502c7cf97ed7a96fa9a96');
   exact(base+'/HANDOFF.v2.json','66df50ca87c353bffbec1b5b23b4a331cad1393b68b513b269b2cf2e5dbc6fdc');
   exact(own+'/browser-local-before-current-sdk-source-OAgQwc/RESULT.json','1137fe28345a05a4ed14c8283b63995a555001428482ba5358f77e20cb5ac1bd');
   assert.equal(shipping.status,0);assert.equal(shipping.all_inputs_unchanged,true);assert.equal(shipping.HOST_JCE,false);
   assert.equal(shipping.borrowed_count,97);assert.equal(shipping.before.length,97);shipping.before.forEach(previousPin);directory(shipping.output);
   assert.equal(shipping.output.path,own+'/browser-local-before-current-sdk-source-OAgQwc/classes');assert.equal(shipping.output.class_count,58);
   assert.equal(compiled.terminal.exit_code,0);assert.equal(compiled.HOST_JCE,false);assert.equal(compiled.fixtureCipherOnJavacClasspath,false);
   assert.equal(compiled.historical_cases_replayed,0);assert.equal(before.borrowed.length,96);
   assert.equal(before.HOST_JCE,false);assert.equal(before.syntheticAdapterOnCompileClasspath,false);
   assert.equal(compiled.after.all96BorrowedAnd3ShippingSourcesUnchanged,true);
   assert.deepEqual(compiled.after.borrowed,before.borrowed);assert.deepEqual(compiled.after.sourcePins,before.sourcePins);
   assert.deepEqual(compiled.after.source,before.source);assert.deepEqual(compiled.after.compiler,before.compiler);
   before.borrowed.forEach(previousPin);pin(before.compiler);pin(before.source);
   assert.equal(before.source.sha256,'e38eb99508f7e1b817b5984427ed0e28a152c25cfca564457ed2599fc170e5ab');
   assert.equal(before.source.path,base+'/source/NativePrivateCustodyReturnedPieceSetTest.java');
   assert.equal(before.sourcePins.length,3);assert.deepEqual(before.sourcePins,shipping.sourcePins);
   for(const row of shipping.sourcePins){
    if(path.basename(row.path)==='VaultEngine.java'){assert.equal(row.sha256,'fc9eecbe27a9aeec0b9d2c48b437928fa062ad4de5149374102a4c9e1bc37624');}
    else if(writerHold&&path.basename(row.path)==='CustodialNativeRuntime.java'){assert.equal(row.sha256,'64d5970eb0eccfdd21befb24df96422837f3d485d3f4ddb7cf29bd8ac7593d71');}
    else if(writerHold&&path.basename(row.path)==='AndroidPrivateCustodyOwnerRecovery.java'){assert.equal(row.sha256,'46f8d91c3f4b67be3102279c0aa57648fa8a427211b3c9a571f08afeb2bf081d');}
    else {assert.equal(currentSources[path.basename(row.path)],row.sha256);pin(row);}
   }
   assert.equal(revoked.status,0);assert.equal(revoked.HOST_JCE,false);assert.equal(revoked.inputsUnchanged,true);
   assert.deepEqual(revoked.after,revoked.before);assert.equal(revoked.before.length,93);
   assert.deepEqual(revoked.before.map(row=>row.path),revoked.classpath);revoked.before.forEach(pin);
   pin(revoked.compiler);assert.equal(revoked.source.path,native+'VaultEngine.java');
   assert.equal(revoked.source.sha256,'f2999848e780b8e7923b1f2255a3c768ab2c84bd569c4d5117165670e0a0230f');
   assert.equal(revoked.output.path,own+'/browser-local-refusal-revocation-vojJhs/classes');
   assert.equal(revoked.output.class_count,55);assert.equal(revoked.output.class_tree_sha256,'fbacca72737df7a47c130c40ab4755ef1ccce043be8e59fd4e228697999a2106');directory(revoked.output);
   assert.equal(savedManager.status,0);assert.equal(savedManager.inputsUnchanged,true);assert.equal(savedManager.HOST_JCE,false);
   assert.deepEqual(savedManager.after,savedManager.before);assert.deepEqual(savedManager.before,revoked.before);
   savedManager.before.forEach(pin);pin(savedManager.compiler);
   assert.equal(savedManager.source.path,native+'VaultEngine.java');assert.equal(savedManager.source.sha256,'af49570900e4f83e4fff7335722949b40586256bec329400844919dc3f10e9ef');
   assert.equal(savedManager.output.path,own+'/saved-browser-manager-recheck-2T3qTz/classes');
   assert.equal(savedManager.output.class_count,55);assert.equal(savedManager.output.class_tree_sha256,'1da5dd788ae415e1cc0d260bcf343ea246fde267ae28973ea7f2ee0d37398c33');directory(savedManager.output);
   assert.equal(coalesced.status,0);assert.equal(coalesced.inputsUnchanged,true);assert.equal(coalesced.HOST_JCE,false);
   assert.deepEqual(coalesced.after,coalesced.before);assert.deepEqual(coalesced.before,savedManager.before);
   coalesced.before.forEach(pin);pin(coalesced.compiler);
   assert.equal(coalesced.source.path,native+'VaultEngine.java');assert.equal(coalesced.source.sha256,'710d6e21d6eea6c1b8821d059a31fb66e2868ef06d9497b8beac97dffb2b504f');
   assert.equal(coalesced.output.path,own+'/saved-browser-validation-coalesced-w3BBxn/classes');
   assert.equal(coalesced.output.class_count,55);assert.equal(coalesced.output.class_tree_sha256,'1f8f75ba11e3a2d14fb29d94f6bb74185f7e2519ec632f2d72a8b22be134067d');directory(coalesced.output);
   assert.equal(fixedRead.status,0);assert.equal(fixedRead.inputsUnchanged,true);assert.equal(fixedRead.HOST_JCE,false);
   assert.deepEqual(fixedRead.after,fixedRead.before);assert.equal(fixedRead.before.length,94);
   assert.equal(fixedRead.before[0].path,epochClasses.path);assert.deepEqual(fixedRead.before.slice(1),coalesced.before);
   fixedRead.before.forEach(pin);pin(fixedRead.compiler);
   assert.equal(fixedRead.source.path,native+'VaultEngine.java');assert.equal(fixedRead.source.sha256,'55ddc6890e3c9ba52717f26e03f738bc9f8a39d5fe590812db088e094983761e');
   assert.equal(fixedRead.output.path,own+'/saved-manager-fixed-read-source-WJq8CW/classes');
   assert.equal(fixedRead.output.class_count,56);assert.equal(fixedRead.output.class_tree_sha256,'9ec6f8a348eb5ae694cb72796b8b316fd070b928e5b8f68a33320bd2edb5aff4');directory(fixedRead.output);
   const ancestryCompile=JSON.parse(exact(ancestryRoot+'/RESULT.json','0508212338429e2ecfdafcafb761918cf182a7be8dd76da491f4c624fe8b1652'));
   const ancestryRun=JSON.parse(exact(ancestryRoot+'/HEAVY_QUALIFICATION_RESULT.json','7a4426a4f5f5cdfcf4cc1dcb13c5e18df1ca51a6e95966938c72e5070062d9cb'));
   exact(ancestryRoot+'/INPUTS.json','a945221b399dc354d6f973a35e519126c54b1b1af66bf1790c47afdfed191011');
   exact(ancestryRoot+'/AFTER_INPUTS.json','e76fbf2d9e5caceffdd532c9e72a3d3fea943d74826cf4bbfd3734cd681bb734');
   assert.equal(ancestryCompile.production.terminal.exit_code,0);assert.equal(ancestryInputs.HOST_JCE,false);
   assert.equal(ancestryInputs.fixtureCipherOnCompileClasspath,false);assert.equal(ancestryAfter.allInputsUnchanged,true);
   assert.deepEqual(ancestryAfter.borrowed,ancestryInputs.borrowed);ancestryInputs.borrowed.forEach(pin);
   pin(ancestryInputs.compiler);ancestryInputs.sources.forEach(pin);assert.deepEqual(ancestryAfter.sources,ancestryInputs.sources);
   assert.equal(ancestryInputs.sources[0].sha256,'7f5f47b58539b2ff0c00c56cdd972522855da6c54d453b2434b1e1a25eabcdab');
   assert.equal(ancestryRun.status,'SEVEN_NEW_MEMBERS_PASS');assert.equal(ancestryRun.execution.cases.length,7);
   assert.deepEqual(ancestryRun.execution.cases.map(r=>r.exitCode),[0,0,0,0,0,0,0]);
   assert.equal(ancestryRun.resources.heavySlot,'RELEASED');assert.equal(ancestryRun.proposal.source_sha256,'7f5f47b58539b2ff0c00c56cdd972522855da6c54d453b2434b1e1a25eabcdab');
   assert.equal(ancestryAfter.outputs.production.path,ancestryRoot+'/production');assert.equal(ancestryAfter.outputs.production.class_count,56);
   assert.equal(ancestryAfter.outputs.production.class_tree_sha256,'8b3e97cfb1eac34f73ee4c252ca1ae46a6bfbf8f0d298b6651af2a0ebc0c383c');directory(ancestryAfter.outputs.production);
   if(writerHold){
    const terminal=JSON.parse(exact(managerTerminalRoot+'/RESULT.json','b7d692f3f7573afd7e1530b261044a5cb30ae58ef8e61b6779182bb4cc8c95ec'));
    assert.equal(terminal.status,'COMBINED_SHIPPING_SOURCE_COMPILED_FOUR_NEW_FRAME_MEMBERS_PASS_NOT_WORKFLOW_PASS');
    assert.equal(terminal.F,'a8bac455ce5815f5376d5b82b701340cf73856b6');
    assert.equal(terminal.source.Engine,'09f85031eca3848cd7365ba19288c1475e77815f7e212a66990816a79a3e724e');
    assert.equal(terminal.compile.production.exit,0);assert.equal(terminal.compile.production.SDKFirst,true);
    assert.equal(terminal.compile.production.fixtureCipher,false);assert.equal(terminal.compile.production.hostJSON,false);
    assert.equal(terminal.compile.test.exit,0);assert.equal(terminal.newTests.length,4);
    assert.deepEqual(terminal.newTests.map(row=>row.exit),[0,0,0,0]);assert.equal(terminal.historicalTestsExecuted,0);
    assert.equal(terminal.resources.activeOwnedCompilerJvmHandles,0);
    assert.equal(terminal.resources.slot,'RELEASED_TO_MAIN_OWNING_SQL_JOIN');directory(managerTerminalProduction);
    const managerCrypto=JSON.parse(exact(managerCryptoRoot+'/RESULT.json','fe18787e6ed7a9fccf032ae812ebe929616694efd2e5a692cff9299e4e7c0592'));
    assert.equal(managerCrypto.status,'NORMAL_COMBINED_SHIPPING_COMPILE_EXIT0_OWNING_WORKFLOW_NOT_RUN');
    assert.equal(managerCrypto.F,'e03394c727123bede5e3a174df588d2faa2be330');
    assert.equal(managerCrypto.source.Engine,'70745bb11682ff5b043166f2d551900bec452c23954c36eceb69833ca8b89d28');
    assert.equal(managerCrypto.compile.production.exit,0);assert.equal(managerCrypto.compile.production.SDKFirst,true);
    assert.equal(managerCrypto.compile.production.fixtureCipher,false);assert.equal(managerCrypto.compile.production.hostJSON,false);
    assert.equal(managerCrypto.compile.test.exit,0);assert.equal(managerCrypto.historicalTestsExecuted,0);
    assert.equal(managerCrypto.resources.activeOwnedCompilerJvmHandles,0);
    assert.equal(managerCrypto.resources.slot,'RELEASED_TO_MAIN_OWNING_SQL_JOIN');directory(managerCryptoProduction);
    const completionTerminal=JSON.parse(exact(completionTerminalRoot+'/RESULT.json','fc4788e52322a5662c38b5ad3db78f1d467b2d398f324b177a4966aab915f732'));
    assert.equal(completionTerminal.status,'NORMAL_COMBINED_SHIPPING_COMPILE_EXIT0_OWNING_SQL_NOT_RUN');
    assert.equal(completionTerminal.engine_sha256,'06a2ea28e7c8f47a572620cbf1dbe25ec9fbf73b79c144d7631c7ae666d31352');
    assert.equal(completionTerminal.compile.terminal,'af113d EXIT0');directory(completionTerminalProduction);
    const packetExport=JSON.parse(exact(packetExportRoot+'/RESULT.json','d225e57e3ce619f05dfeecc0885707700bad2971c733c63a08de75918aab1637'));
    exact(packetExportRoot+'/CLASS_MANIFEST.json','d96f2762ba2a044adebbd1afeebc092a1d9a1ea7e0fea14ef3ca93d2b859d97e');
    exact(packetExportRoot+'/source/NativePrivateCustodyReturnedPieceSetTest.java','7c82291246930e2334f70906f77e6894842c8ff1545d88b2b284dec99028c07d');
    assert.equal(packetExport.status,'CHANGED_PACKET_EXPORT_CALLER_NORMAL_COMPILE_EXIT0_RUNTIME_NOT_RUN');
    assert.equal(packetExport.scope.only_packet_export_block_changed,true);assert.equal(packetExport.scope.exact_inverse_old_block_reconstruction,true);
    assert.equal(packetExport.compile.terminal.exit_code,0);assert.equal(packetExport.inputs_unchanged,115);
    assert.equal(packetExport.cleanup.owned_processes,0);assert.equal(packetExport.cleanup.slot,'RELEASED_TO_MAIN');directory(packetExportProduction);
    const ordered=JSON.parse(exact(runtimeOrderedRoot+'/COMPILE_RESULT.json','e57938837143e8c07a150f3a76c8f415d4008ebf21c3675d7583d037160c2bc4'));
    exact(runtimeOrderedRoot+'/CLASS_MANIFEST.json','21afc3c76da670a82a212500133c51173cbb9ce46a8937afb53e573b361d0969');
    exact(runtimeOrderedRoot+'/INPUTS.json','84a1d7484787d6dab27132cb6b73fc1f44e233d80fdfd69b2273e4df91bf991c');
    exact(runtimeOrderedRoot+'/source/NativePrivateCustodyReturnedPieceSetTest.java','3281f62ab5ecec481b5fd881fd4f67f0b03a4a23fde0087a03ed808da00f2608');
    assert.equal(ordered.status,'SOURCE_COMPILE_PASS_RUNTIME_NOT_RUN');assert.equal(ordered.compile.exit_code,0);
    assert.equal(ordered.inputs.count,116);assert.equal(ordered.inputs.unchanged,true);
    assert.equal(ordered.resources.owned_processes,0);assert.equal(ordered.resources.slot,'RELEASED_TO_MAIN');directory(runtimeOrderedProduction);
    const actionStart=JSON.parse(exact(actionStartRoot+'/qualification/COMPILE_RECEIPT.json','14f02bc5ffce805da1bad41f784ef4a87bb49de0d321c7d6d81ecb49605baab2'));
    assert.equal(actionStart.source.sha256,'15e05780c70d3a079474f94e5dfa2945ca6dc67f4358f9935f6d3c6b75d68409');
    assert.equal(actionStart.compile.terminal,'066eff EXIT0');assert.equal(actionStart.recovery.recompiled,false);directory(actionStartProduction);
    const coldHeld=JSON.parse(exact(coldHeldRoot+'/RESULT.json','73c7242a3afd4c7dc435dadda2b3fa02f6af077ffe4bd25d8cdec26473131773'));
    assert.equal(coldHeld.status,'NORMAL_THREE_CHANGED_SHIPPING_SOURCES_COMPILE_EXIT0_RUNTIME_NOT_RUN');
    assert.equal(coldHeld.compile.terminal,'ccf384 EXIT0');assert.equal(coldHeld.compile.normal_SDK36_first,true);
    for(const [name,digest]of Object.entries(coldHeld.sources))assert.equal(name==='VaultEngine.java'?'7367ef52f6dbdacd966e49fb39939d7e41bdb4085639eb9b434f5d40bfde1656':name==='CustodialNativeRuntime.java'?'f4fd28a11a0e53c92c47d14879b68817849efa57ccacd038bceb8ef66c2dfb39':currentSources[name],digest);
    const warmHeld=JSON.parse(exact(warmHeldRoot+'/RESULT.json','dcb3aeb3a0da8bf5b65f0e30cd2123b7e44fe0eab6182b07b0c34403b54df286'));
    assert.equal(warmHeld.sources['CustodialNativeRuntime.java'],currentSources['CustodialNativeRuntime.java']);
    assert.equal(warmHeld.compile.terminal,'4d5fc9 EXIT0');assert.equal(warmHeld.compile.normal_SDK36_first,true);directory(warmHeldProduction);
    directory(coldHeldProduction);
    const resultCause=JSON.parse(exact(resultCauseRoot+'/RESULT.json','e1028930c4ca7b0d5027729b39c5d9f68b8d88c52b95acd82fa8d05f0a23a987'));
    assert.equal(resultCause.status,'NORMAL_ONE_CHANGED_ENGINE_SOURCE_COMPILE_EXIT0_RUNTIME_NOT_RUN');
    assert.equal(resultCause.Engine,'a93c683235f1f489c8cc972d2b238232bd54bcda2350f8bc42faf6ea30da9eb5');assert.equal(resultCause.compile.terminal,'f129d9 EXIT0');directory(resultCauseProduction);
    const managerShared=JSON.parse(exact(managerSharedRoot+'/RESULT.json','7996c3705886adb58e4134b8a8d67b59b9fdbeae6a758b557074e8a73ca37d69'));
    assert.equal(managerShared.Engine,'6ac0096851cc0fe0277d040e48ecd3d93e6f3046a5369f689daee182534975e5');assert.equal(managerShared.compile.terminal,'a33df0 EXIT0');
    assert.equal(managerShared.compile.normal_SDK36_first,true);directory(managerSharedProduction);
    const detachedPlan=JSON.parse(exact(detachedPlanRoot+'/RESULT.json','e7f3efb730833878b905644c888b6436bc1e4746735e54bce9d2bfc063243671'));
    assert.equal(detachedPlan.Engine,'058dcc6ea6f56bfa1d86633710f1c445b04b1f05b8a65812cd66c95c29c1553e');assert.equal(detachedPlan.compile.terminal,'a3a6e2 EXIT0');directory(detachedPlanProduction);
    const heldSourceBatch=JSON.parse(exact(heldSourceBatchRoot+'/RESULT.json','d740bec91d2cc5d9428d65d70b39baf939b18d615fa6a0eb02e7009291c003e3'));
    assert.equal(heldSourceBatch.Engine,'ec2c5cfde95363c1a3095fdf5f0b45fa6cb1f48b97bb7f2f3ee42664463f116e');assert.equal(heldSourceBatch.compile.terminal,'6c3fc0 EXIT0');
    assert.equal(heldSourceBatch.compile.normal_SDK36_first,true);directory(heldSourceBatchProduction);
    const heldCtor=JSON.parse(exact(heldCtorRoot+'/RESULT.json','dde6b3e70d0fcf834a0bcf761a2174471a7ed8bcbbbacde4b2473629cd5b1b63'));
    assert.equal(heldCtor.Engine,'ecf1960b2695d1d4aa48297808a5a08d65db00ddbd586770dc6192b84fe1bc5f');assert.equal(heldCtor.compile.terminal,'ee09a7 EXIT0');
    assert.equal(heldCtor.compile.normal_SDK36_first,true);directory(heldCtorProduction);
    const browserBatch=JSON.parse(exact(browserBatchRoot+'/RESULT.json','b4f417716c6d5210f6f1fdeeeffede9a318d95c3f6d3901ef75bb12a58015249'));
    assert.equal(browserBatch.Engine,'fc5c75c65451a3121ff625ddfad44192209b147ed155f0752087a094e5408a38');assert.equal(browserBatch.compile.terminal,'52c31d EXIT0');
    assert.equal(browserBatch.compile.normal_SDK36_first,true);directory(browserBatchProduction);
    const presence=JSON.parse(exact(presenceRoot+'/RESULT.json','2213607e667e5aa1179a4ba8ff54fb020531561539846d4dc8c4fa531528c7b4'));
    assert.equal(presence.inputs_before_corrected_compile.sources[0].sha256,'85d2271985a04707bc3312919470450fe24c96626fdee7390cc826c999c2ddad');
    assert.equal(presence.production_compile.terminal.exit_code,0);assert.equal(presence.production_compile.sdk36_first_normal59,true);
    assert.equal(presence.baseline.process.exit_code,1);assert.equal(presence.baseline.candidate_absent,true);
    assert.equal(presence.fixed_cases.length,2);for(const result of presence.fixed_cases)assert.equal(result.process.exit_code,0);
    assert.equal(presence.source_jars_args_and_all_borrowed_parent_pins_unchanged,true);
    assert.equal(presence.owned_compiler_or_jvm_processes.length,0);directory(presenceProduction);
    const sealedQuery=JSON.parse(exact(sealedQueryRoot+'/RESULT.json','0a7f4814bafa86ffcb25f1a94b9ca06d6143e9cdc37c4e0ef1d83e7060e3fe16'));
    assert.equal(sealedQuery.input_pins_before_corrected_compile.sources[0].sha256,'4d27ceac9656ee4d71af4cde5b7f08f55cbce6269b23184260ef8539faa999a5');
    assert.equal(sealedQuery.production_compile.terminal.exit_code,0);assert.equal(sealedQuery.production_compile.normal_sdk36_first,true);
    assert.equal(sealedQuery.corrected_test_compile.terminal.exit_code,0);assert.equal(sealedQuery.new_selected_member.terminal.exit_code,0);
    assert.equal(sealedQuery.corrected_source_args_and_all_normal_file_and_borrowed_tree_pins_unchanged,true);
    assert.equal(sealedQuery.owned_compiler_or_jvm_processes.length,0);directory(sealedQueryProduction);
    const sealedPrepared=JSON.parse(exact(sealedPreparedRoot+'/RESULT.json','80a66dce1280663377562b816a26306262bf5f20742c28c0eca171a2499d431b'));
    assert.equal(sealedPrepared.source_sha256.VaultEngine,'3b8a94d4e56c1fb343652c37f8bc702f1cec01276ff7146949df3fa6578b43e2');
    assert.equal(sealedPrepared.source_tree,'354ee8a973165c775252a8583a32df57cee3045f');
    assert.equal(sealedPrepared.production_compile.terminal.exit_code,0);
    assert.equal(sealedPrepared.test_compile.terminal.exit_code,0);assert.equal(sealedPrepared.selected_run.terminal.exit_code,0);
    assert.equal(sealedPrepared.selected_member,'PREPARED_BATCH_midCryptoOriginalRequestReplacementRevokesSameOwner');
    assert.equal(sealedPrepared.selected_run.observed.owned_processes.length,0);
    directory(sealedPreparedProduction);
    const savedBrowserManager=JSON.parse(exact(savedBrowserManagerRoot+'/RESULT.json','7b77fc5712fa07a7c6a9e629530914685e2790082abb9127bddf6898c50da98f'));
    assert.equal(savedBrowserManager.source_sha256,'8b5def49930274cc95c4a73c78e6be37edece516a2b5469a5a9ff94fb144233f');
    assert.equal(savedBrowserManager.source_tree,'ed9400706cf895d0c2074315b6f59ed3dd2401c9');
    assert.equal(savedBrowserManager.production_compile.terminal.exit_code,0);
    assert.equal(savedBrowserManager.final_pins_exactly_equal_initial,true);assert.equal(savedBrowserManager.owned_processes.length,0);
    directory(savedBrowserManagerProduction);
    const currentQueryRestoration=JSON.parse(exact(currentQueryRestorationRoot+'/RESULT.json','3f06df7ecf4923f2ab592ca5fad5715e93eb1aa364409b2038086df6519a7450'));
    assert.equal(currentQueryRestoration.engine_sha256,'472e6dc15370b63c5644463c5071e07bdca31c069e3b9f9b9a19ee183a840a9e');
    assert.equal(currentQueryRestoration.test_loan.sha256,'e0567bf6fd8f20d1fd03f379b88c00f90f1db766a5a3e410e1bb569c3bebe56e');
    // The historical test loan was Main's exact e056 source. Main now has a
    // new member; preserve the old proof against its byte-identical frozen
    // checkout, not the mutable loan path and not today's different test.
    exact(path.resolve(savedStatusCurrentRoot,'../frontend/mobile/plugins/custodial-native-vault/android/src/test/java/org/memphiszoo/custodial/vault/NativePrivateCustodyReturnedPieceSetTest.java'),currentQueryRestoration.test_loan.sha256);
    assert.equal(currentQueryRestoration.production_compile.terminal.exit_code,0);
    assert.equal(currentQueryRestoration.test_compile.terminal.exit_code,0);assert.equal(currentQueryRestoration.selected_run.terminal.exit_code,0);
    assert.equal(currentQueryRestoration.selected_member,'QUERY_RESTORE_lockedSourceIOEqualByteReplacementRefuses');
    assert.equal(currentQueryRestoration.final_pins_exactly_equal_initial,true);assert.equal(currentQueryRestoration.owned_processes.length,0);
    directory(currentQueryRestorationProduction);
    const savedStatusCurrent=JSON.parse(exact(savedStatusCurrentRoot+'/RESULT.json','f3e25558893e2b5aeffa172fa697647ae1b52d58348afdd6e7ed75272949e2f4'));
    assert.equal(savedStatusCurrent.engine_sha256,'76e39d116f875a4c5bdc0161cb45c08bfc0f361d0f1c369c4c499beb9084637a');
    assert.equal(savedStatusCurrent.source_tree,'ad10f00dabbcc769c713bac01b35368d1826f1b7');
    assert.equal(savedStatusCurrent.production_compile.terminal.exit_code,0);
    assert.equal(savedStatusCurrent.final_pins_exactly_equal_initial,true);assert.equal(savedStatusCurrent.owned_processes.length,0);
    directory(savedStatusCurrentProduction);
    const currentQueryDispatch=JSON.parse(exact(currentQueryDispatchRoot+'/RESULT.json','1cf12f8135a1eebe3cf36c331566922ab7fe320b0e0d1bf368fa43247c9a6f25'));
    assert.equal(currentQueryDispatch.engine_sha256,'d9a66734ff3e24049152b9ebbbea05d1dd83706dab9065efb9919715bd77dd36');
    assert.equal(currentQueryDispatch.source_tree,'58b0681e1bd5f39762af0785260c8348c790bfa9');
    assert.equal(currentQueryDispatch.test_loan.sha256,'ad75138ab48cbf4be2d0fe6aa0c606e7bfe004c9dac370fef924583c57c8541d');
    exact(currentQueryDispatch.test_loan.path,currentQueryDispatch.test_loan.sha256);
    assert.equal(currentQueryDispatch.production_compile.terminal.exit_code,0);
    assert.equal(currentQueryDispatch.test_compile.terminal.exit_code,0);assert.equal(currentQueryDispatch.selected_run.terminal.exit_code,0);
    assert.equal(currentQueryDispatch.selected_member,'CURRENT_QUERY_lockedUnknownReplacementCannotRevive');
    assert.equal(currentQueryDispatch.final_pins_exactly_equal_initial,true);assert.equal(currentQueryDispatch.owned_processes.length,0);
    directory(historicalCurrentQueryDispatchProduction);
    const terminalBrowserReturn=JSON.parse(exact(terminalBrowserReturnRoot+'/RESULT.json','b51db6df39797aee71c7fdc2130189395282826db9501c8827c0f5d5e991c557'));
    exact(terminalBrowserReturnRoot+'/CLASS_MANIFEST.json','5a7783604ec893b8a71bba1bd2a12b5125099df56b3405fddb127659798034cc');
    assert.equal(terminalBrowserReturn.engine_sha256,currentSources['VaultEngine.java']);
    assert.equal(terminalBrowserReturn.source_tree,'3467d8d6169f0cfd1d99a6bb7cb7948cf87b0ebc');
    assert.equal(terminalBrowserReturn.production_compile.terminal.exit_code,0);
    assert.equal(terminalBrowserReturn.pin_commands.unchanged,true);assert.equal(terminalBrowserReturn.owned_compiler_processes.length,0);
    directory(currentQueryDispatchProduction);
    const capsulePresence=JSON.parse(exact(capsulePresenceRoot+'/RESULT.json','0cf35733c586adbc97c54d049712adb4e25713a7c34e1b7dc216a8ee66b536f9'));
    assert.equal(capsulePresence.candidate.product_source_sha256,currentSources['NativePrivateCapsuleFileStore.java']);
    for(const result of capsulePresence.compiles)assert.equal(result.terminal.exit_code,0);
    assert.equal(capsulePresence.old_helper_case.process.exit_code,1);assert.equal(capsulePresence.old_helper_case.candidate_production_absent,true);
    assert.equal(capsulePresence.fixed_cases.length,2);for(const result of capsulePresence.fixed_cases)assert.equal(result.process.exit_code,0);
    assert.equal(capsulePresence.inputs.all_identical,true);assert.equal(capsulePresence.resources.owned_processes,0);
    directory(capsulePresenceProduction);
    const epochHoldEntry=JSON.parse(exact(epochHoldEntryRoot+'/RESULT.json','a95ac6ac49e10df35cea4e761d2790daa14bb3079d23f42b63ded649588d7740'));
    assert.equal(epochHoldEntry.compile.terminal,'679f0a EXIT0');assert.equal(epochHoldEntry.compile.normal_SDK36_first,true);
    for(const [name,digest]of Object.entries(epochHoldEntry.sources))assert.equal(digest,name==='NativePrivateMutationEpochStore.java'?'ac2870e5dc76762b02b12b86da5ac8543b70f293c5b2710badbcb1d04dc3abee':currentSources[name]);directory(epochHoldEntryProduction);
    const epochAbsence=JSON.parse(exact(epochAbsenceRoot+'/RESULT.json','6d7407efa0dba5ee134a225875a30220b2645ba9d2e64b7151a3b82ce94be598'));
    assert.equal(epochAbsence.compile.terminal,'24b248 EXIT0');assert.equal(epochAbsence.compile.normal_SDK36_first,true);
    assert.equal(epochAbsence.sources['NativePrivateMutationEpochStore.java'],'b3c143a77924fb6b7c255a73fa8531f53487646a288d81c5488574883ed16e12');directory(epochAbsenceProduction);
    const epochAbsenceCases=JSON.parse(exact('/home/eric/Documents/Codex/2026-10-09/task-7/native-epoch-bootstrap-absence-affected-20261015-v1/RESULT.json','9db5d5ab95197c633b91806caa2457d0ead41c52b37075366e504a5b19e4f0df'));
    assert.equal(epochAbsenceCases.production.source_sha256,'b3c143a77924fb6b7c255a73fa8531f53487646a288d81c5488574883ed16e12');
    assert.equal(epochAbsenceCases.methods.length,3);for(const result of epochAbsenceCases.methods)assert.equal(result.exit_code,0);
    assert.equal(epochAbsenceCases.existing_held_child.result.exit_code,0);assert.equal(epochAbsenceCases.verification.all_identical,true);
    assert.equal(epochAbsenceCases.resources.owned_processes,0);
    const epochBaseBatch=JSON.parse(exact(epochBaseBatchRoot+'/RESULT.json','7c8a2dec130289a9a818f5ad5f6ae0912d6497d34326e3d69b118670c346a5e4'));
    assert.equal(epochBaseBatch.candidate.sha256,currentSources['NativePrivateMutationEpochStore.java']);
    assert.equal(epochBaseBatch.compile.terminal.exit_code,0);assert.equal(epochBaseBatch.compile.SDK36_first,true);
    assert.equal(epochBaseBatch.tests.members.length,3);for(const result of epochBaseBatch.tests.members)assert.equal(result.terminal.exit_code,0);
    assert.equal(epochBaseBatch.existing_held_read.terminal.exit_code,0);assert.equal(epochBaseBatch.inputs.all_identical,true);
    assert.equal(epochBaseBatch.resources.owned_processes,0);directory(epochBaseBatchProduction);
    exact(privateValuesRoot+'/qualification/COMPILE_RECEIPT.json','547d43daa71c21ccd1506653729ebc96dcbe7632fe84a0ff9fd9d0cf4a42a8bb');
    directory(privateValuesProduction);
    const hashCases=JSON.parse(exact('/home/eric/Documents/Codex/2026-10-09/task-7/private-values-duplicate-hash-affected-20261015-v1/RESULT.json','738ea8d09ac9d9a6c8e32660f883758b27f0a6948f54f7251b910799ed51002e'));
    assert.equal(hashCases.status,'FOUR_NEW_AFFECTED_MEMBERS_PASS_SYNTHETIC_ONLY');
    assert.equal(hashCases.product.values_sha256,currentSources['NativeRetainedNamespaceValues.java']);
    assert.equal(hashCases.product.capsule_sha256,currentSources['NativeRetainedNamespacePrivateCapsule.java']);
    assert.equal(hashCases.compile.exit_code,0);assert.equal(hashCases.runs.length,4);
    assert.deepEqual(hashCases.runs.map(row=>row.exit_code),[0,0,0,0]);assert.equal(hashCases.inputs.unchanged,true);
    assert.equal(hashCases.resources.owned_processes,0);
    const cause=JSON.parse(exact(retainedCauseRoot+'/COMPILE_RESULT.json','8143d502b6d0aaae1f6fd3cac1523e115d132c16001cac4477d28d2634f1d1f5'));
    exact(retainedCauseRoot+'/CLASS_MANIFEST.json','fbc47dbb5501828f53a95da6ef0d11965faf38be502da6a56fabfb0977b979a7');
    exact(retainedCauseRoot+'/INPUTS.json','b0c4d643e736758629b535602646641df6e436dab1a99c55967415e527cef268');
    exact(retainedCauseRoot+'/source/NativePrivateCustodyReturnedPieceSetTest.java','a2b8aab85709b8c0ed301b6347b53d850a8ee6162ebe03f8301712517a473be2');
    assert.equal(cause.status,'CALLER_SOURCE_COMPILE_PASS_RUNTIME_NOT_RUN');assert.equal(cause.compile.exit_code,0);
    assert.equal(cause.inputs.count,124);assert.equal(cause.inputs.unchanged,true);assert.equal(cause.resources.owned_processes,0);
    assert.equal(cause.resources.slot,'RELEASED_TO_MAIN');directory(historicalRetainedCauseProduction);
    const responseExport=JSON.parse(exact(responseExportRoot+'/COMPILE_RESULT.json','2db3ad9c72e9e07bd4726fa65549039b8e965dae6ea5f5eb4844c16eabdce16e'));
    exact(responseExportRoot+'/CLASS_MANIFEST.json','dd5067fdd9f1311c3cb7c73bc794408aaade1d616bf89be0ed5ca50a4461c52c');
    exact(responseExportRoot+'/source/NativePrivateCustodyReturnedPieceSetTest.java','ca5795e51f8a4124782066da57a7c82b46b95a25360b1f832acff5ce15bafe37');
    exact(responseExportRoot+'/CALLER_COMPILE.args','4dc26863827aa479f4255c5fb182801749810aac3842315f1d3a22eebb0644b6');
    assert.equal(responseExport.status,'CALLER_SOURCE_COMPILE_PASS_RUNTIME_NOT_RUN');
    assert.equal(responseExport.compile.terminal.exit_code,0);directory(retainedCauseProduction);
    const coreUid=JSON.parse(exact('/home/eric/Documents/Codex/2026-10-09/task-9/native-epoch-fresh-uid-owner-product-20261015-v1/RESULT_VM_CORE.json','e63a66cfcd1b2a0189ba34f3db4b76bcec6b592928dc9bc29c9e41656c4b99c2'));
    assert.equal(coreUid.currentCompile.productionTerminal.exit_code,0);assert.equal(coreUid.currentCompile.testTerminal.exit_code,0);
    assert.equal(coreUid.currentNewMember.terminal.exit_code,0);assert.equal(coreUid.borrowedAndSourceUnchanged,true);
    assert.equal(coreUid.historicalTestsExecuted,0);assert.equal(coreUid.resources.activeOwnedCompilerJvmHandles,0);
    assert.equal(coreUid.resources.slot,'RELEASED_TO_MAIN');directory(coreUidProduction);
    exact('/home/eric/Documents/Codex/2026-09-13/i-x20/work/autonomous-repair-20260923/overnight-readiness-20261006/lean-held-correction-integration-20261011/native-plan-entry-owner-5YJ9Ut/RESULT.json','6ea546f7dca4d2056a67311396f82bb5530ea37906c82795928047a7657d6ec2');
    exact('/home/eric/Documents/Codex/2026-10-09/task-9/fixed-family-namespace-read-boundary-product-20261015-v1/RESULT.json','d64075c654ffa24ef0a993bf95d81868129d29c7aecdffe9fb02cb16368fa486');
    directory(planEntryProduction);directory(fixedFamilyProduction);
    directory(combinedReadProduction);directory(liveBaselineProduction);
    const fullCompile=JSON.parse(exact(fullShippingRoot+'/CORRECTED_COMPILE_RESULT.json','409305a87aa0f8ee92aff6cb53b8086f9696d4cb535d1694d7806dff86fcd703'));
    exact(fullShippingRoot+'/CLASS_MANIFEST.json','b623d8fe7140ba28616e0f6ee3110e6d06dac4be5ef6b285d6704a24860358e3');
    assert.equal(fullCompile.status,'CORRECTED_NORMAL_FULL_159_SHIPPING_SOURCE_COMPILE_EXIT0');
    assert.equal(fullCompile.F,'0987926f83612714663ebfa6eda35d71e94096f7');
    assert.equal(fullCompile.source_count,159);assert.equal(fullCompile.ordinary_dependency_jars,59);
    assert.equal(fullCompile.resources.active_owned,0);assert.equal(fullCompile.resources.slot,'RELEASED_TO_MAIN');directory(fullShipping);
    // The159-source compile is retained at F098; only the explicitly changed
    // Engine private projection leaf supersedes its58 classes below. This is
    // not a blanket rebind/replay or a new whole-module runtime claim.
    const linear=JSON.parse(exact(linearProofRoot+'/RESULT.json','e552b4a3b32de690d7d39f560b12489561dffd20f7623ae9027afdae954e5c0d'));
    exact(linearProofRoot+'/CLASS_MANIFEST.json','ec21845aac20764fb47a1acc2ee4301caf4046794405c2c762f7df6aef1e1c78');
    assert.equal(linear.status,'NARROW_ENGINE_PROJECTION_SOURCE_COMPILED_THREE_AFFECTED_REFUSAL_MEMBERS_EXIT0');
    assert.equal(linear.resources.active_owned,0);assert.equal(linear.resources.slot,'RELEASED_TO_MAIN');directory(linearProofProduction);
    const stampResult=JSON.parse(exact(stampRoot+'/RESULT.json','61d6eb32d3b3cc043df20f712593919ccf59c37a8d1959b79bfff80d079c8efc'));
    assert.equal(stampResult.compiles.productionSDKFirst.terminal.exit_code,0);
    assert.equal(stampResult.compiles.changedTestHostJSONFirst.terminal.exit_code,0);
    assert.deepEqual(stampResult.runs.map(row=>row.terminal.exit_code),[0,0,0]);
    assert.equal(stampResult.old_groups_replayed,0);assert.equal(stampResult.resources.active_owned,0);
    assert.equal(stampResult.resources.heavy_slot,'RELEASED_TO_MAIN');
    assert.equal(stampClasses.production.path,stampRoot+'/qualification/production');
    assert.equal(stampClasses.production.class_count,7);assert.equal(stampClasses.production.classes_sha256,'7f8c994bd26fa79d1d0dfe476b0ae47e62f85a801c95202e1d23f94e6ffff7d3');
    directory(stampClasses.production);directory(holdCurrent);directory(attributeProduction);directory(currentReadProduction);directory(heldPreferences);directory(heldActivity);
    const attributeRoot='/home/eric/Documents/Codex/2026-10-09/task-7/native-epoch-attribute-read-product-20261015-v1';
    const attributeResult=JSON.parse(exact(attributeRoot+'/RESULT.json','f3e0d23ecfcfb4da109b24e4bd2c5bac07b5f55ed9e4c2c64f4f11b06f20af2a'));
    exact(attributeRoot+'/CLASS_MANIFEST.json','b340fda8ee6d07ec2ec9345b1381b62136ec26d1e5e3bde403680405daa2ba2d');
    assert.equal(attributeResult.compile.production,'82be24/session55282 -> 001408 EXIT0; SDK first; no diagnostics');
    assert.equal(attributeResult.compile.test,'ce878e/session84834 -> 8595f7 EXIT0; host JSON first; no diagnostics');
    assert.deepEqual(attributeResult.runs.map(row=>row.exit_code),[0,0,0]);
    assert.equal(attributeResult.resources.old_groups_replayed,0);
    assert.equal(attributeResult.borrowed,'103 before/after pins identical at terminal BEFORE Main integration; current79 tuplee266 and fixedOwner7 included. Existing cb927 fixture runtime ONLY, never javac.');
    assert.equal(attributeResult.resources.active,0);assert.equal(attributeResult.resources.slot,'RELEASED_TO_MAIN');
    exact(fullReconstructionRoot+'/COMPILE_RESULT.json','325e78f108c25f5f70110bdc459bfe9595f6f9ab0683bad72f1b2588d68437d3');
    assert.equal(holdFresh.compile.exitCode,0);assert.equal(holdFresh.historicalGroupsRun,0);
    assert.equal(holdFresh.borrowedBeforeAndAfter.count,105);
    assert.equal(holdFresh.borrowedBeforeAndAfter.exactMatchWithPrior105,true);
    assert.equal(holdFresh.borrowedBeforeAndAfter.sourceAndArgsAlsoUnchanged,true);
    assert.equal(holdFresh.newEngineE2e0,'NOT_BORROWED_OR_QUALIFIED');
    exact(fullReconstructionRoot+'/../COMPILE_RESULT.json','9a635f5e91c62ec0795fd3983ac08537671e8d700f81105e9dfd9d69e037d3f1');
    exact(holdFresh.compileArgs.path,'ec9605e103011f42650de63e6240e0d8174359e8bbcc9b20645c512eeac2f943',16328);
    assert.equal(holdFresh.source.path,fullReconstructionRoot+'/source/NativePrivateCustodyReturnedPieceSetTest.java');
    exact(holdFresh.source.path,'47a4bf5f4e8960f26965af70fc4c8bd32c8a0ac972d2d69f1143a58635f6b6ef',403471);
    assert.equal(holdFresh.resources,0);assert.equal(holdFresh.slot,'RELEASED_TO_MAIN');
    assert.equal(holdFresh.JVM,'NOT_RUN');assert.equal(holdFresh.SQL,'NOT_RUN');
    assert.equal(holdFresh.output.path,fullReconstructionRoot+'/qualification');
    assert.equal(holdFresh.output.count,14);assert.equal(holdFresh.output.tree,'fba139c5e4f03d59aed21d10c446a4d9adbcdd62650bffce668b72557c300ada');
    directory({...holdFresh.output,class_count:holdFresh.output.count,class_tree_sha256:holdFresh.output.tree});
    exact(holdRoot+'/HELD_PROMOTION_HANDOFF.json','a0fb34c16d9e9a15fdeb2829c434c0f3e4aacf7c447ecfd0de97a419d8e0f2d7');
    assert.equal(holdReceipt.correctedCompile.terminal.exit_code,0);assert.equal(holdReceipt.loan.unchanged,true);
    assert.equal(holdReceipt.resources.slot,'RELEASED');assert.equal(holdReceipt.noOldTestsExecuted,true);
    assert.equal(holdReceipt.source.path,holdRoot+'/source-held/NativePrivateCustodyReturnedPieceSetTest.java');
    assert.equal(holdReceipt.source.candidate_sha256,'7ca143630070fc1c9571870e9b668d027ba858f5cead0e5ec877c2395d7c86c6');
    exact(holdReceipt.source.path,holdReceipt.source.candidate_sha256);
    assert.equal(holdReceipt.correctedCompile.output.path,holdRoot+'/qualification-held-fixed-local-name');
    assert.equal(holdReceipt.correctedCompile.output.class_count,13);
    assert.equal(holdReceipt.correctedCompile.output.class_tree_sha256,'18493c6bd07dfed8d6ef0e760c4d97be701e9ccb55a78d7840cd9df792a738be');
    directory(holdReceipt.correctedCompile.output);directory(holdEngine);directory(holdShipping);
    exact(holdReceipt.correctedCompile.output.path+'/org/memphiszoo/custodial/vault/NativePrivateCustodyReturnedPieceSetTest.class','57d7508b5c7e27bc73f4394cebc293f17d5f4c9668b1ce8c8bc2ca99c0879710');
   }
   for(const [name,digest]of Object.entries(currentSources))
    exact(native+name,writerHold&&Object.hasOwn(joinedHeldSources,name)?joinedHeldSources[name]:digest);
   if(writerHold){
    const operationJoin=JSON.parse(exact(operationJoinRoot+'/RESULT.json','e45467246ff764d0170695fe645e7b8837b69dec54342bb017e113262533f64b'));
    assert.equal(operationJoin.status,'CHANGED_TEST_COMPILE_PASS_RUNTIME_NOT_RUN');
    assert.equal(operationJoin.compile.exit_code,0);assert.equal(operationJoin.pins_before_after_unchanged,125);
    assert.equal(operationJoin.resources.owned_runtime_processes,0);
    exact(operationJoinRoot+'/source/NativePrivateCustodyReturnedPieceSetTest.java','fafb58bb6b59a2190c5b17e1d9a95e57dd8939cb51e7fe24fd6bf0c387734c87');
    exact(operationJoinRoot+'/CLASS_MANIFEST.json','4444485ae023bb06761e26ba50680fe563b5ce50c35f54f6dc559c686a86980f');
    exact(operationJoinRoot+'/CALLER_COMPILE.args','2d1cccbf2856b629e1b2f1410774df566272aeb018d1bc70c44cb0a3547932fb');
    exact(operationJoinRoot+'/INPUTS.json','3bf7a13ae39b96d3a900b79f61b8e43d4042f74d11dace7830176c102f2f84c3');
    exact(currentEngineRoot+'/CLASS_MANIFEST.json','4f95e2094a4762836157400d352136a26b48686105f4986f2d422e07131cb5d3');
    exact(currentEngineRoot+'/source/VaultEngine.java',joinedHeldSources['VaultEngine.java']);
    exact(operationRoot+'/CLASS_MANIFEST.json','124bc2a9032a69c67d5203c9ce3c9d79e266897d9ed888e44fa2c7986b51c6f4');
    exact(operationRoot+'/source/NativePrivateCustodyOperationStore.java',joinedHeldSources['NativePrivateCustodyOperationStore.java']);
    exact(path.resolve(own,'../native-queued-command-lifetime-20261016-MgwatB/RESULT.json'),'6b5229bdc022bbd247dc7ea8e6a42cc2db3ec9a2350475fabe53011d8287b0e3');
    exact(path.resolve(own,'../native-existing-held-browser-source-20261016-xTiKUO/RESULT.json'),'285ce90f58293e6b0f239a27362cba7fd08adbf17ee7cd636c01548ccb38c1be');
    directory(operationJoinProduction);directory(currentEngineProduction);directory(operationProduction);
    directory(currentBrowserProduction);directory(currentWireProduction);
    for(const [name,digest]of Object.entries(joinedHeldSources))exact(native+name,digest);
    exact(joinedHeldRoot+'/CLASS_MANIFEST.json','139f2869f46f29de34f51c5e1c7eda57cbcd693d1137efc00cb07871262be08e');
    directory(joinedHeldProduction);directory(liveBrowserProduction);
    exact(joinedHeldRoot+'/source/NativePrivateCustodyReturnedPieceSetTest.java','afe8813396cd5af893e0685ebaca6e1a9d5105c92b179d6a61979962d1333a24');
    exact(joinedHeldRoot+'/CALLER_COMPILE.args','fc6e02e8e52315af2bd24f5610f6771d2c98825de706ab50a494d777830ea8e0');
    exact(joinedHeldRoot+'/CALLER_CLASS_MANIFEST.json','8b89a7832b10149c179dee979da7da701f20bbe9e4088e4a88f84ae2af4d16e7');
    directory({path:joinedHeldRoot+'/caller',dev:2082,ino:58647204,class_count:14,
     class_tree_sha256:'241a0aab4448fc383e74e585da80f967f64924e80d19744275e9f21ec9e57aed'});
   }
   assert.equal(compiled.after.output.path,base+'/qualification-action-boundary-58');assert.equal(compiled.after.output.class_count,13);directory(compiled.after.output);
   exact(compiled.after.output.path+'/org/memphiszoo/custodial/vault/NativePrivateCustodyReturnedPieceSetTest.class','04aa4f37f24724c53e64367a514875d938aa561104ec357a6505172a3de3e66a');
   exact(adapter+'/org/memphiszoo/custodial/vault/AndroidKeystoreCipher.class','cb927f74c6b6a960bd911c081fac130ae7e10c0508aacff5ea051c499288a8e3',8399);
   exact(backendRoot+'/scripts/same-original-recovery-local-database-tests.mjs',writerHold?'b77c4906037d68d27ebcd1a26fa79433b4bb5a7dd70f5371ea2067fae03e258c':'cb5da4acb979fe4b2028d5888f4b81cae648b86a2dd2012e18f0de20fbf70d8f');
   assert.equal(before.classpath.includes(adapter),false);
  };
  await verify();
  const cp=before.classpath.split(':'),clock='/home/eric/Documents/Codex/2026-10-09/task-7/browser-saved-manager-flow-20261015-v1/fresh-running-host-before-originals/qualification/classes';
  const browser=own+'/browser-retained-owning-source-b3e2ty/classes',typed=own+'/native-original-records-source-v0O1iG/classes';
  const hostJson=cp.find(p=>p.includes('/org.json/')&&p.endsWith('.jar'));assert.ok(hostJson);
  assert.equal(clockManifest.path,clock);assert.ok(shipping.before.some(r=>r.path===browser));assert.ok(shipping.before.some(r=>r.path===typed));
  return {base,packetBase:'/home/eric/Documents/Codex/2026-10-09/task-7/browser-saved-manager-flow-20261015-v1',java:'/usr/lib/jvm/java-21-openjdk-amd64/bin/java',
   // Host fixture cipher is runtime-only and explicitly precedes the complete
   // shipping module. No synthetic cipher was present in the159-source compile.
   classpath:[...new Set([...(writerHold?[adapter,operationJoinProduction.path,currentEngineProduction.path,operationProduction.path,currentBrowserProduction.path,currentWireProduction.path,joinedHeldRoot+'/caller',joinedHeldProduction.path,liveBrowserProduction.path,epochBaseBatchProduction.path,epochAbsenceProduction.path,epochHoldEntryProduction.path,privateValuesProduction.path,capsulePresenceProduction.path,currentQueryDispatchProduction.path,savedStatusCurrentProduction.path,currentQueryRestorationProduction.path,savedBrowserManagerProduction.path,sealedPreparedProduction.path,sealedQueryProduction.path,presenceProduction.path,browserBatchProduction.path,heldCtorProduction.path,heldSourceBatchProduction.path,detachedPlanProduction.path,managerSharedProduction.path,resultCauseProduction.path,retainedCauseProduction.path,warmHeldProduction.path,coldHeldProduction.path,runtimeOrderedProduction.path,actionStartProduction.path,completionTerminalProduction.path,managerCryptoProduction.path,managerTerminalProduction.path,packetExportProduction.path,coreUidProduction.path,planEntryProduction.path,fixedFamilyProduction.path,combinedReadProduction.path,liveBaselineProduction.path,linearProofProduction.path,fullShipping.path,currentReadProduction.path,heldActivity.path,holdCurrent.path,heldPreferences.path,attributeProduction.path,holdFresh.output.path,stampClasses.production.path,holdShipping.path,holdEngine.path,holdReceipt.correctedCompile.output.path]:[]),writerClasses.path,ancestryAfter.outputs.production.path,fixedRead.output.path,shipping.output.path,browser,typed,clock,compiled.after.output.path,adapter,hostJson,...cp])],
   testClassSha256:writerHold?'8d6444e84b12514bbbe41f6a10ff07aaae455c8bec1794187ca1fc5d1b1fe326':'04aa4f37f24724c53e64367a514875d938aa561104ec357a6505172a3de3e66a',savedBrowser:true,writerHold,verify};
 }
 const base='/home/eric/Documents/Codex/2026-10-09/task-7/native-original-completion-http-20261015-v1/accepted-original-current-context-v1';
 const root=base+'/qualification-census-helper-iDilZz/';
 const digests={'INPUTS.json':'4da7c700dea82a6e20426208a48ff7fa97ce6535f09468176645d33485a5edad',
  'COMPILE_RESULT.json':'a10c3fc4ad81f45e8504bdcec346ac9fb60e3b22e5bc2c689da4625d17d66c4a',
  'CLASS_MANIFEST.json':'2172ce6b676138c91f3b26eb9702b77d86f404b161bc96cea8fe3b40964a54e6',
  'RUN_TEMPLATE.json':'f77a63415d47d1f7ac94065dadc9140c9798e3a1265be4897273d94dd1e6e282'};
 const pinned=(file,digest,size)=>{const s=fs.lstatSync(file);assert.equal(s.isFile(),true);assert.equal(s.isSymbolicLink(),false);
  const b=fs.readFileSync(file);assert.equal(sha(b),digest,file);if(size!==undefined)assert.equal(b.length,size);return b;};
 const read=name=>JSON.parse(pinned(root+name,digests[name]));
 const inputs=read('INPUTS.json'),compiled=read('COMPILE_RESULT.json'),classes=read('CLASS_MANIFEST.json'),runtime=read('RUN_TEMPLATE.json');
 const currentRoot='/home/eric/Documents/Codex/2026-10-09/task-8/accepted-all8-disposition-owning-20261015-v1/qualification/';
 const currentDigests={'INPUTS.json':'0bc20a7c2e629337296496303560074478b0b42b4a06cfe69af35109b4436102',
  'COMPILE_RESULT.json':'127ffc1d1fc23c4f1f880c15e6325e9b89f3ece929bcfa834ef1212e9db521b6',
  'CLASS_MANIFEST.json':'8710710fdf363026bcfe5b12dcc3ba5d6735a5d2597d17d16a7762f9a8ead9a2',
  'RUN_TEMPLATE.json':'5bdfc7595249dac8a4e77389839fbd7233ea6915a58eeb3b10c2e1c50d1a43d4'};
 const readCurrent=name=>JSON.parse(pinned(currentRoot+name,currentDigests[name]));
 const currentInputs=readCurrent('INPUTS.json'),currentCompiled=readCurrent('COMPILE_RESULT.json'),
  currentClasses=readCurrent('CLASS_MANIFEST.json'),currentRuntime=readCurrent('RUN_TEMPLATE.json');
 const activeRoot='/home/eric/Documents/Codex/2026-10-09/task-7/accepted-native-finish-prerequisite-20261015-v1/';
 const activeDigests={'INPUTS.json':'3e438cafdac08f57e02421bd4b5ba815b908433714406610ff996adb54afc380',
  'RESULT.json':'89cfce94e2c238ff499f01dc042d3173b829a9a02ee9d9ce4fb8b2aab8e8a3a3',
  'CLASS_MANIFEST.json':'683efe7ddac51920e09f4b34727342eddd4ddf888db3e5b95d8047f2afd77825'};
 const readActive=name=>JSON.parse(pinned(activeRoot+'qualification/'+name,activeDigests[name]));
 const activeInputs=readActive('INPUTS.json'),activeResult=readActive('RESULT.json'),activeClasses=readActive('CLASS_MANIFEST.json');
 const native=path.dirname(backendRoot)+'/frontend/mobile/plugins/custodial-native-vault/android/src/main/java/org/memphiszoo/custodial/vault/';
 const sourcePins={'VaultEngine.java':'34be6fc79cede0789d257239d8aa7663f204b7dd890b9396a96c43a2542c6ac1',
  'NativeRetainedNamespaceSemanticJoin.java':'427d3b050184499fb896896d66170120f103f4975286e60447ff40a8c2d09baf',
  'NativeOriginalBrowserValueFrame.java':'6dbfc8fc2ee18261e785a432567ccbb4d75be6e88f2c0db554acdbff64ea0365',
  'NativeOriginalBrowserPreparation.java':'67d95626de576526aebd300f8c3009befbb83508ea3f22704cf60838da533fb8',
  'NativeSeparationFreeze.java':'e3bfad23012c8bbfefa277c9cbcdc6cb8fc66f4a2df0ad2e171472b5a8684e5f',
  'AndroidOfflineAuthorityTimeStore.java':'4b1e5ed4c6cae8a535aa4715ee621bca9f0f231b45e348bf1cc3ba7beaf2ea8f',
  'NativeRetainedCompletionCensus.java':'e588437794e01e17ed61cf31b8a3e39429f925d27120607fe423b4d58dfebd0b'};
 const verify=async()=>{
  for(const name of Object.keys(digests))read(name);
  assert.equal(compiled.terminal.exit_code,0);assert.deepEqual(compiled.changed,[]);
  assert.deepEqual(inputs.before,compiled.after);assert.deepEqual(inputs.before.helper_manifest_errors,[]);
  assert.equal(inputs.before.pins.length,96);assert.equal(inputs.host_jce,false);
  // The old 33 classes are a retained helper loan, not the changed owning
  // test or shipping production. Admit the exact new compiled overlays below.
  for(const name of Object.keys(currentDigests))readCurrent(name);
  assert.equal(currentCompiled.terminal.exit_code,0);assert.equal(currentCompiled.HOST_JCE_compile,false);
  assert.equal(currentInputs.HOST_JCE_compile,false);
  assert.equal(currentCompiled.after.borrowed_source_metadata_unchanged,true);
  assert.equal(currentCompiled.after.verified_before_after_pin_count,100);
  assert.equal(currentInputs.before.pins.length,100);
  for(const name of Object.keys(activeDigests))readActive(name);
  pinned(activeRoot+'HANDOFF.json','9690ceeaa1370b6940c44c0c6663e7a54ff47fba76135609873a99db613ea565');
  assert.equal(activeResult.compile_terminal.exit_code,0);assert.equal(activeResult.new_focused_test.exit_code,0);
  assert.deepEqual(activeResult.changed,[]);assert.deepEqual(activeResult.borrow_mismatch,[]);assert.deepEqual(activeInputs.before,activeResult.after);
  assert.equal(activeInputs.before.length,106);assert.equal(activeInputs.HOST_JCE_compile,false);assert.equal(activeInputs.HOST_JCE_runtime,false);
  const changedTestSources={'NativeRetainedOwnerTest.java':['c8ba47c71cf1f68c50c592aeb06a07bdfcbd6e1a3150b7f1337fcc4b79b887be','b9fce6180bc31af055ca9a91de83d75ee4eaef523b892dbdc46a73268d425cd5'],
   'VaultTestDoubles.java':['7f182f9acc856a61bf221fe001f6a4050c0de02e047357da7e164ac87e8592f3','2faf9ce1bc36ce0cf64d12686589b29b3add13174b1b09d77d8c3ed399210c0a']};
  for(const [name,digests]of Object.entries(changedTestSources)){
   pinned(activeRoot+'source/'+name,digests[1]);pinned(native.replace('/src/main/java/','/src/test/java/')+name,digests[1]);
  }
  for(const row of [...inputs.before.pins,...currentInputs.before.pins,...activeInputs.before]){
   const delta=changedTestSources[path.basename(row.path)];
   if(delta&&row.path===native.replace('/src/main/java/','/src/test/java/')+path.basename(row.path)){
    // Retained old test helpers remain historical loans. The two deliberately
    // changed TEST sources resolve only from the new qualified 17-class prefix.
    assert.equal([delta[0],delta[1]].includes(row.sha256),true);pinned(row.path,delta[1]);continue;
   }
   const stat=fs.lstatSync(row.path);assert.equal(stat.isSymbolicLink(),false);
   if(!stat.isDirectory()){pinned(row.path,row.sha256,row.bytes);continue;}
   assert.equal(stat.dev,row.dev);assert.equal(stat.ino,row.ino);
   const rows=[];const walk=dir=>{for(const name of fs.readdirSync(dir).sort()){
    const file=path.join(dir,name),s=fs.lstatSync(file);assert.equal(s.isSymbolicLink(),false);
    if(s.isDirectory())walk(file);else if(name.endsWith('.class'))rows.push([path.relative(row.path,file),s.size,sha(fs.readFileSync(file))]);
   }};walk(row.path);assert.equal(rows.length,row.class_count);assert.equal(sha(JSON.stringify(rows)),row.class_tree_sha256,row.path);
  }
  for(const row of currentInputs.before.metadata)pinned(row.path,row.sha256,row.bytes);
  pinned(currentRoot+'../source/NativePrivateCustodyReturnedPieceSetTest.java','c6f50b316a0b3e9e2b386583708c9624be21eee3bbf1ce8a6d7887cd4187bd3c');
  assert.equal(currentClasses.path,currentRoot+'classes');assert.equal(currentClasses.class_count,13);assert.equal(currentClasses.files.length,13);
  const currentStat=fs.lstatSync(currentClasses.path);assert.equal(currentStat.isSymbolicLink(),false);
  assert.equal(currentStat.dev,currentClasses.dev);assert.equal(currentStat.ino,currentClasses.ino);
  for(const row of currentClasses.files){assert.equal(row.path,path.join(currentClasses.path,row.relative_path));
   const stat=fs.lstatSync(row.path);assert.equal(stat.dev,row.dev);assert.equal(stat.ino,row.ino);pinned(row.path,row.sha256,row.bytes);}
  assert.equal(activeClasses.root,activeRoot+'qualification/classes');assert.equal(activeClasses.count,17);assert.equal(activeClasses.files.length,17);
  const activeStat=fs.lstatSync(activeClasses.root);assert.equal(activeStat.isSymbolicLink(),false);assert.equal(activeStat.dev,activeClasses.dev);assert.equal(activeStat.ino,activeClasses.ino);
  for(const row of activeClasses.files){assert.equal(row.path,path.join(activeClasses.root,row.relative_path));
   const stat=fs.lstatSync(row.path);assert.equal(stat.dev,row.dev);assert.equal(stat.ino,row.ino);pinned(row.path,row.sha256,row.bytes);}
  const productionRoot=path.dirname(backendRoot)+'/native-original-records-source-v0O1iG';
  const production=JSON.parse(pinned(productionRoot+'/RESULT.json','0da5dde6d7ba810d0f744a8cafdb3d40ad4f27203e832d6c2594d7a264f70d26'));
  pinned(productionRoot+'/INPUTS.json','e9ad12521e4baf021e1aaba4a8d1098ca58722b90a0b72094f5c607a97b50ba7');
  assert.equal(production.status,0);assert.equal(production.HOST_JCE,false);assert.equal(production.borrowed_unchanged,true);
  assert.equal(production.output.path,productionRoot+'/classes');assert.equal(production.output.class_count,65);
  assert.deepEqual(currentRuntime.production_overlay,production.output);
  for(const row of production.sources){assert.equal(path.dirname(row.path)+'/',native);assert.equal(sourcePins[path.basename(row.path)],row.sha256);pinned(row.path,row.sha256,row.bytes);}
  for(const [name,digest]of Object.entries(sourcePins))pinned(native+name,digest);
  // Runtime JS fixture only, not a javac input: the actual second START
  // required normal assignment history. The fresh setup now uses its normal
  // expected-owner writer before snapshot, without rewriting Native originals.
  pinned(backendRoot+'/scripts/same-original-recovery-local-database-tests.mjs','8f62a58230ab795b75810b8bc43f8d94f9eb75d5e8f9a5444174148b1e55d6e8');
  pinned(base+'/source/NativePrivateCustodyReturnedPieceSetTest.java','28efdaab0493ec5631a4bae2f20332f3618cfad53bc0369ad8268d4803a4d18c');
  pinned(base+'/source/NativeRetainedNamespaceCompletionJoinTest.java','706c9e044d33bba5c58be0d637ff4b5c49a02d4068aceff4fee1e411ca5dd2ab');
  const s=fs.lstatSync(classes.root);assert.equal(s.isSymbolicLink(),false);assert.equal(s.dev,classes.dev);assert.equal(s.ino,classes.ino);
  assert.equal(classes.root,root+'classes');assert.equal(classes.count,33);assert.equal(classes.files.length,33);
  for(const row of classes.files){assert.equal(row.path,path.join(classes.root,row.relative_path));const s=fs.lstatSync(row.path);
   assert.equal(s.dev,row.dev);assert.equal(s.ino,row.ino);pinned(row.path,row.sha256,row.bytes);}
  const adapter=runtime.runtime_adapter;
  assert.equal(adapter.scope,'EXPECTED_EXISTING_SYNTHETIC_RUNTIME_ONLY_MAIN_RECHECK_BEFORE_EXECUTION');
  assert.equal(adapter.on_compile_cp,false);assert.equal(adapter.root,'/tmp/custodial-current-frame-lifetime-nAN3W8/adapter');
  pinned(adapter.root+'/org/memphiszoo/custodial/vault/AndroidKeystoreCipher.class','cb927f74c6b6a960bd911c081fac130ae7e10c0508aacff5ea051c499288a8e3');
  const compileCp=inputs.argv[inputs.argv.indexOf('-classpath')+1].split(':');assert.equal(compileCp.includes(adapter.root),false);
  assert.equal(compileCp[1],path.dirname(backendRoot)+'/native-completion-disposition-source-ZgY1Qh');
  assert.deepEqual(runtime.classpath_order,[compileCp[0],classes.root,adapter.root,...compileCp.slice(1)]);
  assert.equal(runtime.java,'/usr/lib/jvm/java-21-openjdk-amd64/bin/java');
  assert.equal(runtime.final_marker,'ORIGINAL_COMPLETION_ACCEPTED_ALL_CHUNKS_OWNING_CLOSURES_COMPLETE');
  assert.deepEqual(currentRuntime.classpath_order,[currentClasses.path,production.output.path,...runtime.classpath_order]);
  assert.equal(currentRuntime.java,runtime.java);assert.equal(currentRuntime.final_marker,runtime.final_marker);
  assert.equal(currentInputs.argv[currentInputs.argv.indexOf('-classpath')+1].split(':').includes(adapter.root),false);
  assert.equal(currentRuntime.testClassSha,'b0caf827be49c1d2ee3e1ccbc7db59f64b4a4bf5c2377989dfeda2a669ab1142');
  pinned(currentRuntime.testClassPath,currentRuntime.testClassSha);
 };
 await verify();return {base,java:currentRuntime.java,classpath:[activeClasses.root,...currentRuntime.classpath_order],
  testClassSha256:currentRuntime.testClassSha,verify};
}
async function preflightSameOriginalNativeCompletionInputs(backendRoot){
 const base='/home/eric/Documents/Codex/2026-10-09/task-7/native-original-completion-http-20261015-v1';
 const root=base+'/current-context-all-chunks/normal-test-compile-TTcvN6/';
 const digests={'INPUTS.json':'103290ad893af49244b4373477528440df13c7b6384d009880ea6481616be9a9',
  'CLASS_MANIFEST.json':'71ec2f2aa4e5f23f6eeb29b261e8c3b3dd1423eb293699a8040523b50ff6e424',
  'COMPILE_RESULT.json':'0480fa52197b113a57d7861c389e713009573ccf084f60be18e8a126cf67d741',
  'RUN_TEMPLATE.json':'c409ac279fc5c96cb144829663e4271ea46785aebd51db78eef5b5593286ece8'};
 const pinned=(file,digest,size)=>{const stat=fs.lstatSync(file);assert.equal(stat.isSymbolicLink(),false);const b=fs.readFileSync(file);assert.equal(sha(b),digest,file);if(size!==undefined)assert.equal(b.length,size);return b;};
 const read=name=>JSON.parse(pinned(root+name,digests[name]));
 const inputs=read('INPUTS.json'),classes=read('CLASS_MANIFEST.json'),compiled=read('COMPILE_RESULT.json'),runtime=read('RUN_TEMPLATE.json');
 const delta=base+'/current-context-all-chunks/final-arguments-base64-475Qov/';
 const deltaDigests={'INPUTS.json':'b824dde6827e5f008a778ac9eebde93b49cdba4a3516a692534936f1d9ae418e',
  'CLASS_MANIFEST.json':'023f261e2afa613e1454f35d0bed75e838670072001d21c126beb34fa07c68c9',
  'COMPILE_RESULT.json':'f124750bed5b1e78ac7d6526c85d2b89f600c9e4980c0c03bc1003d8f42dc9b6',
  'RUN_TEMPLATE.json':'f0d56f5504152821a95f36c3bf71c90ad8aa0916be058bce1fcf0ba92f1946a6'};
 const readDelta=name=>JSON.parse(pinned(delta+name,deltaDigests[name]));
 const deltaInputs=readDelta('INPUTS.json'),deltaClasses=readDelta('CLASS_MANIFEST.json'),deltaCompile=readDelta('COMPILE_RESULT.json'),deltaRuntime=readDelta('RUN_TEMPLATE.json');
 const verify=async()=>{
  for(const name of Object.keys(digests))read(name);
  for(const name of Object.keys(deltaDigests))readDelta(name);
  assert.equal(deltaCompile.terminal.exit_code,0);assert.deepEqual(deltaCompile.changedPins,[]);
  assert.deepEqual(deltaInputs.before,deltaCompile.afterPins);assert.deepEqual(deltaInputs.before.borrowed64_and_old19_errors,[]);
  pinned(delta+'source/NativePrivateCustodyReturnedPieceSetTest.java','34fd50d06096422c8b658f26f2925d8e97e494286ae9f50ec40ab1177f67a1c3');
  assert.equal(compiled.terminal.exit_code,0);assert.deepEqual(compiled.changedPins,[]);
  assert.deepEqual(inputs.before,compiled.afterPins);assert.deepEqual(inputs.before.borrowed64_errors,[]);
  for(const row of inputs.source_pins)pinned(row.path,row.sha256,row.bytes);
  for(const row of [...inputs.before.pins,...deltaInputs.before.pins]){
   if(row.path===backendRoot+'/scripts/same-original-recovery-local-database-tests.mjs'){
    // JS runtime fixture, not a javac/class input. Main added ONLY first-error
    // retention after that compile; explicitly bind this changed dependency.
    pinned(row.path,'2225191a1c40c859c233e63876f030a09f673cd0c4b549d9f0802a31c41f92dd');continue;
   }
   const stat=fs.lstatSync(row.path);assert.equal(stat.isSymbolicLink(),false);
   if(!stat.isDirectory()){pinned(row.path,row.sha256,row.bytes);continue;}
   assert.equal(stat.dev,row.dev);assert.equal(stat.ino,row.ino);
   const rows=[];const walk=dir=>{for(const name of fs.readdirSync(dir).sort()){const file=path.join(dir,name),s=fs.lstatSync(file);assert.equal(s.isSymbolicLink(),false);if(s.isDirectory())walk(file);else if(name.endsWith('.class'))rows.push([path.relative(row.path,file),s.size,sha(fs.readFileSync(file))]);}};
   walk(row.path);assert.equal(rows.length,row.class_count);assert.equal(sha(JSON.stringify(rows)),row.class_tree_sha256,row.path);
  }
  const stat=fs.lstatSync(classes.root);assert.equal(stat.dev,classes.dev);assert.equal(stat.ino,classes.ino);assert.equal(stat.isSymbolicLink(),false);assert.equal(classes.count,19);assert.equal(classes.files.length,19);
  for(const row of classes.files){assert.equal(row.path,path.join(classes.root,row.relative_path));pinned(row.path,row.sha256,row.bytes);}
  const deltaStat=fs.lstatSync(deltaClasses.root);assert.equal(deltaStat.dev,deltaClasses.dev);assert.equal(deltaStat.ino,deltaClasses.ino);assert.equal(deltaStat.isSymbolicLink(),false);
  assert.equal(deltaClasses.count,12);assert.equal(deltaClasses.files.length,12);
  for(const row of deltaClasses.files){assert.equal(row.path,path.join(deltaClasses.root,row.relative_path));pinned(row.path,row.sha256,row.bytes);}
  const adapter=runtime.runtime_adapter_only;assert.equal(adapter.scope,'EXISTING_SYNTHETIC_HOST_FIXTURE_ONLY_NOT_ANDROID_AUTHORITY');
  pinned(path.join(adapter.root,adapter.class),'cb927f74c6b6a960bd911c081fac130ae7e10c0508aacff5ea051c499288a8e3');
  pinned(backendRoot+'/scripts/same-original-recovery-local-database-tests.mjs','2225191a1c40c859c233e63876f030a09f673cd0c4b549d9f0802a31c41f92dd');
  assert.equal(runtime.classpath_order[1],classes.root);assert.equal(runtime.classpath_order[2],adapter.root);
  assert.deepEqual(deltaRuntime.classpath_order,[runtime.classpath_order[0],deltaClasses.root,...runtime.classpath_order.slice(1)]);
 };
 await verify();
 return {base,java:deltaRuntime.java,classpath:deltaRuntime.classpath_order,
  testClassSha256:deltaClasses.files.find(r=>r.relative_path==='org/memphiszoo/custodial/vault/NativePrivateCustodyReturnedPieceSetTest.class').sha256,verify};
}
async function qualifySameOriginalNativePositive({admin,backendRoot,out,statusBinding=null,managerPreparationBinding=null,completionBinding=null,acceptedCompletionBinding=null,inventoryRegistrationJoin=false,inventoryConfirmationGuard=false,inventoryManifestChunks=false,inventoryManifestStatus=false,inventoryManifestManagerSource=false,inventoryManifestSemanticReview=false,inventoryManagerDecision=false,inventoryManagerDecisionHttp=false}) {
 if(acceptedCompletionBinding!==null){
  assert.equal(statusBinding,null);assert.equal(managerPreparationBinding,null);assert.equal(completionBinding,null);
  const binding=acceptedCompletionBinding;assert.equal(typeof binding.verify,'function');await binding.verify();
  const savedBrowser=binding.savedBrowser===true;
  const writerHold=binding.writerHold===true;
  const leasePairOnly=binding.leasePairOnly===true;assert.equal(leasePairOnly&&!writerHold,false);
  assert.match(binding.testClassSha256,/^[a-f0-9]{64}$/);
  const module=await import(pathToFileURL(backendRoot+'/scripts/same-original-recovery-local-database-tests.mjs'));
  const staged=await module.prepareSameOriginalNativeAcceptedCompletionFixture({admin,backendRoot});
  // Only this synthetic multi-invocation fixture uses a short PRIVATE root.
  // Android's internal no-backup root is not this deeply nested evidence path.
  // Keep every real source/path/identity check; do not cache or widen a guard.
  // Results and packets remain task-local, and this exact synthetic root is
  // retained (not deleted); /tmp retention is not a production backup claim.
  const own=fs.mkdtempSync(writerHold?'/tmp/mz-native-original-':out+'/owned-native-accepted-'),ownStat=fs.lstatSync(own),host=own+'/protected';
  assert.equal(ownStat.isDirectory(),true);assert.equal(ownStat.isSymbolicLink(),false);
  assert.equal(ownStat.mode&511,448);assert.equal(ownStat.uid,process.getuid());
  assert.equal(fs.realpathSync(own),own);
  put('NATIVE_ACCEPTED_FIXTURE_ROOT.json',{path:own,dev:ownStat.dev,ino:ownStat.ino,uid:ownStat.uid,mode:'0700',
   scope:'SYNTHETIC_OWNED_ROOT_ONLY_NO_PRODUCTION_DATA',retained:true,temporary_filesystem_retention_not_backup:true});
  // The unchanged owning test restricts packets to its original Task7 root.
  // Its compiled caller may be borrowed from Task9 without moving that scope.
  const packetBase=savedBrowser?binding.packetBase:binding.base;
  assert.equal(typeof packetBase,'string');const baseStat=fs.lstatSync(packetBase);
  assert.equal(baseStat.isDirectory(),true);assert.equal(baseStat.isSymbolicLink(),false);
  const packetParent=fs.mkdtempSync(packetBase+'/main-sql-packet-');fs.chmodSync(packetParent,0o700);
  const packetStat=fs.lstatSync(packetParent),golden=packetParent+'/emitted';
  fs.mkdirSync(host,{mode:0o700});
  const contextFile=own+'/SQL-context.json',preparedFile=own+'/accepted-prepared.json';
  assert.equal(fs.existsSync(contextFile),false);
  const atomicPublications=[];
  const preparedBytes=Buffer.from(JSON.stringify(staged.prepared));
  publishOwned(preparedFile,preparedBytes);const preparedSha=sha(preparedBytes);preparedBytes.fill(0);
  let prepared=null,contextSha=null,nativeGateway,child,done,timer,stageTimer,childClosed=false,nativeStatus,firstFailure;
  let stdout='',stderr='',lineBuffer='',stage='WAIT_START',stageChain=Promise.resolve(),stageDeadline=null,wholeDeadline=null,goldenStat=null;
  let rejectionRecorded=false,originalDispatchStarted=false,originalDispatchSettled=false;
  let completionArguments=null,completionRequest=null,completionResponse=null,captureDescriptor=null;
  const loans=[],pins=[],inFlight=new Set(),consumed=[],mainPins=new Map([[preparedFile,fs.lstatSync(preparedFile)]]);
  const markers=['ORIGINAL_COMPLETION_ACCEPTED_START_READY','ORIGINAL_COMPLETION_ACCEPTED_COMMIT_READY','ORIGINAL_COMPLETION_ACCEPTED_NATIVE_CAPTURE_READY'];
  const effects=['inventory_acknowledged','work_accepted','replay_allowed','finalizer_allowed','key_removal','phone_released'];
  function publishOwned(finalPath,bytes){
   assert.ok(Buffer.isBuffer(bytes)&&bytes.length>0&&bytes.length<=1048576);
   const parent=path.dirname(finalPath);assert.ok(parent===own||parent===golden);
   if(parent===golden)currentRoot();
   const parentOriginal=parent===own?ownStat:goldenStat,parentNow=fs.lstatSync(parent);
   assert.equal(parentNow.isDirectory(),true);assert.equal(parentNow.isSymbolicLink(),false);assert.equal(parentNow.mode&511,448);
   assert.equal(parentNow.dev,parentOriginal.dev);assert.equal(parentNow.ino,parentOriginal.ino);
   const pending=finalPath+'.publishing',publication={pending,final:finalPath,published:false,pending_removed:false};
   atomicPublications.push(publication);let fd=null,dirfd=null,primary;
   try{
    fd=fs.openSync(pending,fs.constants.O_RDWR|fs.constants.O_CREAT|fs.constants.O_EXCL|fs.constants.O_NOFOLLOW,0o600);
    const original=fs.fstatSync(fd);assert.equal(original.isFile(),true);assert.equal(original.mode&511,384);assert.equal(original.nlink,1);
    assert.equal(original.dev,parentOriginal.dev);publication.dev=original.dev;publication.ino=original.ino;
    let offset=0;while(offset<bytes.length){const n=fs.writeSync(fd,bytes,offset,bytes.length-offset,offset);assert.ok(n>0);offset+=n;}
    fs.fsyncSync(fd);assert.equal(fs.fstatSync(fd).size,bytes.length);
    const copied=Buffer.alloc(bytes.length);
    try{offset=0;while(offset<copied.length){const n=fs.readSync(fd,copied,offset,copied.length-offset,offset);assert.ok(n>0);offset+=n;}assert.ok(copied.equals(bytes));}
    finally{copied.fill(0);}
    const pendingNow=fs.lstatSync(pending);assert.equal(pendingNow.dev,original.dev);assert.equal(pendingNow.ino,original.ino);assert.equal(pendingNow.isSymbolicLink(),false);
    dirfd=fs.openSync(parent,fs.constants.O_RDONLY|fs.constants.O_DIRECTORY|fs.constants.O_NOFOLLOW);
    const dir=fs.fstatSync(dirfd);assert.equal(dir.dev,parentOriginal.dev);assert.equal(dir.ino,parentOriginal.ino);
    // link is absent-only; never rename-overwrite or update a published file.
    fs.linkSync(pending,finalPath);publication.published=true;fs.fsyncSync(dirfd);
    const linked=fs.lstatSync(finalPath),stillPending=fs.lstatSync(pending);
    for(const s of [linked,stillPending]){assert.equal(s.isFile(),true);assert.equal(s.isSymbolicLink(),false);assert.equal(s.dev,original.dev);
     assert.equal(s.ino,original.ino);assert.equal(s.size,bytes.length);assert.equal(s.mode&511,384);assert.equal(s.nlink,2);}
    fs.unlinkSync(pending);publication.pending_removed=true;fs.fsyncSync(dirfd);
   }catch(error){primary=error;throw error;}finally{
    const errors=[];for(const ownedFd of [fd,dirfd])if(ownedFd!==null)try{fs.closeSync(ownedFd);}catch(error){errors.push(error);}
    if(errors.length){if(primary)primary.closeFailures=errors;else throw errors[0];}
   }
  }
  function checkMainFile(file,expectedSha){
   const original=mainPins.get(file),s=fs.lstatSync(file);assert.ok(original);assert.equal(s.isFile(),true);assert.equal(s.isSymbolicLink(),false);
   assert.equal(s.mode&511,384);assert.equal(s.nlink,1);assert.equal(s.dev,original.dev);assert.equal(s.ino,original.ino);assert.ok(s.size>0&&s.size<=1048576);
   const fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);let bytes;
   try{const before=fs.fstatSync(fd);assert.equal(before.dev,s.dev);assert.equal(before.ino,s.ino);assert.equal(before.size,s.size);
    bytes=fs.readFileSync(fd);assert.equal(sha(bytes),expectedSha);
    const after=fs.fstatSync(fd),atPath=fs.lstatSync(file);
    for(const k of ['dev','ino','size','mtimeMs','ctimeMs']){assert.equal(after[k],s[k]);assert.equal(atPath[k],s[k]);}
   }finally{bytes?.fill(0);fs.closeSync(fd);}
  }
  function currentRoot(){
   const p=fs.lstatSync(packetParent);assert.equal(p.dev,packetStat.dev);assert.equal(p.ino,packetStat.ino);assert.equal(p.isSymbolicLink(),false);
   const s=fs.lstatSync(golden);assert.equal(s.isDirectory(),true);assert.equal(s.isSymbolicLink(),false);assert.equal(s.mode&511,448);assert.equal(s.dev,packetStat.dev);
   if(goldenStat){assert.equal(s.dev,goldenStat.dev);assert.equal(s.ino,goldenStat.ino);}else goldenStat=s;
  }
  function readFile(file,descriptor=null,track=true){
   assert.equal(file,path.basename(file));assert.ok(file!=='.'&&file!=='..');currentRoot();
   const p=golden+'/'+file,before=fs.lstatSync(p);assert.equal(before.isFile(),true);assert.equal(before.isSymbolicLink(),false);
   assert.equal(before.mode&511,384);assert.equal(before.nlink,1);assert.equal(before.dev,packetStat.dev);assert.ok(before.size>0&&before.size<=1048576);
   const fd=fs.openSync(p,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);let bytes;
   try{
    const s=fs.fstatSync(fd);assert.equal(s.dev,before.dev);assert.equal(s.ino,before.ino);assert.equal(s.size,before.size);
    bytes=fs.readFileSync(fd);const after=fs.fstatSync(fd),atPath=fs.lstatSync(p);
    for(const k of ['dev','ino','size','mtimeMs','ctimeMs']){assert.equal(after[k],before[k]);assert.equal(atPath[k],before[k]);}
    assert.equal(bytes.length,before.size);assert.equal(atPath.isSymbolicLink(),false);assert.equal(after.mode&511,384);assert.equal(after.nlink,1);
    if(descriptor){assert.equal(bytes.length,descriptor.bytes);assert.equal(sha(bytes),descriptor.sha256);}
    if(track){pins.push({file:p,sha256:sha(bytes),bytes:bytes.length,dev:before.dev,ino:before.ino});loans.push(bytes);}
    return bytes;
   }catch(error){bytes?.fill(0);throw error;}finally{fs.closeSync(fd);}
  }
  function writeResponse(file,bytes){
   currentRoot();assert.ok(Buffer.isBuffer(bytes)&&bytes.length>0&&bytes.length<=1048576);
   publishOwned(golden+'/'+file,bytes);const retained=readFile(file);
   assert.ok(retained.equals(bytes));return retained;
  }
  function requireWholeCurrent(){if(firstFailure)throw firstFailure;assert.ok(wholeDeadline!==null&&process.hrtime.bigint()<wholeDeadline,'ACCEPTED_NATIVE_WHOLE_DEADLINE');}
  function checkStages(){requireWholeCurrent();assert.ok(stageDeadline!==null&&process.hrtime.bigint()<stageDeadline,'ACCEPTED_NATIVE_STAGE_DEADLINE');}
  function fail(error){
   firstFailure??=error;
   // Preserve the first actual rejection BEFORE drain/cleanup can wait on an
   // interrupted child. Diagnostic only; no deadline or product guard changes.
   if(writerHold&&!rejectionRecorded){
    rejectionRecorded=true;
    put('NATIVE_ACCEPTED_SQL_JOIN_FAILURE_AT_REJECTION.json',{
     message:String(firstFailure.message).slice(0,500),stack:String(firstFailure.stack||'').slice(0,5000),
     stage,consumed:[...consumed],nativeStatus,native_child_pid:child?.pid??null,
     native_stdout:stdout,native_stderr:stderr,
     native_gateway_diagnostic:typeof nativeGateway?.diagnostic==='function'?nativeGateway.diagnostic():null,
     captured_before_cleanup:true,product_effect_authority:false});
   }
   if(child&&!childClosed)try{child.kill('SIGTERM');}catch(cleanup){firstFailure.killFailure??=cleanup;}
  }
  async function drain(){while(inFlight.size)await Promise.allSettled([...inFlight]);await stageChain;}
  async function stageAction(marker){
   checkStages();await binding.verify();checkStages();
   if(marker===markers[0]){
    const request=readFile('accepted-start.request.bin'),args=readFile('accepted-start.arguments.bin'),headers=JSON.parse(readFile('accepted-start.headers.json'));
    const result=await staged.startOriginal({exactRequestBytes:request,exactArgumentBytes:args,nativeHeaders:headers});
    checkStages();writeResponse('accepted-start.response.bin',result.exactResponseBytes);result.exactResponseBytes.fill(0);stage='WAIT_COMMIT';
   }else if(marker===markers[1]){
    completionRequest=readFile('accepted-completion.request.bin');completionArguments=readFile('accepted-completion.arguments.bin');
    const headers=JSON.parse(readFile('accepted-completion.headers.json'));
    const result=await staged.commitOriginal({exactRequestBytes:completionRequest,exactArgumentBytes:completionArguments,nativeHeaders:headers});
    checkStages();assert.equal(result.original_completion_arguments_sha256,sha(completionArguments));
    assert.equal(result.original_completion_arguments_utf8,new TextDecoder('utf-8',{fatal:true}).decode(completionArguments));
    completionResponse=writeResponse('accepted-completion.response.bin',result.exactResponseBytes);result.exactResponseBytes.fill(0);stage='WAIT_CAPTURE';
   }else{
    const captured=readFile('accepted-completion.response.captured.bin');assert.ok(captured.equals(completionResponse));
    captureDescriptor=JSON.parse(readFile('accepted-native-capture.json'));
    const keys=['schema','state','request_sha256','arguments_sha256','response_sha256','receipt_key','start_key','finish_key',
     'receipt_ciphertext_sha256','start_ciphertext_sha256','finish_ciphertext_sha256','native_capture_restart_checked','transaction_authority',...effects];
    assert.deepEqual(Object.keys(captureDescriptor).sort(),keys.slice().sort());
    assert.equal(captureDescriptor.schema,'custodial.test-native-original-completion-capture.v1');
    assert.equal(captureDescriptor.state,'ORIGINAL_NATIVE_RECEIPT_START_FINISH_CAPTURED_RESTART_CHECKED_NOT_AUTHORITY');
    assert.equal(captureDescriptor.request_sha256,sha(completionRequest));assert.equal(captureDescriptor.arguments_sha256,sha(completionArguments));
    assert.equal(captureDescriptor.response_sha256,sha(completionResponse));assert.equal(captureDescriptor.native_capture_restart_checked,true);
    assert.equal(captureDescriptor.transaction_authority,false);for(const k of effects)assert.equal(captureDescriptor[k],false);
    const args=JSON.parse(completionArguments),session=args.p_client_session_id,completion=args.p_client_completion_id;
    assert.match(session,/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/);assert.match(completion,/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/);
    assert.equal(args.p_device_id,'KIOSK_08');
    assert.equal(captureDescriptor.receipt_key,'authenticated_completion_receipt_sha256:'+sha('KIOSK_08|'+session+'|'+completion));
    assert.equal(captureDescriptor.start_key,'offline_occurrence_sha256:'+sha(session));assert.equal(captureDescriptor.finish_key,'offline_finish_proof_sha256:'+sha(session));
    for(const k of ['receipt_ciphertext_sha256','start_ciphertext_sha256','finish_ciphertext_sha256'])assert.match(captureDescriptor[k],/^[a-f0-9]{64}$/);
    // Descriptor flags/echo are matching evidence ONLY. The privately verified
    // actual child class emits this marker only AFTER journal capture, restart
    // and exact encrypted-row checks; binding.verify owns that Source/class pin.
    await binding.verify();checkStages();
    prepared=await staged.separateOriginal({exactCapturedResponseBytes:captured});checkStages();
    assert.equal(prepared.original_completion_arguments_sha256,sha(completionArguments));
    assert.equal(prepared.original_completion_arguments_utf8,new TextDecoder('utf-8',{fatal:true}).decode(completionArguments));
    const bytes=Buffer.from(JSON.stringify(prepared.context));contextSha=sha(bytes);
    assert.equal(fs.existsSync(contextFile),false);
    checkStages();publishOwned(contextFile,bytes);mainPins.set(contextFile,fs.lstatSync(contextFile));bytes.fill(0);
    checkStages();stage='SEPARATED';clearTimeout(stageTimer); // File-stage window ends; whole deadline is NEVER renewed.
   }
   if(stage==='SEPARATED')requireWholeCurrent();else checkStages();
  }
  function markerLine(line){
   if(writerHold&&line==='ORIGINAL_CUSTODY_WRITES_PREPARED_READY'){
    if(stage!=='SEPARATED'||originalDispatchStarted){fail(Error('ORIGINAL_CUSTODY_PREREQUISITE_STAGE_REFUSED'));return;}
    originalDispatchStarted=true;
    const work=stageChain.then(async()=>{
     requireWholeCurrent();assert.equal(typeof nativeGateway.settleOriginalPrerequisites,'function');
     const count=await nativeGateway.settleOriginalPrerequisites();requireWholeCurrent();
     const manifest=JSON.parse(readFile('sql-original-writes.json'));assert.equal(count,manifest.count);
     const result={schema:'custodial.test-original-custody-write-prerequisites.v1',state:'ORIGINAL_WRITES_ADMITTED_NOT_ACK',count};
     for(const flag of effects)result[flag]=false;
     const bytes=Buffer.from(JSON.stringify(result));
     try{writeResponse('original-custody-writes-admitted.json',bytes);originalDispatchSettled=true;}
     finally{bytes.fill(0);}
    });inFlight.add(work);stageChain=work.catch(fail).finally(()=>inFlight.delete(work));return;
   }
   if(!markers.includes(line))return;
   const expected=stage==='WAIT_START'?markers[0]:stage==='WAIT_COMMIT'?markers[1]:stage==='WAIT_CAPTURE'?markers[2]:null;
   if(line!==expected||consumed.includes(line)){fail(Error('ACCEPTED_NATIVE_STAGE_ORDER_REFUSED'));return;}
   consumed.push(line);stage='RUNNING'; // Consume synchronously, before any await.
   const work=stageChain.then(()=>stageAction(line));inFlight.add(work);
   stageChain=work.catch(fail).finally(()=>inFlight.delete(work));
  }
  try{
   nativeGateway=await module.createSameOriginalNativeRegistrationTestGateway({admin,backendRoot,
    expectedManagerPreparationReads:leasePairOnly?2:writerHold?4:savedBrowser?2:1,expectedOriginalCompletionReads:writerHold&&!leasePairOnly?2:1,
    ...(writerHold?{expectedPreparationCycles:leasePairOnly?1:2}:{}),readOriginalInput:async()=>{
    assert.equal(stage,'SEPARATED');assert.ok(prepared&&contextSha);requireWholeCurrent();
    checkMainFile(preparedFile,preparedSha);
    const m=JSON.parse(readFile('sql-original-writes.json'));assert.equal(m.schema,'custodial.test-original-write-source-inputs.v1');
    assert.ok(Number.isSafeInteger(m.count)&&m.count>=1&&m.count<=4096);assert.equal(m.originals.length,m.count);
    assert.equal(m.Main_context_file_sha256,contextSha);checkMainFile(contextFile,contextSha);
    const originals=m.originals.map((entry,i)=>{assert.equal(entry.index,i);assert.equal(entry.raw.path,'sql-original-write-'+i+'.bin');assert.equal(entry.headers.path,'sql-original-write-'+i+'.headers.json');
     return {raw:readFile(entry.raw.path,entry.raw),headers:JSON.parse(readFile(entry.headers.path,entry.headers))};});
    const sourceFacts=JSON.parse(readFile('sql-source-facts.json'));assert.deepEqual(Object.keys(sourceFacts).sort(),['separationContext','original_WRITE0','native_principal','originalGeneration','source_recipe','native_credential_sha256'].sort());
    assert.deepEqual(sourceFacts.separationContext,prepared.context);return {originals,sourceFacts};
   }});
   const args=['--add-modules','java.net.http','-Xmx256m','-Dcustodial.custody.fixture.root='+host,
    ...(savedBrowser?['-Dcustodial.fixture.original-clock-mode=fresh-running-host-before-originals']:[]),
    '-Dcustodial.fixture.original-clock-source=fresh-host-before-originals','-Dcustodial.actual.fixture.context='+contextFile,
    '-Dcustodial.actual.fixture.accepted.prepared='+preparedFile,'-Dcustodial.actual.fixture.gateway.port='+new URL(nativeGateway.origin).port,
    '-Dcustodial.fixture.g08.packet.output='+golden,'-cp',binding.classpath.join(':'),
    'org.memphiszoo.custodial.vault.NativePrivateCustodyReturnedPieceSetTest',leasePairOnly?'--same-prepared-manager-lease-pair-current-context-only':writerHold?'--durable-writer-hold-full-reconstruction-current-context-only':savedBrowser?'--browser-saved-manager-current-context-only':'--original-completion-accepted-current-context-only'];
   // This staged case owns a <=60s original file exchange BEFORE the existing
   // native frame control starts its unchanged 180s window. A 150s driver
   // cutoff killed valid post-response currentness work before that control
   // could settle. Bound the driver to their sum; do not extend native/auth IO.
   const spawnedAt=process.hrtime.bigint();stageDeadline=spawnedAt+60000000000n;wholeDeadline=spawnedAt+240000000000n;
   if(writerHold){
    // This compound caller now covers first registration, a SEPARATE saved
    // browser invocation, and a SEPARATE held-original reconstruction. Each
    // owns its unchanged native180s control; archived auth/freshness/manager
    // limits never renew. The old240s SINGLE-invocation aggregate preempted
    // the owning path (retained deadline receipts), not a product refusal.
    // Allocate only the existing350s total runner budget: parent finish320s,
    // Node/child300s with20s drain. No product/control/file-stage limit changes,
    // and all historical non-writerHold modes keep their exact budgets.
    wholeDeadline=spawnedAt+300000000000n;
    const remaining=300-Math.ceil(process.uptime());
    if(remaining<=0)throw Error('ACCEPTED_NATIVE_PARENT_BUDGET_EXHAUSTED');
    const parentDeadline=spawnedAt+BigInt(remaining)*1000000000n;
    if(parentDeadline<wholeDeadline)wholeDeadline=parentDeadline;
    if(wholeDeadline<stageDeadline)stageDeadline=wholeDeadline;
   }
   child=spawn(binding.java,args,{cwd:path.dirname(backendRoot)+'/frontend',stdio:['ignore','pipe','pipe'],env:{PATH:'/usr/bin:/bin',LANG:'C.UTF-8',LC_ALL:'C.UTF-8'}});
   // Exact owned child only, so a bounded normal thread diagnostic can target
   // this qualification without broad process scans or request/credential data.
   if(writerHold)put('NATIVE_CHILD_IDENTITY.json',{pid:child.pid,scope:'OWNED_ISOLATED_NATIVE_QUALIFICATION_ONLY',
    test_class_sha256:binding.testClassSha256,product_effect_authority:false});
   done=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(status,signal)=>{childClosed=true;nativeStatus={status,signal};status===0?resolve():reject(Error('NEW_ACCEPTED_NATIVE_SQL_JOIN_REFUSED'));});});done.catch(()=>{});
   child.stdout.on('data',data=>{
    stdout+=data;if(stdout.length>32768){fail(Error('ACCEPTED_NATIVE_STDOUT_LIMIT'));return;}
    lineBuffer+=data;let at;while((at=lineBuffer.indexOf('\n'))>=0){const line=lineBuffer.slice(0,at).replace(/\r$/,'');lineBuffer=lineBuffer.slice(at+1);markerLine(line);}
   });
   child.stderr.on('data',data=>{stderr+=data;if(stderr.length>32768)fail(Error('ACCEPTED_NATIVE_STDERR_LIMIT'));});
   const remainingMs=absolute=>Math.max(0,Number(absolute-process.hrtime.bigint())/1000000);
   stageTimer=setTimeout(()=>fail(Error('ACCEPTED_NATIVE_STAGE_DEADLINE')),remainingMs(stageDeadline));stageTimer.unref();
   timer=setTimeout(()=>fail(Error('ACCEPTED_NATIVE_WHOLE_DEADLINE')),remainingMs(wholeDeadline));timer.unref();
   await done;await drain();requireWholeCurrent();clearTimeout(stageTimer);clearTimeout(timer);
   assert.equal(stage,'SEPARATED');assert.deepEqual(consumed,markers);
   if(leasePairOnly){
    for(const marker of ['LEASE_PAIR_BOTH_VALID_NOT_AUTHORITY','LEASE_PAIR_EXPIRED_ORIGINAL_REFUSED',
     'LEASE_PAIR_EXPIRED_REFRESHED_REFUSED','LEASE_PAIR_CANCELED_CONTROL_REFUSED','LEASE_PAIR_OWNING_CALLER_CLOSURES_COMPLETE'])
     assert.ok(stdout.split(/\r?\n/).includes(marker),marker);
    assert.equal(originalDispatchStarted,true);assert.equal(originalDispatchSettled,true);
    const native_SQL=await nativeGateway.finish();await nativeGateway.close();nativeGateway=null;
    assert.equal(native_SQL.native_manager_preparation_reads,2);assert.equal(native_SQL.native_original_completion_reads,1);
    assert.deepEqual(native_SQL.original_completion_dispositions,['ACCEPTED_EXACT_ORIGINAL']);
    for(const p of pins){const s=fs.lstatSync(p.file);assert.equal(s.dev,p.dev);assert.equal(s.ino,p.ino);
     const bytes=readFile(path.basename(p.file),p,false);try{assert.equal(sha(bytes),p.sha256);}finally{bytes.fill(0);}}
    checkMainFile(preparedFile,preparedSha);checkMainFile(contextFile,contextSha);requireWholeCurrent();await binding.verify();requireWholeCurrent();
    return {native_SQL,nativeStatus,native_stdout:stdout,native_stderr:stderr,
     scope:'ACTUAL_ISSUED_MANAGER_PAIR_VALID_EXPIRY_AND_CANCEL_GUARDS_ONLY_NOT_HOLD_ACK_OR_ANDROID',
     different_prepared_read:'NOT_RUN_NO_SECOND_ISSUER',writer_hold:false,real_manager:false,Android:false,native_TLS:false,ACK:false,finalizer:false,key_removal:false};
   }
   assert.ok(stdout.split(/\r?\n/).includes(writerHold?'DURABLE_WRITER_HOLD_OWNING_CALLER_CLOSURES_COMPLETE':savedBrowser?'BROWSER_SAVED_MANAGER_OWNING_CLOSURES_COMPLETE':'ORIGINAL_COMPLETION_ACCEPTED_ALL_CHUNKS_OWNING_CLOSURES_COMPLETE'));
   if(writerHold){
    assert.equal(originalDispatchStarted,true);assert.equal(originalDispatchSettled,true);
    for(const phase of ['durable_writer_hold_promoted_original_metadata_denied_writers_and_closed_token_checked',
     'held_full_original_saved_owner_reconstructed','HELD_OPERATION_STORE_DIRECT_ENTRY_REFUSALS_COMPLETE',
     'held_full_original_current_manager_browser_read_and_effect_denials_checked'])
     assert.ok(stdout.includes('CURRENT_FRAME_CONSUMER_PHASE '+phase),phase);
   }
   const native_SQL=await nativeGateway.finish();await nativeGateway.close();nativeGateway=null;
   const observed=JSON.parse(readFile('native-original-completion-outcome.json'));
   assert.equal(Object.keys(observed).length,14);assert.equal(observed.schema,'custodial.native-original-completion-read-observation.v1');
   assert.equal(observed.state,'CURRENT_AUTHENTICATED_ORIGINAL_COMPLETION_READS_NOT_ACK');
   assert.equal(observed.selected_argument_count,1);assert.equal(observed.accepted_count,1);assert.equal(observed.unresolved_selected_count,0);
   assert.equal(native_SQL.native_original_completion_reads,writerHold?2:1);
   assert.deepEqual(native_SQL.original_completion_dispositions,writerHold?['ACCEPTED_EXACT_ORIGINAL','ACCEPTED_EXACT_ORIGINAL']:['ACCEPTED_EXACT_ORIGINAL']);
   if(savedBrowser){
    assert.equal(native_SQL.native_manager_preparation_reads,writerHold?4:2);assert.equal(native_SQL.after.approvals,1);
    const browser=JSON.parse(readFile('native-saved-browser-manager-outcome.json'));
    assert.equal(browser.schema,'custodial.native-current-original-browser-preparation.v3');
    assert.equal(browser.state,'CURRENT_MANAGER_AND_SAVED_BROWSER_DATA_NOT_CURRENT_BROWSER_AUTHORITY');
    assert.equal(browser.current_browser_source_authenticated,false);
    for(const key of effects)assert.equal(browser[key],false);
    assert.equal(browser.original_browser_local_custody.record_count,2);
    assert.equal(browser.original_browser_local_custody.all_writer_durable_freeze_or_ABA_guard,false);
    const finalManager=JSON.parse(readFile('manager-preparation-final-http-response.bin'));
    assert.equal(finalManager.ok,true);assert.equal(finalManager.data.transaction_authority,false);
    for(const key of effects)assert.equal(finalManager.data.limits[key],false);
   }
   const response=JSON.parse(readFile('original-completion-http-response.bin'));
   assert.equal(response.ok,true);assert.equal(response.data.disposition,'ACCEPTED_EXACT_ORIGINAL');assert.ok(response.data.result);
   const selectedArguments=readFile('original-completion-arguments.bin');assert.ok(selectedArguments.equals(completionArguments));
   assert.equal(response.data.argument_values_sha256,sha(completionArguments));assert.equal(response.data.transaction_authority,false);
   for(const k of effects){assert.equal(observed[k],false);assert.equal(response.data.limits[k],false);}
   if(writerHold){
    // A second fixed-name packet is emitted by the actual reconstructed owner,
    // never by a new original write/registration/approval or copied response.
    const recovered=JSON.parse(readFile('held-reconstruction-original-completion-http-response.bin'));
    assert.equal(recovered.ok,true);assert.equal(recovered.data.disposition,'ACCEPTED_EXACT_ORIGINAL');assert.ok(recovered.data.result);
    assert.equal(recovered.data.argument_values_sha256,sha(completionArguments));assert.equal(recovered.data.transaction_authority,false);
    for(const k of effects)assert.equal(recovered.data.limits[k],false);
    const manager=JSON.parse(readFile('held-reconstruction-manager-preparation-http-response.bin'));
    assert.equal(manager.ok,true);assert.equal(manager.data.transaction_authority,false);
    for(const k of effects)assert.equal(manager.data.limits[k],false);
    const emission=JSON.parse(readFile('held-reconstruction-original-completion-emission.json'));
    assert.equal(emission.schema,'custodial.test-native-original-completion-emission.v1');
    assert.equal(emission.classification,'SOURCE_LOOPBACK_NOT_TLS_OR_APPROVAL');
    assert.equal(emission.files.length,2);
    for(const file of emission.files)readFile(file.path,file);
    const request=readFile('held-reconstruction-original-completion-request.bin');assert.ok(request.length>0);
    assert.ok(readFile('held-reconstruction-original-completion-native-headers.json').length>0);
    assert.ok(readFile('held-reconstruction-current-first-envelope.bin').length>0);
    assert.ok(readFile('held-reconstruction-current-first-envelope.headers.json').length>0);
    const sourceFacts=JSON.parse(readFile('held-reconstruction-sql-source-facts.json'));
    assert.deepEqual(sourceFacts,JSON.parse(readFile('sql-source-facts.json')));
   }
   for(const p of pins){
    const s=fs.lstatSync(p.file);assert.equal(s.dev,p.dev);assert.equal(s.ino,p.ino);
    const bytes=readFile(path.basename(p.file),p,false);try{assert.equal(sha(bytes),p.sha256);}finally{bytes.fill(0);}
   }
   checkMainFile(preparedFile,preparedSha);checkMainFile(contextFile,contextSha);requireWholeCurrent();await binding.verify();requireWholeCurrent();
   return {native_SQL,native_completion:observed,native_capture_matching:captureDescriptor,nativeStatus,native_stdout_sha256:sha(stdout),native_stderr_sha256:sha(stderr),
    context_source:prepared.context_source,scope:writerHold?'NEW_ORIGINAL_DURABLE_HOLD_FRESH_HOST_METADATA_FULL_TYPED_RECONSTRUCTION_SQL_JOIN_NOT_ANDROID_OR_ACK':savedBrowser?'NEW_SAVED_BROWSER_ORIGINAL_DATA_CURRENT_MANAGER_NATIVE_SQL_JOIN_NOT_BROWSER_SOURCE_OR_ACK':'NEW_STAGED_NATIVE_ORIGINAL_ACCEPTED_BEFORE_SEPARATION_FIXED_SQL_SOURCE_JOIN_NOT_ACK',
    ...(writerHold?{native_writer_hold_fixture:{promotion_assertions_passed:true,original_metadata_readback:true,ordinary_callback_entries:0,closed_original_token_refused:true,fresh_host_process_metadata:true,full_typed_original_reconstruction:true,current_manager_read_cycles:2,restart:'FRESH_HOST_METADATA_ONLY_NOT_ANDROID',Android:false,ACK:false}}:{}),
    real_manager:false,Android:false,native_TLS:false,ACK:false,finalizer:false,key_removal:false};
  }catch(error){
   fail(error);await drain();
   put('NATIVE_ACCEPTED_SQL_JOIN_FAILURE.json',{message:String(firstFailure.message).slice(0,500),code:firstFailure.code,
    native_gateway_diagnostic:typeof nativeGateway?.diagnostic==='function'?nativeGateway.diagnostic():null,
    stack:String(firstFailure.stack||'').slice(0,5000),
    native_stdout:stdout,native_stderr:stderr,
    nativeStatus,stage,consumed,stdout_sha256:sha(stdout),stderr_sha256:sha(stderr),stdout_tail:stdout.slice(-2000),stderr_tail:stderr.slice(-2000),
    originals_retained:own,packet_parent_retained:packetParent,product_PASS:false});
   throw firstFailure;
  }finally{
   const cleanupErrors=[];const settle=async operation=>{try{await operation();}catch(error){cleanupErrors.push(error);}};
   clearTimeout(stageTimer);clearTimeout(timer);if(child&&!childClosed){await settle(()=>child.kill('SIGTERM'));await settle(()=>done.catch(()=>{}));}
   // Never close the borrowed SQL client/gateway while an owning SQL stage is
   // running; cancellation stops the next stage, not an in-flight SQL forcekill.
   await settle(drain);let gatewayClosed=!nativeGateway;
   if(nativeGateway)await settle(async()=>{await nativeGateway.close();gatewayClosed=true;nativeGateway=null;});
   await settle(()=>staged.close());for(const b of loans)b.fill(0);
   await settle(()=>{const s=fs.lstatSync(own);assert.equal(s.dev,ownStat.dev);assert.equal(s.ino,ownStat.ino);assert.equal(s.isSymbolicLink(),false);
    const ps=fs.lstatSync(packetParent);assert.equal(ps.dev,packetStat.dev);assert.equal(ps.ino,packetStat.ino);assert.equal(ps.isSymbolicLink(),false);});
   await settle(()=>put('NATIVE_ACCEPTED_SQL_JOIN_RESOURCES.json',{native_closed:!child||childClosed,SQL_stages_drained:inFlight.size===0,
    gateway_closed:gatewayClosed,cleanup_failure_count:cleanupErrors.length,atomic_publications:atomicPublications,
    retained_owned_root:own,retained_packet_parent:packetParent,borrowed_admin_closed_by_parent:true,protected_fixture_data_retained:true}));
   if(cleanupErrors.length){if(firstFailure)firstFailure.cleanupFailures=cleanupErrors;else throw cleanupErrors[0];}
  }
 }
 // The restart-status member needs its separately sealed changed producer and
 // compiled classes. The historical registration member keeps its old pins;
 // never silently rebind or replay its already-passing manager/page flow.
 const statusJoin=statusBinding!==null;
 const preparationJoin=managerPreparationBinding!==null;
 const completionJoin=completionBinding!==null;
 assert.ok(Number(statusJoin)+Number(preparationJoin)+Number(completionJoin)<=1);
 const binding=completionJoin?completionBinding:preparationJoin?managerPreparationBinding:statusJoin?statusBinding:await preflightSameOriginalNativeInputs(backendRoot);
 if(statusJoin||preparationJoin||completionJoin){
  assert.equal(typeof binding.verify,'function');await binding.verify();
  assert.match(binding.testClassSha256,/^[a-f0-9]{64}$/);
 }
 const module=await import(pathToFileURL(backendRoot+'/scripts/same-original-recovery-local-database-tests.mjs'));
 const prepared=await module.prepareSameOriginalNativeRegistrationFixture({admin,backendRoot,...(inventoryRegistrationJoin?{inventoryJoin:true}:{})});
 const own=fs.mkdtempSync(out+'/owned-native-registration-'),ownStat=fs.lstatSync(own),host=own+'/protected';
 // The native packet contract admits only new Task7-local outputs. Keep its
 // protected-root separation and CREATE_NEW checks intact at the caller.
 const packetParent=fs.mkdtempSync(binding.base+'/main-sql-packet-');
 fs.chmodSync(packetParent,0o700);const packetStat=fs.lstatSync(packetParent),golden=packetParent+'/emitted';
 fs.mkdirSync(host,{mode:0o700});
 const contextFile=own+'/SQL-context.json',contextBytes=Buffer.from(JSON.stringify(prepared.context));
 fs.writeFileSync(contextFile,contextBytes,{flag:'wx',mode:0o600});const contextSha=sha(contextBytes);contextBytes.fill(0);
 let nativeGateway,managerGateway,child,done,timer,childClosed=false,stdout='',stderr='',nativeStatus;
 const loans=[],pins=[];
 function emitted(file,descriptor){
  assert.equal(file,path.basename(file));const p=golden+'/'+file,s=fs.lstatSync(p);assert.equal(s.isSymbolicLink(),false);assert.equal(s.mode&511,384);
  const bytes=fs.readFileSync(p);if(descriptor){assert.equal(bytes.length,descriptor.bytes);assert.equal(sha(bytes),descriptor.sha256);}
  pins.push({file:p,sha256:sha(bytes),bytes:bytes.length});loans.push(bytes);return bytes;
 }
 try {
  nativeGateway=await module.createSameOriginalNativeRegistrationTestGateway({admin,backendRoot,...(statusJoin?{expectedStatusReads:1}:{}),
   ...((preparationJoin||completionJoin)?{expectedManagerPreparationReads:1}:{}),...(completionJoin?{expectedOriginalCompletionReads:1}:{}),readOriginalInput:async()=>{
   const m=JSON.parse(emitted('sql-original-writes.json'));assert.equal(m.schema,'custodial.test-original-write-source-inputs.v1');
   if(completionJoin)assert.ok(Number.isSafeInteger(m.count)&&m.count>=1&&m.count<=4096);else assert.equal(m.count,3);
   assert.equal(m.Main_context_file_sha256,contextSha);assert.equal(sha(fs.readFileSync(contextFile)),contextSha);
   assert.equal(m.originals.length,m.count);
   const originals=m.originals.map((entry,i)=>{assert.equal(entry.index,i);assert.equal(entry.raw.path,'sql-original-write-'+i+'.bin');assert.equal(entry.headers.path,'sql-original-write-'+i+'.headers.json');
    return {raw:emitted(entry.raw.path,entry.raw),headers:JSON.parse(emitted(entry.headers.path,entry.headers))};});
   const sourceFacts=JSON.parse(emitted('sql-source-facts.json'));assert.deepEqual(Object.keys(sourceFacts).sort(),['separationContext','original_WRITE0','native_principal','originalGeneration','source_recipe','native_credential_sha256'].sort());
   assert.deepEqual(sourceFacts.separationContext,prepared.context);return {originals,sourceFacts};
  }});
  const args=['--add-modules','java.net.http','-Xmx256m','-Dcustodial.custody.fixture.root='+host,'-Dcustodial.fixture.original-clock-source=fresh-host-before-originals',
   '-Dcustodial.actual.fixture.context='+contextFile,'-Dcustodial.actual.fixture.gateway.port='+new URL(nativeGateway.origin).port,
   '-Dcustodial.fixture.g08.packet.output='+golden,'-cp',binding.classpath.join(':'),'org.memphiszoo.custodial.vault.NativePrivateCustodyReturnedPieceSetTest',
   completionJoin?'--original-completion-current-context-all-chunks-only':preparationJoin?'--g08-sql-manager-preparation-capture-only':statusJoin?'--g08-sql-status-capture-only':'--g08-sql-join-capture-only'];
  child=spawn(binding.java,args,{cwd:path.dirname(backendRoot)+'/frontend',stdio:['ignore','pipe','pipe'],env:{PATH:'/usr/bin:/bin',LANG:'C.UTF-8',LC_ALL:'C.UTF-8'}});
  done=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(status,signal)=>{childClosed=true;nativeStatus={status,signal};status===0?resolve():reject(Error('NEW_NATIVE_SQL_JOIN_REFUSED'));});});done.catch(()=>{});
  child.stdout.on('data',data=>{stdout+=data;if(stdout.length>32768)child.kill('SIGTERM');});child.stderr.on('data',data=>{stderr+=data;if(stderr.length>32768)child.kill('SIGTERM');});
  timer=setTimeout(()=>child.kill('SIGTERM'),150000);timer.unref();await done;clearTimeout(timer);
  assert.ok(stdout.includes(completionJoin?'ORIGINAL_COMPLETION_ALL_CHUNKS_OWNING_CLOSURES_COMPLETE':preparationJoin?'G08_SQL_MANAGER_PREPARATION_OWNING_CLOSURES_COMPLETE':statusJoin?'G08_SQL_STATUS_OWNING_CLOSURES_COMPLETE':'G08_SQL_JOIN_OWNING_CLOSURES_COMPLETE'));
  const native_SQL=await nativeGateway.finish();await nativeGateway.close();nativeGateway=null;
  if(completionJoin){
   const observed=JSON.parse(emitted('native-original-completion-outcome.json'));
   assert.equal(Object.keys(observed).length,14);
   assert.equal(observed.schema,'custodial.native-original-completion-read-observation.v1');
   assert.equal(observed.state,'CURRENT_AUTHENTICATED_ORIGINAL_COMPLETION_READS_NOT_ACK');
   assert.equal(observed.selected_argument_count,1);assert.equal(observed.accepted_count,0);assert.equal(observed.unresolved_selected_count,1);
   assert.equal(native_SQL.native_original_completion_reads,1);assert.deepEqual(native_SQL.original_completion_dispositions,['UNRESOLVED_RETAINED']);
   const response=JSON.parse(emitted('original-completion-http-response.bin'));
   assert.equal(response.ok,true);assert.equal(response.data.disposition,'UNRESOLVED_RETAINED');assert.equal(response.data.result,null);
   assert.equal(response.data.argument_values_sha256,sha(emitted('original-completion-arguments.bin')));
   assert.equal(response.data.transaction_authority,false);
   for(const field of ['inventory_acknowledged','work_accepted','replay_allowed','finalizer_allowed','key_removal','phone_released']){
    assert.equal(observed[field],false);assert.equal(response.data.limits[field],false);
   }
   for(const p of pins)assert.equal(sha(fs.readFileSync(p.file)),p.sha256);
   await binding.verify();
   return {native_SQL,native_completion:observed,nativeStatus,native_stdout_sha256:sha(stdout),native_stderr_sha256:sha(stderr),context_source:prepared.context_source,
    scope:'NEW_CURRENT_ORIGINAL_NATIVE_FIXED_COMPLETION_READ_ACTUAL_SQL_UNRESOLVED_RETAINED_NOT_ACK',real_manager:false,Android:false,native_TLS:false,ACK:false,finalizer:false,key_removal:false};
  }
  const pending=JSON.parse(emitted('pending-response.json'));assert.equal(pending.test_class_sha256,statusJoin||preparationJoin?binding.testClassSha256:'37d0cf58fbfb9a062aac491f3c3f060498ab45f98d70aa7726fae4bee36167be');
  for(const entry of pending.files)emitted(entry.path,entry);
  const response=JSON.parse(emitted('actual-http-response.bin'));assert.equal(response.ok,true);assert.deepEqual(response.data,native_SQL.receipt);
  const outcome=JSON.parse(emitted('native-outcome.json'));assert.equal(outcome.native_receipt_metadata_validated,true);assert.deepEqual(outcome.native_receipt,native_SQL.receipt);
  for(const field of ['manager_approval','inventory_acknowledged','work_accepted','replay_allowed','finalizer_allowed','key_removal','phone_released'])assert.equal(outcome[field],false);
  if(preparationJoin){
   const response=JSON.parse(emitted('manager-preparation-http-response.bin'));
   const observed=JSON.parse(emitted('native-manager-preparation-outcome.json'));
   assert.equal(response.ok,true);assert.deepEqual(response.data,native_SQL.manager_preparation);
   assert.equal(observed.schema,'custodial.native-current-manager-preparation-observation.v1');
   assert.equal(observed.state,'CURRENT_ORIGINAL_MANAGER_PREPARATION_OBSERVED_NOT_EFFECT_AUTHORITY');
   assert.equal(observed.native_request_id,outcome.native_request_id);
   assert.deepEqual(observed.manager_preparation_observation,native_SQL.manager_preparation);
   // Newly changed owning Engine join: SAME original native inventory after
   // current-manager read, not a refreshed census or acceptance capability.
   const inventory=observed.original_native_inventory_observation;
   assert.equal(inventory.schema,'custodial.native-retained-eight-namespace-semantic-join.v1');
   assert.equal(inventory.namespaces.length,8);
   assert.deepEqual(inventory.namespaces.map(r=>r.namespace).sort(),[
    'MemphisZooCustodialNativeVaultV2','MemphisZooCustodialOfflineAuthorityTimeV1',
    'MemphisZooCustodialRetainedAttemptV1','MemphisZooCustodialRetainedReadQueryV1',
    'MemphisZooCustodialRetainedBatchV1','MemphisZooCustodialNativeProviderV1',
    'MemphisZooCustodialNativeVaultV1','WSSecureStorageSharedPreferences'].sort());
   assert.equal(inventory.record_count,inventory.records.length);
   assert.equal(inventory.namespaces.reduce((sum,r)=>sum+r.record_count,0),inventory.record_count);
   assert.equal(inventory.source_classified_record_count+inventory.unresolved_source_record_count,inventory.record_count);
   assert.equal(inventory.native_semantic_inventory_state,'UNKNOWN');assert.equal(inventory.browser_inventory_state,'UNKNOWN');
   for(const row of inventory.records){assert.equal(row.application_semantic_disposition,'UNKNOWN_RETAINED');
    for(const key of ['current_server_readback','inventory_acknowledged','work_accepted','resend_allowed','finalizer_allowed','key_removal'])assert.equal(row[key],false);}
   for(const key of ['complete_namespace_inventory','all_writer_durable_freeze_or_ABA_guard','current_server_readback',
    'inventory_acknowledged','work_accepted','new_work_allowed','resend_allowed','finalizer_allowed','key_removal','phone_released'])assert.equal(inventory[key],false);
   // Newly affected shipping join: actual native completion/session decoding
   // must describe THIS same original all8 owner after the manager-purpose
   // read. Local matches remain observations, not accepted inventory or ACK.
   const completions=observed.original_native_completion_observation;
   assert.equal(completions.schema,'custodial.native-all8-original-completion-reconciliation.v1');
   assert.equal(completions.state,'ALL8_EXACT_ROWS_WITH_ORIGINAL_NATIVE_COMPLETION_SEMANTICS_NOT_ACCEPTANCE');
   for(const key of ['source_capture_sha256','values_sha256','original_generation_id','principal_digest','engine_revision','record_count'])
    assert.equal(completions[key],inventory[key]);
   assert.equal(completions.original_source_join_sha256,inventory.semantic_join_sha256);
   assert.equal(completions.record_count,completions.records.length);
   assert.equal(completions.completion_semantic_joined_record_count,3*completions.matched_completion_count);
   assert.equal(completions.application_unresolved_record_count+completions.completion_semantic_joined_record_count,inventory.record_count);
   assert.deepEqual(completions.namespaces,inventory.namespaces);
   assert.deepEqual(completions.key_family_references,inventory.key_family_references);
   assert.deepEqual(completions.records.map(r=>[r.namespace,r.raw_identity_sha256]),inventory.records.map(r=>[r.namespace,r.raw_identity_sha256]));
   for(const row of completions.records){
    assert.equal(typeof row.application_semantic_disposition,'string');
    for(const key of ['current_server_readback','inventory_acknowledged','work_accepted','resend_allowed','finalizer_allowed','key_removal','cutoff_eligible','browser_source_authenticated'])assert.equal(row[key],false);
    if(row.native_completion_semantics)assert.equal(row.native_completion_semantics.automatic_acceptance,false);
   }
   for(const key of ['saved_source_join_layout_capsule_identity_rewritten','historical_snapshot_principal_verified','clock_profile_qualified',
    'durable_retention','all_writer_durable_freeze_or_ABA_guard','current_server_readback','complete_namespace_inventory','cutoff_eligible',
    'inventory_acknowledged','work_accepted','new_work_allowed','resend_allowed','finalizer_allowed','key_removal','phone_released','browser_source_authenticated'])assert.equal(completions[key],false);
   assert.equal(native_SQL.native_manager_preparation_reads,1);assert.equal(native_SQL.manager_SQL.issue_calls,1);
   for(const field of ['local_status_observation_persisted','network_dispatch_allowed','manager_approval','inventory_acknowledged','work_accepted','replay_allowed','finalizer_allowed','key_removal','phone_released'])assert.equal(observed[field],false);
   for(const p of pins)assert.equal(sha(fs.readFileSync(p.file)),p.sha256);
   await binding.verify();
   return {native_SQL,native_preparation:observed,nativeStatus,native_stdout_sha256:sha(stdout),native_stderr_sha256:sha(stderr),context_source:prepared.context_source,
    scope:'NEW_NATIVE_SAVED_ORIGINAL_CURRENT_SIGNED_SOURCE_MANAGER_PREPARATION_TO_ACTUAL_SQL_ONLY',real_manager:false,Android:false,native_TLS:false,ACK:false,finalizer:false,key_removal:false};
  }
  if(statusJoin){
   const response=JSON.parse(emitted('status-http-response.bin'));
   const observed=JSON.parse(emitted('native-status-outcome.json'));
   assert.equal(response.ok,true);assert.deepEqual(response.data,native_SQL.receipt);
   assert.equal(observed.schema,'custodial.native-same-original-challenge-status-observation.v1');
   assert.equal(observed.state,'ORIGINAL_REMOTE_REGISTRATION_OBSERVATION_NOT_APPROVAL');
   assert.equal(observed.native_request_id,outcome.native_request_id);
   assert.equal(observed.native_receipt_metadata_validated,true);
   assert.deepEqual(observed.native_receipt,native_SQL.receipt);
   for(const field of ['local_status_observation_persisted','network_dispatch_allowed','manager_approval','inventory_acknowledged','work_accepted','replay_allowed','finalizer_allowed','key_removal','phone_released'])assert.equal(observed[field],false);
   for(const p of pins)assert.equal(sha(fs.readFileSync(p.file)),p.sha256);
   await binding.verify();
   return {native_SQL,native_status:observed,nativeStatus,native_stdout_sha256:sha(stdout),native_stderr_sha256:sha(stderr),context_source:prepared.context_source,
    scope:'NEW_NATIVE_SAVED_ORIGINAL_SOURCE_STATUS_TO_ACTUAL_SQL_ONLY',real_manager:false,Android:false,native_TLS:false,ACK:false,finalizer:false,key_removal:false};
  }
  process.argv.push('--joined-manager-sql-new');
  const {createSameOriginalRecoveryManagerSqlFixture}=await import(pathToFileURL(backendRoot+'/scripts/same-original-recovery-manager-composition-tests.mjs'));
  managerGateway=await createSameOriginalRecoveryManagerSqlFixture({admin,backendRoot,challengeId:native_SQL.receipt.challenge_id});
  if(inventoryRegistrationJoin){
   const prefix='/admin-api/device-security/same-original-recovery',preview=await managerGateway.request(Object.freeze({method:'GET',path:prefix+'/challenges/'+managerGateway.challengeId}));
   const issuer=managerGateway.currentOwner();
   const body={schema:'custodial.same-original-recovery-approval-request.v1',request_id:randomUUID(),challenge_id:preview.challenge_id,
    expected_challenge_sha256:preview.challenge_sha256,expected_preview_sha256:preview.preview_sha256,expected_manager_id:issuer.manager_id,
    expected_manager_credential_id:issuer.manager_credential_id,expected_manager_device_id:issuer.manager_device_id,
    decision:preview.purpose,manager_confirmation:'CONFIRM_THIS_SAME_ORIGINAL_ONLY'};
   await managerGateway.request(Object.freeze({method:'POST',path:prefix+'/approvals',body}));
   if(!inventoryManifestChunks)await managerGateway.request(Object.freeze({method:'POST',path:prefix+'/approvals/original-status',body}));
   let manager_SQL,managerArguments=null;
   if(inventoryManifestChunks){
    // Existing original approval is ONLY setup for this NEW chunk case.
    // Do not run the older status workflow just to satisfy its finish verdict.
    const rows=(await admin.query('select original_request_utf8 from public.custodial_same_original_recovery_approvals where challenge_id=$1',[managerGateway.challengeId])).rows;
    assert.equal(rows.length,1);assert.equal(rows[0].original_request_utf8,JSON.stringify(body));
    manager_SQL={scope:'MINIMAL_ORIGINAL_PARENT_APPROVAL_PREREQUISITE_NOT_OLD_STATUS_REQUALIFICATION',rows:1,genuine_manager:false};
    if(inventoryManifestManagerSource||inventoryManifestSemanticReview){
     // Actual auth/issue fixture supplies this immutable original owner tuple;
     // no new session/token/role and no unrelated provider/grant effect.
     const m=(await admin.query('select manager_id,manager_credential_id,manager_device_id,signed_session_expires_at,security_session_id,security_password_version,security_token_hash,security_csrf_hash from public.custodial_same_original_recovery_approvals where challenge_id=$1',[managerGateway.challengeId])).rows;
     assert.equal(m.length,1);managerArguments=['manager_id','manager_credential_id','manager_device_id','signed_session_expires_at',
      'security_session_id','security_password_version','security_token_hash','security_csrf_hash'].map(k=>m[0][k]);
    }
   }else manager_SQL=await managerGateway.finish();
   await managerGateway.close();managerGateway=null;
   const {qualifyNativeInventoryRegistrationStatusJoin}=await import(pathToFileURL(backendRoot+'/scripts/native-original-inventory-request-sql-tests.mjs'));
   let confirmationGuardBaseline=null;
   if(inventoryConfirmationGuard){
    const old=fs.readFileSync(backendRoot+'/supabase/migrations/20261016095134_native_original_inventory_request_registration.sql','utf8');
    assert.equal(sha(old),'c0d0f2b0aa9bd7a98adeb4b7a460256c2cc57b5edd748fdf3778504bf9fd7041');
    const start=old.indexOf('CREATE FUNCTION custodial_recovery.register_native_inventory_request_once('),end=old.indexOf('END $fn$;',start);
    assert.ok(start>0&&end>start);confirmationGuardBaseline=old.slice(start,end+'END $fn$;'.length).replace('CREATE FUNCTION ','CREATE OR REPLACE FUNCTION ');
   }
   const inventory_SQL=await qualifyNativeInventoryRegistrationStatusJoin({admin,target:preview.original_target,
    preparationBody:emitted('request.bin'),preparationHeaders:JSON.parse(emitted('native-headers.json')),confirmationGuardBaseline,manifestChunksOnly:inventoryManifestChunks,manifestStatusOnly:inventoryManifestStatus,
    manifestManagerSourceOnly:inventoryManifestManagerSource,manifestSemanticReviewOnly:inventoryManifestSemanticReview,managerDecisionOnly:inventoryManagerDecision,managerDecisionHttpOnly:inventoryManagerDecisionHttp,managerArguments});
   for(const p of pins)assert.equal(sha(fs.readFileSync(p.file)),p.sha256);
   await preflightSameOriginalNativeInputs(backendRoot);
   return {native_SQL,manager_SQL,inventory_SQL,nativeStatus,native_stdout_sha256:sha(stdout),native_stderr_sha256:sha(stderr),context_source:prepared.context_source,
    scope:inventoryManagerDecisionHttp?'NEW283_CURRENT_NATIVE_DECISION_HTTP_ACTUAL_FIXED_SQL_READ_ONLY_NOT_NATIVE_ACK':inventoryManagerDecision?'NEW283_ONE_ORIGINAL_MANAGER_DECISION_SQL_LOST_REPLY_FIXED_STATUS_NOT_NATIVE_ACK_OR_FINALIZER':inventoryManifestSemanticReview?'NEW282_CURRENT_MANAGER_PENDING_INVENTORY_SQL_REVIEW_AND_STORE_JOIN_NOT_ACCEPTED_ACK_OR_FINALIZER':inventoryManifestManagerSource?'NEW281_CURRENT_MANAGER_READ_ONLY_MANIFEST_SOURCE_NOT_REVIEW_OR_ACK':inventoryManifestStatus?'NEW280_SIGNED_HTTP_SQL_LOST_CHUNK_REPLY_READ_ONLY_STATUS_NOT_NATIVE_ISSUER_SEMANTIC_REVIEW_OR_ACK':inventoryManifestChunks?'NEW280_ORIGINAL_MANIFEST_CHUNKS_SQL_AUTH_CUSTODY_NOT_NATIVE_ISSUER_SEMANTIC_REVIEW_OR_ACK':'NEW_ACTUAL_SQL_INVENTORY_REGISTRATION_STATUS_WITH_SYNTHETIC_INVENTORY_DATA_NOT_NATIVE_PRIVATE_ISSUER',
    real_manager:false,Android:false,native_TLS:false,ACK:false,finalizer:false,key_removal:false};
  }
  const {sameOriginalRecoveryPageHttpSqlJoin}=await import(pathToFileURL(path.dirname(backendRoot)+'/frontend/scripts/same-original-recovery-page-tests.mjs'));
  const manager_page=await sameOriginalRecoveryPageHttpSqlJoin({request:managerGateway.request,currentOwner:managerGateway.currentOwner,challengeId:managerGateway.challengeId});
  const manager_SQL=await managerGateway.finish();await managerGateway.close();managerGateway=null;
  for(const p of pins)assert.equal(sha(fs.readFileSync(p.file)),p.sha256);
  await preflightSameOriginalNativeInputs(backendRoot);
  return {native_SQL,manager_page,manager_SQL,nativeStatus,native_stdout_sha256:sha(stdout),native_stderr_sha256:sha(stderr),context_source:prepared.context_source,
   scope:'NEW_NATIVE_SOURCE_FACADE_ACTUAL_SQL_NORMAL_AUTH_MANAGER_SOURCE_DOM_ORIGINAL_ROUNDTRIP',real_manager:false,Android:false,native_TLS:false,ACK:false,finalizer:false,key_removal:false};
 }catch(error){
  let first_current_packet=null;
  if(fs.existsSync(golden+'/current-first-envelope.json')){
   const packet=JSON.parse(emitted('current-first-envelope.json'));
   assert.equal(packet.schema,'custodial.test-native-sql-first-current-envelope.v1');
   assert.equal(packet.classification,'SOURCE_LOOPBACK_NOT_TLS_OR_APPROVAL');assert.equal(packet.method,'POST');
   assert.equal(new URL(packet.native_url).pathname,'/device-auth/private-custody-current-read');
   assert.deepEqual(packet.files.map(f=>f.path),['current-first-envelope.bin','current-first-envelope.headers.json']);
   for(const f of packet.files)emitted(f.path,f);
   first_current_packet={root:golden,files:packet.files,native_request_timestamp:packet.native_request_timestamp,
    classification:packet.classification};
  }
  // finish() exposes the retained prerequisite failure; never use this
  // diagnostic as a receipt, a fallback read, or a retry authority.
  let native_gateway_failure=null;
  if(nativeGateway)try{await nativeGateway.finish();}catch(gatewayError){
   native_gateway_failure={name:gatewayError.name,code:gatewayError.code,operator:gatewayError.operator,
    message:String(gatewayError.message??'').slice(0,500),
    SQL_function_frames:typeof gatewayError.where==='string'?gatewayError.where.split('\n').filter(line=>line.startsWith('PL/pgSQL function ')).slice(0,8):[],
    native_gateway_diagnostic:gatewayError.native_gateway_diagnostic??null,
    source_frames:String(gatewayError.stack??'').split('\n').filter(line=>/^\s+at /.test(line)).slice(0,12)};
  }
  put('NATIVE_SQL_JOIN_FAILURE.json',{message:String(error.message).slice(0,500),code:error.code,nativeStatus,stdout_sha256:sha(stdout),stderr_sha256:sha(stderr),
   stdout_tail:stdout.slice(-2000),stderr_tail:stderr.slice(-2000),
   native_failure_frames:stderr.split('\n').filter(line=>/^G08_CHANGED_FAILURE_(CLASS|CODE|AT) /.test(line)).slice(0,80),
   native_gateway_failure,first_current_packet,originals_retained:own,packet_parent_retained:packetParent,manager_join_evidence:error.joinEvidence??null,product_PASS:false});
  throw error;
 }finally{
  clearTimeout(timer);if(child&&!childClosed){child.kill('SIGTERM');await done.catch(()=>{});}
  if(managerGateway)await managerGateway.close();if(nativeGateway)await nativeGateway.close();
  for(const b of loans)b.fill(0);
  const s=fs.lstatSync(own);assert.equal(s.dev,ownStat.dev);assert.equal(s.ino,ownStat.ino);assert.equal(s.isSymbolicLink(),false);
  const ps=fs.lstatSync(packetParent);assert.equal(ps.dev,packetStat.dev);assert.equal(ps.ino,packetStat.ino);assert.equal(ps.isSymbolicLink(),false);
  put('NATIVE_SQL_JOIN_RESOURCES.json',{native_closed:!child||childClosed,gateways_closed:true,retained_owned_root:own,retained_packet_parent:packetParent,borrowed_admin_closed_by_parent:true,protected_fixture_data_retained:true});
 }
}

