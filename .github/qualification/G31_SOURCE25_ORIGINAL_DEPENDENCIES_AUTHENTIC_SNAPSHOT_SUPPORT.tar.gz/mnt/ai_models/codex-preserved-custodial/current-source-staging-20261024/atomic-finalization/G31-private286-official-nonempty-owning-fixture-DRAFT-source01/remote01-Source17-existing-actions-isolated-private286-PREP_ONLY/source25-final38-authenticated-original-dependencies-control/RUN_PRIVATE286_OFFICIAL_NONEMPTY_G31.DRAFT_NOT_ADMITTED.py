#!/usr/bin/env python3
"""Root-only maintained npm lock generation; no tests, app build or publication."""
from pathlib import Path
import argparse,json,hashlib,subprocess,os,errno,resource,selectors,signal,stat,sys,time
MEM_MIN=2*1024**3
MAX_FILE=16*1024**2
class Refusal(Exception):
    pass

class CustodyUnknown(Exception):
    pass

def require(value, message):
    if not value:
        raise Refusal(message)

def nine(s):
    return [s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid, s.st_nlink,
            s.st_size, s.st_mtime_ns, s.st_ctime_ns]

def safe_relative(value):
    require(isinstance(value, str) and value and not value.startswith('/')
            and all(p not in ('', '.', '..') for p in value.split('/')),
            'exact repository-relative path required')
    return value

def no_link_path(path):
    path = Path(path)
    require(path.is_absolute(), 'absolute path required')
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        require(not stat.S_ISLNK(current.lstat().st_mode), 'symlink path refused: ' + str(current))
    return path

def read_file(path, expected=None, limit=MAX_FILE):
    path = no_link_path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
            and before.st_size <= limit, 'regular bounded single-link input required: ' + str(path))
    if expected is not None:
        require(before.st_size == expected['bytes'], 'input expected length changed')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        require(nine(os.fstat(fd)) == nine(before), 'birth FD mismatch')
        chunks, remaining = [], before.st_size + 1
        while remaining:
            block = os.read(fd, min(65536, remaining))
            if not block:
                break
            chunks.append(block)
            remaining -= len(block)
        body = b''.join(chunks)
        require(len(body) == before.st_size and nine(before) == nine(os.fstat(fd))
                == nine(path.lstat()), 'read identity/EOF mismatch')
    finally:
        os.close(fd)
    ref = {'path': str(path), 'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}
    if expected is not None:
        require(ref == expected, 'input full ref mismatch')
    return body, ref, nine(before)

def write_new(path, body, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    no_link_path(path.parent)
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    try:
        at = 0
        while at < len(body):
            wrote = os.write(fd, body[at:])
            require(wrote > 0, 'short output write')
            at += wrote
        os.fchmod(fd, mode)
        os.fsync(fd)
    finally:
        os.close(fd)
    actual, ref, _ = read_file(path, limit=max(MAX_FILE, len(body)))
    require(actual == body, 'output readback mismatch')
    return ref

def available():
    return int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                    if line.startswith('MemAvailable:'))) * 1024

def absent(pid):
    for action in (os.kill, os.killpg):
        try:
            action(pid, 0)
        except ProcessLookupError as error:
            require(error.errno == errno.ESRCH, 'wrong absence errno')
        else:
            raise CustodyUnknown('owned PID/PGID remains')
    try:
        os.lstat('/proc/' + str(pid))
    except FileNotFoundError as error:
        require(error.errno == errno.ENOENT, 'wrong proc absence errno')
    else:
        raise CustodyUnknown('owned proc remains')

def bounded_run(directory, number, argv, cwd, env, seconds=60, cleanup=2, cap=1024**2):
    prefix = str(number).zfill(2)
    capacity = available()
    receipt_js(directory, prefix + '-CAPACITY_BEFORE_COMPARISON.json', {'MemAvailable_bytes': capacity, 'minimum': MEM_MIN})
    require(capacity >= MEM_MIN, 'scoped2GiB capacity refused before child')
    cpu = min(os.sched_getaffinity(0))
    receipt_js(directory, prefix + '-INTENT.json', {'argv': argv, 'cwd': str(cwd), 'CPU1': cpu,
        'work_seconds': seconds, 'cleanup_seconds': cleanup, 'stream_cap_each': cap,
        'actual_wait': None, 'payload_read_before_custody': False})
    outp, errp = directory / (prefix + '.stdout'), directory / (prefix + '.stderr')
    output_fds = [os.open(p, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
                  for p in (outp, errp)]
    def setup():
        os.umask(0o077)
        os.sched_setaffinity(0, {cpu})
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    started = time.monotonic()
    child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True, preexec_fn=setup)
    selector = selectors.DefaultSelector()
    lengths, reason, term_at, killed = [0, 0], None, None, False
    memory_minimum, drain_deadline = capacity, started + seconds + cleanup
    birth_fields=None
    try:
        birth_stat=Path('/proc/'+str(child.pid)+'/stat').read_text();birth_fields=birth_stat[birth_stat.rindex(')')+2:].split();birth_pgid=os.getpgid(child.pid);require(birth_pgid==child.pid,'owned original child PGID mismatch')
        receipt_js(directory, prefix + '-OWNED_CHILD.json', {'pid': child.pid, 'pgid': birth_pgid, 'proc_start_ticks':int(birth_fields[19]), 'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(), 'actual_wait': None})
        selector.register(child.stdout, selectors.EVENT_READ, 0)
        selector.register(child.stderr, selectors.EVENT_READ, 1)
        while selector.get_map() or child.poll() is None:
            now = time.monotonic()
            mem = available()
            memory_minimum = min(memory_minimum, mem)
            if reason is None and now - started >= seconds:
                reason = 'WORK_TIMEOUT'
            if reason is None and mem < MEM_MIN:
                reason = 'SCOPED_MEMORY_FLOOR'
            if reason is not None and term_at is None:
                receipt_js(directory, prefix + '-DURABLE_REFUSAL_BEFORE_SIGNAL.json', {
                    'pid': child.pid, 'pgid': child.pid, 'proc_start_ticks': int(birth_fields[19]),
                    'refusal_reason': reason, 'seconds': now - started,
                    'work_seconds': seconds, 'MemAvailable_bytes': mem,
                    'MemAvailable_min_bytes': memory_minimum, 'minimum_required_bytes': MEM_MIN,
                    'stream_bytes_captured': lengths, 'payload_adopted': False,
                    'signal_not_yet_sent': True})
                try: os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError: pass
                term_at = now
            if term_at is not None and not killed and now - term_at >= max(0.1, cleanup - 1):
                try: os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError: pass
                killed = True
            for key, _ in selector.select(0.05):
                chunk = os.read(key.fileobj.fileno(), 65536)
                if not chunk:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                index = key.data
                keep = chunk[:max(0, cap - lengths[index])]
                pos = 0
                while pos < len(keep):
                    pos += os.write(output_fds[index], keep[pos:])
                lengths[index] += len(keep)
                if len(keep) != len(chunk) and reason is None:
                    reason = 'STREAM_LIMIT'
            if now > drain_deadline:
                raise CustodyUnknown('bounded child/pipe settlement exceeded; no payload adoption')
        try:
            observed = child.wait(timeout=1)
        except subprocess.TimeoutExpired as error:
            raise CustodyUnknown('actual wait unresolved') from error
        receipt_js(directory, prefix + '-ORIGINAL_HOST_WAIT_BEFORE_DESCENDANT_RECONCILIATION.json', {
            'pid': child.pid, 'pgid': child.pid, 'proc_start_ticks': int(birth_fields[19]),
            'actual_wait_returned': True, 'observed_exit': observed, 'payload_adopted': False})
        if number == 1 and callable(globals().get('reconcile_owned_descendants')):
            reconcile_owned_descendants()
        absent(child.pid)
        fence = receipt_js(directory, prefix + '-ACTUAL_WAIT_AND_FRESH_ABSENCE_BEFORE_PAYLOAD.json', {
            'pid': child.pid, 'pgid': child.pid, 'proc_start_ticks':int(birth_fields[19]), 'actual_wait_returned': True,
            'observed_exit': observed, 'refusal_reason': reason, 'term_sent': term_at is not None,
            'kill_sent': killed, 'fresh_PID_PGID_ESRCH_proc_ENOENT': True,
            'seconds': time.monotonic() - started, 'MemAvailable_min_bytes': memory_minimum,
            'payload_read_before_fence': False, 'stream_bytes_captured': lengths})
    except BaseException as error:
        # Preserve the original refusal before exceptional settlement can mask it.
        receipt_js(directory, prefix + '-EXCEPTION_ORIGINAL_REASON_BEFORE_CUSTODY.json', {
            'pid': child.pid, 'pgid': child.pid,
            'proc_start_ticks': int(birth_fields[19]) if birth_fields else None,
            'original_exception_class': type(error).__name__, 'original_exception_message': str(error),
            'refusal_reason': reason, 'seconds': time.monotonic() - started,
            'work_seconds': seconds, 'MemAvailable_min_bytes': memory_minimum,
            'minimum_required_bytes': MEM_MIN, 'term_sent': term_at is not None,
            'kill_sent': killed, 'stream_bytes_captured': lengths, 'payload_adopted': False})
        # No payload adoption after exceptional control flow. Settle this exact born group.
        try: os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        try:
            observed=child.wait(timeout=cleanup)
            if number == 1 and callable(globals().get('reconcile_owned_descendants')):
                reconcile_owned_descendants()
            absent(child.pid)
            receipt_js(directory,prefix+'-EXCEPTION_ACTUAL_WAIT_AND_FRESH_ABSENCE.json',{
                'pid':child.pid,'pgid':child.pid,'proc_start_ticks':int(birth_fields[19]) if birth_fields else None,
                'actual_wait_returned':True,'observed_exit':observed,
                'fresh_PID_PGID_ESRCH_proc_ENOENT':True,'payload_adopted':False,
                'exception_class':type(error).__name__})
        except BaseException as custody_error:
            receipt_js(directory,prefix+'-CUSTODY_UNKNOWN_NO_PAYLOAD.json',{
                'pid':child.pid,'pgid':child.pid,'payload_adopted':False,
                'exception_class':type(custody_error).__name__})
            raise CustodyUnknown('exceptional original-child settlement unresolved') from custody_error
        raise
    finally:
        selector.close()
        for fd in output_fds:
            os.fsync(fd)
            os.close(fd)
    # All pipe contents are retained only as opaque bounded bytes until this fence.
    output, outr, _ = read_file(outp, limit=cap)
    errors, errr, _ = read_file(errp, limit=cap)
    return {'argv': argv, 'cwd': str(cwd), 'fence': fence, 'observed_exit': observed,
            'refusal_reason': reason, 'stdout': outr, 'stderr': errr}, output, errors
def receipt_js(directory,name,value):
    return write_new(directory/name,(json.dumps(value,indent=2)+'\n').encode())

# Narrow existing v146 lifecycle; original286 schema and current c088 CLI are separate inputs.
import ctypes,uuid,shutil,re,tempfile
CFG={'path': '/mnt/ai_models/codex-preserved-custodial/current-source-staging-20261024/atomic-finalization/G31-private286-official-nonempty-owning-fixture-DRAFT-source01/remote01-Source17-existing-actions-isolated-private286-PREP_ONLY/source25-final38-authenticated-original-dependencies-control/FIXED_PRIVATE286_OFFICIAL_NONEMPTY_INPUTS.DRAFT.json', 'sha256': '2161041c0e43533e818c0882374fd9d0a1ee2423e856fb1bfb4f74c1069d836f', 'bytes': 13814}
IMAGE='supabase/postgres@sha256:fbf77524fc188126c1775fd2d2e54040bde295438a3e6f07936f3c39e6f688ed'
OWNED_GROUPS=set()
D=None
START=None
SEQ=0
ENV=None
SOURCE=None
CLOSING=False
BOUND_IMAGE_ID=None

def exact(r):return read_file(r['path'],expected=r,limit=max(MAX_FILE,r['bytes']))[0]
def js(r):return json.loads(exact(r))
def proc(pid):
    raw=Path('/proc',str(pid),'stat').read_text();f=raw[raw.rindex(')')+2:].split()
    return {'pid':pid,'ppid':int(f[1]),'pgid':int(f[2]),'start_ticks':int(f[19])}
def retain_unregistered_child_refusal(q,known_groups):
    try:
        r={'observed_proc':q,'own_parent':proc(os.getpid()),'known_group_ids':sorted(known_groups),
           'no_signal_or_payload_adoption':True,'original_refusal_preserved':True,
           'observed_monotonic':time.monotonic()}
        p=Path('/proc',str(q['pid']))
        try:
            raw=(p/'stat').read_text();f=raw[raw.rindex(')')+2:].split();r['state']=f[0]
            r['comm']=(p/'comm').read_text()[:128].rstrip('\n')
            status=(p/'status').read_text()[:16384].splitlines()
            r['process_ids']={line.split(':',1)[0]:line.split(':',1)[1].split()[:10]
                              for line in status if line.startswith(('Uid:','Gid:','NSpid:'))}
            try:
                e=p/'exe';s=e.stat();r['exe_identity']={'path':os.readlink(e)[:4096],
                    'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'bytes':s.st_size}
            except OSError as e:r['exe_identity']={'unavailable_errno':e.errno}
            r['same_PID_start_after_metadata']=proc(q['pid'])==q
        except (OSError,ValueError) as e:r['metadata_unavailable_class']=type(e).__name__
        name='UNREGISTERED_CHILD_REFUSAL_'+str(q['pid'])+'_'+str(q['start_ticks'])+'.json'
        if not (D/name).exists():receipt_js(D,name,r)
    except BaseException:
        pass # Metadata refusal can never replace or relax the original guard.

def reconcile_owned_descendants():
    # Only children adopted by this subreaper from its recorded owned groups.
    deadline=time.monotonic()+2;settled=[]
    for p in D.glob('command-*/01-OWNED_CHILD.json'):
        OWNED_GROUPS.add(json.loads(p.read_bytes())['pgid'])
    while True:
        children=[]
        for p in Path('/proc').iterdir():
            if not p.name.isdigit():continue
            try:q=proc(int(p.name))
            except (FileNotFoundError,ProcessLookupError):continue
            if q['ppid']==os.getpid():
                if q['pgid'] not in OWNED_GROUPS:retain_unregistered_child_refusal(q,OWNED_GROUPS)
                require(q['pgid'] in OWNED_GROUPS,'foreign direct/adopted child refuses reconciliation')
                children.append(q)
        if not children:break
        for q in children:
            pid,status=os.waitpid(q['pid'],os.WNOHANG)
            if pid:settled.append(q|{'actual_waitpid':pid,'status':status})
        require(time.monotonic()<deadline,'owned adopted descendant settlement timeout')
        if children:time.sleep(.02)
    receipt_js(D,'DESCENDANTS-'+uuid.uuid4().hex+'.json',{'settled':settled,'all_direct_adopted_children_absent':True})
def invoke(label,argv,cap=8,allow=False):
    global SEQ,MEM_MIN
    remaining=(1845 if CLOSING else 1800)-(time.monotonic()-START)
    require(remaining>2,'original whole lifecycle allowance exhausted')
    SEQ+=1;sub=D/('command-'+str(SEQ).zfill(3)+'-'+label);sub.mkdir(mode=0o700)
    # bounded_run persists original wait first, then callback reaps adopted children, then absence.
    # Birth/intent receipts are opaque private0600; only synthetic ephemeral UNIT values are supplied.
    original_floor=MEM_MIN
    if CLOSING:
        require(label in ('exact-inspect','remove-exact-CID','owned-network-inspect','owned-network-remove','owned-network-absence') and argv[:3]==['/usr/bin/docker','--host','unix:///var/run/docker.sock'] and argv[3] in ('inspect','rm','network'),'closing permits exact owned inspect/removal only')
        MEM_MIN=0
    try:
        row,out,err=bounded_run(sub,1,argv,SOURCE,ENV,seconds=min(cap,max(1,remaining-2)),cleanup=2,cap=1024**2)
    finally:
        MEM_MIN=original_floor
    require(row['refusal_reason'] is None,'bounded command refusal')
    receipt_js(sub,'SETTLED.json',row)
    if not allow:require(row['observed_exit']==0,'first owning command failed: '+label)
    return row,out,err
def docker(label,args,cap=8,allow=False):return invoke(label,['/usr/bin/docker','--host','unix:///var/run/docker.sock',*args],cap,allow)
def inspect_exact(cid,name,fixture,socket,allow_absent=False):
    target=cid or name
    fmt='{"Id":{{json .Id}},"Name":{{json .Name}},"Image":{{json .Image}},"ConfigImage":{{json .Config.Image}},"Labels":{{json .Config.Labels}},"Network":{{json .HostConfig.NetworkMode}},"Privileged":{{json .HostConfig.Privileged}},"Ports":{{json .HostConfig.PortBindings}},"Tmpfs":{{json .HostConfig.Tmpfs}},"Mounts":{{json .Mounts}},"Memory":{{json .HostConfig.Memory}},"NanoCpus":{{json .HostConfig.NanoCpus}},"PidsLimit":{{json .HostConfig.PidsLimit}},"Cmd":{{json .Config.Cmd}}}'
    row,out,err=docker('exact-inspect',['inspect','--format',fmt,target],allow=True)
    if row['observed_exit']:
        message=err.decode().strip().lower()
        require(allow_absent and message in ('error: no such object: '+target.lower(),'error: no such container: '+target.lower()),'unknown Docker absence refuses')
        return None
    o=json.loads(out);require((cid is None or o['Id']==cid)and re.fullmatch('[a-f0-9]{64}',o['Id']),'exact durableCID changed')
    require(o['Name']=='/'+name and o['Image']==BOUND_IMAGE_ID and o['ConfigImage']==IMAGE,'name/image changed')
    require(o['Labels'].get('custodial.fixture-id')==fixture and o['Labels'].get('custodial.owner')=='overnight-held-correction-product-sql-effect','birth owner mismatch')
    require(o['Network']==NETWORK_NAME and not o['Privileged']and not o['Ports']and o['Tmpfs']=={'/var/lib/postgresql/data':'rw,size=1g'},'containment changed')
    require(len(o['Mounts'])==1 and o['Mounts'][0]['Source']==str(socket)and o['Mounts'][0]['Destination']=='/tmp/owned-socket','socket mount changed')
    require(o['Memory']==1024**3 and o['NanoCpus']==1000000000 and o['PidsLimit']==256 and 'listen_addresses=*'in o['Cmd'],'exact bounded provider PG resources/config changed')
    return o

def main():
    global D,START,ENV,SOURCE,CLOSING,BOUND_IMAGE_ID,NETWORK_NAME
    ap=argparse.ArgumentParser();ap.add_argument('--Root-admission',required=True);args=ap.parse_args()
    cfg=js(CFG);ad=json.loads(read_file(Path(args.Root_admission))[0]);own=read_file(Path(__file__).resolve())[1]
    require(ad['state']=='ROOT_ADMITS_PRIVATE286_OFFICIAL_NONEMPTY_PROVIDER_DISPOSABLE_ONLY'and ad['operator_sha256']==own['sha256']and ad['fixed_inputs']==CFG and ad['Root_sole_child_owner'] is True,'exact Root execution admission required')
    require(ad['no_production_provider_build_device_authority'] is True,'scope fence required')
    out=Path(ad['output']);require(out.parent==Path(__file__).resolve().parent and not os.path.lexists(out),'new immediate private output only')
    D=out;D.mkdir(mode=0o700);START=time.monotonic();SOURCE=D/'current-unpublished-selected-source';SOURCE.mkdir(mode=0o700)
    # Installing subreaper capability is process-local custody, never a service or cloud change.
    require(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'subreaper refused')
    receipt_js(D,'ROOT_SELECTION_BEFORE_ANY_CHILD_BIRTH.json',{'admission':ad,'operator':own,'fixed_inputs':CFG,'pid':os.getpid(),'proc':proc(os.getpid()),'source_only_local_disposable':True})
    m=js(cfg['current_candidate_map']);rows=m['rows'];require(len(rows)==cfg['authority_count']==1111 and m['authority_count']==1111 and m['pre_generation_authority_tree_NOT_actual_published_tree']==cfg['current_candidate_tree_NOT_ACTUAL_COMMIT'],'exact unpublished current candidate source mismatch')
    require(js(cfg['current_candidate_owner_result'])['frame']==cfg['current_candidate_map'],'candidate owner map binding differs')
    for n,pin in cfg['selected_current_G31_product_afters'].items():require(next(r for r in rows if r['logical_path']==n)['full_raw_ref']==pin,'selected G31 source counterpart differs')
    for r in rows:
        b=exact(r['full_raw_ref']);require(hashlib.sha256(b).hexdigest()==r['sha256']and len(b)==r['bytes']and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_blob_sha1'],'source raw tuple mismatch')
        write_new(SOURCE/safe_relative(r['logical_path']),b,0o755 if r['mode']=='100755'else 0o644)
    proof=js(cfg['original286_schema_proof']);require(proof['all286_exact_git_manifest_and_ledger_statement_bytes'] is True and len(proof['rows'])==286,'authentic original286 proof required')
    for r in proof['rows']:exact(r['raw_body'])
    require(js(cfg['historical_artifact_fixture_NOT_current_authority'])['authority_content_identity']['authority_path_count']==1098,'genuine historical physical artifact fixture required')
    write_new(SOURCE/'release/integrated-backend-authority-evidence.json',exact(cfg['historical_artifact_fixture_NOT_current_authority']),0o644)
    for n,h in cfg['sevenCLI_current_literal_sha256'].items():require(hashlib.sha256((SOURCE/safe_relative(n)).read_bytes()).hexdigest()==h,'seven CLI source differs')
    for n in cfg['sevenCLI_names']:require(any(r['logical_path']==n for r in rows),'missing CLI input')
    exact(cfg['node_tool']);exact(cfg['dependency_graph_lock']);graph=Path(cfg['dependency_graph']);require(graph.is_dir()and not(SOURCE/'node_modules').exists(),'exact dependency graph absent')
    qualifier=D/'qualify-private286-nonempty.mjs';write_new(qualifier,exact(cfg['qualifier_adapter']));write_new(D/'initialize-private286-official-storage-source.mjs',exact(cfg['source_initializer']))
    runtime=no_link_path(Path('/run/user')/str(os.getuid()));rs=runtime.lstat()
    require(stat.S_ISDIR(rs.st_mode)and rs.st_uid==os.getuid()and stat.S_IMODE(rs.st_mode)==0o700,'private owned runtime directory required')
    parent=None;socket=None;socket_ids=[]
    NETWORK_NAME=None;network_id=None;network_born=False
    fixture=uuid.uuid4().hex;name='mz_schema_rebuild_held_product_'+fixture[:16];cid=None;birth_attempted=False;failure=None;closed={};bootstrap=uuid.uuid4().hex+uuid.uuid4().hex
    ENV={'PATH':str(Path(cfg['node_tool']['path']).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','HOME':str(D),'TMPDIR':str(D),'NODE_OPTIONS':'--max-old-space-size=384','NODE_DISABLE_COMPILE_CACHE':'1'}
    try:
        # Cleanup is armed BEFORE either short runtime directory can be born.
        parent=Path(tempfile.mkdtemp(prefix='mz-g31-',dir=runtime))
        parent_birth=parent.lstat();socket_ids.append((str(parent),nine(parent_birth)))
        require(stat.S_ISDIR(parent_birth.st_mode)and not parent.is_symlink()and parent_birth.st_uid==os.getuid()and stat.S_IMODE(parent_birth.st_mode)==0o700,'new private socket-parent identity mismatch')
        receipt_js(D,'SOCKET_PARENT_BIRTH_ARMED_FOR_CLEANUP.json',{'parent':str(parent),'identity9':nine(parent_birth),'cleanup_armed_before_birth':True})
        socket=parent/'socket';socket.mkdir(mode=0o777)
        socket_birth=socket.lstat();socket_ids.append((str(socket),nine(socket_birth)))
        require(stat.S_ISDIR(socket_birth.st_mode)and not socket.is_symlink()and socket_birth.st_uid==os.getuid(),'new socket identity mismatch')
        socket.chmod(0o777)
        require(len(os.fsencode(socket/'.s.PGSQL.5432'))<108,'Unix socket pathname exceeds native AF_UNIX bound')
        receipt_js(D,'SHORT_SOCKET_RUNTIME_PARENT.json',{'runtime':str(runtime),'runtime_identity9':nine(rs),'parent':str(parent),'parent_identity9':nine(parent.lstat()),'socket_path_bytes':len(os.fsencode(socket/'.s.PGSQL.5432')),'private_parent0700':True})
        os.symlink(graph,SOURCE/'node_modules',target_is_directory=True)
        _,image,_=docker('image-id',['image','inspect',IMAGE,'--format','{{.Id}}']);BOUND_IMAGE_ID=image.decode().strip();require(re.fullmatch('sha256:[a-f0-9]{64}',BOUND_IMAGE_ID),'actual cached image config ID malformed');receipt_js(D,'ACTUAL_CACHED_IMAGE_ID_BOUND_BEFORE_CONTAINER_BIRTH.json',{'exact_image_ref':IMAGE,'actual_config_image_ID':BOUND_IMAGE_ID,'inspection':'exact pinned ref image inspect .Id; not assumed RepoDigest equivalence'})
        _,cmd,_=docker('image-cmd',['image','inspect',IMAGE,'--format','{{json .Config.Cmd}}']);require(cmd.decode().strip()=='["postgres","-D","/etc/postgresql"]','original cached image command changed')
        # Build a NEW original source, never mutate/re-sign retained58753 input.
        NETWORK_NAME='mz_schema_rebuild_storage_source_'+fixture[:20]
        _,net,_=docker('source-network-create',['network','create','--internal','--label','custodial.storage-source='+NETWORK_NAME,NETWORK_NAME]);network_id=net.decode().strip();require(re.fullmatch('[a-f0-9]{64}',network_id),'network ID');network_born=True
        ENV['G31_PRIVATE_SOURCE_NETWORK']=NETWORK_NAME;ENV['G31_PRIVATE_SOURCE_NETWORK_ID']=network_id
        oldsource=Path(cfg['original_source_root']);originaltuples=js(cfg['original_source_fulltuples']);require(originaltuples['commit']=='b20499c6a98b90db1779fe5d0060b619bceae261','original source commit')
        for row in originaltuples['rows']:exact(row['full_raw_ref'])
        require(not os.path.lexists(oldsource/'node_modules'),'historical source graph name already present');os.symlink(graph,oldsource/'node_modules',target_is_directory=True)
        sourceout=D/'source-capture';sourceout.mkdir(mode=0o700)
        require(available()>=4*1024**3,'fresh4GiB floor before source PG birth')
        _,born,_=docker('source-create',['create','--pull','never','--network',NETWORK_NAME,'--name',name,'--label','custodial.owner=overnight-held-correction-product-sql-effect','--label','custodial.fixture-id='+fixture,'--label','org.memphiszoo.custodial.fixture=synthetic','--label','org.memphiszoo.custodial.owner=/root','--label','org.memphiszoo.custodial.fixture-id='+str(uuid.UUID(hex=fixture)),'--cpus','1','--memory','1g','--pids-limit','256','--tmpfs','/var/lib/postgresql/data:rw,size=1g','--mount','type=bind,source='+str(socket)+',target=/tmp/owned-socket','-e','POSTGRES_PASSWORD='+bootstrap,'-e','PGPASSWORD='+bootstrap,'-e','POSTGRES_DB=postgres',IMAGE,'-c','cron.database_name=postgres','-c','shared_preload_libraries=pg_cron,pg_net,pg_stat_statements','-c','listen_addresses=*','-c','unix_socket_directories=/var/run/postgresql,/tmp/owned-socket'])
        cid=born.decode().strip();birth_attempted=True;require(re.fullmatch('[a-f0-9]{64}',cid),'source exactCID');receipt_js(D,'SOURCE_DURABLE_CID.json',{'CID':cid,'network':NETWORK_NAME,'source_fixture_only':True});inspect_exact(cid,name,fixture,socket);docker('source-start',['start',cid])
        invoke('source-ready',[cfg['node_tool']['path'],'--max-old-space-size=384',str(qualifier),str(socket),str(oldsource),str(sourceout),bootstrap,'start','vendor-auth-populated-authority-original-capture',name],44)
        # Existing genuine vendor Auth migrate recipe, same binary/config pins.
        vcp=Path('/home/eric/Documents/Codex/2026-10-09/task-9/vendor-auth-restore-fixture-product-20261017-v1/UNIT_MIGRATE_CONFIG.json');vc=js(read_file(vcp)[1]);require(read_file(vcp)[1]['sha256']=='20c866333a45ba849bc682cdaa837efe4d3e057499263dc6ba5e57c2dab4de28','Auth config changed');require(hashlib.sha256(Path(vc['executable']).read_bytes()).hexdigest()==vc['executable_sha256']=='c66b5efc816ccf3e13c24022bdefd5c6a9bea1fd1a1aeb9c586e1279c75a6306','Auth binary changed')
        from urllib.parse import quote
        url='postgresql://supabase_auth_admin:'+bootstrap+'@localhost/postgres?host='+quote(str(socket),safe='')+'&sslmode=disable'
        settings={**vc['fixed_environment'],'GOTRUE_DB_DATABASE_URL':url};privatecfg=D/'AUTH_VENDOR_PRIVATE.env';write_new(privatecfg,('\n'.join(k+'='+json.dumps(v)for k,v in sorted(settings.items()))+'\n').encode())
        auth_had_gopath='GOPATH'in ENV;auth_prior_gopath=ENV.get('GOPATH')
        try:
            require(ENV.get('HOME')==str(D) and not auth_had_gopath,'exact Auth discovery environment differs')
            ENV['GOPATH']=str(D/'go') # Same ordinary owned-HOME default; skip optional go env discovery.
            invoke('source-vendor-auth-migrate',[vc['executable'],'--config',str(privatecfg),'migrate'],60)
        finally:
            if auth_had_gopath:ENV['GOPATH']=auth_prior_gopath
            else:ENV.pop('GOPATH',None)
            privatecfg.unlink()
        invoke('source-original-capture',[cfg['node_tool']['path'],'--max-old-space-size=384',str(qualifier),str(socket),str(oldsource),str(sourceout),bootstrap,'finish','vendor-auth-populated-authority-original-capture',name],600)
        capture_ref=read_file(sourceout/'NEW_AUTH_COMPLETE_ORIGINAL_CAPTURE.json')[1];capture=js(capture_ref);require(capture['sealed_archive']['private_tables']==2 and capture['sealed_archive']['provider_storage_observed']is True,'new signed nonempty private original absent')
        ENV['G31_PRIVATE_PROVIDER_SOURCE_CAPTURE_REF']=json.dumps(capture_ref,separators=(',',':'))
        ENV['G31_PRIVATE_PROVIDER_ORIGINAL_ARCHIVE']=capture['directory']
        inspect_exact(cid,name,fixture,socket);docker('remove-source-CID',['rm','-f',cid]);require(inspect_exact(cid,name,fixture,socket,True)is None,'sourceCID survived');cid=None;birth_attempted=False
        for item in socket.iterdir():require(item.name in('.s.PGSQL.5432','.s.PGSQL.5432.lock')and not item.is_symlink(),'unknown source socket child');item.unlink()
        require((oldsource/'node_modules').is_symlink()and Path(os.readlink(oldsource/'node_modules'))==graph,'historical graph changed');(oldsource/'node_modules').unlink()

        require(inspect_exact(None,name,fixture,socket,True)is None,'fresh original name already present')
        receipt_js(D,'PREBIRTH_ORIGINAL_CONTAINER.json',{'name':name,'CID':None,'fixture':fixture,'image':IMAGE,'socket_identities':socket_ids,'owner_process':proc(os.getpid()),'network':NETWORK_NAME,'authentic_original286_only':True})
        require(available()>=4*1024**3,'fresh4GiB floor before target PG birth')
        birth_attempted=True
        _,b,_=docker('create',['create','--pull','never','--network',NETWORK_NAME,'--cpus','1','--memory','1g','--pids-limit','256','--name',name,'--label','custodial.owner=overnight-held-correction-product-sql-effect','--label','custodial.fixture-id='+fixture,'--label','org.memphiszoo.custodial.fixture=synthetic','--label','org.memphiszoo.custodial.owner=/root','--label','org.memphiszoo.custodial.fixture-id='+str(uuid.UUID(hex=fixture)),'--tmpfs','/var/lib/postgresql/data:rw,size=1g','--mount','type=bind,source='+str(socket)+',target=/tmp/owned-socket','-e','POSTGRES_PASSWORD='+bootstrap,'-e','PGPASSWORD='+bootstrap,'-e','POSTGRES_DB='+name,IMAGE,'postgres','-D','/etc/postgresql','-c','cron.database_name='+name,'-c','shared_preload_libraries=pg_cron,pg_net,pg_stat_statements','-c','listen_addresses=*','-c','unix_socket_directories=/var/run/postgresql,/tmp/owned-socket'])
        cid=b.decode().strip();require(re.fullmatch('[a-f0-9]{64}',cid),'create did not return exact CID');receipt_js(D,'DURABLE_ORIGINAL_CID.json',{'name':name,'CID':cid,'fixture':fixture});inspect_exact(cid,name,fixture,socket)
        docker('start',['start',cid]);qout=D/'normal-qualification';qout.mkdir(mode=0o700)
        for stage,limit in [('start',44),('finish',1800)]:
            invoke('qualifier-'+stage,[cfg['node_tool']['path'],'--max-old-space-size=384',str(qualifier),str(socket),str(SOURCE),str(qout),bootstrap,stage,'immutable-private-no-storage-normal-cli',name],limit)
        result=json.loads((qout/'PRODUCT_RESULT.json').read_bytes());require(result['whole_G31'] is False and result['production'] is False,'scope drift')
        receipt_js(D,'NORMAL_CURRENT_CLI_OBSERVATIONS.json',{'product_result':read_file(qout/'PRODUCT_RESULT.json')[1],'normal_terminal':read_file(qout/'NORMAL_CLI_TERMINAL.json')[1],'scope':'Current closed core/new synthetic private286 official nonempty source and target; no production restore'})
    except BaseException as e:failure={'class':type(e).__name__,'message':str(e)}
    finally:
        CLOSING=True
        try:
            if birth_attempted:
                # DurableCID is always primary. NAME lookup only discovers our exact prebirth after missing create receipt.
                o=inspect_exact(cid,name,fixture,socket,True)
                if o is not None:
                    if cid is None:
                        cid=o['Id'];receipt_js(D,'RECOVERED_OWNED_CREATE_CID.json',{'CID':cid,'name':name,'exact_prebirth_owner_verified':True})
                    docker('remove-exact-CID',['rm','-f',cid]);require(inspect_exact(cid,name,fixture,socket,True)is None,'owned CID survived')
                # Even if CID is absent, a foreign same-NAME collision is a refusal, never an absence inference.
                require(inspect_exact(None,name,fixture,socket,True)is None,'original NAME remains')
            closed['CID_and_name_absent']=True
            if network_born:
                _,raw,_=docker('owned-network-inspect',['network','inspect',NETWORK_NAME]);n=json.loads(raw)[0];require(n['Id']==network_id and n['Internal']is True and n['Labels'].get('custodial.storage-source')==NETWORK_NAME and not n['Containers'],'owned network has unknown members')
                docker('owned-network-remove',['network','rm',NETWORK_NAME]);_,left,_=docker('owned-network-absence',['network','ls','--no-trunc','-q','--filter','id='+network_id]);require(not left.strip(),'owned network survives')
            closed['owned_internal_network_absent_or_never_born']=True
            for p,identity in socket_ids:
                st=Path(p).lstat();require((st.st_dev,st.st_ino)==tuple(identity[:2])and st.st_uid==identity[3]==os.getuid()and stat.S_ISDIR(st.st_mode)and not Path(p).is_symlink(),'socket inode/owner identity drift')
            if parent is not None:
                require(any(p==str(parent)for p,_ in socket_ids),'unbound parent birth refuses cleanup')
                if socket is not None and os.path.lexists(socket):
                    require(any(p==str(socket)for p,_ in socket_ids),'unbound socket birth refuses cleanup')
                    for p in socket.iterdir():require(p.name in('.s.PGSQL.5432','.s.PGSQL.5432.lock')and not p.is_symlink(),'unknown socket child');p.unlink()
                    socket.rmdir()
                require(not list(parent.iterdir()),'unknown private-parent child refuses cleanup')
                parent.rmdir()
            closed['socket_absent_or_never_born']=parent is None or not parent.exists()
            snapshot_record=D/'normal-qualification/OWNED_ARCHIVE_SNAPSHOT.json'
            if snapshot_record.exists():
                x=json.loads(snapshot_record.read_bytes());p=Path(x['directory']);require(p.parent==D and re.fullmatch('memphis-zoo-verified-archive-[A-Za-z0-9]+',p.name),'archive must be owned private TMPDIR child')
                if p.exists():st=p.lstat();require(stat.S_ISDIR(st.st_mode)and not p.is_symlink()and st.st_uid==x['uid']==os.getuid()and stat.S_IMODE(st.st_mode)==x['mode']==0o700 and(st.st_dev,st.st_ino)==(x['dev'],x['ino']),'archive snapshot identity mismatch');shutil.rmtree(p)
                closed['owned_archive_snapshot_absent']=not p.exists()
        except BaseException as e:closed['cleanup_error']={'class':type(e).__name__,'message':str(e)}
        finally:
            oldsource=Path(cfg['original_source_root'])
            if os.path.lexists(oldsource/'node_modules'):
                require((oldsource/'node_modules').is_symlink()and Path(os.readlink(oldsource/'node_modules'))==graph,'historical graph changed');(oldsource/'node_modules').unlink()
            for row in js(cfg['original_source_fulltuples'])['rows']:exact(row['full_raw_ref'])
            if os.path.lexists(SOURCE/'node_modules'):
                require((SOURCE/'node_modules').is_symlink()and Path(os.readlink(SOURCE/'node_modules'))==graph,'graph link identity mismatch');(SOURCE/'node_modules').unlink()
            closed['graph_link_removed_or_never_born']=True
            for r in rows:
                b,_,_=read_file(SOURCE/r['logical_path'],limit=max(MAX_FILE,r['bytes']));require(hashlib.sha256(b).hexdigest()==r['sha256']and len(b)==r['bytes']and stat.S_IMODE((SOURCE/r['logical_path']).lstat().st_mode)==(0o755 if r['mode']=='100755'else 0o644),'source bytes/mode changed')
            require(hashlib.sha256((SOURCE/'release/integrated-backend-authority-evidence.json').read_bytes()).hexdigest()==cfg['historical_artifact_fixture_NOT_current_authority']['sha256'],'historical physical fixture changed')
            closed['all1111_current_raw_source_and_historical_physical_artifact_preserved']=True
            receipt_js(D,'RESULT.json',{'state':'ACTUAL_PRIVATE286_OFFICIAL_NONEMPTY_STORAGE_SCOPED_RESULT','passed':failure is None and 'cleanup_error'not in closed,'error':failure,'cleanup':closed,'fixed_inputs':CFG,'whole_G31':False,'production_current294_restore':False,'original286_currentCLI_scope_only':True})
    require(failure is None and 'cleanup_error'not in closed,'original qualification or custody failed; no retry')
if __name__=='__main__':main()
